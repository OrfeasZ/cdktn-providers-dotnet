# `data_scaleway_opensearch_deployment`

Refer to the Terraform Registry for docs: [`data_scaleway_opensearch_deployment`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/opensearch_deployment).
