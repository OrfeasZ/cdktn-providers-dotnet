# `scaleway_iot_device`

Refer to the Terraform Registry for docs: [`scaleway_iot_device`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/iot_device).
