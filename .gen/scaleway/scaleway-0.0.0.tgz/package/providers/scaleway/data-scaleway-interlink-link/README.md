# `data_scaleway_interlink_link`

Refer to the Terraform Registry for docs: [`data_scaleway_interlink_link`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/interlink_link).
