# `scaleway_cockpit`

Refer to the Terraform Registry for docs: [`scaleway_cockpit`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/cockpit).
