# `scaleway_container`

Refer to the Terraform Registry for docs: [`scaleway_container`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/container).
