# `scaleway_apple_silicon_runner`

Refer to the Terraform Registry for docs: [`scaleway_apple_silicon_runner`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/apple_silicon_runner).
