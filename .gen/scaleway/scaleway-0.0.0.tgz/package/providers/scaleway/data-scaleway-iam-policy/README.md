# `data_scaleway_iam_policy`

Refer to the Terraform Registry for docs: [`data_scaleway_iam_policy`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/iam_policy).
