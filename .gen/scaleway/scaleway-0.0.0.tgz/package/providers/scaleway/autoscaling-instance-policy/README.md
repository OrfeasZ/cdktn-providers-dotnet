# `scaleway_autoscaling_instance_policy`

Refer to the Terraform Registry for docs: [`scaleway_autoscaling_instance_policy`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/autoscaling_instance_policy).
