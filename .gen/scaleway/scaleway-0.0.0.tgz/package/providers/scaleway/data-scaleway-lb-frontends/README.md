# `data_scaleway_lb_frontends`

Refer to the Terraform Registry for docs: [`data_scaleway_lb_frontends`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/lb_frontends).
