# `data_scaleway_lb_acls`

Refer to the Terraform Registry for docs: [`data_scaleway_lb_acls`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/lb_acls).
