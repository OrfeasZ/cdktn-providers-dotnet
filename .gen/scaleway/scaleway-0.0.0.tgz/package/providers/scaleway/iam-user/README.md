# `scaleway_iam_user`

Refer to the Terraform Registry for docs: [`scaleway_iam_user`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/iam_user).
