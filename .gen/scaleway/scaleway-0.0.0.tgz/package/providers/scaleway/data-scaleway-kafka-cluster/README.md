# `data_scaleway_kafka_cluster`

Refer to the Terraform Registry for docs: [`data_scaleway_kafka_cluster`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/kafka_cluster).
