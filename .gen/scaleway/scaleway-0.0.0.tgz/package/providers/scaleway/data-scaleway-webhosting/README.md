# `data_scaleway_webhosting`

Refer to the Terraform Registry for docs: [`data_scaleway_webhosting`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/webhosting).
