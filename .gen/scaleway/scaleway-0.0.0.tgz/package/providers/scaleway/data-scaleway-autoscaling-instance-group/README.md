# `data_scaleway_autoscaling_instance_group`

Refer to the Terraform Registry for docs: [`data_scaleway_autoscaling_instance_group`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/autoscaling_instance_group).
