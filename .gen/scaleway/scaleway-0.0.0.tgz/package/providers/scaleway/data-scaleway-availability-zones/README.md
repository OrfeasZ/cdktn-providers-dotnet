# `data_scaleway_availability_zones`

Refer to the Terraform Registry for docs: [`data_scaleway_availability_zones`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/data-sources/availability_zones).
