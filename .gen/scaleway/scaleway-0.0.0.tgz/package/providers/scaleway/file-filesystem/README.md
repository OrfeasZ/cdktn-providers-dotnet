# `scaleway_file_filesystem`

Refer to the Terraform Registry for docs: [`scaleway_file_filesystem`](https://registry.terraform.io/providers/scaleway/scaleway/2.73.0/docs/resources/file_filesystem).
