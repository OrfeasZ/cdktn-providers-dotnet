# `data_scaleway_marketplace_image`

Refer to the Terraform Registry for docs: [`data_scaleway_marketplace_image`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/marketplace_image).
