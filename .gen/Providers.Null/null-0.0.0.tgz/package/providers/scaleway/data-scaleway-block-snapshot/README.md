# `data_scaleway_block_snapshot`

Refer to the Terraform Registry for docs: [`data_scaleway_block_snapshot`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/block_snapshot).
