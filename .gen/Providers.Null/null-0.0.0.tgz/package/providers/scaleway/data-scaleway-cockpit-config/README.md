# `data_scaleway_cockpit_config`

Refer to the Terraform Registry for docs: [`data_scaleway_cockpit_config`](https://registry.terraform.io/providers/scaleway/scaleway/2.76.0/docs/data-sources/cockpit_config).
