# `scaleway_function_cron`

Refer to the Terraform Registry for docs: [`scaleway_function_cron`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/resources/function_cron).
