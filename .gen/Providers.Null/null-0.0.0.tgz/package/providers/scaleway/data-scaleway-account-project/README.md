# `data_scaleway_account_project`

Refer to the Terraform Registry for docs: [`data_scaleway_account_project`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/account_project).
