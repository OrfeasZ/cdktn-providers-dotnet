# `data_scaleway_account_ssh_key`

Refer to the Terraform Registry for docs: [`data_scaleway_account_ssh_key`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/account_ssh_key).
