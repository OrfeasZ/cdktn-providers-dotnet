# `data_scaleway_autoscaling_instance_policy`

Refer to the Terraform Registry for docs: [`data_scaleway_autoscaling_instance_policy`](https://registry.terraform.io/providers/scaleway/scaleway/2.76.0/docs/data-sources/autoscaling_instance_policy).
