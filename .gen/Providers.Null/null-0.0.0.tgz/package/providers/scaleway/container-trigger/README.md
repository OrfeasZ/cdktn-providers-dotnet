# `scaleway_container_trigger`

Refer to the Terraform Registry for docs: [`scaleway_container_trigger`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/resources/container_trigger).
