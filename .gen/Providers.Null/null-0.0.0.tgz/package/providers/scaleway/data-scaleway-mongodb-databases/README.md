# `data_scaleway_mongodb_databases`

Refer to the Terraform Registry for docs: [`data_scaleway_mongodb_databases`](https://registry.terraform.io/providers/scaleway/scaleway/2.76.0/docs/data-sources/mongodb_databases).
