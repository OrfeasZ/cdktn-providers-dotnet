# `scaleway_edge_services_pipeline`

Refer to the Terraform Registry for docs: [`scaleway_edge_services_pipeline`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/resources/edge_services_pipeline).
