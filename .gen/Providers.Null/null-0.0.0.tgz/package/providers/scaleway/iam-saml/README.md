# `scaleway_iam_saml`

Refer to the Terraform Registry for docs: [`scaleway_iam_saml`](https://registry.terraform.io/providers/scaleway/scaleway/2.76.0/docs/resources/iam_saml).
