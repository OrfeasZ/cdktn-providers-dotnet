# `data_scaleway_instance_ip`

Refer to the Terraform Registry for docs: [`data_scaleway_instance_ip`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/instance_ip).
