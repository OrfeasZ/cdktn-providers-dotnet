# `data_scaleway_cockpit_preconfigured_alert`

Refer to the Terraform Registry for docs: [`data_scaleway_cockpit_preconfigured_alert`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/cockpit_preconfigured_alert).
