# `data_scaleway_s2s_vpn_connection`

Refer to the Terraform Registry for docs: [`data_scaleway_s2s_vpn_connection`](https://registry.terraform.io/providers/scaleway/scaleway/2.76.0/docs/data-sources/s2s_vpn_connection).
