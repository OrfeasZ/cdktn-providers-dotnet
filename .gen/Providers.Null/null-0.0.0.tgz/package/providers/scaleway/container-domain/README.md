# `scaleway_container_domain`

Refer to the Terraform Registry for docs: [`scaleway_container_domain`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/resources/container_domain).
