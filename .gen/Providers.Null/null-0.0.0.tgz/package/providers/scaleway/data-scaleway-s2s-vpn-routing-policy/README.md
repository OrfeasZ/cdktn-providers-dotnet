# `data_scaleway_s2s_vpn_routing_policy`

Refer to the Terraform Registry for docs: [`data_scaleway_s2s_vpn_routing_policy`](https://registry.terraform.io/providers/scaleway/scaleway/2.75.0/docs/data-sources/s2s_vpn_routing_policy).
