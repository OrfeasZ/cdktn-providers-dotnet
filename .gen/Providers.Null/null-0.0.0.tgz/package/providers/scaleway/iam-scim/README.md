# `scaleway_iam_scim`

Refer to the Terraform Registry for docs: [`scaleway_iam_scim`](https://registry.terraform.io/providers/scaleway/scaleway/2.76.0/docs/resources/iam_scim).
