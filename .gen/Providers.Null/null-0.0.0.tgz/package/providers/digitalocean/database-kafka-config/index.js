"use strict";
// https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config
// generated from terraform resource schema
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseKafkaConfig = void 0;
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config digitalocean_database_kafka_config}
*/
class DatabaseKafkaConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseKafkaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseKafkaConfig to import
    * @param importFromId The id of the existing DatabaseKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseKafkaConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_kafka_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config digitalocean_database_kafka_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseKafkaConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_kafka_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._autoCreateTopicsEnable = config.autoCreateTopicsEnable;
        this._clusterId = config.clusterId;
        this._groupInitialRebalanceDelayMs = config.groupInitialRebalanceDelayMs;
        this._groupMaxSessionTimeoutMs = config.groupMaxSessionTimeoutMs;
        this._groupMinSessionTimeoutMs = config.groupMinSessionTimeoutMs;
        this._id = config.id;
        this._logCleanerDeleteRetentionMs = config.logCleanerDeleteRetentionMs;
        this._logCleanerMinCompactionLagMs = config.logCleanerMinCompactionLagMs;
        this._logFlushIntervalMs = config.logFlushIntervalMs;
        this._logIndexIntervalBytes = config.logIndexIntervalBytes;
        this._logMessageDownconversionEnable = config.logMessageDownconversionEnable;
        this._logMessageTimestampDifferenceMaxMs = config.logMessageTimestampDifferenceMaxMs;
        this._logPreallocate = config.logPreallocate;
        this._logRetentionBytes = config.logRetentionBytes;
        this._logRetentionHours = config.logRetentionHours;
        this._logRetentionMs = config.logRetentionMs;
        this._logRollJitterMs = config.logRollJitterMs;
        this._logSegmentDeleteDelayMs = config.logSegmentDeleteDelayMs;
        this._messageMaxBytes = config.messageMaxBytes;
    }
    get autoCreateTopicsEnable() {
        return this.getBooleanAttribute('auto_create_topics_enable');
    }
    set autoCreateTopicsEnable(value) {
        this._autoCreateTopicsEnable = value;
    }
    resetAutoCreateTopicsEnable() {
        this._autoCreateTopicsEnable = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autoCreateTopicsEnableInput() {
        return this._autoCreateTopicsEnable;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get groupInitialRebalanceDelayMs() {
        return this.getNumberAttribute('group_initial_rebalance_delay_ms');
    }
    set groupInitialRebalanceDelayMs(value) {
        this._groupInitialRebalanceDelayMs = value;
    }
    resetGroupInitialRebalanceDelayMs() {
        this._groupInitialRebalanceDelayMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupInitialRebalanceDelayMsInput() {
        return this._groupInitialRebalanceDelayMs;
    }
    get groupMaxSessionTimeoutMs() {
        return this.getNumberAttribute('group_max_session_timeout_ms');
    }
    set groupMaxSessionTimeoutMs(value) {
        this._groupMaxSessionTimeoutMs = value;
    }
    resetGroupMaxSessionTimeoutMs() {
        this._groupMaxSessionTimeoutMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupMaxSessionTimeoutMsInput() {
        return this._groupMaxSessionTimeoutMs;
    }
    get groupMinSessionTimeoutMs() {
        return this.getNumberAttribute('group_min_session_timeout_ms');
    }
    set groupMinSessionTimeoutMs(value) {
        this._groupMinSessionTimeoutMs = value;
    }
    resetGroupMinSessionTimeoutMs() {
        this._groupMinSessionTimeoutMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupMinSessionTimeoutMsInput() {
        return this._groupMinSessionTimeoutMs;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get logCleanerDeleteRetentionMs() {
        return this.getNumberAttribute('log_cleaner_delete_retention_ms');
    }
    set logCleanerDeleteRetentionMs(value) {
        this._logCleanerDeleteRetentionMs = value;
    }
    resetLogCleanerDeleteRetentionMs() {
        this._logCleanerDeleteRetentionMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logCleanerDeleteRetentionMsInput() {
        return this._logCleanerDeleteRetentionMs;
    }
    get logCleanerMinCompactionLagMs() {
        return this.getStringAttribute('log_cleaner_min_compaction_lag_ms');
    }
    set logCleanerMinCompactionLagMs(value) {
        this._logCleanerMinCompactionLagMs = value;
    }
    resetLogCleanerMinCompactionLagMs() {
        this._logCleanerMinCompactionLagMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logCleanerMinCompactionLagMsInput() {
        return this._logCleanerMinCompactionLagMs;
    }
    get logFlushIntervalMs() {
        return this.getStringAttribute('log_flush_interval_ms');
    }
    set logFlushIntervalMs(value) {
        this._logFlushIntervalMs = value;
    }
    resetLogFlushIntervalMs() {
        this._logFlushIntervalMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logFlushIntervalMsInput() {
        return this._logFlushIntervalMs;
    }
    get logIndexIntervalBytes() {
        return this.getNumberAttribute('log_index_interval_bytes');
    }
    set logIndexIntervalBytes(value) {
        this._logIndexIntervalBytes = value;
    }
    resetLogIndexIntervalBytes() {
        this._logIndexIntervalBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logIndexIntervalBytesInput() {
        return this._logIndexIntervalBytes;
    }
    get logMessageDownconversionEnable() {
        return this.getBooleanAttribute('log_message_downconversion_enable');
    }
    set logMessageDownconversionEnable(value) {
        this._logMessageDownconversionEnable = value;
    }
    resetLogMessageDownconversionEnable() {
        this._logMessageDownconversionEnable = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logMessageDownconversionEnableInput() {
        return this._logMessageDownconversionEnable;
    }
    get logMessageTimestampDifferenceMaxMs() {
        return this.getStringAttribute('log_message_timestamp_difference_max_ms');
    }
    set logMessageTimestampDifferenceMaxMs(value) {
        this._logMessageTimestampDifferenceMaxMs = value;
    }
    resetLogMessageTimestampDifferenceMaxMs() {
        this._logMessageTimestampDifferenceMaxMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logMessageTimestampDifferenceMaxMsInput() {
        return this._logMessageTimestampDifferenceMaxMs;
    }
    get logPreallocate() {
        return this.getBooleanAttribute('log_preallocate');
    }
    set logPreallocate(value) {
        this._logPreallocate = value;
    }
    resetLogPreallocate() {
        this._logPreallocate = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logPreallocateInput() {
        return this._logPreallocate;
    }
    get logRetentionBytes() {
        return this.getStringAttribute('log_retention_bytes');
    }
    set logRetentionBytes(value) {
        this._logRetentionBytes = value;
    }
    resetLogRetentionBytes() {
        this._logRetentionBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRetentionBytesInput() {
        return this._logRetentionBytes;
    }
    get logRetentionHours() {
        return this.getNumberAttribute('log_retention_hours');
    }
    set logRetentionHours(value) {
        this._logRetentionHours = value;
    }
    resetLogRetentionHours() {
        this._logRetentionHours = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRetentionHoursInput() {
        return this._logRetentionHours;
    }
    get logRetentionMs() {
        return this.getStringAttribute('log_retention_ms');
    }
    set logRetentionMs(value) {
        this._logRetentionMs = value;
    }
    resetLogRetentionMs() {
        this._logRetentionMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRetentionMsInput() {
        return this._logRetentionMs;
    }
    get logRollJitterMs() {
        return this.getStringAttribute('log_roll_jitter_ms');
    }
    set logRollJitterMs(value) {
        this._logRollJitterMs = value;
    }
    resetLogRollJitterMs() {
        this._logRollJitterMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRollJitterMsInput() {
        return this._logRollJitterMs;
    }
    get logSegmentDeleteDelayMs() {
        return this.getNumberAttribute('log_segment_delete_delay_ms');
    }
    set logSegmentDeleteDelayMs(value) {
        this._logSegmentDeleteDelayMs = value;
    }
    resetLogSegmentDeleteDelayMs() {
        this._logSegmentDeleteDelayMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logSegmentDeleteDelayMsInput() {
        return this._logSegmentDeleteDelayMs;
    }
    get messageMaxBytes() {
        return this.getNumberAttribute('message_max_bytes');
    }
    set messageMaxBytes(value) {
        this._messageMaxBytes = value;
    }
    resetMessageMaxBytes() {
        this._messageMaxBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get messageMaxBytesInput() {
        return this._messageMaxBytes;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            auto_create_topics_enable: cdktn.booleanToTerraform(this._autoCreateTopicsEnable),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            group_initial_rebalance_delay_ms: cdktn.numberToTerraform(this._groupInitialRebalanceDelayMs),
            group_max_session_timeout_ms: cdktn.numberToTerraform(this._groupMaxSessionTimeoutMs),
            group_min_session_timeout_ms: cdktn.numberToTerraform(this._groupMinSessionTimeoutMs),
            id: cdktn.stringToTerraform(this._id),
            log_cleaner_delete_retention_ms: cdktn.numberToTerraform(this._logCleanerDeleteRetentionMs),
            log_cleaner_min_compaction_lag_ms: cdktn.stringToTerraform(this._logCleanerMinCompactionLagMs),
            log_flush_interval_ms: cdktn.stringToTerraform(this._logFlushIntervalMs),
            log_index_interval_bytes: cdktn.numberToTerraform(this._logIndexIntervalBytes),
            log_message_downconversion_enable: cdktn.booleanToTerraform(this._logMessageDownconversionEnable),
            log_message_timestamp_difference_max_ms: cdktn.stringToTerraform(this._logMessageTimestampDifferenceMaxMs),
            log_preallocate: cdktn.booleanToTerraform(this._logPreallocate),
            log_retention_bytes: cdktn.stringToTerraform(this._logRetentionBytes),
            log_retention_hours: cdktn.numberToTerraform(this._logRetentionHours),
            log_retention_ms: cdktn.stringToTerraform(this._logRetentionMs),
            log_roll_jitter_ms: cdktn.stringToTerraform(this._logRollJitterMs),
            log_segment_delete_delay_ms: cdktn.numberToTerraform(this._logSegmentDeleteDelayMs),
            message_max_bytes: cdktn.numberToTerraform(this._messageMaxBytes),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            auto_create_topics_enable: {
                value: cdktn.booleanToHclTerraform(this._autoCreateTopicsEnable),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            group_initial_rebalance_delay_ms: {
                value: cdktn.numberToHclTerraform(this._groupInitialRebalanceDelayMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            group_max_session_timeout_ms: {
                value: cdktn.numberToHclTerraform(this._groupMaxSessionTimeoutMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            group_min_session_timeout_ms: {
                value: cdktn.numberToHclTerraform(this._groupMinSessionTimeoutMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_cleaner_delete_retention_ms: {
                value: cdktn.numberToHclTerraform(this._logCleanerDeleteRetentionMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_cleaner_min_compaction_lag_ms: {
                value: cdktn.stringToHclTerraform(this._logCleanerMinCompactionLagMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_flush_interval_ms: {
                value: cdktn.stringToHclTerraform(this._logFlushIntervalMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_index_interval_bytes: {
                value: cdktn.numberToHclTerraform(this._logIndexIntervalBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_message_downconversion_enable: {
                value: cdktn.booleanToHclTerraform(this._logMessageDownconversionEnable),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            log_message_timestamp_difference_max_ms: {
                value: cdktn.stringToHclTerraform(this._logMessageTimestampDifferenceMaxMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_preallocate: {
                value: cdktn.booleanToHclTerraform(this._logPreallocate),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            log_retention_bytes: {
                value: cdktn.stringToHclTerraform(this._logRetentionBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_retention_hours: {
                value: cdktn.numberToHclTerraform(this._logRetentionHours),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_retention_ms: {
                value: cdktn.stringToHclTerraform(this._logRetentionMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_roll_jitter_ms: {
                value: cdktn.stringToHclTerraform(this._logRollJitterMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_segment_delete_delay_ms: {
                value: cdktn.numberToHclTerraform(this._logSegmentDeleteDelayMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            message_max_bytes: {
                value: cdktn.numberToHclTerraform(this._messageMaxBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseKafkaConfig = DatabaseKafkaConfig;
// =================
// STATIC PROPERTIES
// =================
DatabaseKafkaConfig.tfResourceType = "digitalocean_database_kafka_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsZ0hBQWdIO0FBQ2hILDJDQUEyQzs7O0FBRzNDLCtCQUErQjtBQXNGL0I7O0VBRUU7QUFDRixNQUFhLG1CQUFvQixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPOUQsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLG9DQUFvQyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM1SixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBaUM7UUFDaEYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSxvQ0FBb0M7WUFDM0QsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsdUJBQXVCLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDO1FBQzdELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxNQUFNLENBQUMsd0JBQXdCLENBQUM7UUFDakUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQztRQUNqRSxJQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDckQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLENBQUMsK0JBQStCLEdBQUcsTUFBTSxDQUFDLDhCQUE4QixDQUFDO1FBQzdFLElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxNQUFNLENBQUMsa0NBQWtDLENBQUM7UUFDckYsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1FBQzdDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7UUFDN0MsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7UUFDL0MsSUFBSSxDQUFDLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztRQUMvRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQztJQUNqRCxDQUFDO0lBUUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFrQztRQUNsRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFDRCxJQUFXLDRCQUE0QixDQUFDLEtBQWE7UUFDbkQsSUFBSSxDQUFDLDZCQUE2QixHQUFHLEtBQUssQ0FBQztJQUM3QyxDQUFDO0lBQ00saUNBQWlDO1FBQ3RDLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxTQUFTLENBQUM7SUFDakQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlDQUFpQztRQUMxQyxPQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztJQUM1QyxDQUFDO0lBSUQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ0QsSUFBVyx3QkFBd0IsQ0FBQyxLQUFhO1FBQy9DLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxLQUFLLENBQUM7SUFDekMsQ0FBQztJQUNNLDZCQUE2QjtRQUNsQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsU0FBUyxDQUFDO0lBQzdDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw2QkFBNkI7UUFDdEMsT0FBTyxJQUFJLENBQUMseUJBQXlCLENBQUM7SUFDeEMsQ0FBQztJQUlELElBQVcsd0JBQXdCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNELElBQVcsd0JBQXdCLENBQUMsS0FBYTtRQUMvQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO0lBQ3pDLENBQUM7SUFDTSw2QkFBNkI7UUFDbEMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLFNBQVMsQ0FBQztJQUM3QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixDQUFDO0lBQ3hDLENBQUM7SUFJRCxJQUFXLEVBQUU7UUFDWCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBVyxFQUFFLENBQUMsS0FBYTtRQUN6QixJQUFJLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQztJQUNuQixDQUFDO0lBQ00sT0FBTztRQUNaLElBQUksQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFDO0lBQ3ZCLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxPQUFPO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNsQixDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUNELElBQVcsNEJBQTRCLENBQUMsS0FBYTtRQUNuRCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFDTSxpQ0FBaUM7UUFDdEMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLFNBQVMsQ0FBQztJQUNqRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDO0lBQzVDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUlELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUNELElBQVcsOEJBQThCLENBQUMsS0FBa0M7UUFDMUUsSUFBSSxDQUFDLCtCQUErQixHQUFHLEtBQUssQ0FBQztJQUMvQyxDQUFDO0lBQ00sbUNBQW1DO1FBQ3hDLElBQUksQ0FBQywrQkFBK0IsR0FBRyxTQUFTLENBQUM7SUFDbkQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1DQUFtQztRQUM1QyxPQUFPLElBQUksQ0FBQywrQkFBK0IsQ0FBQztJQUM5QyxDQUFDO0lBSUQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBQ0QsSUFBVyxrQ0FBa0MsQ0FBQyxLQUFhO1FBQ3pELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUM7SUFDbkQsQ0FBQztJQUNNLHVDQUF1QztRQUM1QyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsU0FBUyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1Q0FBdUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsbUNBQW1DLENBQUM7SUFDbEQsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFrQztRQUMxRCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBQ00sbUJBQW1CO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO0lBQ25DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsZUFBZTtRQUN4QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxJQUFXLGVBQWUsQ0FBQyxLQUFhO1FBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7SUFDaEMsQ0FBQztJQUNNLG9CQUFvQjtRQUN6QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsU0FBUyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxvQkFBb0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7SUFDL0IsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDZCQUE2QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBYTtRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0QsSUFBVyxlQUFlLENBQUMsS0FBYTtRQUN0QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQ2hDLENBQUM7SUFDTSxvQkFBb0I7UUFDekIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFNBQVMsQ0FBQztJQUNwQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7SUFFRCxZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFFRixvQkFBb0I7UUFDNUIsT0FBTztZQUNMLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDakYsVUFBVSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3BELGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7WUFDN0YsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUNyRiw0QkFBNEIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1lBQ3JGLEVBQUUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNyQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO1lBQzNGLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7WUFDOUYscUJBQXFCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN4RSx3QkFBd0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzlFLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7WUFDakcsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQ0FBbUMsQ0FBQztZQUMxRyxlQUFlLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNyRSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3JFLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1lBQy9ELGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDbEUsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNuRixpQkFBaUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1NBQ2xFLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCO1FBQy9CLE1BQU0sS0FBSyxHQUFHO1lBQ1oseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUNoRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGdDQUFnQyxFQUFFO2dCQUNoQyxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztnQkFDckUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDakUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDakUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELEVBQUUsRUFBRTtnQkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7Z0JBQ3BFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQ0FBaUMsRUFBRTtnQkFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7Z0JBQ3JFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx3QkFBd0IsRUFBRTtnQkFDeEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQ0FBaUMsRUFBRTtnQkFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7Z0JBQ3hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUNBQW1DLENBQUM7Z0JBQzNFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxlQUFlLEVBQUU7Z0JBQ2YsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUN4RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZ0JBQWdCLEVBQUU7Z0JBQ2hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDdkQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDeEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztnQkFDaEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGlCQUFpQixFQUFFO2dCQUNqQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDeEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtTQUNGLENBQUM7UUFFRiw4QkFBOEI7UUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUUsQ0FBQyxDQUFBO0lBQzVILENBQUM7O0FBMWdCSCxrREEyZ0JDO0FBemdCQyxvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNHLGtDQUFjLEdBQUcsb0NBQW9DLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnXG4vLyBnZW5lcmF0ZWQgZnJvbSB0ZXJyYWZvcm0gcmVzb3VyY2Ugc2NoZW1hXG5cbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0ICogYXMgY2RrdG4gZnJvbSAnY2RrdG4nO1xuXG4vLyBDb25maWd1cmF0aW9uXG5cbmV4cG9ydCBpbnRlcmZhY2UgRGF0YWJhc2VLYWZrYUNvbmZpZ0NvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybU1ldGFBcmd1bWVudHMge1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjYXV0b19jcmVhdGVfdG9waWNzX2VuYWJsZSBEYXRhYmFzZUthZmthQ29uZmlnI2F1dG9fY3JlYXRlX3RvcGljc19lbmFibGV9XG4gICovXG4gIHJlYWRvbmx5IGF1dG9DcmVhdGVUb3BpY3NFbmFibGU/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNjbHVzdGVyX2lkIERhdGFiYXNlS2Fma2FDb25maWcjY2x1c3Rlcl9pZH1cbiAgKi9cbiAgcmVhZG9ubHkgY2x1c3RlcklkOiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNncm91cF9pbml0aWFsX3JlYmFsYW5jZV9kZWxheV9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2dyb3VwX2luaXRpYWxfcmViYWxhbmNlX2RlbGF5X21zfVxuICAqL1xuICByZWFkb25seSBncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjZ3JvdXBfbWF4X3Nlc3Npb25fdGltZW91dF9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2dyb3VwX21heF9zZXNzaW9uX3RpbWVvdXRfbXN9XG4gICovXG4gIHJlYWRvbmx5IGdyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2dyb3VwX21pbl9zZXNzaW9uX3RpbWVvdXRfbXMgRGF0YWJhc2VLYWZrYUNvbmZpZyNncm91cF9taW5fc2Vzc2lvbl90aW1lb3V0X21zfVxuICAqL1xuICByZWFkb25seSBncm91cE1pblNlc3Npb25UaW1lb3V0TXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNpZCBEYXRhYmFzZUthZmthQ29uZmlnI2lkfVxuICAqXG4gICogUGxlYXNlIGJlIGF3YXJlIHRoYXQgdGhlIGlkIGZpZWxkIGlzIGF1dG9tYXRpY2FsbHkgYWRkZWQgdG8gYWxsIHJlc291cmNlcyBpbiBUZXJyYWZvcm0gcHJvdmlkZXJzIHVzaW5nIGEgVGVycmFmb3JtIHByb3ZpZGVyIFNESyB2ZXJzaW9uIGJlbG93IDIuXG4gICogSWYgeW91IGV4cGVyaWVuY2UgcHJvYmxlbXMgc2V0dGluZyB0aGlzIHZhbHVlIGl0IG1pZ2h0IG5vdCBiZSBzZXR0YWJsZS4gUGxlYXNlIHRha2UgYSBsb29rIGF0IHRoZSBwcm92aWRlciBkb2N1bWVudGF0aW9uIHRvIGVuc3VyZSBpdCBzaG91bGQgYmUgc2V0dGFibGUuXG4gICovXG4gIHJlYWRvbmx5IGlkPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX2NsZWFuZXJfZGVsZXRlX3JldGVudGlvbl9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19jbGVhbmVyX2RlbGV0ZV9yZXRlbnRpb25fbXN9XG4gICovXG4gIHJlYWRvbmx5IGxvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25Ncz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19jbGVhbmVyX21pbl9jb21wYWN0aW9uX2xhZ19tcyBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19jbGVhbmVyX21pbl9jb21wYWN0aW9uX2xhZ19tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nQ2xlYW5lck1pbkNvbXBhY3Rpb25MYWdNcz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19mbHVzaF9pbnRlcnZhbF9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19mbHVzaF9pbnRlcnZhbF9tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nRmx1c2hJbnRlcnZhbE1zPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX2luZGV4X2ludGVydmFsX2J5dGVzIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX2luZGV4X2ludGVydmFsX2J5dGVzfVxuICAqL1xuICByZWFkb25seSBsb2dJbmRleEludGVydmFsQnl0ZXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfbWVzc2FnZV9kb3duY29udmVyc2lvbl9lbmFibGUgRGF0YWJhc2VLYWZrYUNvbmZpZyNsb2dfbWVzc2FnZV9kb3duY29udmVyc2lvbl9lbmFibGV9XG4gICovXG4gIHJlYWRvbmx5IGxvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19tZXNzYWdlX3RpbWVzdGFtcF9kaWZmZXJlbmNlX21heF9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19tZXNzYWdlX3RpbWVzdGFtcF9kaWZmZXJlbmNlX21heF9tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19wcmVhbGxvY2F0ZSBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19wcmVhbGxvY2F0ZX1cbiAgKi9cbiAgcmVhZG9ubHkgbG9nUHJlYWxsb2NhdGU/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfcmV0ZW50aW9uX2J5dGVzIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX3JldGVudGlvbl9ieXRlc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nUmV0ZW50aW9uQnl0ZXM/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfcmV0ZW50aW9uX2hvdXJzIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX3JldGVudGlvbl9ob3Vyc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nUmV0ZW50aW9uSG91cnM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfcmV0ZW50aW9uX21zIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX3JldGVudGlvbl9tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nUmV0ZW50aW9uTXM/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfcm9sbF9qaXR0ZXJfbXMgRGF0YWJhc2VLYWZrYUNvbmZpZyNsb2dfcm9sbF9qaXR0ZXJfbXN9XG4gICovXG4gIHJlYWRvbmx5IGxvZ1JvbGxKaXR0ZXJNcz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19zZWdtZW50X2RlbGV0ZV9kZWxheV9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19zZWdtZW50X2RlbGV0ZV9kZWxheV9tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nU2VnbWVudERlbGV0ZURlbGF5TXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNtZXNzYWdlX21heF9ieXRlcyBEYXRhYmFzZUthZmthQ29uZmlnI21lc3NhZ2VfbWF4X2J5dGVzfVxuICAqL1xuICByZWFkb25seSBtZXNzYWdlTWF4Qnl0ZXM/OiBudW1iZXI7XG59XG5cbi8qKlxuKiBSZXByZXNlbnRzIGEge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX2thZmthX2NvbmZpZ31cbiovXG5leHBvcnQgY2xhc3MgRGF0YWJhc2VLYWZrYUNvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybVJlc291cmNlIHtcblxuICAvLyA9PT09PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgUFJPUEVSVElFU1xuICAvLyA9PT09PT09PT09PT09PT09PVxuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IHRmUmVzb3VyY2VUeXBlID0gXCJkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfa2Fma2FfY29uZmlnXCI7XG5cbiAgLy8gPT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIE1ldGhvZHNcbiAgLy8gPT09PT09PT09PT09PT1cbiAgLyoqXG4gICogR2VuZXJhdGVzIENES1ROIGNvZGUgZm9yIGltcG9ydGluZyBhIERhdGFiYXNlS2Fma2FDb25maWcgcmVzb3VyY2UgdXBvbiBydW5uaW5nIFwiY2RrdG4gcGxhbiA8c3RhY2stbmFtZT5cIlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGltcG9ydFRvSWQgVGhlIGNvbnN0cnVjdCBpZCB1c2VkIGluIHRoZSBnZW5lcmF0ZWQgY29uZmlnIGZvciB0aGUgRGF0YWJhc2VLYWZrYUNvbmZpZyB0byBpbXBvcnRcbiAgKiBAcGFyYW0gaW1wb3J0RnJvbUlkIFRoZSBpZCBvZiB0aGUgZXhpc3RpbmcgRGF0YWJhc2VLYWZrYUNvbmZpZyB0aGF0IHNob3VsZCBiZSBpbXBvcnRlZC4gUmVmZXIgdG8gdGhlIHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2ltcG9ydCBpbXBvcnQgc2VjdGlvbn0gaW4gdGhlIGRvY3VtZW50YXRpb24gb2YgdGhpcyByZXNvdXJjZSBmb3IgdGhlIGlkIHRvIHVzZVxuICAqIEBwYXJhbSBwcm92aWRlcj8gT3B0aW9uYWwgaW5zdGFuY2Ugb2YgdGhlIHByb3ZpZGVyIHdoZXJlIHRoZSBEYXRhYmFzZUthZmthQ29uZmlnIHRvIGltcG9ydCBpcyBmb3VuZFxuICAqL1xuICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQ29uZmlnRm9ySW1wb3J0KHNjb3BlOiBDb25zdHJ1Y3QsIGltcG9ydFRvSWQ6IHN0cmluZywgaW1wb3J0RnJvbUlkOiBzdHJpbmcsIHByb3ZpZGVyPzogY2RrdG4uVGVycmFmb3JtUHJvdmlkZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBjZGt0bi5JbXBvcnRhYmxlUmVzb3VyY2Uoc2NvcGUsIGltcG9ydFRvSWQsIHsgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9rYWZrYV9jb25maWdcIiwgaW1wb3J0SWQ6IGltcG9ydEZyb21JZCwgcHJvdmlkZXIgfSk7XG4gICAgICB9XG5cbiAgLy8gPT09PT09PT09PT1cbiAgLy8gSU5JVElBTElaRVJcbiAgLy8gPT09PT09PT09PT1cblxuICAvKipcbiAgKiBDcmVhdGUgYSBuZXcge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX2thZmthX2NvbmZpZ30gUmVzb3VyY2VcbiAgKlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGlkIFRoZSBzY29wZWQgY29uc3RydWN0IElELiBNdXN0IGJlIHVuaXF1ZSBhbW9uZ3N0IHNpYmxpbmdzIGluIHRoZSBzYW1lIHNjb3BlXG4gICogQHBhcmFtIG9wdGlvbnMgRGF0YWJhc2VLYWZrYUNvbmZpZ0NvbmZpZ1xuICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgY29uZmlnOiBEYXRhYmFzZUthZmthQ29uZmlnQ29uZmlnKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6ICdkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfa2Fma2FfY29uZmlnJyxcbiAgICAgIHRlcnJhZm9ybUdlbmVyYXRvck1ldGFkYXRhOiB7XG4gICAgICAgIHByb3ZpZGVyTmFtZTogJ2RpZ2l0YWxvY2VhbicsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbjogJzIuODcuMCcsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbkNvbnN0cmFpbnQ6ICcyLjg3LjAnXG4gICAgICB9LFxuICAgICAgcHJvdmlkZXI6IGNvbmZpZy5wcm92aWRlcixcbiAgICAgIGRlcGVuZHNPbjogY29uZmlnLmRlcGVuZHNPbixcbiAgICAgIGNvdW50OiBjb25maWcuY291bnQsXG4gICAgICBsaWZlY3ljbGU6IGNvbmZpZy5saWZlY3ljbGUsXG4gICAgICBwcm92aXNpb25lcnM6IGNvbmZpZy5wcm92aXNpb25lcnMsXG4gICAgICBjb25uZWN0aW9uOiBjb25maWcuY29ubmVjdGlvbixcbiAgICAgIGZvckVhY2g6IGNvbmZpZy5mb3JFYWNoXG4gICAgfSk7XG4gICAgdGhpcy5fYXV0b0NyZWF0ZVRvcGljc0VuYWJsZSA9IGNvbmZpZy5hdXRvQ3JlYXRlVG9waWNzRW5hYmxlO1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IGNvbmZpZy5jbHVzdGVySWQ7XG4gICAgdGhpcy5fZ3JvdXBJbml0aWFsUmViYWxhbmNlRGVsYXlNcyA9IGNvbmZpZy5ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zO1xuICAgIHRoaXMuX2dyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcyA9IGNvbmZpZy5ncm91cE1heFNlc3Npb25UaW1lb3V0TXM7XG4gICAgdGhpcy5fZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zID0gY29uZmlnLmdyb3VwTWluU2Vzc2lvblRpbWVvdXRNcztcbiAgICB0aGlzLl9pZCA9IGNvbmZpZy5pZDtcbiAgICB0aGlzLl9sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXMgPSBjb25maWcubG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zO1xuICAgIHRoaXMuX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXMgPSBjb25maWcubG9nQ2xlYW5lck1pbkNvbXBhY3Rpb25MYWdNcztcbiAgICB0aGlzLl9sb2dGbHVzaEludGVydmFsTXMgPSBjb25maWcubG9nRmx1c2hJbnRlcnZhbE1zO1xuICAgIHRoaXMuX2xvZ0luZGV4SW50ZXJ2YWxCeXRlcyA9IGNvbmZpZy5sb2dJbmRleEludGVydmFsQnl0ZXM7XG4gICAgdGhpcy5fbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlID0gY29uZmlnLmxvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZTtcbiAgICB0aGlzLl9sb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zID0gY29uZmlnLmxvZ01lc3NhZ2VUaW1lc3RhbXBEaWZmZXJlbmNlTWF4TXM7XG4gICAgdGhpcy5fbG9nUHJlYWxsb2NhdGUgPSBjb25maWcubG9nUHJlYWxsb2NhdGU7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uQnl0ZXMgPSBjb25maWcubG9nUmV0ZW50aW9uQnl0ZXM7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uSG91cnMgPSBjb25maWcubG9nUmV0ZW50aW9uSG91cnM7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uTXMgPSBjb25maWcubG9nUmV0ZW50aW9uTXM7XG4gICAgdGhpcy5fbG9nUm9sbEppdHRlck1zID0gY29uZmlnLmxvZ1JvbGxKaXR0ZXJNcztcbiAgICB0aGlzLl9sb2dTZWdtZW50RGVsZXRlRGVsYXlNcyA9IGNvbmZpZy5sb2dTZWdtZW50RGVsZXRlRGVsYXlNcztcbiAgICB0aGlzLl9tZXNzYWdlTWF4Qnl0ZXMgPSBjb25maWcubWVzc2FnZU1heEJ5dGVzO1xuICB9XG5cbiAgLy8gPT09PT09PT09PVxuICAvLyBBVFRSSUJVVEVTXG4gIC8vID09PT09PT09PT1cblxuICAvLyBhdXRvX2NyZWF0ZV90b3BpY3NfZW5hYmxlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b0NyZWF0ZVRvcGljc0VuYWJsZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgYXV0b0NyZWF0ZVRvcGljc0VuYWJsZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdhdXRvX2NyZWF0ZV90b3BpY3NfZW5hYmxlJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvQ3JlYXRlVG9waWNzRW5hYmxlKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9hdXRvQ3JlYXRlVG9waWNzRW5hYmxlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b0NyZWF0ZVRvcGljc0VuYWJsZSgpIHtcbiAgICB0aGlzLl9hdXRvQ3JlYXRlVG9waWNzRW5hYmxlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvQ3JlYXRlVG9waWNzRW5hYmxlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG9DcmVhdGVUb3BpY3NFbmFibGU7XG4gIH1cblxuICAvLyBjbHVzdGVyX2lkIC0gY29tcHV0ZWQ6IGZhbHNlLCBvcHRpb25hbDogZmFsc2UsIHJlcXVpcmVkOiB0cnVlXG4gIHByaXZhdGUgX2NsdXN0ZXJJZD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgY2x1c3RlcklkKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnY2x1c3Rlcl9pZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgY2x1c3RlcklkKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9jbHVzdGVySWQgPSB2YWx1ZTtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgY2x1c3RlcklkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NsdXN0ZXJJZDtcbiAgfVxuXG4gIC8vIGdyb3VwX2luaXRpYWxfcmViYWxhbmNlX2RlbGF5X21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZ3JvdXBJbml0aWFsUmViYWxhbmNlRGVsYXlNcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgZ3JvdXBJbml0aWFsUmViYWxhbmNlRGVsYXlNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2dyb3VwX2luaXRpYWxfcmViYWxhbmNlX2RlbGF5X21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0R3JvdXBJbml0aWFsUmViYWxhbmNlRGVsYXlNcygpIHtcbiAgICB0aGlzLl9ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2dyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXM7XG4gIH1cblxuICAvLyBncm91cF9tYXhfc2Vzc2lvbl90aW1lb3V0X21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZ3JvdXBNYXhTZXNzaW9uVGltZW91dE1zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBncm91cE1heFNlc3Npb25UaW1lb3V0TXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdncm91cF9tYXhfc2Vzc2lvbl90aW1lb3V0X21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBncm91cE1heFNlc3Npb25UaW1lb3V0TXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2dyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEdyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcygpIHtcbiAgICB0aGlzLl9ncm91cE1heFNlc3Npb25UaW1lb3V0TXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGdyb3VwTWF4U2Vzc2lvblRpbWVvdXRNc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9ncm91cE1heFNlc3Npb25UaW1lb3V0TXM7XG4gIH1cblxuICAvLyBncm91cF9taW5fc2Vzc2lvbl90aW1lb3V0X21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBncm91cE1pblNlc3Npb25UaW1lb3V0TXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdncm91cF9taW5fc2Vzc2lvbl90aW1lb3V0X21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBncm91cE1pblNlc3Npb25UaW1lb3V0TXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2dyb3VwTWluU2Vzc2lvblRpbWVvdXRNcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEdyb3VwTWluU2Vzc2lvblRpbWVvdXRNcygpIHtcbiAgICB0aGlzLl9ncm91cE1pblNlc3Npb25UaW1lb3V0TXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGdyb3VwTWluU2Vzc2lvblRpbWVvdXRNc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9ncm91cE1pblNlc3Npb25UaW1lb3V0TXM7XG4gIH1cblxuICAvLyBpZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBpZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5faWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJZCgpIHtcbiAgICB0aGlzLl9pZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWQ7XG4gIH1cblxuICAvLyBsb2dfY2xlYW5lcl9kZWxldGVfcmV0ZW50aW9uX21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsb2dfY2xlYW5lcl9kZWxldGVfcmV0ZW50aW9uX21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2xvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcygpIHtcbiAgICB0aGlzLl9sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25Nc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXM7XG4gIH1cblxuICAvLyBsb2dfY2xlYW5lcl9taW5fY29tcGFjdGlvbl9sYWdfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBsb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX2NsZWFuZXJfbWluX2NvbXBhY3Rpb25fbGFnX21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9sb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nQ2xlYW5lck1pbkNvbXBhY3Rpb25MYWdNcygpIHtcbiAgICB0aGlzLl9sb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXM7XG4gIH1cblxuICAvLyBsb2dfZmx1c2hfaW50ZXJ2YWxfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dGbHVzaEludGVydmFsTXM/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGxvZ0ZsdXNoSW50ZXJ2YWxNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2xvZ19mbHVzaF9pbnRlcnZhbF9tcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nRmx1c2hJbnRlcnZhbE1zKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9sb2dGbHVzaEludGVydmFsTXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dGbHVzaEludGVydmFsTXMoKSB7XG4gICAgdGhpcy5fbG9nRmx1c2hJbnRlcnZhbE1zID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dGbHVzaEludGVydmFsTXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nRmx1c2hJbnRlcnZhbE1zO1xuICB9XG5cbiAgLy8gbG9nX2luZGV4X2ludGVydmFsX2J5dGVzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nSW5kZXhJbnRlcnZhbEJ5dGVzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsb2dJbmRleEludGVydmFsQnl0ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsb2dfaW5kZXhfaW50ZXJ2YWxfYnl0ZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ0luZGV4SW50ZXJ2YWxCeXRlcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9nSW5kZXhJbnRlcnZhbEJ5dGVzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nSW5kZXhJbnRlcnZhbEJ5dGVzKCkge1xuICAgIHRoaXMuX2xvZ0luZGV4SW50ZXJ2YWxCeXRlcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nSW5kZXhJbnRlcnZhbEJ5dGVzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ0luZGV4SW50ZXJ2YWxCeXRlcztcbiAgfVxuXG4gIC8vIGxvZ19tZXNzYWdlX2Rvd25jb252ZXJzaW9uX2VuYWJsZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2xvZ19tZXNzYWdlX2Rvd25jb252ZXJzaW9uX2VuYWJsZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9sb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGUoKSB7XG4gICAgdGhpcy5fbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlO1xuICB9XG5cbiAgLy8gbG9nX21lc3NhZ2VfdGltZXN0YW1wX2RpZmZlcmVuY2VfbWF4X21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2xvZ19tZXNzYWdlX3RpbWVzdGFtcF9kaWZmZXJlbmNlX21heF9tcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ01lc3NhZ2VUaW1lc3RhbXBEaWZmZXJlbmNlTWF4TXMoKSB7XG4gICAgdGhpcy5fbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zO1xuICB9XG5cbiAgLy8gbG9nX3ByZWFsbG9jYXRlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nUHJlYWxsb2NhdGU/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IGxvZ1ByZWFsbG9jYXRlKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2xvZ19wcmVhbGxvY2F0ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nUHJlYWxsb2NhdGUodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2xvZ1ByZWFsbG9jYXRlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nUHJlYWxsb2NhdGUoKSB7XG4gICAgdGhpcy5fbG9nUHJlYWxsb2NhdGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ1ByZWFsbG9jYXRlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ1ByZWFsbG9jYXRlO1xuICB9XG5cbiAgLy8gbG9nX3JldGVudGlvbl9ieXRlcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ1JldGVudGlvbkJ5dGVzPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBsb2dSZXRlbnRpb25CeXRlcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2xvZ19yZXRlbnRpb25fYnl0ZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ1JldGVudGlvbkJ5dGVzKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25CeXRlcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ1JldGVudGlvbkJ5dGVzKCkge1xuICAgIHRoaXMuX2xvZ1JldGVudGlvbkJ5dGVzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dSZXRlbnRpb25CeXRlc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dSZXRlbnRpb25CeXRlcztcbiAgfVxuXG4gIC8vIGxvZ19yZXRlbnRpb25faG91cnMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dSZXRlbnRpb25Ib3Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbG9nUmV0ZW50aW9uSG91cnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsb2dfcmV0ZW50aW9uX2hvdXJzJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dSZXRlbnRpb25Ib3Vycyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uSG91cnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dSZXRlbnRpb25Ib3VycygpIHtcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25Ib3VycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nUmV0ZW50aW9uSG91cnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nUmV0ZW50aW9uSG91cnM7XG4gIH1cblxuICAvLyBsb2dfcmV0ZW50aW9uX21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nUmV0ZW50aW9uTXM/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGxvZ1JldGVudGlvbk1zKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX3JldGVudGlvbl9tcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nUmV0ZW50aW9uTXModmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2xvZ1JldGVudGlvbk1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nUmV0ZW50aW9uTXMoKSB7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uTXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ1JldGVudGlvbk1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ1JldGVudGlvbk1zO1xuICB9XG5cbiAgLy8gbG9nX3JvbGxfaml0dGVyX21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nUm9sbEppdHRlck1zPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBsb2dSb2xsSml0dGVyTXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdsb2dfcm9sbF9qaXR0ZXJfbXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ1JvbGxKaXR0ZXJNcyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fbG9nUm9sbEppdHRlck1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nUm9sbEppdHRlck1zKCkge1xuICAgIHRoaXMuX2xvZ1JvbGxKaXR0ZXJNcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nUm9sbEppdHRlck1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ1JvbGxKaXR0ZXJNcztcbiAgfVxuXG4gIC8vIGxvZ19zZWdtZW50X2RlbGV0ZV9kZWxheV9tcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ1NlZ21lbnREZWxldGVEZWxheU1zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsb2dTZWdtZW50RGVsZXRlRGVsYXlNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xvZ19zZWdtZW50X2RlbGV0ZV9kZWxheV9tcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nU2VnbWVudERlbGV0ZURlbGF5TXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2xvZ1NlZ21lbnREZWxldGVEZWxheU1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nU2VnbWVudERlbGV0ZURlbGF5TXMoKSB7XG4gICAgdGhpcy5fbG9nU2VnbWVudERlbGV0ZURlbGF5TXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ1NlZ21lbnREZWxldGVEZWxheU1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ1NlZ21lbnREZWxldGVEZWxheU1zO1xuICB9XG5cbiAgLy8gbWVzc2FnZV9tYXhfYnl0ZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tZXNzYWdlTWF4Qnl0ZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1lc3NhZ2VNYXhCeXRlcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21lc3NhZ2VfbWF4X2J5dGVzJyk7XG4gIH1cbiAgcHVibGljIHNldCBtZXNzYWdlTWF4Qnl0ZXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21lc3NhZ2VNYXhCeXRlcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1lc3NhZ2VNYXhCeXRlcygpIHtcbiAgICB0aGlzLl9tZXNzYWdlTWF4Qnl0ZXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1lc3NhZ2VNYXhCeXRlc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tZXNzYWdlTWF4Qnl0ZXM7XG4gIH1cblxuICAvLyA9PT09PT09PT1cbiAgLy8gU1lOVEhFU0lTXG4gIC8vID09PT09PT09PVxuXG4gIHByb3RlY3RlZCBzeW50aGVzaXplQXR0cmlidXRlcygpOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGF1dG9fY3JlYXRlX3RvcGljc19lbmFibGU6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9hdXRvQ3JlYXRlVG9waWNzRW5hYmxlKSxcbiAgICAgIGNsdXN0ZXJfaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICBncm91cF9pbml0aWFsX3JlYmFsYW5jZV9kZWxheV9tczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fZ3JvdXBJbml0aWFsUmViYWxhbmNlRGVsYXlNcyksXG4gICAgICBncm91cF9tYXhfc2Vzc2lvbl90aW1lb3V0X21zOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9ncm91cE1heFNlc3Npb25UaW1lb3V0TXMpLFxuICAgICAgZ3JvdXBfbWluX3Nlc3Npb25fdGltZW91dF9tczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zKSxcbiAgICAgIGlkOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9pZCksXG4gICAgICBsb2dfY2xlYW5lcl9kZWxldGVfcmV0ZW50aW9uX21zOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXMpLFxuICAgICAgbG9nX2NsZWFuZXJfbWluX2NvbXBhY3Rpb25fbGFnX21zOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9sb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zKSxcbiAgICAgIGxvZ19mbHVzaF9pbnRlcnZhbF9tczogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fbG9nRmx1c2hJbnRlcnZhbE1zKSxcbiAgICAgIGxvZ19pbmRleF9pbnRlcnZhbF9ieXRlczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbG9nSW5kZXhJbnRlcnZhbEJ5dGVzKSxcbiAgICAgIGxvZ19tZXNzYWdlX2Rvd25jb252ZXJzaW9uX2VuYWJsZTogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2xvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZSksXG4gICAgICBsb2dfbWVzc2FnZV90aW1lc3RhbXBfZGlmZmVyZW5jZV9tYXhfbXM6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2xvZ01lc3NhZ2VUaW1lc3RhbXBEaWZmZXJlbmNlTWF4TXMpLFxuICAgICAgbG9nX3ByZWFsbG9jYXRlOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fbG9nUHJlYWxsb2NhdGUpLFxuICAgICAgbG9nX3JldGVudGlvbl9ieXRlczogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fbG9nUmV0ZW50aW9uQnl0ZXMpLFxuICAgICAgbG9nX3JldGVudGlvbl9ob3VyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbG9nUmV0ZW50aW9uSG91cnMpLFxuICAgICAgbG9nX3JldGVudGlvbl9tczogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fbG9nUmV0ZW50aW9uTXMpLFxuICAgICAgbG9nX3JvbGxfaml0dGVyX21zOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9sb2dSb2xsSml0dGVyTXMpLFxuICAgICAgbG9nX3NlZ21lbnRfZGVsZXRlX2RlbGF5X21zOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9sb2dTZWdtZW50RGVsZXRlRGVsYXlNcyksXG4gICAgICBtZXNzYWdlX21heF9ieXRlczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWVzc2FnZU1heEJ5dGVzKSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVIY2xBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICBjb25zdCBhdHRycyA9IHtcbiAgICAgIGF1dG9fY3JlYXRlX3RvcGljc19lbmFibGU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvQ3JlYXRlVG9waWNzRW5hYmxlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGNsdXN0ZXJfaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGdyb3VwX2luaXRpYWxfcmViYWxhbmNlX2RlbGF5X21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgZ3JvdXBfbWF4X3Nlc3Npb25fdGltZW91dF9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fZ3JvdXBNYXhTZXNzaW9uVGltZW91dE1zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgZ3JvdXBfbWluX3Nlc3Npb25fdGltZW91dF9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9nX2NsZWFuZXJfZGVsZXRlX3JldGVudGlvbl9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbG9nX2NsZWFuZXJfbWluX2NvbXBhY3Rpb25fbGFnX21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9nX2ZsdXNoX2ludGVydmFsX21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dGbHVzaEludGVydmFsTXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBsb2dfaW5kZXhfaW50ZXJ2YWxfYnl0ZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ0luZGV4SW50ZXJ2YWxCeXRlcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGxvZ19tZXNzYWdlX2Rvd25jb252ZXJzaW9uX2VuYWJsZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBsb2dfbWVzc2FnZV90aW1lc3RhbXBfZGlmZmVyZW5jZV9tYXhfbXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ01lc3NhZ2VUaW1lc3RhbXBEaWZmZXJlbmNlTWF4TXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBsb2dfcHJlYWxsb2NhdGU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dQcmVhbGxvY2F0ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBsb2dfcmV0ZW50aW9uX2J5dGVzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dSZXRlbnRpb25CeXRlcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19yZXRlbnRpb25faG91cnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ1JldGVudGlvbkhvdXJzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbG9nX3JldGVudGlvbl9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nUmV0ZW50aW9uTXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBsb2dfcm9sbF9qaXR0ZXJfbXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ1JvbGxKaXR0ZXJNcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19zZWdtZW50X2RlbGV0ZV9kZWxheV9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nU2VnbWVudERlbGV0ZURlbGF5TXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtZXNzYWdlX21heF9ieXRlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWVzc2FnZU1heEJ5dGVzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgIH07XG5cbiAgICAvLyByZW1vdmUgdW5kZWZpbmVkIGF0dHJpYnV0ZXNcbiAgICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGF0dHJzKS5maWx0ZXIoKFtfLCB2YWx1ZV0pID0+IHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUudmFsdWUgIT09IHVuZGVmaW5lZCApKVxuICB9XG59XG4iXX0=