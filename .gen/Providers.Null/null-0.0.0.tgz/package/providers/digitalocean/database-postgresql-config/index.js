"use strict";
// https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config
// generated from terraform resource schema
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabasePostgresqlConfig = exports.DatabasePostgresqlConfigTimescaledbOutputReference = exports.DatabasePostgresqlConfigPgbouncerList = exports.DatabasePostgresqlConfigPgbouncerOutputReference = void 0;
exports.databasePostgresqlConfigPgbouncerToTerraform = databasePostgresqlConfigPgbouncerToTerraform;
exports.databasePostgresqlConfigPgbouncerToHclTerraform = databasePostgresqlConfigPgbouncerToHclTerraform;
exports.databasePostgresqlConfigTimescaledbToTerraform = databasePostgresqlConfigTimescaledbToTerraform;
exports.databasePostgresqlConfigTimescaledbToHclTerraform = databasePostgresqlConfigTimescaledbToHclTerraform;
const cdktn = require("cdktn");
function databasePostgresqlConfigPgbouncerToTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    return {
        autodb_idle_timeout: cdktn.numberToTerraform(struct.autodbIdleTimeout),
        autodb_max_db_connections: cdktn.numberToTerraform(struct.autodbMaxDbConnections),
        autodb_pool_mode: cdktn.stringToTerraform(struct.autodbPoolMode),
        autodb_pool_size: cdktn.numberToTerraform(struct.autodbPoolSize),
        ignore_startup_parameters: cdktn.listMapper(cdktn.stringToTerraform, false)(struct.ignoreStartupParameters),
        min_pool_size: cdktn.numberToTerraform(struct.minPoolSize),
        server_idle_timeout: cdktn.numberToTerraform(struct.serverIdleTimeout),
        server_lifetime: cdktn.numberToTerraform(struct.serverLifetime),
        server_reset_query_always: cdktn.booleanToTerraform(struct.serverResetQueryAlways),
    };
}
function databasePostgresqlConfigPgbouncerToHclTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    const attrs = {
        autodb_idle_timeout: {
            value: cdktn.numberToHclTerraform(struct.autodbIdleTimeout),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        autodb_max_db_connections: {
            value: cdktn.numberToHclTerraform(struct.autodbMaxDbConnections),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        autodb_pool_mode: {
            value: cdktn.stringToHclTerraform(struct.autodbPoolMode),
            isBlock: false,
            type: "simple",
            storageClassType: "string",
        },
        autodb_pool_size: {
            value: cdktn.numberToHclTerraform(struct.autodbPoolSize),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        ignore_startup_parameters: {
            value: cdktn.listMapperHcl(cdktn.stringToHclTerraform, false)(struct.ignoreStartupParameters),
            isBlock: false,
            type: "set",
            storageClassType: "stringList",
        },
        min_pool_size: {
            value: cdktn.numberToHclTerraform(struct.minPoolSize),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        server_idle_timeout: {
            value: cdktn.numberToHclTerraform(struct.serverIdleTimeout),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        server_lifetime: {
            value: cdktn.numberToHclTerraform(struct.serverLifetime),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        server_reset_query_always: {
            value: cdktn.booleanToHclTerraform(struct.serverResetQueryAlways),
            isBlock: false,
            type: "simple",
            storageClassType: "boolean",
        },
    };
    // remove undefined attributes
    return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
}
class DatabasePostgresqlConfigPgbouncerOutputReference extends cdktn.ComplexObject {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource, terraformAttribute, complexObjectIndex, complexObjectIsFromSet) {
        super(terraformResource, terraformAttribute, complexObjectIsFromSet, complexObjectIndex);
        this.isEmptyObject = false;
    }
    get internalValue() {
        if (this.resolvableValue) {
            return this.resolvableValue;
        }
        let hasAnyValues = this.isEmptyObject;
        const internalValueResult = {};
        if (this._autodbIdleTimeout !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbIdleTimeout = this._autodbIdleTimeout;
        }
        if (this._autodbMaxDbConnections !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbMaxDbConnections = this._autodbMaxDbConnections;
        }
        if (this._autodbPoolMode !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbPoolMode = this._autodbPoolMode;
        }
        if (this._autodbPoolSize !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbPoolSize = this._autodbPoolSize;
        }
        if (this._ignoreStartupParameters !== undefined) {
            hasAnyValues = true;
            internalValueResult.ignoreStartupParameters = this._ignoreStartupParameters;
        }
        if (this._minPoolSize !== undefined) {
            hasAnyValues = true;
            internalValueResult.minPoolSize = this._minPoolSize;
        }
        if (this._serverIdleTimeout !== undefined) {
            hasAnyValues = true;
            internalValueResult.serverIdleTimeout = this._serverIdleTimeout;
        }
        if (this._serverLifetime !== undefined) {
            hasAnyValues = true;
            internalValueResult.serverLifetime = this._serverLifetime;
        }
        if (this._serverResetQueryAlways !== undefined) {
            hasAnyValues = true;
            internalValueResult.serverResetQueryAlways = this._serverResetQueryAlways;
        }
        return hasAnyValues ? internalValueResult : undefined;
    }
    set internalValue(value) {
        if (value === undefined) {
            this.isEmptyObject = false;
            this.resolvableValue = undefined;
            this._autodbIdleTimeout = undefined;
            this._autodbMaxDbConnections = undefined;
            this._autodbPoolMode = undefined;
            this._autodbPoolSize = undefined;
            this._ignoreStartupParameters = undefined;
            this._minPoolSize = undefined;
            this._serverIdleTimeout = undefined;
            this._serverLifetime = undefined;
            this._serverResetQueryAlways = undefined;
        }
        else if (cdktn.Tokenization.isResolvable(value)) {
            this.isEmptyObject = false;
            this.resolvableValue = value;
        }
        else {
            this.isEmptyObject = Object.keys(value).length === 0;
            this.resolvableValue = undefined;
            this._autodbIdleTimeout = value.autodbIdleTimeout;
            this._autodbMaxDbConnections = value.autodbMaxDbConnections;
            this._autodbPoolMode = value.autodbPoolMode;
            this._autodbPoolSize = value.autodbPoolSize;
            this._ignoreStartupParameters = value.ignoreStartupParameters;
            this._minPoolSize = value.minPoolSize;
            this._serverIdleTimeout = value.serverIdleTimeout;
            this._serverLifetime = value.serverLifetime;
            this._serverResetQueryAlways = value.serverResetQueryAlways;
        }
    }
    get autodbIdleTimeout() {
        return this.getNumberAttribute('autodb_idle_timeout');
    }
    set autodbIdleTimeout(value) {
        this._autodbIdleTimeout = value;
    }
    resetAutodbIdleTimeout() {
        this._autodbIdleTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbIdleTimeoutInput() {
        return this._autodbIdleTimeout;
    }
    get autodbMaxDbConnections() {
        return this.getNumberAttribute('autodb_max_db_connections');
    }
    set autodbMaxDbConnections(value) {
        this._autodbMaxDbConnections = value;
    }
    resetAutodbMaxDbConnections() {
        this._autodbMaxDbConnections = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbMaxDbConnectionsInput() {
        return this._autodbMaxDbConnections;
    }
    get autodbPoolMode() {
        return this.getStringAttribute('autodb_pool_mode');
    }
    set autodbPoolMode(value) {
        this._autodbPoolMode = value;
    }
    resetAutodbPoolMode() {
        this._autodbPoolMode = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbPoolModeInput() {
        return this._autodbPoolMode;
    }
    get autodbPoolSize() {
        return this.getNumberAttribute('autodb_pool_size');
    }
    set autodbPoolSize(value) {
        this._autodbPoolSize = value;
    }
    resetAutodbPoolSize() {
        this._autodbPoolSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbPoolSizeInput() {
        return this._autodbPoolSize;
    }
    get ignoreStartupParameters() {
        return cdktn.Fn.tolist(this.getListAttribute('ignore_startup_parameters'));
    }
    set ignoreStartupParameters(value) {
        this._ignoreStartupParameters = value;
    }
    resetIgnoreStartupParameters() {
        this._ignoreStartupParameters = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ignoreStartupParametersInput() {
        return this._ignoreStartupParameters;
    }
    get minPoolSize() {
        return this.getNumberAttribute('min_pool_size');
    }
    set minPoolSize(value) {
        this._minPoolSize = value;
    }
    resetMinPoolSize() {
        this._minPoolSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get minPoolSizeInput() {
        return this._minPoolSize;
    }
    get serverIdleTimeout() {
        return this.getNumberAttribute('server_idle_timeout');
    }
    set serverIdleTimeout(value) {
        this._serverIdleTimeout = value;
    }
    resetServerIdleTimeout() {
        this._serverIdleTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get serverIdleTimeoutInput() {
        return this._serverIdleTimeout;
    }
    get serverLifetime() {
        return this.getNumberAttribute('server_lifetime');
    }
    set serverLifetime(value) {
        this._serverLifetime = value;
    }
    resetServerLifetime() {
        this._serverLifetime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get serverLifetimeInput() {
        return this._serverLifetime;
    }
    get serverResetQueryAlways() {
        return this.getBooleanAttribute('server_reset_query_always');
    }
    set serverResetQueryAlways(value) {
        this._serverResetQueryAlways = value;
    }
    resetServerResetQueryAlways() {
        this._serverResetQueryAlways = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get serverResetQueryAlwaysInput() {
        return this._serverResetQueryAlways;
    }
}
exports.DatabasePostgresqlConfigPgbouncerOutputReference = DatabasePostgresqlConfigPgbouncerOutputReference;
class DatabasePostgresqlConfigPgbouncerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource, terraformAttribute, wrapsSet) {
        super(terraformResource, terraformAttribute, wrapsSet);
    }
    /**
    * @param index the index of the item to return
    */
    get(index) {
        return new DatabasePostgresqlConfigPgbouncerOutputReference(this.terraformResource, this.terraformAttribute, index, this.wrapsSet);
    }
}
exports.DatabasePostgresqlConfigPgbouncerList = DatabasePostgresqlConfigPgbouncerList;
function databasePostgresqlConfigTimescaledbToTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    return {
        max_background_workers: cdktn.numberToTerraform(struct.maxBackgroundWorkers),
    };
}
function databasePostgresqlConfigTimescaledbToHclTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    const attrs = {
        max_background_workers: {
            value: cdktn.numberToHclTerraform(struct.maxBackgroundWorkers),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
    };
    // remove undefined attributes
    return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
}
class DatabasePostgresqlConfigTimescaledbOutputReference extends cdktn.ComplexObject {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource, terraformAttribute) {
        super(terraformResource, terraformAttribute, false, 0);
        this.isEmptyObject = false;
    }
    get internalValue() {
        let hasAnyValues = this.isEmptyObject;
        const internalValueResult = {};
        if (this._maxBackgroundWorkers !== undefined) {
            hasAnyValues = true;
            internalValueResult.maxBackgroundWorkers = this._maxBackgroundWorkers;
        }
        return hasAnyValues ? internalValueResult : undefined;
    }
    set internalValue(value) {
        if (value === undefined) {
            this.isEmptyObject = false;
            this._maxBackgroundWorkers = undefined;
        }
        else {
            this.isEmptyObject = Object.keys(value).length === 0;
            this._maxBackgroundWorkers = value.maxBackgroundWorkers;
        }
    }
    get maxBackgroundWorkers() {
        return this.getNumberAttribute('max_background_workers');
    }
    set maxBackgroundWorkers(value) {
        this._maxBackgroundWorkers = value;
    }
    resetMaxBackgroundWorkers() {
        this._maxBackgroundWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxBackgroundWorkersInput() {
        return this._maxBackgroundWorkers;
    }
}
exports.DatabasePostgresqlConfigTimescaledbOutputReference = DatabasePostgresqlConfigTimescaledbOutputReference;
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config digitalocean_database_postgresql_config}
*/
class DatabasePostgresqlConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabasePostgresqlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabasePostgresqlConfig to import
    * @param importFromId The id of the existing DatabasePostgresqlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabasePostgresqlConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_postgresql_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config digitalocean_database_postgresql_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabasePostgresqlConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_postgresql_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        // pgbouncer - computed: false, optional: true, required: false
        this._pgbouncer = new DatabasePostgresqlConfigPgbouncerList(this, "pgbouncer", false);
        // timescaledb - computed: false, optional: true, required: false
        this._timescaledb = new DatabasePostgresqlConfigTimescaledbOutputReference(this, "timescaledb");
        this._autovacuumAnalyzeScaleFactor = config.autovacuumAnalyzeScaleFactor;
        this._autovacuumAnalyzeThreshold = config.autovacuumAnalyzeThreshold;
        this._autovacuumFreezeMaxAge = config.autovacuumFreezeMaxAge;
        this._autovacuumMaxWorkers = config.autovacuumMaxWorkers;
        this._autovacuumNaptime = config.autovacuumNaptime;
        this._autovacuumVacuumCostDelay = config.autovacuumVacuumCostDelay;
        this._autovacuumVacuumCostLimit = config.autovacuumVacuumCostLimit;
        this._autovacuumVacuumScaleFactor = config.autovacuumVacuumScaleFactor;
        this._autovacuumVacuumThreshold = config.autovacuumVacuumThreshold;
        this._backupHour = config.backupHour;
        this._backupMinute = config.backupMinute;
        this._bgwriterDelay = config.bgwriterDelay;
        this._bgwriterFlushAfter = config.bgwriterFlushAfter;
        this._bgwriterLruMaxpages = config.bgwriterLruMaxpages;
        this._bgwriterLruMultiplier = config.bgwriterLruMultiplier;
        this._clusterId = config.clusterId;
        this._deadlockTimeout = config.deadlockTimeout;
        this._defaultToastCompression = config.defaultToastCompression;
        this._id = config.id;
        this._idleInTransactionSessionTimeout = config.idleInTransactionSessionTimeout;
        this._jit = config.jit;
        this._logAutovacuumMinDuration = config.logAutovacuumMinDuration;
        this._logErrorVerbosity = config.logErrorVerbosity;
        this._logLinePrefix = config.logLinePrefix;
        this._logMinDurationStatement = config.logMinDurationStatement;
        this._maxFilesPerProcess = config.maxFilesPerProcess;
        this._maxLocksPerTransaction = config.maxLocksPerTransaction;
        this._maxLogicalReplicationWorkers = config.maxLogicalReplicationWorkers;
        this._maxParallelWorkers = config.maxParallelWorkers;
        this._maxParallelWorkersPerGather = config.maxParallelWorkersPerGather;
        this._maxPredLocksPerTransaction = config.maxPredLocksPerTransaction;
        this._maxPreparedTransactions = config.maxPreparedTransactions;
        this._maxReplicationSlots = config.maxReplicationSlots;
        this._maxStackDepth = config.maxStackDepth;
        this._maxStandbyArchiveDelay = config.maxStandbyArchiveDelay;
        this._maxStandbyStreamingDelay = config.maxStandbyStreamingDelay;
        this._maxWalSenders = config.maxWalSenders;
        this._maxWorkerProcesses = config.maxWorkerProcesses;
        this._pgPartmanBgwInterval = config.pgPartmanBgwInterval;
        this._pgPartmanBgwRole = config.pgPartmanBgwRole;
        this._pgStatStatementsTrack = config.pgStatStatementsTrack;
        this._sharedBuffersPercentage = config.sharedBuffersPercentage;
        this._tempFileLimit = config.tempFileLimit;
        this._timezone = config.timezone;
        this._trackActivityQuerySize = config.trackActivityQuerySize;
        this._trackCommitTimestamp = config.trackCommitTimestamp;
        this._trackFunctions = config.trackFunctions;
        this._trackIoTiming = config.trackIoTiming;
        this._walSenderTimeout = config.walSenderTimeout;
        this._walWriterDelay = config.walWriterDelay;
        this._workMem = config.workMem;
        this._pgbouncer.internalValue = config.pgbouncer;
        this._timescaledb.internalValue = config.timescaledb;
    }
    get autovacuumAnalyzeScaleFactor() {
        return this.getNumberAttribute('autovacuum_analyze_scale_factor');
    }
    set autovacuumAnalyzeScaleFactor(value) {
        this._autovacuumAnalyzeScaleFactor = value;
    }
    resetAutovacuumAnalyzeScaleFactor() {
        this._autovacuumAnalyzeScaleFactor = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumAnalyzeScaleFactorInput() {
        return this._autovacuumAnalyzeScaleFactor;
    }
    get autovacuumAnalyzeThreshold() {
        return this.getNumberAttribute('autovacuum_analyze_threshold');
    }
    set autovacuumAnalyzeThreshold(value) {
        this._autovacuumAnalyzeThreshold = value;
    }
    resetAutovacuumAnalyzeThreshold() {
        this._autovacuumAnalyzeThreshold = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumAnalyzeThresholdInput() {
        return this._autovacuumAnalyzeThreshold;
    }
    get autovacuumFreezeMaxAge() {
        return this.getNumberAttribute('autovacuum_freeze_max_age');
    }
    set autovacuumFreezeMaxAge(value) {
        this._autovacuumFreezeMaxAge = value;
    }
    resetAutovacuumFreezeMaxAge() {
        this._autovacuumFreezeMaxAge = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumFreezeMaxAgeInput() {
        return this._autovacuumFreezeMaxAge;
    }
    get autovacuumMaxWorkers() {
        return this.getNumberAttribute('autovacuum_max_workers');
    }
    set autovacuumMaxWorkers(value) {
        this._autovacuumMaxWorkers = value;
    }
    resetAutovacuumMaxWorkers() {
        this._autovacuumMaxWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumMaxWorkersInput() {
        return this._autovacuumMaxWorkers;
    }
    get autovacuumNaptime() {
        return this.getNumberAttribute('autovacuum_naptime');
    }
    set autovacuumNaptime(value) {
        this._autovacuumNaptime = value;
    }
    resetAutovacuumNaptime() {
        this._autovacuumNaptime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumNaptimeInput() {
        return this._autovacuumNaptime;
    }
    get autovacuumVacuumCostDelay() {
        return this.getNumberAttribute('autovacuum_vacuum_cost_delay');
    }
    set autovacuumVacuumCostDelay(value) {
        this._autovacuumVacuumCostDelay = value;
    }
    resetAutovacuumVacuumCostDelay() {
        this._autovacuumVacuumCostDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumCostDelayInput() {
        return this._autovacuumVacuumCostDelay;
    }
    get autovacuumVacuumCostLimit() {
        return this.getNumberAttribute('autovacuum_vacuum_cost_limit');
    }
    set autovacuumVacuumCostLimit(value) {
        this._autovacuumVacuumCostLimit = value;
    }
    resetAutovacuumVacuumCostLimit() {
        this._autovacuumVacuumCostLimit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumCostLimitInput() {
        return this._autovacuumVacuumCostLimit;
    }
    get autovacuumVacuumScaleFactor() {
        return this.getNumberAttribute('autovacuum_vacuum_scale_factor');
    }
    set autovacuumVacuumScaleFactor(value) {
        this._autovacuumVacuumScaleFactor = value;
    }
    resetAutovacuumVacuumScaleFactor() {
        this._autovacuumVacuumScaleFactor = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumScaleFactorInput() {
        return this._autovacuumVacuumScaleFactor;
    }
    get autovacuumVacuumThreshold() {
        return this.getNumberAttribute('autovacuum_vacuum_threshold');
    }
    set autovacuumVacuumThreshold(value) {
        this._autovacuumVacuumThreshold = value;
    }
    resetAutovacuumVacuumThreshold() {
        this._autovacuumVacuumThreshold = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumThresholdInput() {
        return this._autovacuumVacuumThreshold;
    }
    get backupHour() {
        return this.getNumberAttribute('backup_hour');
    }
    set backupHour(value) {
        this._backupHour = value;
    }
    resetBackupHour() {
        this._backupHour = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupHourInput() {
        return this._backupHour;
    }
    get backupMinute() {
        return this.getNumberAttribute('backup_minute');
    }
    set backupMinute(value) {
        this._backupMinute = value;
    }
    resetBackupMinute() {
        this._backupMinute = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupMinuteInput() {
        return this._backupMinute;
    }
    get bgwriterDelay() {
        return this.getNumberAttribute('bgwriter_delay');
    }
    set bgwriterDelay(value) {
        this._bgwriterDelay = value;
    }
    resetBgwriterDelay() {
        this._bgwriterDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterDelayInput() {
        return this._bgwriterDelay;
    }
    get bgwriterFlushAfter() {
        return this.getNumberAttribute('bgwriter_flush_after');
    }
    set bgwriterFlushAfter(value) {
        this._bgwriterFlushAfter = value;
    }
    resetBgwriterFlushAfter() {
        this._bgwriterFlushAfter = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterFlushAfterInput() {
        return this._bgwriterFlushAfter;
    }
    get bgwriterLruMaxpages() {
        return this.getNumberAttribute('bgwriter_lru_maxpages');
    }
    set bgwriterLruMaxpages(value) {
        this._bgwriterLruMaxpages = value;
    }
    resetBgwriterLruMaxpages() {
        this._bgwriterLruMaxpages = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterLruMaxpagesInput() {
        return this._bgwriterLruMaxpages;
    }
    get bgwriterLruMultiplier() {
        return this.getNumberAttribute('bgwriter_lru_multiplier');
    }
    set bgwriterLruMultiplier(value) {
        this._bgwriterLruMultiplier = value;
    }
    resetBgwriterLruMultiplier() {
        this._bgwriterLruMultiplier = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterLruMultiplierInput() {
        return this._bgwriterLruMultiplier;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get deadlockTimeout() {
        return this.getNumberAttribute('deadlock_timeout');
    }
    set deadlockTimeout(value) {
        this._deadlockTimeout = value;
    }
    resetDeadlockTimeout() {
        this._deadlockTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get deadlockTimeoutInput() {
        return this._deadlockTimeout;
    }
    get defaultToastCompression() {
        return this.getStringAttribute('default_toast_compression');
    }
    set defaultToastCompression(value) {
        this._defaultToastCompression = value;
    }
    resetDefaultToastCompression() {
        this._defaultToastCompression = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get defaultToastCompressionInput() {
        return this._defaultToastCompression;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get idleInTransactionSessionTimeout() {
        return this.getNumberAttribute('idle_in_transaction_session_timeout');
    }
    set idleInTransactionSessionTimeout(value) {
        this._idleInTransactionSessionTimeout = value;
    }
    resetIdleInTransactionSessionTimeout() {
        this._idleInTransactionSessionTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idleInTransactionSessionTimeoutInput() {
        return this._idleInTransactionSessionTimeout;
    }
    get jit() {
        return this.getBooleanAttribute('jit');
    }
    set jit(value) {
        this._jit = value;
    }
    resetJit() {
        this._jit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get jitInput() {
        return this._jit;
    }
    get logAutovacuumMinDuration() {
        return this.getNumberAttribute('log_autovacuum_min_duration');
    }
    set logAutovacuumMinDuration(value) {
        this._logAutovacuumMinDuration = value;
    }
    resetLogAutovacuumMinDuration() {
        this._logAutovacuumMinDuration = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logAutovacuumMinDurationInput() {
        return this._logAutovacuumMinDuration;
    }
    get logErrorVerbosity() {
        return this.getStringAttribute('log_error_verbosity');
    }
    set logErrorVerbosity(value) {
        this._logErrorVerbosity = value;
    }
    resetLogErrorVerbosity() {
        this._logErrorVerbosity = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logErrorVerbosityInput() {
        return this._logErrorVerbosity;
    }
    get logLinePrefix() {
        return this.getStringAttribute('log_line_prefix');
    }
    set logLinePrefix(value) {
        this._logLinePrefix = value;
    }
    resetLogLinePrefix() {
        this._logLinePrefix = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logLinePrefixInput() {
        return this._logLinePrefix;
    }
    get logMinDurationStatement() {
        return this.getNumberAttribute('log_min_duration_statement');
    }
    set logMinDurationStatement(value) {
        this._logMinDurationStatement = value;
    }
    resetLogMinDurationStatement() {
        this._logMinDurationStatement = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logMinDurationStatementInput() {
        return this._logMinDurationStatement;
    }
    get maxFilesPerProcess() {
        return this.getNumberAttribute('max_files_per_process');
    }
    set maxFilesPerProcess(value) {
        this._maxFilesPerProcess = value;
    }
    resetMaxFilesPerProcess() {
        this._maxFilesPerProcess = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxFilesPerProcessInput() {
        return this._maxFilesPerProcess;
    }
    get maxLocksPerTransaction() {
        return this.getNumberAttribute('max_locks_per_transaction');
    }
    set maxLocksPerTransaction(value) {
        this._maxLocksPerTransaction = value;
    }
    resetMaxLocksPerTransaction() {
        this._maxLocksPerTransaction = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxLocksPerTransactionInput() {
        return this._maxLocksPerTransaction;
    }
    get maxLogicalReplicationWorkers() {
        return this.getNumberAttribute('max_logical_replication_workers');
    }
    set maxLogicalReplicationWorkers(value) {
        this._maxLogicalReplicationWorkers = value;
    }
    resetMaxLogicalReplicationWorkers() {
        this._maxLogicalReplicationWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxLogicalReplicationWorkersInput() {
        return this._maxLogicalReplicationWorkers;
    }
    get maxParallelWorkers() {
        return this.getNumberAttribute('max_parallel_workers');
    }
    set maxParallelWorkers(value) {
        this._maxParallelWorkers = value;
    }
    resetMaxParallelWorkers() {
        this._maxParallelWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxParallelWorkersInput() {
        return this._maxParallelWorkers;
    }
    get maxParallelWorkersPerGather() {
        return this.getNumberAttribute('max_parallel_workers_per_gather');
    }
    set maxParallelWorkersPerGather(value) {
        this._maxParallelWorkersPerGather = value;
    }
    resetMaxParallelWorkersPerGather() {
        this._maxParallelWorkersPerGather = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxParallelWorkersPerGatherInput() {
        return this._maxParallelWorkersPerGather;
    }
    get maxPredLocksPerTransaction() {
        return this.getNumberAttribute('max_pred_locks_per_transaction');
    }
    set maxPredLocksPerTransaction(value) {
        this._maxPredLocksPerTransaction = value;
    }
    resetMaxPredLocksPerTransaction() {
        this._maxPredLocksPerTransaction = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxPredLocksPerTransactionInput() {
        return this._maxPredLocksPerTransaction;
    }
    get maxPreparedTransactions() {
        return this.getNumberAttribute('max_prepared_transactions');
    }
    set maxPreparedTransactions(value) {
        this._maxPreparedTransactions = value;
    }
    resetMaxPreparedTransactions() {
        this._maxPreparedTransactions = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxPreparedTransactionsInput() {
        return this._maxPreparedTransactions;
    }
    get maxReplicationSlots() {
        return this.getNumberAttribute('max_replication_slots');
    }
    set maxReplicationSlots(value) {
        this._maxReplicationSlots = value;
    }
    resetMaxReplicationSlots() {
        this._maxReplicationSlots = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxReplicationSlotsInput() {
        return this._maxReplicationSlots;
    }
    get maxStackDepth() {
        return this.getNumberAttribute('max_stack_depth');
    }
    set maxStackDepth(value) {
        this._maxStackDepth = value;
    }
    resetMaxStackDepth() {
        this._maxStackDepth = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxStackDepthInput() {
        return this._maxStackDepth;
    }
    get maxStandbyArchiveDelay() {
        return this.getNumberAttribute('max_standby_archive_delay');
    }
    set maxStandbyArchiveDelay(value) {
        this._maxStandbyArchiveDelay = value;
    }
    resetMaxStandbyArchiveDelay() {
        this._maxStandbyArchiveDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxStandbyArchiveDelayInput() {
        return this._maxStandbyArchiveDelay;
    }
    get maxStandbyStreamingDelay() {
        return this.getNumberAttribute('max_standby_streaming_delay');
    }
    set maxStandbyStreamingDelay(value) {
        this._maxStandbyStreamingDelay = value;
    }
    resetMaxStandbyStreamingDelay() {
        this._maxStandbyStreamingDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxStandbyStreamingDelayInput() {
        return this._maxStandbyStreamingDelay;
    }
    get maxWalSenders() {
        return this.getNumberAttribute('max_wal_senders');
    }
    set maxWalSenders(value) {
        this._maxWalSenders = value;
    }
    resetMaxWalSenders() {
        this._maxWalSenders = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxWalSendersInput() {
        return this._maxWalSenders;
    }
    get maxWorkerProcesses() {
        return this.getNumberAttribute('max_worker_processes');
    }
    set maxWorkerProcesses(value) {
        this._maxWorkerProcesses = value;
    }
    resetMaxWorkerProcesses() {
        this._maxWorkerProcesses = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxWorkerProcessesInput() {
        return this._maxWorkerProcesses;
    }
    get pgPartmanBgwInterval() {
        return this.getNumberAttribute('pg_partman_bgw_interval');
    }
    set pgPartmanBgwInterval(value) {
        this._pgPartmanBgwInterval = value;
    }
    resetPgPartmanBgwInterval() {
        this._pgPartmanBgwInterval = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgPartmanBgwIntervalInput() {
        return this._pgPartmanBgwInterval;
    }
    get pgPartmanBgwRole() {
        return this.getStringAttribute('pg_partman_bgw_role');
    }
    set pgPartmanBgwRole(value) {
        this._pgPartmanBgwRole = value;
    }
    resetPgPartmanBgwRole() {
        this._pgPartmanBgwRole = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgPartmanBgwRoleInput() {
        return this._pgPartmanBgwRole;
    }
    get pgStatStatementsTrack() {
        return this.getStringAttribute('pg_stat_statements_track');
    }
    set pgStatStatementsTrack(value) {
        this._pgStatStatementsTrack = value;
    }
    resetPgStatStatementsTrack() {
        this._pgStatStatementsTrack = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgStatStatementsTrackInput() {
        return this._pgStatStatementsTrack;
    }
    get sharedBuffersPercentage() {
        return this.getNumberAttribute('shared_buffers_percentage');
    }
    set sharedBuffersPercentage(value) {
        this._sharedBuffersPercentage = value;
    }
    resetSharedBuffersPercentage() {
        this._sharedBuffersPercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sharedBuffersPercentageInput() {
        return this._sharedBuffersPercentage;
    }
    get tempFileLimit() {
        return this.getNumberAttribute('temp_file_limit');
    }
    set tempFileLimit(value) {
        this._tempFileLimit = value;
    }
    resetTempFileLimit() {
        this._tempFileLimit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get tempFileLimitInput() {
        return this._tempFileLimit;
    }
    get timezone() {
        return this.getStringAttribute('timezone');
    }
    set timezone(value) {
        this._timezone = value;
    }
    resetTimezone() {
        this._timezone = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get timezoneInput() {
        return this._timezone;
    }
    get trackActivityQuerySize() {
        return this.getNumberAttribute('track_activity_query_size');
    }
    set trackActivityQuerySize(value) {
        this._trackActivityQuerySize = value;
    }
    resetTrackActivityQuerySize() {
        this._trackActivityQuerySize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackActivityQuerySizeInput() {
        return this._trackActivityQuerySize;
    }
    get trackCommitTimestamp() {
        return this.getStringAttribute('track_commit_timestamp');
    }
    set trackCommitTimestamp(value) {
        this._trackCommitTimestamp = value;
    }
    resetTrackCommitTimestamp() {
        this._trackCommitTimestamp = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackCommitTimestampInput() {
        return this._trackCommitTimestamp;
    }
    get trackFunctions() {
        return this.getStringAttribute('track_functions');
    }
    set trackFunctions(value) {
        this._trackFunctions = value;
    }
    resetTrackFunctions() {
        this._trackFunctions = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackFunctionsInput() {
        return this._trackFunctions;
    }
    get trackIoTiming() {
        return this.getStringAttribute('track_io_timing');
    }
    set trackIoTiming(value) {
        this._trackIoTiming = value;
    }
    resetTrackIoTiming() {
        this._trackIoTiming = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackIoTimingInput() {
        return this._trackIoTiming;
    }
    get walSenderTimeout() {
        return this.getNumberAttribute('wal_sender_timeout');
    }
    set walSenderTimeout(value) {
        this._walSenderTimeout = value;
    }
    resetWalSenderTimeout() {
        this._walSenderTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get walSenderTimeoutInput() {
        return this._walSenderTimeout;
    }
    get walWriterDelay() {
        return this.getNumberAttribute('wal_writer_delay');
    }
    set walWriterDelay(value) {
        this._walWriterDelay = value;
    }
    resetWalWriterDelay() {
        this._walWriterDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get walWriterDelayInput() {
        return this._walWriterDelay;
    }
    get workMem() {
        return this.getNumberAttribute('work_mem');
    }
    set workMem(value) {
        this._workMem = value;
    }
    resetWorkMem() {
        this._workMem = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get workMemInput() {
        return this._workMem;
    }
    get pgbouncer() {
        return this._pgbouncer;
    }
    putPgbouncer(value) {
        this._pgbouncer.internalValue = value;
    }
    resetPgbouncer() {
        this._pgbouncer.internalValue = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgbouncerInput() {
        return this._pgbouncer.internalValue;
    }
    get timescaledb() {
        return this._timescaledb;
    }
    putTimescaledb(value) {
        this._timescaledb.internalValue = value;
    }
    resetTimescaledb() {
        this._timescaledb.internalValue = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get timescaledbInput() {
        return this._timescaledb.internalValue;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            autovacuum_analyze_scale_factor: cdktn.numberToTerraform(this._autovacuumAnalyzeScaleFactor),
            autovacuum_analyze_threshold: cdktn.numberToTerraform(this._autovacuumAnalyzeThreshold),
            autovacuum_freeze_max_age: cdktn.numberToTerraform(this._autovacuumFreezeMaxAge),
            autovacuum_max_workers: cdktn.numberToTerraform(this._autovacuumMaxWorkers),
            autovacuum_naptime: cdktn.numberToTerraform(this._autovacuumNaptime),
            autovacuum_vacuum_cost_delay: cdktn.numberToTerraform(this._autovacuumVacuumCostDelay),
            autovacuum_vacuum_cost_limit: cdktn.numberToTerraform(this._autovacuumVacuumCostLimit),
            autovacuum_vacuum_scale_factor: cdktn.numberToTerraform(this._autovacuumVacuumScaleFactor),
            autovacuum_vacuum_threshold: cdktn.numberToTerraform(this._autovacuumVacuumThreshold),
            backup_hour: cdktn.numberToTerraform(this._backupHour),
            backup_minute: cdktn.numberToTerraform(this._backupMinute),
            bgwriter_delay: cdktn.numberToTerraform(this._bgwriterDelay),
            bgwriter_flush_after: cdktn.numberToTerraform(this._bgwriterFlushAfter),
            bgwriter_lru_maxpages: cdktn.numberToTerraform(this._bgwriterLruMaxpages),
            bgwriter_lru_multiplier: cdktn.numberToTerraform(this._bgwriterLruMultiplier),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            deadlock_timeout: cdktn.numberToTerraform(this._deadlockTimeout),
            default_toast_compression: cdktn.stringToTerraform(this._defaultToastCompression),
            id: cdktn.stringToTerraform(this._id),
            idle_in_transaction_session_timeout: cdktn.numberToTerraform(this._idleInTransactionSessionTimeout),
            jit: cdktn.booleanToTerraform(this._jit),
            log_autovacuum_min_duration: cdktn.numberToTerraform(this._logAutovacuumMinDuration),
            log_error_verbosity: cdktn.stringToTerraform(this._logErrorVerbosity),
            log_line_prefix: cdktn.stringToTerraform(this._logLinePrefix),
            log_min_duration_statement: cdktn.numberToTerraform(this._logMinDurationStatement),
            max_files_per_process: cdktn.numberToTerraform(this._maxFilesPerProcess),
            max_locks_per_transaction: cdktn.numberToTerraform(this._maxLocksPerTransaction),
            max_logical_replication_workers: cdktn.numberToTerraform(this._maxLogicalReplicationWorkers),
            max_parallel_workers: cdktn.numberToTerraform(this._maxParallelWorkers),
            max_parallel_workers_per_gather: cdktn.numberToTerraform(this._maxParallelWorkersPerGather),
            max_pred_locks_per_transaction: cdktn.numberToTerraform(this._maxPredLocksPerTransaction),
            max_prepared_transactions: cdktn.numberToTerraform(this._maxPreparedTransactions),
            max_replication_slots: cdktn.numberToTerraform(this._maxReplicationSlots),
            max_stack_depth: cdktn.numberToTerraform(this._maxStackDepth),
            max_standby_archive_delay: cdktn.numberToTerraform(this._maxStandbyArchiveDelay),
            max_standby_streaming_delay: cdktn.numberToTerraform(this._maxStandbyStreamingDelay),
            max_wal_senders: cdktn.numberToTerraform(this._maxWalSenders),
            max_worker_processes: cdktn.numberToTerraform(this._maxWorkerProcesses),
            pg_partman_bgw_interval: cdktn.numberToTerraform(this._pgPartmanBgwInterval),
            pg_partman_bgw_role: cdktn.stringToTerraform(this._pgPartmanBgwRole),
            pg_stat_statements_track: cdktn.stringToTerraform(this._pgStatStatementsTrack),
            shared_buffers_percentage: cdktn.numberToTerraform(this._sharedBuffersPercentage),
            temp_file_limit: cdktn.numberToTerraform(this._tempFileLimit),
            timezone: cdktn.stringToTerraform(this._timezone),
            track_activity_query_size: cdktn.numberToTerraform(this._trackActivityQuerySize),
            track_commit_timestamp: cdktn.stringToTerraform(this._trackCommitTimestamp),
            track_functions: cdktn.stringToTerraform(this._trackFunctions),
            track_io_timing: cdktn.stringToTerraform(this._trackIoTiming),
            wal_sender_timeout: cdktn.numberToTerraform(this._walSenderTimeout),
            wal_writer_delay: cdktn.numberToTerraform(this._walWriterDelay),
            work_mem: cdktn.numberToTerraform(this._workMem),
            pgbouncer: cdktn.listMapper(databasePostgresqlConfigPgbouncerToTerraform, true)(this._pgbouncer.internalValue),
            timescaledb: databasePostgresqlConfigTimescaledbToTerraform(this._timescaledb.internalValue),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            autovacuum_analyze_scale_factor: {
                value: cdktn.numberToHclTerraform(this._autovacuumAnalyzeScaleFactor),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_analyze_threshold: {
                value: cdktn.numberToHclTerraform(this._autovacuumAnalyzeThreshold),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_freeze_max_age: {
                value: cdktn.numberToHclTerraform(this._autovacuumFreezeMaxAge),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_max_workers: {
                value: cdktn.numberToHclTerraform(this._autovacuumMaxWorkers),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_naptime: {
                value: cdktn.numberToHclTerraform(this._autovacuumNaptime),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_cost_delay: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumCostDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_cost_limit: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumCostLimit),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_scale_factor: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumScaleFactor),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_threshold: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumThreshold),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            backup_hour: {
                value: cdktn.numberToHclTerraform(this._backupHour),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            backup_minute: {
                value: cdktn.numberToHclTerraform(this._backupMinute),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_delay: {
                value: cdktn.numberToHclTerraform(this._bgwriterDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_flush_after: {
                value: cdktn.numberToHclTerraform(this._bgwriterFlushAfter),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_lru_maxpages: {
                value: cdktn.numberToHclTerraform(this._bgwriterLruMaxpages),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_lru_multiplier: {
                value: cdktn.numberToHclTerraform(this._bgwriterLruMultiplier),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            deadlock_timeout: {
                value: cdktn.numberToHclTerraform(this._deadlockTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            default_toast_compression: {
                value: cdktn.stringToHclTerraform(this._defaultToastCompression),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            idle_in_transaction_session_timeout: {
                value: cdktn.numberToHclTerraform(this._idleInTransactionSessionTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            jit: {
                value: cdktn.booleanToHclTerraform(this._jit),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            log_autovacuum_min_duration: {
                value: cdktn.numberToHclTerraform(this._logAutovacuumMinDuration),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_error_verbosity: {
                value: cdktn.stringToHclTerraform(this._logErrorVerbosity),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_line_prefix: {
                value: cdktn.stringToHclTerraform(this._logLinePrefix),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_min_duration_statement: {
                value: cdktn.numberToHclTerraform(this._logMinDurationStatement),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_files_per_process: {
                value: cdktn.numberToHclTerraform(this._maxFilesPerProcess),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_locks_per_transaction: {
                value: cdktn.numberToHclTerraform(this._maxLocksPerTransaction),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_logical_replication_workers: {
                value: cdktn.numberToHclTerraform(this._maxLogicalReplicationWorkers),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_parallel_workers: {
                value: cdktn.numberToHclTerraform(this._maxParallelWorkers),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_parallel_workers_per_gather: {
                value: cdktn.numberToHclTerraform(this._maxParallelWorkersPerGather),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_pred_locks_per_transaction: {
                value: cdktn.numberToHclTerraform(this._maxPredLocksPerTransaction),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_prepared_transactions: {
                value: cdktn.numberToHclTerraform(this._maxPreparedTransactions),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_replication_slots: {
                value: cdktn.numberToHclTerraform(this._maxReplicationSlots),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_stack_depth: {
                value: cdktn.numberToHclTerraform(this._maxStackDepth),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_standby_archive_delay: {
                value: cdktn.numberToHclTerraform(this._maxStandbyArchiveDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_standby_streaming_delay: {
                value: cdktn.numberToHclTerraform(this._maxStandbyStreamingDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_wal_senders: {
                value: cdktn.numberToHclTerraform(this._maxWalSenders),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_worker_processes: {
                value: cdktn.numberToHclTerraform(this._maxWorkerProcesses),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            pg_partman_bgw_interval: {
                value: cdktn.numberToHclTerraform(this._pgPartmanBgwInterval),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            pg_partman_bgw_role: {
                value: cdktn.stringToHclTerraform(this._pgPartmanBgwRole),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            pg_stat_statements_track: {
                value: cdktn.stringToHclTerraform(this._pgStatStatementsTrack),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            shared_buffers_percentage: {
                value: cdktn.numberToHclTerraform(this._sharedBuffersPercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            temp_file_limit: {
                value: cdktn.numberToHclTerraform(this._tempFileLimit),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            timezone: {
                value: cdktn.stringToHclTerraform(this._timezone),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            track_activity_query_size: {
                value: cdktn.numberToHclTerraform(this._trackActivityQuerySize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            track_commit_timestamp: {
                value: cdktn.stringToHclTerraform(this._trackCommitTimestamp),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            track_functions: {
                value: cdktn.stringToHclTerraform(this._trackFunctions),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            track_io_timing: {
                value: cdktn.stringToHclTerraform(this._trackIoTiming),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            wal_sender_timeout: {
                value: cdktn.numberToHclTerraform(this._walSenderTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            wal_writer_delay: {
                value: cdktn.numberToHclTerraform(this._walWriterDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            work_mem: {
                value: cdktn.numberToHclTerraform(this._workMem),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            pgbouncer: {
                value: cdktn.listMapperHcl(databasePostgresqlConfigPgbouncerToHclTerraform, true)(this._pgbouncer.internalValue),
                isBlock: true,
                type: "list",
                storageClassType: "DatabasePostgresqlConfigPgbouncerList",
            },
            timescaledb: {
                value: databasePostgresqlConfigTimescaledbToHclTerraform(this._timescaledb.internalValue),
                isBlock: true,
                type: "list",
                storageClassType: "DatabasePostgresqlConfigTimescaledbList",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabasePostgresqlConfig = DatabasePostgresqlConfig;
// =================
// STATIC PROPERTIES
// =================
DatabasePostgresqlConfig.tfResourceType = "digitalocean_database_postgresql_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEscUhBQXFIO0FBQ3JILDJDQUEyQzs7O0FBMlEzQyxvR0FnQkM7QUFHRCwwR0FnRUM7QUF5UUQsd0dBUUM7QUFHRCw4R0FnQkM7QUEvbkJELCtCQUErQjtBQXdRL0IsU0FBZ0IsNENBQTRDLENBQUMsTUFBOEQ7SUFDekgsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUFDLE9BQU8sTUFBTSxDQUFDO0lBQUMsQ0FBQztJQUM1RixJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ25DLE1BQU0sSUFBSSxLQUFLLENBQUMsb0hBQW9ILENBQUMsQ0FBQztJQUN4SSxDQUFDO0lBQ0QsT0FBTztRQUNMLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsaUJBQWlCLENBQUM7UUFDdkUseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLE1BQU8sQ0FBQyxzQkFBc0IsQ0FBQztRQUNsRixnQkFBZ0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsTUFBTyxDQUFDLGNBQWMsQ0FBQztRQUNqRSxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsTUFBTyxDQUFDLGNBQWMsQ0FBQztRQUNqRSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFPLENBQUMsdUJBQXVCLENBQUM7UUFDNUcsYUFBYSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsV0FBVyxDQUFDO1FBQzNELG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsaUJBQWlCLENBQUM7UUFDdkUsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsY0FBYyxDQUFDO1FBQ2hFLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxNQUFPLENBQUMsc0JBQXNCLENBQUM7S0FDcEYsQ0FBQTtBQUNILENBQUM7QUFHRCxTQUFnQiwrQ0FBK0MsQ0FBQyxNQUE4RDtJQUM1SCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQUMsT0FBTyxNQUFNLENBQUM7SUFBQyxDQUFDO0lBQzVGLElBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDbkMsTUFBTSxJQUFJLEtBQUssQ0FBQyxvSEFBb0gsQ0FBQyxDQUFDO0lBQ3hJLENBQUM7SUFDRCxNQUFNLEtBQUssR0FBRztRQUNaLG1CQUFtQixFQUFFO1lBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsTUFBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzVELE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFLFFBQVE7WUFDZCxnQkFBZ0IsRUFBRSxRQUFRO1NBQzNCO1FBQ0QseUJBQXlCLEVBQUU7WUFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsc0JBQXNCLENBQUM7WUFDakUsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCxnQkFBZ0IsRUFBRTtZQUNoQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxjQUFjLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCxnQkFBZ0IsRUFBRTtZQUNoQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxjQUFjLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCx5QkFBeUIsRUFBRTtZQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTyxDQUFDLHVCQUF1QixDQUFDO1lBQzlGLE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFLEtBQUs7WUFDWCxnQkFBZ0IsRUFBRSxZQUFZO1NBQy9CO1FBQ0QsYUFBYSxFQUFFO1lBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsV0FBVyxDQUFDO1lBQ3RELE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFLFFBQVE7WUFDZCxnQkFBZ0IsRUFBRSxRQUFRO1NBQzNCO1FBQ0QsbUJBQW1CLEVBQUU7WUFDbkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsaUJBQWlCLENBQUM7WUFDNUQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCxlQUFlLEVBQUU7WUFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxjQUFjLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCx5QkFBeUIsRUFBRTtZQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLHFCQUFxQixDQUFDLE1BQU8sQ0FBQyxzQkFBc0IsQ0FBQztZQUNsRSxPQUFPLEVBQUUsS0FBSztZQUNkLElBQUksRUFBRSxRQUFRO1lBQ2QsZ0JBQWdCLEVBQUUsU0FBUztTQUM1QjtLQUNGLENBQUM7SUFFRiw4QkFBOEI7SUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzVILENBQUM7QUFFRCxNQUFhLGdEQUFpRCxTQUFRLEtBQUssQ0FBQyxhQUFhO0lBSXZGOzs7OztNQUtFO0lBQ0YsWUFBbUIsaUJBQTZDLEVBQUUsa0JBQTBCLEVBQUUsa0JBQTBCLEVBQUUsc0JBQStCO1FBQ3ZKLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxrQkFBa0IsRUFBRSxzQkFBc0IsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBVm5GLGtCQUFhLEdBQUcsS0FBSyxDQUFDO0lBVzlCLENBQUM7SUFFRCxJQUFXLGFBQWE7UUFDdEIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzlCLENBQUM7UUFDRCxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3RDLE1BQU0sbUJBQW1CLEdBQVEsRUFBRSxDQUFDO1FBQ3BDLElBQUksSUFBSSxDQUFDLGtCQUFrQixLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2xFLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyx1QkFBdUIsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUMvQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUM1RSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsZUFBZSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3ZDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDNUQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN2QyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzVELENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyx3QkFBd0IsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNoRCxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztRQUM5RSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3BDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDdEQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGtCQUFrQixLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2xFLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxlQUFlLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDdkMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNwQixtQkFBbUIsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUM1RCxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsdUJBQXVCLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDL0MsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNwQixtQkFBbUIsQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7UUFDNUUsQ0FBQztRQUNELE9BQU8sWUFBWSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBQ3hELENBQUM7SUFFRCxJQUFXLGFBQWEsQ0FBQyxLQUF3RTtRQUMvRixJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztZQUNqQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO1lBQ3BDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7WUFDekMsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7WUFDakMsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7WUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztZQUMxQyxJQUFJLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQztZQUM5QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO1lBQ2pDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7UUFDM0MsQ0FBQzthQUNJLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNoRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztRQUMvQixDQUFDO2FBQ0ksQ0FBQztZQUNKLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1lBQ3JELElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDbEQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztZQUM1RCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7WUFDNUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQzVDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUMsdUJBQXVCLENBQUM7WUFDOUQsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDbEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQzVDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsc0JBQXNCLENBQUM7UUFDOUQsQ0FBQztJQUNILENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFhO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUM7SUFDdkMsQ0FBQztJQUNNLDJCQUEyQjtRQUNoQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsU0FBUyxDQUFDO0lBQzNDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEMsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFlO1FBQ2hELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUNNLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0lBQzVDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw0QkFBNEI7UUFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUlELElBQVcsV0FBVztRQUNwQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBVyxXQUFXLENBQUMsS0FBYTtRQUNsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBQ00sZ0JBQWdCO1FBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDO0lBQ2hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQVcsY0FBYyxDQUFDLEtBQWE7UUFDckMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQUNNLG1CQUFtQjtRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztJQUNuQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsbUJBQW1CO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFrQztRQUNsRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7Q0FDRjtBQTNPRCw0R0EyT0M7QUFFRCxNQUFhLHFDQUFzQyxTQUFRLEtBQUssQ0FBQyxXQUFXO0lBRzFFOzs7O01BSUU7SUFDRixZQUFZLGlCQUE2QyxFQUFFLGtCQUEwQixFQUFFLFFBQWlCO1FBQ3RHLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxrQkFBa0IsRUFBRSxRQUFRLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBRUQ7O01BRUU7SUFDSyxHQUFHLENBQUMsS0FBYTtRQUN0QixPQUFPLElBQUksZ0RBQWdELENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JJLENBQUM7Q0FDRjtBQWxCRCxzRkFrQkM7QUFRRCxTQUFnQiw4Q0FBOEMsQ0FBQyxNQUFpRztJQUM5SixJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQUMsT0FBTyxNQUFNLENBQUM7SUFBQyxDQUFDO0lBQzVGLElBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDbkMsTUFBTSxJQUFJLEtBQUssQ0FBQyxvSEFBb0gsQ0FBQyxDQUFDO0lBQ3hJLENBQUM7SUFDRCxPQUFPO1FBQ0wsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLE1BQU8sQ0FBQyxvQkFBb0IsQ0FBQztLQUM5RSxDQUFBO0FBQ0gsQ0FBQztBQUdELFNBQWdCLGlEQUFpRCxDQUFDLE1BQWlHO0lBQ2pLLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFBQyxPQUFPLE1BQU0sQ0FBQztJQUFDLENBQUM7SUFDNUYsSUFBSSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNuQyxNQUFNLElBQUksS0FBSyxDQUFDLG9IQUFvSCxDQUFDLENBQUM7SUFDeEksQ0FBQztJQUNELE1BQU0sS0FBSyxHQUFHO1FBQ1osc0JBQXNCLEVBQUU7WUFDdEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsb0JBQW9CLENBQUM7WUFDL0QsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7S0FDRixDQUFDO0lBRUYsOEJBQThCO0lBQzlCLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztBQUM1SCxDQUFDO0FBRUQsTUFBYSxrREFBbUQsU0FBUSxLQUFLLENBQUMsYUFBYTtJQUd6Rjs7O01BR0U7SUFDRixZQUFtQixpQkFBNkMsRUFBRSxrQkFBMEI7UUFDMUYsS0FBSyxDQUFDLGlCQUFpQixFQUFFLGtCQUFrQixFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztRQVBqRCxrQkFBYSxHQUFHLEtBQUssQ0FBQztJQVE5QixDQUFDO0lBRUQsSUFBVyxhQUFhO1FBQ3RCLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDdEMsTUFBTSxtQkFBbUIsR0FBUSxFQUFFLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMscUJBQXFCLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDN0MsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNwQixtQkFBbUIsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUM7UUFDeEUsQ0FBQztRQUNELE9BQU8sWUFBWSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBQ3hELENBQUM7SUFFRCxJQUFXLGFBQWEsQ0FBQyxLQUFzRDtRQUM3RSxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMscUJBQXFCLEdBQUcsU0FBUyxDQUFDO1FBQ3pDLENBQUM7YUFDSSxDQUFDO1lBQ0osSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztRQUMxRCxDQUFDO0lBQ0gsQ0FBQztJQUlELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUNELElBQVcsb0JBQW9CLENBQUMsS0FBYTtRQUMzQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDO0lBQ3JDLENBQUM7SUFDTSx5QkFBeUI7UUFDOUIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLFNBQVMsQ0FBQztJQUN6QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDO0lBQ3BDLENBQUM7Q0FDRjtBQS9DRCxnSEErQ0M7QUFFRDs7RUFFRTtBQUNGLE1BQWEsd0JBQXlCLFNBQVEsS0FBSyxDQUFDLGlCQUFpQjtJQU9uRSxpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQjs7Ozs7O01BTUU7SUFDSyxNQUFNLENBQUMsdUJBQXVCLENBQUMsS0FBZ0IsRUFBRSxVQUFrQixFQUFFLFlBQW9CLEVBQUUsUUFBa0M7UUFDOUgsT0FBTyxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUscUJBQXFCLEVBQUUseUNBQXlDLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ2pLLENBQUM7SUFFTCxjQUFjO0lBQ2QsY0FBYztJQUNkLGNBQWM7SUFFZDs7Ozs7O01BTUU7SUFDRixZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxNQUFzQztRQUNyRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLHFCQUFxQixFQUFFLHlDQUF5QztZQUNoRSwwQkFBMEIsRUFBRTtnQkFDMUIsWUFBWSxFQUFFLGNBQWM7Z0JBQzVCLGVBQWUsRUFBRSxRQUFRO2dCQUN6Qix5QkFBeUIsRUFBRSxRQUFRO2FBQ3BDO1lBQ0QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO1lBQ3pCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO1lBQzNCLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtZQUNqQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7WUFDN0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1NBQ3hCLENBQUMsQ0FBQztRQXkyQkwsK0RBQStEO1FBQ3ZELGVBQVUsR0FBRyxJQUFJLHFDQUFxQyxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFlekYsaUVBQWlFO1FBQ3pELGlCQUFZLEdBQUcsSUFBSSxrREFBa0QsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7UUF6M0JqRyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQywyQkFBMkIsR0FBRyxNQUFNLENBQUMsMEJBQTBCLENBQUM7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMscUJBQXFCLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixDQUFDO1FBQ3pELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLDBCQUEwQixHQUFHLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztRQUNuRSxJQUFJLENBQUMsMEJBQTBCLEdBQUcsTUFBTSxDQUFDLHlCQUF5QixDQUFDO1FBQ25FLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxNQUFNLENBQUMsMkJBQTJCLENBQUM7UUFDdkUsSUFBSSxDQUFDLDBCQUEwQixHQUFHLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztRQUNuRSxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDckMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDO1FBQ3JELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxNQUFNLENBQUMsbUJBQW1CLENBQUM7UUFDdkQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFDbkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7UUFDL0MsSUFBSSxDQUFDLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztRQUMvRCxJQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGdDQUFnQyxHQUFHLE1BQU0sQ0FBQywrQkFBK0IsQ0FBQztRQUMvRSxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFDdkIsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQztRQUNqRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLHVCQUF1QixDQUFDO1FBQy9ELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDckQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDckQsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsMkJBQTJCLEdBQUcsTUFBTSxDQUFDLDBCQUEwQixDQUFDO1FBQ3JFLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLG9CQUFvQixHQUFHLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQztRQUN2RCxJQUFJLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDM0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMseUJBQXlCLEdBQUcsTUFBTSxDQUFDLHdCQUF3QixDQUFDO1FBQ2pFLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDO1FBQ3JELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQztRQUNqRCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzNELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQzNDLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNqQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDO1FBQzdELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1FBQzdDLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQ2pELElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQ3ZELENBQUM7SUFRRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDRCxJQUFXLDRCQUE0QixDQUFDLEtBQWE7UUFDbkQsSUFBSSxDQUFDLDZCQUE2QixHQUFHLEtBQUssQ0FBQztJQUM3QyxDQUFDO0lBQ00saUNBQWlDO1FBQ3RDLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxTQUFTLENBQUM7SUFDakQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlDQUFpQztRQUMxQyxPQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztJQUM1QyxDQUFDO0lBSUQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ0QsSUFBVywwQkFBMEIsQ0FBQyxLQUFhO1FBQ2pELElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUM7SUFDM0MsQ0FBQztJQUNNLCtCQUErQjtRQUNwQyxJQUFJLENBQUMsMkJBQTJCLEdBQUcsU0FBUyxDQUFDO0lBQy9DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywrQkFBK0I7UUFDeEMsT0FBTyxJQUFJLENBQUMsMkJBQTJCLENBQUM7SUFDMUMsQ0FBQztJQUlELElBQVcsc0JBQXNCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcsc0JBQXNCLENBQUMsS0FBYTtRQUM3QyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFDRCxJQUFXLHlCQUF5QixDQUFDLEtBQWE7UUFDaEQsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQztJQUMxQyxDQUFDO0lBQ00sOEJBQThCO1FBQ25DLElBQUksQ0FBQywwQkFBMEIsR0FBRyxTQUFTLENBQUM7SUFDOUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDhCQUE4QjtRQUN2QyxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQztJQUN6QyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDZCQUE2QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLFVBQVU7UUFDbkIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQVcsVUFBVSxDQUFDLEtBQWE7UUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7SUFDM0IsQ0FBQztJQUNNLGVBQWU7UUFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7SUFDL0IsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFJRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELElBQVcsWUFBWSxDQUFDLEtBQWE7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUNNLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUJBQWlCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBSUQsSUFBVyxhQUFhO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQVcsYUFBYSxDQUFDLEtBQWE7UUFDcEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNNLGtCQUFrQjtRQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztJQUNsQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsa0JBQWtCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM3QixDQUFDO0lBSUQsSUFBVyxrQkFBa0I7UUFDM0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxrQkFBa0IsQ0FBQyxLQUFhO1FBQ3pDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUM7SUFDbkMsQ0FBQztJQUNNLHVCQUF1QjtRQUM1QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsU0FBUyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDbEMsQ0FBQztJQUlELElBQVcsbUJBQW1CO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUNELElBQVcsbUJBQW1CLENBQUMsS0FBYTtRQUMxQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsS0FBSyxDQUFDO0lBQ3BDLENBQUM7SUFDTSx3QkFBd0I7UUFDN0IsSUFBSSxDQUFDLG9CQUFvQixHQUFHLFNBQVMsQ0FBQztJQUN4QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsd0JBQXdCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDO0lBQ25DLENBQUM7SUFJRCxJQUFXLHFCQUFxQjtRQUM5QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFDRCxJQUFXLHFCQUFxQixDQUFDLEtBQWE7UUFDNUMsSUFBSSxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQztJQUN0QyxDQUFDO0lBQ00sMEJBQTBCO1FBQy9CLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxTQUFTLENBQUM7SUFDMUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDBCQUEwQjtRQUNuQyxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztJQUNyQyxDQUFDO0lBSUQsSUFBVyxTQUFTO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFXLFNBQVMsQ0FBQyxLQUFhO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN6QixDQUFDO0lBSUQsSUFBVyxlQUFlO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDckQsQ0FBQztJQUNELElBQVcsZUFBZSxDQUFDLEtBQWE7UUFDdEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztJQUNoQyxDQUFDO0lBQ00sb0JBQW9CO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxTQUFTLENBQUM7SUFDcEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUMvQixDQUFDO0lBSUQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFhO1FBQzlDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUNNLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0lBQzVDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw0QkFBNEI7UUFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUlELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFXLEVBQUUsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFDTSxPQUFPO1FBQ1osSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2xCLENBQUM7SUFJRCxJQUFXLCtCQUErQjtRQUN4QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFDRCxJQUFXLCtCQUErQixDQUFDLEtBQWE7UUFDdEQsSUFBSSxDQUFDLGdDQUFnQyxHQUFHLEtBQUssQ0FBQztJQUNoRCxDQUFDO0lBQ00sb0NBQW9DO1FBQ3pDLElBQUksQ0FBQyxnQ0FBZ0MsR0FBRyxTQUFTLENBQUM7SUFDcEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG9DQUFvQztRQUM3QyxPQUFPLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQztJQUMvQyxDQUFDO0lBSUQsSUFBVyxHQUFHO1FBQ1osT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQVcsR0FBRyxDQUFDLEtBQWtDO1FBQy9DLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLENBQUM7SUFDTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7SUFDeEIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25CLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBYTtRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFhO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUM7SUFDdkMsQ0FBQztJQUNNLDJCQUEyQjtRQUNoQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsU0FBUyxDQUFDO0lBQzNDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEMsQ0FBQztJQUlELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlDQUFpQyxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUNELElBQVcsNEJBQTRCLENBQUMsS0FBYTtRQUNuRCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFDTSxpQ0FBaUM7UUFDdEMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLFNBQVMsQ0FBQztJQUNqRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDO0lBQzVDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdDQUFnQyxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUNELElBQVcsMEJBQTBCLENBQUMsS0FBYTtRQUNqRCxJQUFJLENBQUMsMkJBQTJCLEdBQUcsS0FBSyxDQUFDO0lBQzNDLENBQUM7SUFDTSwrQkFBK0I7UUFDcEMsSUFBSSxDQUFDLDJCQUEyQixHQUFHLFNBQVMsQ0FBQztJQUMvQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsK0JBQStCO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLDJCQUEyQixDQUFDO0lBQzFDLENBQUM7SUFJRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFDRCxJQUFXLHVCQUF1QixDQUFDLEtBQWE7UUFDOUMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQztJQUN4QyxDQUFDO0lBQ00sNEJBQTRCO1FBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxTQUFTLENBQUM7SUFDNUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztJQUN2QyxDQUFDO0lBSUQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBQ0QsSUFBVyxtQkFBbUIsQ0FBQyxLQUFhO1FBQzFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUNNLHdCQUF3QjtRQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFDbkMsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsc0JBQXNCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcsc0JBQXNCLENBQUMsS0FBYTtRQUM3QyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxhQUFhO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQVcsYUFBYSxDQUFDLEtBQWE7UUFDcEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNNLGtCQUFrQjtRQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztJQUNsQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsa0JBQWtCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM3QixDQUFDO0lBSUQsSUFBVyxrQkFBa0I7UUFDM0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxrQkFBa0IsQ0FBQyxLQUFhO1FBQ3pDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUM7SUFDbkMsQ0FBQztJQUNNLHVCQUF1QjtRQUM1QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsU0FBUyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDbEMsQ0FBQztJQUlELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUNELElBQVcsb0JBQW9CLENBQUMsS0FBYTtRQUMzQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDO0lBQ3JDLENBQUM7SUFDTSx5QkFBeUI7UUFDOUIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLFNBQVMsQ0FBQztJQUN6QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDO0lBQ3BDLENBQUM7SUFJRCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGdCQUFnQixDQUFDLEtBQWE7UUFDdkMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBQ00scUJBQXFCO1FBQzFCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxTQUFTLENBQUM7SUFDckMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHFCQUFxQjtRQUM5QixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztJQUNoQyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBYTtRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGFBQWE7UUFDdEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBVyxhQUFhLENBQUMsS0FBYTtRQUNwQyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUM5QixDQUFDO0lBQ00sa0JBQWtCO1FBQ3ZCLElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO0lBQ2xDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxrQkFBa0I7UUFDM0IsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO0lBQzdCLENBQUM7SUFJRCxJQUFXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQVcsUUFBUSxDQUFDLEtBQWE7UUFDL0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDekIsQ0FBQztJQUNNLGFBQWE7UUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7SUFDN0IsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGFBQWE7UUFDdEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3hCLENBQUM7SUFJRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWE7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyxvQkFBb0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0QsSUFBVyxvQkFBb0IsQ0FBQyxLQUFhO1FBQzNDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7SUFDckMsQ0FBQztJQUNNLHlCQUF5QjtRQUM5QixJQUFJLENBQUMscUJBQXFCLEdBQUcsU0FBUyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx5QkFBeUI7UUFDbEMsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUM7SUFDcEMsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFJRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBQ0QsSUFBVyxjQUFjLENBQUMsS0FBYTtRQUNyQyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBQ00sbUJBQW1CO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO0lBQ25DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFJRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQVcsT0FBTyxDQUFDLEtBQWE7UUFDOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDeEIsQ0FBQztJQUNNLFlBQVk7UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7SUFDNUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFDTSxZQUFZLENBQUMsS0FBOEQ7UUFDaEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSxjQUFjO1FBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLFdBQVc7UUFDcEIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFDTSxjQUFjLENBQUMsS0FBMEM7UUFDOUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSxnQkFBZ0I7UUFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztJQUN6QyxDQUFDO0lBRUQsWUFBWTtJQUNaLFlBQVk7SUFDWixZQUFZO0lBRUYsb0JBQW9CO1FBQzVCLE9BQU87WUFDTCwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO1lBQzVGLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7WUFDdkYseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUNoRixzQkFBc0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO1lBQzNFLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFDcEUsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztZQUN0Riw0QkFBNEIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDO1lBQ3RGLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7WUFDMUYsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztZQUNyRixXQUFXLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDdEQsYUFBYSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQzFELGNBQWMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUM1RCxvQkFBb0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1lBQ3ZFLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDekUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztZQUM3RSxVQUFVLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDcEQsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNoRSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ2pGLEVBQUUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNyQyxtQ0FBbUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxDQUFDO1lBQ25HLEdBQUcsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN4QywyQkFBMkIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1lBQ3BGLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFDckUsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzdELDBCQUEwQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7WUFDbEYscUJBQXFCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN4RSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1lBQ2hGLCtCQUErQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7WUFDNUYsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN2RSwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO1lBQzNGLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7WUFDekYseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNqRixxQkFBcUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3pFLGVBQWUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUM3RCx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1lBQ2hGLDJCQUEyQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7WUFDcEYsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzdELG9CQUFvQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7WUFDdkUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUM1RSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ3BFLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7WUFDOUUseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNqRixlQUFlLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7WUFDN0QsUUFBUSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2pELHlCQUF5QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDaEYsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUMzRSxlQUFlLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDOUQsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzdELGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDbkUsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsUUFBUSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ2hELFNBQVMsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLDRDQUE0QyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBQzlHLFdBQVcsRUFBRSw4Q0FBOEMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztTQUM3RixDQUFDO0lBQ0osQ0FBQztJQUVTLHVCQUF1QjtRQUMvQixNQUFNLEtBQUssR0FBRztZQUNaLCtCQUErQixFQUFFO2dCQUMvQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztnQkFDckUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQztnQkFDbkUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHlCQUF5QixFQUFFO2dCQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztnQkFDL0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHNCQUFzQixFQUFFO2dCQUN0QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDMUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDhCQUE4QixFQUFFO2dCQUM5QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztnQkFDcEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFdBQVcsRUFBRTtnQkFDWCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7Z0JBQ25ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsY0FBYyxFQUFFO2dCQUNkLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG9CQUFvQixFQUFFO2dCQUNwQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztnQkFDM0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHFCQUFxQixFQUFFO2dCQUNyQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztnQkFDNUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHVCQUF1QixFQUFFO2dCQUN2QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztnQkFDOUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFVBQVUsRUFBRTtnQkFDVixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7Z0JBQ2xELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxFQUFFLEVBQUU7Z0JBQ0YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUMzQyxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsbUNBQW1DLEVBQUU7Z0JBQ25DLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxDQUFDO2dCQUN4RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsR0FBRyxFQUFFO2dCQUNILEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDN0MsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDakUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDMUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwwQkFBMEIsRUFBRTtnQkFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7Z0JBQ3JFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7Z0JBQ3BFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw4QkFBOEIsRUFBRTtnQkFDOUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ25FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7Z0JBQzVELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxlQUFlLEVBQUU7Z0JBQ2YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO2dCQUN0RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUMvRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsMkJBQTJCLEVBQUU7Z0JBQzNCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO2dCQUNqRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG9CQUFvQixFQUFFO2dCQUNwQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztnQkFDM0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHVCQUF1QixFQUFFO2dCQUN2QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDekQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHdCQUF3QixFQUFFO2dCQUN4QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztnQkFDOUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHlCQUF5QixFQUFFO2dCQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztnQkFDaEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxRQUFRLEVBQUU7Z0JBQ1IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNqRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUMvRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsc0JBQXNCLEVBQUU7Z0JBQ3RCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDdkQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxrQkFBa0IsRUFBRTtnQkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7Z0JBQ3pELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUN2RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsUUFBUSxFQUFFO2dCQUNSLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDaEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFNBQVMsRUFBRTtnQkFDVCxLQUFLLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQywrQ0FBK0MsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztnQkFDaEgsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osZ0JBQWdCLEVBQUUsdUNBQXVDO2FBQzFEO1lBQ0QsV0FBVyxFQUFFO2dCQUNYLEtBQUssRUFBRSxpREFBaUQsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztnQkFDekYsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osZ0JBQWdCLEVBQUUseUNBQXlDO2FBQzVEO1NBQ0YsQ0FBQztRQUVGLDhCQUE4QjtRQUM5QixPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsS0FBSyxLQUFLLFNBQVMsQ0FBRSxDQUFDLENBQUE7SUFDNUgsQ0FBQzs7QUExekNILDREQTJ6Q0M7QUF6ekNDLG9CQUFvQjtBQUNwQixvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ0csdUNBQWMsR0FBRyx5Q0FBeUMsQUFBNUMsQ0FBNkMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWdcbi8vIGdlbmVyYXRlZCBmcm9tIHRlcnJhZm9ybSByZXNvdXJjZSBzY2hlbWFcblxuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBjZGt0biBmcm9tICdjZGt0bic7XG5cbi8vIENvbmZpZ3VyYXRpb25cblxuZXhwb3J0IGludGVyZmFjZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdDb25maWcgZXh0ZW5kcyBjZGt0bi5UZXJyYWZvcm1NZXRhQXJndW1lbnRzIHtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV9hbmFseXplX3NjYWxlX2ZhY3RvciBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV9hbmFseXplX3NjYWxlX2ZhY3Rvcn1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bUFuYWx5emVTY2FsZUZhY3Rvcj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV9hbmFseXplX3RocmVzaG9sZCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV9hbmFseXplX3RocmVzaG9sZH1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fZnJlZXplX21heF9hZ2UgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG92YWN1dW1fZnJlZXplX21heF9hZ2V9XG4gICovXG4gIHJlYWRvbmx5IGF1dG92YWN1dW1GcmVlemVNYXhBZ2U/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fbWF4X3dvcmtlcnMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG92YWN1dW1fbWF4X3dvcmtlcnN9XG4gICovXG4gIHJlYWRvbmx5IGF1dG92YWN1dW1NYXhXb3JrZXJzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNhdXRvdmFjdXVtX25hcHRpbWUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG92YWN1dW1fbmFwdGltZX1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bU5hcHRpbWU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fdmFjdXVtX2Nvc3RfZGVsYXkgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG92YWN1dW1fdmFjdXVtX2Nvc3RfZGVsYXl9XG4gICovXG4gIHJlYWRvbmx5IGF1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXk/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fdmFjdXVtX2Nvc3RfbGltaXQgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG92YWN1dW1fdmFjdXVtX2Nvc3RfbGltaXR9XG4gICovXG4gIHJlYWRvbmx5IGF1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fdmFjdXVtX3NjYWxlX2ZhY3RvciBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fc2NhbGVfZmFjdG9yfVxuICAqL1xuICByZWFkb25seSBhdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3I/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fdmFjdXVtX3RocmVzaG9sZCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fdGhyZXNob2xkfVxuICAqL1xuICByZWFkb25seSBhdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNiYWNrdXBfaG91ciBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYmFja3VwX2hvdXJ9XG4gICovXG4gIHJlYWRvbmx5IGJhY2t1cEhvdXI/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2JhY2t1cF9taW51dGUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2JhY2t1cF9taW51dGV9XG4gICovXG4gIHJlYWRvbmx5IGJhY2t1cE1pbnV0ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYmd3cml0ZXJfZGVsYXkgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2Jnd3JpdGVyX2RlbGF5fVxuICAqL1xuICByZWFkb25seSBiZ3dyaXRlckRlbGF5PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNiZ3dyaXRlcl9mbHVzaF9hZnRlciBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYmd3cml0ZXJfZmx1c2hfYWZ0ZXJ9XG4gICovXG4gIHJlYWRvbmx5IGJnd3JpdGVyRmx1c2hBZnRlcj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYmd3cml0ZXJfbHJ1X21heHBhZ2VzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNiZ3dyaXRlcl9scnVfbWF4cGFnZXN9XG4gICovXG4gIHJlYWRvbmx5IGJnd3JpdGVyTHJ1TWF4cGFnZXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2Jnd3JpdGVyX2xydV9tdWx0aXBsaWVyIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNiZ3dyaXRlcl9scnVfbXVsdGlwbGllcn1cbiAgKi9cbiAgcmVhZG9ubHkgYmd3cml0ZXJMcnVNdWx0aXBsaWVyPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNjbHVzdGVyX2lkIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNjbHVzdGVyX2lkfVxuICAqL1xuICByZWFkb25seSBjbHVzdGVySWQ6IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjZGVhZGxvY2tfdGltZW91dCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjZGVhZGxvY2tfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgZGVhZGxvY2tUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNkZWZhdWx0X3RvYXN0X2NvbXByZXNzaW9uIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNkZWZhdWx0X3RvYXN0X2NvbXByZXNzaW9ufVxuICAqL1xuICByZWFkb25seSBkZWZhdWx0VG9hc3RDb21wcmVzc2lvbj86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjaWQgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2lkfVxuICAqXG4gICogUGxlYXNlIGJlIGF3YXJlIHRoYXQgdGhlIGlkIGZpZWxkIGlzIGF1dG9tYXRpY2FsbHkgYWRkZWQgdG8gYWxsIHJlc291cmNlcyBpbiBUZXJyYWZvcm0gcHJvdmlkZXJzIHVzaW5nIGEgVGVycmFmb3JtIHByb3ZpZGVyIFNESyB2ZXJzaW9uIGJlbG93IDIuXG4gICogSWYgeW91IGV4cGVyaWVuY2UgcHJvYmxlbXMgc2V0dGluZyB0aGlzIHZhbHVlIGl0IG1pZ2h0IG5vdCBiZSBzZXR0YWJsZS4gUGxlYXNlIHRha2UgYSBsb29rIGF0IHRoZSBwcm92aWRlciBkb2N1bWVudGF0aW9uIHRvIGVuc3VyZSBpdCBzaG91bGQgYmUgc2V0dGFibGUuXG4gICovXG4gIHJlYWRvbmx5IGlkPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNpZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IGlkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2ppdCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjaml0fVxuICAqL1xuICByZWFkb25seSBqaXQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2xvZ19hdXRvdmFjdXVtX21pbl9kdXJhdGlvbiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbG9nX2F1dG92YWN1dW1fbWluX2R1cmF0aW9ufVxuICAqL1xuICByZWFkb25seSBsb2dBdXRvdmFjdXVtTWluRHVyYXRpb24/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2xvZ19lcnJvcl92ZXJib3NpdHkgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2xvZ19lcnJvcl92ZXJib3NpdHl9XG4gICovXG4gIHJlYWRvbmx5IGxvZ0Vycm9yVmVyYm9zaXR5Pzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNsb2dfbGluZV9wcmVmaXggRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2xvZ19saW5lX3ByZWZpeH1cbiAgKi9cbiAgcmVhZG9ubHkgbG9nTGluZVByZWZpeD86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbG9nX21pbl9kdXJhdGlvbl9zdGF0ZW1lbnQgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2xvZ19taW5fZHVyYXRpb25fc3RhdGVtZW50fVxuICAqL1xuICByZWFkb25seSBsb2dNaW5EdXJhdGlvblN0YXRlbWVudD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X2ZpbGVzX3Blcl9wcm9jZXNzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfZmlsZXNfcGVyX3Byb2Nlc3N9XG4gICovXG4gIHJlYWRvbmx5IG1heEZpbGVzUGVyUHJvY2Vzcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X2xvY2tzX3Blcl90cmFuc2FjdGlvbiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X2xvY2tzX3Blcl90cmFuc2FjdGlvbn1cbiAgKi9cbiAgcmVhZG9ubHkgbWF4TG9ja3NQZXJUcmFuc2FjdGlvbj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X2xvZ2ljYWxfcmVwbGljYXRpb25fd29ya2VycyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X2xvZ2ljYWxfcmVwbGljYXRpb25fd29ya2Vyc31cbiAgKi9cbiAgcmVhZG9ubHkgbWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2Vycz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X3BhcmFsbGVsX3dvcmtlcnMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9wYXJhbGxlbF93b3JrZXJzfVxuICAqL1xuICByZWFkb25seSBtYXhQYXJhbGxlbFdvcmtlcnM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21heF9wYXJhbGxlbF93b3JrZXJzX3Blcl9nYXRoZXIgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9wYXJhbGxlbF93b3JrZXJzX3Blcl9nYXRoZXJ9XG4gICovXG4gIHJlYWRvbmx5IG1heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlcj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X3ByZWRfbG9ja3NfcGVyX3RyYW5zYWN0aW9uIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfcHJlZF9sb2Nrc19wZXJfdHJhbnNhY3Rpb259XG4gICovXG4gIHJlYWRvbmx5IG1heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfcHJlcGFyZWRfdHJhbnNhY3Rpb25zIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfcHJlcGFyZWRfdHJhbnNhY3Rpb25zfVxuICAqL1xuICByZWFkb25seSBtYXhQcmVwYXJlZFRyYW5zYWN0aW9ucz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X3JlcGxpY2F0aW9uX3Nsb3RzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfcmVwbGljYXRpb25fc2xvdHN9XG4gICovXG4gIHJlYWRvbmx5IG1heFJlcGxpY2F0aW9uU2xvdHM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21heF9zdGFja19kZXB0aCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X3N0YWNrX2RlcHRofVxuICAqL1xuICByZWFkb25seSBtYXhTdGFja0RlcHRoPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfc3RhbmRieV9hcmNoaXZlX2RlbGF5IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfc3RhbmRieV9hcmNoaXZlX2RlbGF5fVxuICAqL1xuICByZWFkb25seSBtYXhTdGFuZGJ5QXJjaGl2ZURlbGF5PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfc3RhbmRieV9zdHJlYW1pbmdfZGVsYXkgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9zdGFuZGJ5X3N0cmVhbWluZ19kZWxheX1cbiAgKi9cbiAgcmVhZG9ubHkgbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfd2FsX3NlbmRlcnMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF93YWxfc2VuZGVyc31cbiAgKi9cbiAgcmVhZG9ubHkgbWF4V2FsU2VuZGVycz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X3dvcmtlcl9wcm9jZXNzZXMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF93b3JrZXJfcHJvY2Vzc2VzfVxuICAqL1xuICByZWFkb25seSBtYXhXb3JrZXJQcm9jZXNzZXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3BnX3BhcnRtYW5fYmd3X2ludGVydmFsIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNwZ19wYXJ0bWFuX2Jnd19pbnRlcnZhbH1cbiAgKi9cbiAgcmVhZG9ubHkgcGdQYXJ0bWFuQmd3SW50ZXJ2YWw/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3BnX3BhcnRtYW5fYmd3X3JvbGUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3BnX3BhcnRtYW5fYmd3X3JvbGV9XG4gICovXG4gIHJlYWRvbmx5IHBnUGFydG1hbkJnd1JvbGU/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3BnX3N0YXRfc3RhdGVtZW50c190cmFjayBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjcGdfc3RhdF9zdGF0ZW1lbnRzX3RyYWNrfVxuICAqL1xuICByZWFkb25seSBwZ1N0YXRTdGF0ZW1lbnRzVHJhY2s/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3NoYXJlZF9idWZmZXJzX3BlcmNlbnRhZ2UgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3NoYXJlZF9idWZmZXJzX3BlcmNlbnRhZ2V9XG4gICovXG4gIHJlYWRvbmx5IHNoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN0ZW1wX2ZpbGVfbGltaXQgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3RlbXBfZmlsZV9saW1pdH1cbiAgKi9cbiAgcmVhZG9ubHkgdGVtcEZpbGVMaW1pdD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjdGltZXpvbmUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3RpbWV6b25lfVxuICAqL1xuICByZWFkb25seSB0aW1lem9uZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjdHJhY2tfYWN0aXZpdHlfcXVlcnlfc2l6ZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjdHJhY2tfYWN0aXZpdHlfcXVlcnlfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjdHJhY2tfY29tbWl0X3RpbWVzdGFtcCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjdHJhY2tfY29tbWl0X3RpbWVzdGFtcH1cbiAgKi9cbiAgcmVhZG9ubHkgdHJhY2tDb21taXRUaW1lc3RhbXA/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3RyYWNrX2Z1bmN0aW9ucyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjdHJhY2tfZnVuY3Rpb25zfVxuICAqL1xuICByZWFkb25seSB0cmFja0Z1bmN0aW9ucz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjdHJhY2tfaW9fdGltaW5nIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyN0cmFja19pb190aW1pbmd9XG4gICovXG4gIHJlYWRvbmx5IHRyYWNrSW9UaW1pbmc/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3dhbF9zZW5kZXJfdGltZW91dCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjd2FsX3NlbmRlcl90aW1lb3V0fVxuICAqL1xuICByZWFkb25seSB3YWxTZW5kZXJUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN3YWxfd3JpdGVyX2RlbGF5IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyN3YWxfd3JpdGVyX2RlbGF5fVxuICAqL1xuICByZWFkb25seSB3YWxXcml0ZXJEZWxheT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjd29ya19tZW0gRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3dvcmtfbWVtfVxuICAqL1xuICByZWFkb25seSB3b3JrTWVtPzogbnVtYmVyO1xuICAvKipcbiAgKiBwZ2JvdW5jZXIgYmxvY2tcbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3BnYm91bmNlciBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjcGdib3VuY2VyfVxuICAqL1xuICByZWFkb25seSBwZ2JvdW5jZXI/OiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJbXSB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiB0aW1lc2NhbGVkYiBibG9ja1xuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjdGltZXNjYWxlZGIgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3RpbWVzY2FsZWRifVxuICAqL1xuICByZWFkb25seSB0aW1lc2NhbGVkYj86IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiO1xufVxuZXhwb3J0IGludGVyZmFjZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXIge1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNhdXRvZGJfaWRsZV90aW1lb3V0IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvZGJfaWRsZV90aW1lb3V0fVxuICAqL1xuICByZWFkb25seSBhdXRvZGJJZGxlVGltZW91dD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b2RiX21heF9kYl9jb25uZWN0aW9ucyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b2RiX21heF9kYl9jb25uZWN0aW9uc31cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b2RiTWF4RGJDb25uZWN0aW9ucz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b2RiX3Bvb2xfbW9kZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b2RiX3Bvb2xfbW9kZX1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b2RiUG9vbE1vZGU/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG9kYl9wb29sX3NpemUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG9kYl9wb29sX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IGF1dG9kYlBvb2xTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNpZ25vcmVfc3RhcnR1cF9wYXJhbWV0ZXJzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNpZ25vcmVfc3RhcnR1cF9wYXJhbWV0ZXJzfVxuICAqL1xuICByZWFkb25seSBpZ25vcmVTdGFydHVwUGFyYW1ldGVycz86IHN0cmluZ1tdO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtaW5fcG9vbF9zaXplIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtaW5fcG9vbF9zaXplfVxuICAqL1xuICByZWFkb25seSBtaW5Qb29sU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjc2VydmVyX2lkbGVfdGltZW91dCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjc2VydmVyX2lkbGVfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgc2VydmVySWRsZVRpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3NlcnZlcl9saWZldGltZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjc2VydmVyX2xpZmV0aW1lfVxuICAqL1xuICByZWFkb25seSBzZXJ2ZXJMaWZldGltZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjc2VydmVyX3Jlc2V0X3F1ZXJ5X2Fsd2F5cyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjc2VydmVyX3Jlc2V0X3F1ZXJ5X2Fsd2F5c31cbiAgKi9cbiAgcmVhZG9ubHkgc2VydmVyUmVzZXRRdWVyeUFsd2F5cz86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlclRvVGVycmFmb3JtKHN0cnVjdD86IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlciB8IGNka3RuLklSZXNvbHZhYmxlKTogYW55IHtcbiAgaWYgKCFjZGt0bi5jYW5JbnNwZWN0KHN0cnVjdCkgfHwgY2RrdG4uVG9rZW5pemF0aW9uLmlzUmVzb2x2YWJsZShzdHJ1Y3QpKSB7IHJldHVybiBzdHJ1Y3Q7IH1cbiAgaWYgKGNka3RuLmlzQ29tcGxleEVsZW1lbnQoc3RydWN0KSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkEgY29tcGxleCBlbGVtZW50IHdhcyB1c2VkIGFzIGNvbmZpZ3VyYXRpb24sIHRoaXMgaXMgbm90IHN1cHBvcnRlZDogaHR0cHM6Ly9jZGsudGYvY29tcGxleC1vYmplY3QtYXMtY29uZmlndXJhdGlvblwiKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGF1dG9kYl9pZGxlX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHN0cnVjdCEuYXV0b2RiSWRsZVRpbWVvdXQpLFxuICAgIGF1dG9kYl9tYXhfZGJfY29ubmVjdGlvbnM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHN0cnVjdCEuYXV0b2RiTWF4RGJDb25uZWN0aW9ucyksXG4gICAgYXV0b2RiX3Bvb2xfbW9kZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJQb29sTW9kZSksXG4gICAgYXV0b2RiX3Bvb2xfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJQb29sU2l6ZSksXG4gICAgaWdub3JlX3N0YXJ0dXBfcGFyYW1ldGVyczogY2RrdG4ubGlzdE1hcHBlcihjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSwgZmFsc2UpKHN0cnVjdCEuaWdub3JlU3RhcnR1cFBhcmFtZXRlcnMpLFxuICAgIG1pbl9wb29sX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHN0cnVjdCEubWluUG9vbFNpemUpLFxuICAgIHNlcnZlcl9pZGxlX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHN0cnVjdCEuc2VydmVySWRsZVRpbWVvdXQpLFxuICAgIHNlcnZlcl9saWZldGltZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5zZXJ2ZXJMaWZldGltZSksXG4gICAgc2VydmVyX3Jlc2V0X3F1ZXJ5X2Fsd2F5czogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHN0cnVjdCEuc2VydmVyUmVzZXRRdWVyeUFsd2F5cyksXG4gIH1cbn1cblxuXG5leHBvcnQgZnVuY3Rpb24gZGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyVG9IY2xUZXJyYWZvcm0oc3RydWN0PzogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyIHwgY2RrdG4uSVJlc29sdmFibGUpOiBhbnkge1xuICBpZiAoIWNka3RuLmNhbkluc3BlY3Qoc3RydWN0KSB8fCBjZGt0bi5Ub2tlbml6YXRpb24uaXNSZXNvbHZhYmxlKHN0cnVjdCkpIHsgcmV0dXJuIHN0cnVjdDsgfVxuICBpZiAoY2RrdG4uaXNDb21wbGV4RWxlbWVudChzdHJ1Y3QpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQSBjb21wbGV4IGVsZW1lbnQgd2FzIHVzZWQgYXMgY29uZmlndXJhdGlvbiwgdGhpcyBpcyBub3Qgc3VwcG9ydGVkOiBodHRwczovL2Nkay50Zi9jb21wbGV4LW9iamVjdC1hcy1jb25maWd1cmF0aW9uXCIpO1xuICB9XG4gIGNvbnN0IGF0dHJzID0ge1xuICAgIGF1dG9kYl9pZGxlX3RpbWVvdXQ6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLmF1dG9kYklkbGVUaW1lb3V0KSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgfSxcbiAgICBhdXRvZGJfbWF4X2RiX2Nvbm5lY3Rpb25zOiB7XG4gICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJNYXhEYkNvbm5lY3Rpb25zKSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgfSxcbiAgICBhdXRvZGJfcG9vbF9tb2RlOiB7XG4gICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJQb29sTW9kZSksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgIH0sXG4gICAgYXV0b2RiX3Bvb2xfc2l6ZToge1xuICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHN0cnVjdCEuYXV0b2RiUG9vbFNpemUpLFxuICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICB9LFxuICAgIGlnbm9yZV9zdGFydHVwX3BhcmFtZXRlcnM6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5saXN0TWFwcGVySGNsKGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtLCBmYWxzZSkoc3RydWN0IS5pZ25vcmVTdGFydHVwUGFyYW1ldGVycyksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2V0XCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ0xpc3RcIixcbiAgICB9LFxuICAgIG1pbl9wb29sX3NpemU6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLm1pblBvb2xTaXplKSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgfSxcbiAgICBzZXJ2ZXJfaWRsZV90aW1lb3V0OiB7XG4gICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0oc3RydWN0IS5zZXJ2ZXJJZGxlVGltZW91dCksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgIH0sXG4gICAgc2VydmVyX2xpZmV0aW1lOiB7XG4gICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0oc3RydWN0IS5zZXJ2ZXJMaWZldGltZSksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgIH0sXG4gICAgc2VydmVyX3Jlc2V0X3F1ZXJ5X2Fsd2F5czoge1xuICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybShzdHJ1Y3QhLnNlcnZlclJlc2V0UXVlcnlBbHdheXMpLFxuICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgfSxcbiAgfTtcblxuICAvLyByZW1vdmUgdW5kZWZpbmVkIGF0dHJpYnV0ZXNcbiAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhhdHRycykuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnZhbHVlICE9PSB1bmRlZmluZWQpKTtcbn1cblxuZXhwb3J0IGNsYXNzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlck91dHB1dFJlZmVyZW5jZSBleHRlbmRzIGNka3RuLkNvbXBsZXhPYmplY3Qge1xuICBwcml2YXRlIGlzRW1wdHlPYmplY3QgPSBmYWxzZTtcbiAgcHJpdmF0ZSByZXNvbHZhYmxlVmFsdWU/OiBjZGt0bi5JUmVzb2x2YWJsZTtcblxuICAvKipcbiAgKiBAcGFyYW0gdGVycmFmb3JtUmVzb3VyY2UgVGhlIHBhcmVudCByZXNvdXJjZVxuICAqIEBwYXJhbSB0ZXJyYWZvcm1BdHRyaWJ1dGUgVGhlIGF0dHJpYnV0ZSBvbiB0aGUgcGFyZW50IHJlc291cmNlIHRoaXMgY2xhc3MgaXMgcmVmZXJlbmNpbmdcbiAgKiBAcGFyYW0gY29tcGxleE9iamVjdEluZGV4IHRoZSBpbmRleCBvZiB0aGlzIGl0ZW0gaW4gdGhlIGxpc3RcbiAgKiBAcGFyYW0gY29tcGxleE9iamVjdElzRnJvbVNldCB3aGV0aGVyIHRoZSBsaXN0IGlzIHdyYXBwaW5nIGEgc2V0ICh3aWxsIGFkZCB0b2xpc3QoKSB0byBiZSBhYmxlIHRvIGFjY2VzcyBhbiBpdGVtIHZpYSBhbiBpbmRleClcbiAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHRlcnJhZm9ybVJlc291cmNlOiBjZGt0bi5JSW50ZXJwb2xhdGluZ1BhcmVudCwgdGVycmFmb3JtQXR0cmlidXRlOiBzdHJpbmcsIGNvbXBsZXhPYmplY3RJbmRleDogbnVtYmVyLCBjb21wbGV4T2JqZWN0SXNGcm9tU2V0OiBib29sZWFuKSB7XG4gICAgc3VwZXIodGVycmFmb3JtUmVzb3VyY2UsIHRlcnJhZm9ybUF0dHJpYnV0ZSwgY29tcGxleE9iamVjdElzRnJvbVNldCwgY29tcGxleE9iamVjdEluZGV4KTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgaW50ZXJuYWxWYWx1ZSgpOiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXIgfCBjZGt0bi5JUmVzb2x2YWJsZSB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKHRoaXMucmVzb2x2YWJsZVZhbHVlKSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXNvbHZhYmxlVmFsdWU7XG4gICAgfVxuICAgIGxldCBoYXNBbnlWYWx1ZXMgPSB0aGlzLmlzRW1wdHlPYmplY3Q7XG4gICAgY29uc3QgaW50ZXJuYWxWYWx1ZVJlc3VsdDogYW55ID0ge307XG4gICAgaWYgKHRoaXMuX2F1dG9kYklkbGVUaW1lb3V0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0LmF1dG9kYklkbGVUaW1lb3V0ID0gdGhpcy5fYXV0b2RiSWRsZVRpbWVvdXQ7XG4gICAgfVxuICAgIGlmICh0aGlzLl9hdXRvZGJNYXhEYkNvbm5lY3Rpb25zICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0LmF1dG9kYk1heERiQ29ubmVjdGlvbnMgPSB0aGlzLl9hdXRvZGJNYXhEYkNvbm5lY3Rpb25zO1xuICAgIH1cbiAgICBpZiAodGhpcy5fYXV0b2RiUG9vbE1vZGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQuYXV0b2RiUG9vbE1vZGUgPSB0aGlzLl9hdXRvZGJQb29sTW9kZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2F1dG9kYlBvb2xTaXplICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0LmF1dG9kYlBvb2xTaXplID0gdGhpcy5fYXV0b2RiUG9vbFNpemU7XG4gICAgfVxuICAgIGlmICh0aGlzLl9pZ25vcmVTdGFydHVwUGFyYW1ldGVycyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBoYXNBbnlWYWx1ZXMgPSB0cnVlO1xuICAgICAgaW50ZXJuYWxWYWx1ZVJlc3VsdC5pZ25vcmVTdGFydHVwUGFyYW1ldGVycyA9IHRoaXMuX2lnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzO1xuICAgIH1cbiAgICBpZiAodGhpcy5fbWluUG9vbFNpemUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQubWluUG9vbFNpemUgPSB0aGlzLl9taW5Qb29sU2l6ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3NlcnZlcklkbGVUaW1lb3V0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0LnNlcnZlcklkbGVUaW1lb3V0ID0gdGhpcy5fc2VydmVySWRsZVRpbWVvdXQ7XG4gICAgfVxuICAgIGlmICh0aGlzLl9zZXJ2ZXJMaWZldGltZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBoYXNBbnlWYWx1ZXMgPSB0cnVlO1xuICAgICAgaW50ZXJuYWxWYWx1ZVJlc3VsdC5zZXJ2ZXJMaWZldGltZSA9IHRoaXMuX3NlcnZlckxpZmV0aW1lO1xuICAgIH1cbiAgICBpZiAodGhpcy5fc2VydmVyUmVzZXRRdWVyeUFsd2F5cyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBoYXNBbnlWYWx1ZXMgPSB0cnVlO1xuICAgICAgaW50ZXJuYWxWYWx1ZVJlc3VsdC5zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzID0gdGhpcy5fc2VydmVyUmVzZXRRdWVyeUFsd2F5cztcbiAgICB9XG4gICAgcmV0dXJuIGhhc0FueVZhbHVlcyA/IGludGVybmFsVmFsdWVSZXN1bHQgOiB1bmRlZmluZWQ7XG4gIH1cblxuICBwdWJsaWMgc2V0IGludGVybmFsVmFsdWUodmFsdWU6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlciB8IGNka3RuLklSZXNvbHZhYmxlIHwgdW5kZWZpbmVkKSB7XG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuaXNFbXB0eU9iamVjdCA9IGZhbHNlO1xuICAgICAgdGhpcy5yZXNvbHZhYmxlVmFsdWUgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9hdXRvZGJJZGxlVGltZW91dCA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX2F1dG9kYk1heERiQ29ubmVjdGlvbnMgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9hdXRvZGJQb29sTW9kZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX2F1dG9kYlBvb2xTaXplID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5faWdub3JlU3RhcnR1cFBhcmFtZXRlcnMgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9taW5Qb29sU2l6ZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX3NlcnZlcklkbGVUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fc2VydmVyTGlmZXRpbWUgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBlbHNlIGlmIChjZGt0bi5Ub2tlbml6YXRpb24uaXNSZXNvbHZhYmxlKHZhbHVlKSkge1xuICAgICAgdGhpcy5pc0VtcHR5T2JqZWN0ID0gZmFsc2U7XG4gICAgICB0aGlzLnJlc29sdmFibGVWYWx1ZSA9IHZhbHVlO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHRoaXMuaXNFbXB0eU9iamVjdCA9IE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGggPT09IDA7XG4gICAgICB0aGlzLnJlc29sdmFibGVWYWx1ZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX2F1dG9kYklkbGVUaW1lb3V0ID0gdmFsdWUuYXV0b2RiSWRsZVRpbWVvdXQ7XG4gICAgICB0aGlzLl9hdXRvZGJNYXhEYkNvbm5lY3Rpb25zID0gdmFsdWUuYXV0b2RiTWF4RGJDb25uZWN0aW9ucztcbiAgICAgIHRoaXMuX2F1dG9kYlBvb2xNb2RlID0gdmFsdWUuYXV0b2RiUG9vbE1vZGU7XG4gICAgICB0aGlzLl9hdXRvZGJQb29sU2l6ZSA9IHZhbHVlLmF1dG9kYlBvb2xTaXplO1xuICAgICAgdGhpcy5faWdub3JlU3RhcnR1cFBhcmFtZXRlcnMgPSB2YWx1ZS5pZ25vcmVTdGFydHVwUGFyYW1ldGVycztcbiAgICAgIHRoaXMuX21pblBvb2xTaXplID0gdmFsdWUubWluUG9vbFNpemU7XG4gICAgICB0aGlzLl9zZXJ2ZXJJZGxlVGltZW91dCA9IHZhbHVlLnNlcnZlcklkbGVUaW1lb3V0O1xuICAgICAgdGhpcy5fc2VydmVyTGlmZXRpbWUgPSB2YWx1ZS5zZXJ2ZXJMaWZldGltZTtcbiAgICAgIHRoaXMuX3NlcnZlclJlc2V0UXVlcnlBbHdheXMgPSB2YWx1ZS5zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzO1xuICAgIH1cbiAgfVxuXG4gIC8vIGF1dG9kYl9pZGxlX3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvZGJJZGxlVGltZW91dD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b2RiSWRsZVRpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvZGJfaWRsZV90aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvZGJJZGxlVGltZW91dCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b2RiSWRsZVRpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvZGJJZGxlVGltZW91dCgpIHtcbiAgICB0aGlzLl9hdXRvZGJJZGxlVGltZW91dCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b2RiSWRsZVRpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b2RiSWRsZVRpbWVvdXQ7XG4gIH1cblxuICAvLyBhdXRvZGJfbWF4X2RiX2Nvbm5lY3Rpb25zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b2RiTWF4RGJDb25uZWN0aW9ucz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b2RiTWF4RGJDb25uZWN0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG9kYl9tYXhfZGJfY29ubmVjdGlvbnMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG9kYk1heERiQ29ubmVjdGlvbnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG9kYk1heERiQ29ubmVjdGlvbnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvZGJNYXhEYkNvbm5lY3Rpb25zKCkge1xuICAgIHRoaXMuX2F1dG9kYk1heERiQ29ubmVjdGlvbnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG9kYk1heERiQ29ubmVjdGlvbnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b2RiTWF4RGJDb25uZWN0aW9ucztcbiAgfVxuXG4gIC8vIGF1dG9kYl9wb29sX21vZGUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvZGJQb29sTW9kZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgYXV0b2RiUG9vbE1vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdhdXRvZGJfcG9vbF9tb2RlJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvZGJQb29sTW9kZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fYXV0b2RiUG9vbE1vZGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvZGJQb29sTW9kZSgpIHtcbiAgICB0aGlzLl9hdXRvZGJQb29sTW9kZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b2RiUG9vbE1vZGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b2RiUG9vbE1vZGU7XG4gIH1cblxuICAvLyBhdXRvZGJfcG9vbF9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b2RiUG9vbFNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG9kYlBvb2xTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b2RiX3Bvb2xfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b2RiUG9vbFNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG9kYlBvb2xTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b2RiUG9vbFNpemUoKSB7XG4gICAgdGhpcy5fYXV0b2RiUG9vbFNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG9kYlBvb2xTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG9kYlBvb2xTaXplO1xuICB9XG5cbiAgLy8gaWdub3JlX3N0YXJ0dXBfcGFyYW1ldGVycyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzPzogc3RyaW5nW107IFxuICBwdWJsaWMgZ2V0IGlnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzKCkge1xuICAgIHJldHVybiBjZGt0bi5Gbi50b2xpc3QodGhpcy5nZXRMaXN0QXR0cmlidXRlKCdpZ25vcmVfc3RhcnR1cF9wYXJhbWV0ZXJzJykpO1xuICB9XG4gIHB1YmxpYyBzZXQgaWdub3JlU3RhcnR1cFBhcmFtZXRlcnModmFsdWU6IHN0cmluZ1tdKSB7XG4gICAgdGhpcy5faWdub3JlU3RhcnR1cFBhcmFtZXRlcnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJZ25vcmVTdGFydHVwUGFyYW1ldGVycygpIHtcbiAgICB0aGlzLl9pZ25vcmVTdGFydHVwUGFyYW1ldGVycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaWdub3JlU3RhcnR1cFBhcmFtZXRlcnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWdub3JlU3RhcnR1cFBhcmFtZXRlcnM7XG4gIH1cblxuICAvLyBtaW5fcG9vbF9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWluUG9vbFNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1pblBvb2xTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWluX3Bvb2xfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWluUG9vbFNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21pblBvb2xTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWluUG9vbFNpemUoKSB7XG4gICAgdGhpcy5fbWluUG9vbFNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1pblBvb2xTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21pblBvb2xTaXplO1xuICB9XG5cbiAgLy8gc2VydmVyX2lkbGVfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NlcnZlcklkbGVUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBzZXJ2ZXJJZGxlVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3NlcnZlcl9pZGxlX3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNlcnZlcklkbGVUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9zZXJ2ZXJJZGxlVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFNlcnZlcklkbGVUaW1lb3V0KCkge1xuICAgIHRoaXMuX3NlcnZlcklkbGVUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzZXJ2ZXJJZGxlVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9zZXJ2ZXJJZGxlVGltZW91dDtcbiAgfVxuXG4gIC8vIHNlcnZlcl9saWZldGltZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NlcnZlckxpZmV0aW1lPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBzZXJ2ZXJMaWZldGltZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3NlcnZlcl9saWZldGltZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgc2VydmVyTGlmZXRpbWUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3NlcnZlckxpZmV0aW1lID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U2VydmVyTGlmZXRpbWUoKSB7XG4gICAgdGhpcy5fc2VydmVyTGlmZXRpbWUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNlcnZlckxpZmV0aW1lSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NlcnZlckxpZmV0aW1lO1xuICB9XG5cbiAgLy8gc2VydmVyX3Jlc2V0X3F1ZXJ5X2Fsd2F5cyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NlcnZlclJlc2V0UXVlcnlBbHdheXM/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IHNlcnZlclJlc2V0UXVlcnlBbHdheXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnc2VydmVyX3Jlc2V0X3F1ZXJ5X2Fsd2F5cycpO1xuICB9XG4gIHB1YmxpYyBzZXQgc2VydmVyUmVzZXRRdWVyeUFsd2F5cyh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fc2VydmVyUmVzZXRRdWVyeUFsd2F5cyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFNlcnZlclJlc2V0UXVlcnlBbHdheXMoKSB7XG4gICAgdGhpcy5fc2VydmVyUmVzZXRRdWVyeUFsd2F5cyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgc2VydmVyUmVzZXRRdWVyeUFsd2F5c0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJMaXN0IGV4dGVuZHMgY2RrdG4uQ29tcGxleExpc3Qge1xuICBwdWJsaWMgaW50ZXJuYWxWYWx1ZT8gOiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJbXSB8IGNka3RuLklSZXNvbHZhYmxlXG5cbiAgLyoqXG4gICogQHBhcmFtIHRlcnJhZm9ybVJlc291cmNlIFRoZSBwYXJlbnQgcmVzb3VyY2VcbiAgKiBAcGFyYW0gdGVycmFmb3JtQXR0cmlidXRlIFRoZSBhdHRyaWJ1dGUgb24gdGhlIHBhcmVudCByZXNvdXJjZSB0aGlzIGNsYXNzIGlzIHJlZmVyZW5jaW5nXG4gICogQHBhcmFtIHdyYXBzU2V0IHdoZXRoZXIgdGhlIGxpc3QgaXMgd3JhcHBpbmcgYSBzZXQgKHdpbGwgYWRkIHRvbGlzdCgpIHRvIGJlIGFibGUgdG8gYWNjZXNzIGFuIGl0ZW0gdmlhIGFuIGluZGV4KVxuICAqL1xuICBjb25zdHJ1Y3Rvcih0ZXJyYWZvcm1SZXNvdXJjZTogY2RrdG4uSUludGVycG9sYXRpbmdQYXJlbnQsIHRlcnJhZm9ybUF0dHJpYnV0ZTogc3RyaW5nLCB3cmFwc1NldDogYm9vbGVhbikge1xuICAgIHN1cGVyKHRlcnJhZm9ybVJlc291cmNlLCB0ZXJyYWZvcm1BdHRyaWJ1dGUsIHdyYXBzU2V0KVxuICB9XG5cbiAgLyoqXG4gICogQHBhcmFtIGluZGV4IHRoZSBpbmRleCBvZiB0aGUgaXRlbSB0byByZXR1cm5cbiAgKi9cbiAgcHVibGljIGdldChpbmRleDogbnVtYmVyKTogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyT3V0cHV0UmVmZXJlbmNlIHtcbiAgICByZXR1cm4gbmV3IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlck91dHB1dFJlZmVyZW5jZSh0aGlzLnRlcnJhZm9ybVJlc291cmNlLCB0aGlzLnRlcnJhZm9ybUF0dHJpYnV0ZSwgaW5kZXgsIHRoaXMud3JhcHNTZXQpO1xuICB9XG59XG5leHBvcnQgaW50ZXJmYWNlIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiIHtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X2JhY2tncm91bmRfd29ya2VycyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X2JhY2tncm91bmRfd29ya2Vyc31cbiAgKi9cbiAgcmVhZG9ubHkgbWF4QmFja2dyb3VuZFdvcmtlcnM/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYlRvVGVycmFmb3JtKHN0cnVjdD86IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiT3V0cHV0UmVmZXJlbmNlIHwgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGIpOiBhbnkge1xuICBpZiAoIWNka3RuLmNhbkluc3BlY3Qoc3RydWN0KSB8fCBjZGt0bi5Ub2tlbml6YXRpb24uaXNSZXNvbHZhYmxlKHN0cnVjdCkpIHsgcmV0dXJuIHN0cnVjdDsgfVxuICBpZiAoY2RrdG4uaXNDb21wbGV4RWxlbWVudChzdHJ1Y3QpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQSBjb21wbGV4IGVsZW1lbnQgd2FzIHVzZWQgYXMgY29uZmlndXJhdGlvbiwgdGhpcyBpcyBub3Qgc3VwcG9ydGVkOiBodHRwczovL2Nkay50Zi9jb21wbGV4LW9iamVjdC1hcy1jb25maWd1cmF0aW9uXCIpO1xuICB9XG4gIHJldHVybiB7XG4gICAgbWF4X2JhY2tncm91bmRfd29ya2VyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5tYXhCYWNrZ3JvdW5kV29ya2VycyksXG4gIH1cbn1cblxuXG5leHBvcnQgZnVuY3Rpb24gZGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGJUb0hjbFRlcnJhZm9ybShzdHJ1Y3Q/OiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYk91dHB1dFJlZmVyZW5jZSB8IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiKTogYW55IHtcbiAgaWYgKCFjZGt0bi5jYW5JbnNwZWN0KHN0cnVjdCkgfHwgY2RrdG4uVG9rZW5pemF0aW9uLmlzUmVzb2x2YWJsZShzdHJ1Y3QpKSB7IHJldHVybiBzdHJ1Y3Q7IH1cbiAgaWYgKGNka3RuLmlzQ29tcGxleEVsZW1lbnQoc3RydWN0KSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkEgY29tcGxleCBlbGVtZW50IHdhcyB1c2VkIGFzIGNvbmZpZ3VyYXRpb24sIHRoaXMgaXMgbm90IHN1cHBvcnRlZDogaHR0cHM6Ly9jZGsudGYvY29tcGxleC1vYmplY3QtYXMtY29uZmlndXJhdGlvblwiKTtcbiAgfVxuICBjb25zdCBhdHRycyA9IHtcbiAgICBtYXhfYmFja2dyb3VuZF93b3JrZXJzOiB7XG4gICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0oc3RydWN0IS5tYXhCYWNrZ3JvdW5kV29ya2VycyksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgIH0sXG4gIH07XG5cbiAgLy8gcmVtb3ZlIHVuZGVmaW5lZCBhdHRyaWJ1dGVzXG4gIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoYXR0cnMpLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS52YWx1ZSAhPT0gdW5kZWZpbmVkKSk7XG59XG5cbmV4cG9ydCBjbGFzcyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYk91dHB1dFJlZmVyZW5jZSBleHRlbmRzIGNka3RuLkNvbXBsZXhPYmplY3Qge1xuICBwcml2YXRlIGlzRW1wdHlPYmplY3QgPSBmYWxzZTtcblxuICAvKipcbiAgKiBAcGFyYW0gdGVycmFmb3JtUmVzb3VyY2UgVGhlIHBhcmVudCByZXNvdXJjZVxuICAqIEBwYXJhbSB0ZXJyYWZvcm1BdHRyaWJ1dGUgVGhlIGF0dHJpYnV0ZSBvbiB0aGUgcGFyZW50IHJlc291cmNlIHRoaXMgY2xhc3MgaXMgcmVmZXJlbmNpbmdcbiAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHRlcnJhZm9ybVJlc291cmNlOiBjZGt0bi5JSW50ZXJwb2xhdGluZ1BhcmVudCwgdGVycmFmb3JtQXR0cmlidXRlOiBzdHJpbmcpIHtcbiAgICBzdXBlcih0ZXJyYWZvcm1SZXNvdXJjZSwgdGVycmFmb3JtQXR0cmlidXRlLCBmYWxzZSwgMCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0IGludGVybmFsVmFsdWUoKTogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGIgfCB1bmRlZmluZWQge1xuICAgIGxldCBoYXNBbnlWYWx1ZXMgPSB0aGlzLmlzRW1wdHlPYmplY3Q7XG4gICAgY29uc3QgaW50ZXJuYWxWYWx1ZVJlc3VsdDogYW55ID0ge307XG4gICAgaWYgKHRoaXMuX21heEJhY2tncm91bmRXb3JrZXJzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0Lm1heEJhY2tncm91bmRXb3JrZXJzID0gdGhpcy5fbWF4QmFja2dyb3VuZFdvcmtlcnM7XG4gICAgfVxuICAgIHJldHVybiBoYXNBbnlWYWx1ZXMgPyBpbnRlcm5hbFZhbHVlUmVzdWx0IDogdW5kZWZpbmVkO1xuICB9XG5cbiAgcHVibGljIHNldCBpbnRlcm5hbFZhbHVlKHZhbHVlOiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYiB8IHVuZGVmaW5lZCkge1xuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLmlzRW1wdHlPYmplY3QgPSBmYWxzZTtcbiAgICAgIHRoaXMuX21heEJhY2tncm91bmRXb3JrZXJzID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHRoaXMuaXNFbXB0eU9iamVjdCA9IE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGggPT09IDA7XG4gICAgICB0aGlzLl9tYXhCYWNrZ3JvdW5kV29ya2VycyA9IHZhbHVlLm1heEJhY2tncm91bmRXb3JrZXJzO1xuICAgIH1cbiAgfVxuXG4gIC8vIG1heF9iYWNrZ3JvdW5kX3dvcmtlcnMgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4QmFja2dyb3VuZFdvcmtlcnM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heEJhY2tncm91bmRXb3JrZXJzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X2JhY2tncm91bmRfd29ya2VycycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4QmFja2dyb3VuZFdvcmtlcnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heEJhY2tncm91bmRXb3JrZXJzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4QmFja2dyb3VuZFdvcmtlcnMoKSB7XG4gICAgdGhpcy5fbWF4QmFja2dyb3VuZFdvcmtlcnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heEJhY2tncm91bmRXb3JrZXJzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heEJhY2tncm91bmRXb3JrZXJzO1xuICB9XG59XG5cbi8qKlxuKiBSZXByZXNlbnRzIGEge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWd9XG4qL1xuZXhwb3J0IGNsYXNzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybVJlc291cmNlIHtcblxuICAvLyA9PT09PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgUFJPUEVSVElFU1xuICAvLyA9PT09PT09PT09PT09PT09PVxuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IHRmUmVzb3VyY2VUeXBlID0gXCJkaWdpdGFsb2NlYW5fZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWdcIjtcblxuICAvLyA9PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgTWV0aG9kc1xuICAvLyA9PT09PT09PT09PT09PVxuICAvKipcbiAgKiBHZW5lcmF0ZXMgQ0RLVE4gY29kZSBmb3IgaW1wb3J0aW5nIGEgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnIHJlc291cmNlIHVwb24gcnVubmluZyBcImNka3RuIHBsYW4gPHN0YWNrLW5hbWU+XCJcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpbXBvcnRUb0lkIFRoZSBjb25zdHJ1Y3QgaWQgdXNlZCBpbiB0aGUgZ2VuZXJhdGVkIGNvbmZpZyBmb3IgdGhlIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyB0byBpbXBvcnRcbiAgKiBAcGFyYW0gaW1wb3J0RnJvbUlkIFRoZSBpZCBvZiB0aGUgZXhpc3RpbmcgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnIHRoYXQgc2hvdWxkIGJlIGltcG9ydGVkLiBSZWZlciB0byB0aGUge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNpbXBvcnQgaW1wb3J0IHNlY3Rpb259IGluIHRoZSBkb2N1bWVudGF0aW9uIG9mIHRoaXMgcmVzb3VyY2UgZm9yIHRoZSBpZCB0byB1c2VcbiAgKiBAcGFyYW0gcHJvdmlkZXI/IE9wdGlvbmFsIGluc3RhbmNlIG9mIHRoZSBwcm92aWRlciB3aGVyZSB0aGUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnIHRvIGltcG9ydCBpcyBmb3VuZFxuICAqL1xuICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQ29uZmlnRm9ySW1wb3J0KHNjb3BlOiBDb25zdHJ1Y3QsIGltcG9ydFRvSWQ6IHN0cmluZywgaW1wb3J0RnJvbUlkOiBzdHJpbmcsIHByb3ZpZGVyPzogY2RrdG4uVGVycmFmb3JtUHJvdmlkZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBjZGt0bi5JbXBvcnRhYmxlUmVzb3VyY2Uoc2NvcGUsIGltcG9ydFRvSWQsIHsgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZ1wiLCBpbXBvcnRJZDogaW1wb3J0RnJvbUlkLCBwcm92aWRlciB9KTtcbiAgICAgIH1cblxuICAvLyA9PT09PT09PT09PVxuICAvLyBJTklUSUFMSVpFUlxuICAvLyA9PT09PT09PT09PVxuXG4gIC8qKlxuICAqIENyZWF0ZSBhIG5ldyB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnIGRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZ30gUmVzb3VyY2VcbiAgKlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGlkIFRoZSBzY29wZWQgY29uc3RydWN0IElELiBNdXN0IGJlIHVuaXF1ZSBhbW9uZ3N0IHNpYmxpbmdzIGluIHRoZSBzYW1lIHNjb3BlXG4gICogQHBhcmFtIG9wdGlvbnMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnQ29uZmlnXG4gICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBjb25maWc6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ0NvbmZpZykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiAnZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnJyxcbiAgICAgIHRlcnJhZm9ybUdlbmVyYXRvck1ldGFkYXRhOiB7XG4gICAgICAgIHByb3ZpZGVyTmFtZTogJ2RpZ2l0YWxvY2VhbicsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbjogJzIuODcuMCcsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbkNvbnN0cmFpbnQ6ICcyLjg3LjAnXG4gICAgICB9LFxuICAgICAgcHJvdmlkZXI6IGNvbmZpZy5wcm92aWRlcixcbiAgICAgIGRlcGVuZHNPbjogY29uZmlnLmRlcGVuZHNPbixcbiAgICAgIGNvdW50OiBjb25maWcuY291bnQsXG4gICAgICBsaWZlY3ljbGU6IGNvbmZpZy5saWZlY3ljbGUsXG4gICAgICBwcm92aXNpb25lcnM6IGNvbmZpZy5wcm92aXNpb25lcnMsXG4gICAgICBjb25uZWN0aW9uOiBjb25maWcuY29ubmVjdGlvbixcbiAgICAgIGZvckVhY2g6IGNvbmZpZy5mb3JFYWNoXG4gICAgfSk7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVTY2FsZUZhY3RvciA9IGNvbmZpZy5hdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yO1xuICAgIHRoaXMuX2F1dG92YWN1dW1BbmFseXplVGhyZXNob2xkID0gY29uZmlnLmF1dG92YWN1dW1BbmFseXplVGhyZXNob2xkO1xuICAgIHRoaXMuX2F1dG92YWN1dW1GcmVlemVNYXhBZ2UgPSBjb25maWcuYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZTtcbiAgICB0aGlzLl9hdXRvdmFjdXVtTWF4V29ya2VycyA9IGNvbmZpZy5hdXRvdmFjdXVtTWF4V29ya2VycztcbiAgICB0aGlzLl9hdXRvdmFjdXVtTmFwdGltZSA9IGNvbmZpZy5hdXRvdmFjdXVtTmFwdGltZTtcbiAgICB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5ID0gY29uZmlnLmF1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXk7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCA9IGNvbmZpZy5hdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0O1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvciA9IGNvbmZpZy5hdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3I7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZCA9IGNvbmZpZy5hdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkO1xuICAgIHRoaXMuX2JhY2t1cEhvdXIgPSBjb25maWcuYmFja3VwSG91cjtcbiAgICB0aGlzLl9iYWNrdXBNaW51dGUgPSBjb25maWcuYmFja3VwTWludXRlO1xuICAgIHRoaXMuX2Jnd3JpdGVyRGVsYXkgPSBjb25maWcuYmd3cml0ZXJEZWxheTtcbiAgICB0aGlzLl9iZ3dyaXRlckZsdXNoQWZ0ZXIgPSBjb25maWcuYmd3cml0ZXJGbHVzaEFmdGVyO1xuICAgIHRoaXMuX2Jnd3JpdGVyTHJ1TWF4cGFnZXMgPSBjb25maWcuYmd3cml0ZXJMcnVNYXhwYWdlcztcbiAgICB0aGlzLl9iZ3dyaXRlckxydU11bHRpcGxpZXIgPSBjb25maWcuYmd3cml0ZXJMcnVNdWx0aXBsaWVyO1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IGNvbmZpZy5jbHVzdGVySWQ7XG4gICAgdGhpcy5fZGVhZGxvY2tUaW1lb3V0ID0gY29uZmlnLmRlYWRsb2NrVGltZW91dDtcbiAgICB0aGlzLl9kZWZhdWx0VG9hc3RDb21wcmVzc2lvbiA9IGNvbmZpZy5kZWZhdWx0VG9hc3RDb21wcmVzc2lvbjtcbiAgICB0aGlzLl9pZCA9IGNvbmZpZy5pZDtcbiAgICB0aGlzLl9pZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0ID0gY29uZmlnLmlkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQ7XG4gICAgdGhpcy5faml0ID0gY29uZmlnLmppdDtcbiAgICB0aGlzLl9sb2dBdXRvdmFjdXVtTWluRHVyYXRpb24gPSBjb25maWcubG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uO1xuICAgIHRoaXMuX2xvZ0Vycm9yVmVyYm9zaXR5ID0gY29uZmlnLmxvZ0Vycm9yVmVyYm9zaXR5O1xuICAgIHRoaXMuX2xvZ0xpbmVQcmVmaXggPSBjb25maWcubG9nTGluZVByZWZpeDtcbiAgICB0aGlzLl9sb2dNaW5EdXJhdGlvblN0YXRlbWVudCA9IGNvbmZpZy5sb2dNaW5EdXJhdGlvblN0YXRlbWVudDtcbiAgICB0aGlzLl9tYXhGaWxlc1BlclByb2Nlc3MgPSBjb25maWcubWF4RmlsZXNQZXJQcm9jZXNzO1xuICAgIHRoaXMuX21heExvY2tzUGVyVHJhbnNhY3Rpb24gPSBjb25maWcubWF4TG9ja3NQZXJUcmFuc2FjdGlvbjtcbiAgICB0aGlzLl9tYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzID0gY29uZmlnLm1heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnM7XG4gICAgdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzID0gY29uZmlnLm1heFBhcmFsbGVsV29ya2VycztcbiAgICB0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXIgPSBjb25maWcubWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyO1xuICAgIHRoaXMuX21heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uID0gY29uZmlnLm1heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uO1xuICAgIHRoaXMuX21heFByZXBhcmVkVHJhbnNhY3Rpb25zID0gY29uZmlnLm1heFByZXBhcmVkVHJhbnNhY3Rpb25zO1xuICAgIHRoaXMuX21heFJlcGxpY2F0aW9uU2xvdHMgPSBjb25maWcubWF4UmVwbGljYXRpb25TbG90cztcbiAgICB0aGlzLl9tYXhTdGFja0RlcHRoID0gY29uZmlnLm1heFN0YWNrRGVwdGg7XG4gICAgdGhpcy5fbWF4U3RhbmRieUFyY2hpdmVEZWxheSA9IGNvbmZpZy5tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5O1xuICAgIHRoaXMuX21heFN0YW5kYnlTdHJlYW1pbmdEZWxheSA9IGNvbmZpZy5tYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXk7XG4gICAgdGhpcy5fbWF4V2FsU2VuZGVycyA9IGNvbmZpZy5tYXhXYWxTZW5kZXJzO1xuICAgIHRoaXMuX21heFdvcmtlclByb2Nlc3NlcyA9IGNvbmZpZy5tYXhXb3JrZXJQcm9jZXNzZXM7XG4gICAgdGhpcy5fcGdQYXJ0bWFuQmd3SW50ZXJ2YWwgPSBjb25maWcucGdQYXJ0bWFuQmd3SW50ZXJ2YWw7XG4gICAgdGhpcy5fcGdQYXJ0bWFuQmd3Um9sZSA9IGNvbmZpZy5wZ1BhcnRtYW5CZ3dSb2xlO1xuICAgIHRoaXMuX3BnU3RhdFN0YXRlbWVudHNUcmFjayA9IGNvbmZpZy5wZ1N0YXRTdGF0ZW1lbnRzVHJhY2s7XG4gICAgdGhpcy5fc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2UgPSBjb25maWcuc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2U7XG4gICAgdGhpcy5fdGVtcEZpbGVMaW1pdCA9IGNvbmZpZy50ZW1wRmlsZUxpbWl0O1xuICAgIHRoaXMuX3RpbWV6b25lID0gY29uZmlnLnRpbWV6b25lO1xuICAgIHRoaXMuX3RyYWNrQWN0aXZpdHlRdWVyeVNpemUgPSBjb25maWcudHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZTtcbiAgICB0aGlzLl90cmFja0NvbW1pdFRpbWVzdGFtcCA9IGNvbmZpZy50cmFja0NvbW1pdFRpbWVzdGFtcDtcbiAgICB0aGlzLl90cmFja0Z1bmN0aW9ucyA9IGNvbmZpZy50cmFja0Z1bmN0aW9ucztcbiAgICB0aGlzLl90cmFja0lvVGltaW5nID0gY29uZmlnLnRyYWNrSW9UaW1pbmc7XG4gICAgdGhpcy5fd2FsU2VuZGVyVGltZW91dCA9IGNvbmZpZy53YWxTZW5kZXJUaW1lb3V0O1xuICAgIHRoaXMuX3dhbFdyaXRlckRlbGF5ID0gY29uZmlnLndhbFdyaXRlckRlbGF5O1xuICAgIHRoaXMuX3dvcmtNZW0gPSBjb25maWcud29ya01lbTtcbiAgICB0aGlzLl9wZ2JvdW5jZXIuaW50ZXJuYWxWYWx1ZSA9IGNvbmZpZy5wZ2JvdW5jZXI7XG4gICAgdGhpcy5fdGltZXNjYWxlZGIuaW50ZXJuYWxWYWx1ZSA9IGNvbmZpZy50aW1lc2NhbGVkYjtcbiAgfVxuXG4gIC8vID09PT09PT09PT1cbiAgLy8gQVRUUklCVVRFU1xuICAvLyA9PT09PT09PT09XG5cbiAgLy8gYXV0b3ZhY3V1bV9hbmFseXplX3NjYWxlX2ZhY3RvciAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2F1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3I/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX2FuYWx5emVfc2NhbGVfZmFjdG9yJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b3ZhY3V1bUFuYWx5emVTY2FsZUZhY3RvcigpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9ySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3I7XG4gIH1cblxuICAvLyBhdXRvdmFjdXVtX2FuYWx5emVfdGhyZXNob2xkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1BbmFseXplVGhyZXNob2xkKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b3ZhY3V1bV9hbmFseXplX3RocmVzaG9sZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG92YWN1dW1BbmFseXplVGhyZXNob2xkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQoKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1BbmFseXplVGhyZXNob2xkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG92YWN1dW1BbmFseXplVGhyZXNob2xkO1xuICB9XG5cbiAgLy8gYXV0b3ZhY3V1bV9mcmVlemVfbWF4X2FnZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2F1dG92YWN1dW1GcmVlemVNYXhBZ2U/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1GcmVlemVNYXhBZ2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX2ZyZWV6ZV9tYXhfYWdlJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvdmFjdXVtRnJlZXplTWF4QWdlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtRnJlZXplTWF4QWdlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b3ZhY3V1bUZyZWV6ZU1heEFnZSgpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtRnJlZXplTWF4QWdlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvdmFjdXVtRnJlZXplTWF4QWdlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG92YWN1dW1GcmVlemVNYXhBZ2U7XG4gIH1cblxuICAvLyBhdXRvdmFjdXVtX21heF93b3JrZXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bU1heFdvcmtlcnM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1NYXhXb3JrZXJzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b3ZhY3V1bV9tYXhfd29ya2VycycpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b3ZhY3V1bU1heFdvcmtlcnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG92YWN1dW1NYXhXb3JrZXJzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b3ZhY3V1bU1heFdvcmtlcnMoKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bU1heFdvcmtlcnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1NYXhXb3JrZXJzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG92YWN1dW1NYXhXb3JrZXJzO1xuICB9XG5cbiAgLy8gYXV0b3ZhY3V1bV9uYXB0aW1lIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bU5hcHRpbWU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1OYXB0aW1lKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b3ZhY3V1bV9uYXB0aW1lJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvdmFjdXVtTmFwdGltZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bU5hcHRpbWUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtTmFwdGltZSgpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtTmFwdGltZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bU5hcHRpbWVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bU5hcHRpbWU7XG4gIH1cblxuICAvLyBhdXRvdmFjdXVtX3ZhY3V1bV9jb3N0X2RlbGF5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG92YWN1dW1fdmFjdXVtX2Nvc3RfZGVsYXknKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXkodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXkgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5KCkge1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXkgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXlJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheTtcbiAgfVxuXG4gIC8vIGF1dG92YWN1dW1fdmFjdXVtX2Nvc3RfbGltaXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBhdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9saW1pdCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQoKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0O1xuICB9XG5cbiAgLy8gYXV0b3ZhY3V1bV92YWN1dW1fc2NhbGVfZmFjdG9yIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBhdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX3ZhY3V1bV9zY2FsZV9mYWN0b3InKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3Rvcih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yKCkge1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvciA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9ySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvcjtcbiAgfVxuXG4gIC8vIGF1dG92YWN1dW1fdmFjdXVtX3RocmVzaG9sZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2F1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX3ZhY3V1bV90aHJlc2hvbGQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkKCkge1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZDtcbiAgfVxuXG4gIC8vIGJhY2t1cF9ob3VyIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYmFja3VwSG91cj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmFja3VwSG91cigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2JhY2t1cF9ob3VyJyk7XG4gIH1cbiAgcHVibGljIHNldCBiYWNrdXBIb3VyKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9iYWNrdXBIb3VyID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QmFja3VwSG91cigpIHtcbiAgICB0aGlzLl9iYWNrdXBIb3VyID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBiYWNrdXBIb3VySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2JhY2t1cEhvdXI7XG4gIH1cblxuICAvLyBiYWNrdXBfbWludXRlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYmFja3VwTWludXRlPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBiYWNrdXBNaW51dGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdiYWNrdXBfbWludXRlJyk7XG4gIH1cbiAgcHVibGljIHNldCBiYWNrdXBNaW51dGUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2JhY2t1cE1pbnV0ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEJhY2t1cE1pbnV0ZSgpIHtcbiAgICB0aGlzLl9iYWNrdXBNaW51dGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGJhY2t1cE1pbnV0ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9iYWNrdXBNaW51dGU7XG4gIH1cblxuICAvLyBiZ3dyaXRlcl9kZWxheSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2Jnd3JpdGVyRGVsYXk/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGJnd3JpdGVyRGVsYXkoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdiZ3dyaXRlcl9kZWxheScpO1xuICB9XG4gIHB1YmxpYyBzZXQgYmd3cml0ZXJEZWxheSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYmd3cml0ZXJEZWxheSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEJnd3JpdGVyRGVsYXkoKSB7XG4gICAgdGhpcy5fYmd3cml0ZXJEZWxheSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYmd3cml0ZXJEZWxheUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9iZ3dyaXRlckRlbGF5O1xuICB9XG5cbiAgLy8gYmd3cml0ZXJfZmx1c2hfYWZ0ZXIgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9iZ3dyaXRlckZsdXNoQWZ0ZXI/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGJnd3JpdGVyRmx1c2hBZnRlcigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2Jnd3JpdGVyX2ZsdXNoX2FmdGVyJyk7XG4gIH1cbiAgcHVibGljIHNldCBiZ3dyaXRlckZsdXNoQWZ0ZXIodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2Jnd3JpdGVyRmx1c2hBZnRlciA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEJnd3JpdGVyRmx1c2hBZnRlcigpIHtcbiAgICB0aGlzLl9iZ3dyaXRlckZsdXNoQWZ0ZXIgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGJnd3JpdGVyRmx1c2hBZnRlcklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9iZ3dyaXRlckZsdXNoQWZ0ZXI7XG4gIH1cblxuICAvLyBiZ3dyaXRlcl9scnVfbWF4cGFnZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9iZ3dyaXRlckxydU1heHBhZ2VzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBiZ3dyaXRlckxydU1heHBhZ2VzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYmd3cml0ZXJfbHJ1X21heHBhZ2VzJyk7XG4gIH1cbiAgcHVibGljIHNldCBiZ3dyaXRlckxydU1heHBhZ2VzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9iZ3dyaXRlckxydU1heHBhZ2VzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Qmd3cml0ZXJMcnVNYXhwYWdlcygpIHtcbiAgICB0aGlzLl9iZ3dyaXRlckxydU1heHBhZ2VzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBiZ3dyaXRlckxydU1heHBhZ2VzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Jnd3JpdGVyTHJ1TWF4cGFnZXM7XG4gIH1cblxuICAvLyBiZ3dyaXRlcl9scnVfbXVsdGlwbGllciAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2Jnd3JpdGVyTHJ1TXVsdGlwbGllcj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmd3cml0ZXJMcnVNdWx0aXBsaWVyKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYmd3cml0ZXJfbHJ1X211bHRpcGxpZXInKTtcbiAgfVxuICBwdWJsaWMgc2V0IGJnd3JpdGVyTHJ1TXVsdGlwbGllcih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYmd3cml0ZXJMcnVNdWx0aXBsaWVyID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Qmd3cml0ZXJMcnVNdWx0aXBsaWVyKCkge1xuICAgIHRoaXMuX2Jnd3JpdGVyTHJ1TXVsdGlwbGllciA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYmd3cml0ZXJMcnVNdWx0aXBsaWVySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Jnd3JpdGVyTHJ1TXVsdGlwbGllcjtcbiAgfVxuXG4gIC8vIGNsdXN0ZXJfaWQgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiBmYWxzZSwgcmVxdWlyZWQ6IHRydWVcbiAgcHJpdmF0ZSBfY2x1c3RlcklkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBjbHVzdGVySWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdjbHVzdGVyX2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBjbHVzdGVySWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IHZhbHVlO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVySWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3RlcklkO1xuICB9XG5cbiAgLy8gZGVhZGxvY2tfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2RlYWRsb2NrVGltZW91dD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgZGVhZGxvY2tUaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnZGVhZGxvY2tfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgZGVhZGxvY2tUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9kZWFkbG9ja1RpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXREZWFkbG9ja1RpbWVvdXQoKSB7XG4gICAgdGhpcy5fZGVhZGxvY2tUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBkZWFkbG9ja1RpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZGVhZGxvY2tUaW1lb3V0O1xuICB9XG5cbiAgLy8gZGVmYXVsdF90b2FzdF9jb21wcmVzc2lvbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2RlZmF1bHRUb2FzdENvbXByZXNzaW9uPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBkZWZhdWx0VG9hc3RDb21wcmVzc2lvbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2RlZmF1bHRfdG9hc3RfY29tcHJlc3Npb24nKTtcbiAgfVxuICBwdWJsaWMgc2V0IGRlZmF1bHRUb2FzdENvbXByZXNzaW9uKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9kZWZhdWx0VG9hc3RDb21wcmVzc2lvbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldERlZmF1bHRUb2FzdENvbXByZXNzaW9uKCkge1xuICAgIHRoaXMuX2RlZmF1bHRUb2FzdENvbXByZXNzaW9uID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBkZWZhdWx0VG9hc3RDb21wcmVzc2lvbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9kZWZhdWx0VG9hc3RDb21wcmVzc2lvbjtcbiAgfVxuXG4gIC8vIGlkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGlkKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlkKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9pZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElkKCkge1xuICAgIHRoaXMuX2lkID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pZDtcbiAgfVxuXG4gIC8vIGlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBpZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dCgpIHtcbiAgICB0aGlzLl9pZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQ7XG4gIH1cblxuICAvLyBqaXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9qaXQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IGppdCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdqaXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGppdCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5faml0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Sml0KCkge1xuICAgIHRoaXMuX2ppdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaml0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2ppdDtcbiAgfVxuXG4gIC8vIGxvZ19hdXRvdmFjdXVtX21pbl9kdXJhdGlvbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbG9nX2F1dG92YWN1dW1fbWluX2R1cmF0aW9uJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dBdXRvdmFjdXVtTWluRHVyYXRpb24odmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbigpIHtcbiAgICB0aGlzLl9sb2dBdXRvdmFjdXVtTWluRHVyYXRpb24gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dBdXRvdmFjdXVtTWluRHVyYXRpb247XG4gIH1cblxuICAvLyBsb2dfZXJyb3JfdmVyYm9zaXR5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nRXJyb3JWZXJib3NpdHk/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGxvZ0Vycm9yVmVyYm9zaXR5KCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX2Vycm9yX3ZlcmJvc2l0eScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nRXJyb3JWZXJib3NpdHkodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2xvZ0Vycm9yVmVyYm9zaXR5ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nRXJyb3JWZXJib3NpdHkoKSB7XG4gICAgdGhpcy5fbG9nRXJyb3JWZXJib3NpdHkgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ0Vycm9yVmVyYm9zaXR5SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ0Vycm9yVmVyYm9zaXR5O1xuICB9XG5cbiAgLy8gbG9nX2xpbmVfcHJlZml4IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nTGluZVByZWZpeD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgbG9nTGluZVByZWZpeCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2xvZ19saW5lX3ByZWZpeCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nTGluZVByZWZpeCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fbG9nTGluZVByZWZpeCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ0xpbmVQcmVmaXgoKSB7XG4gICAgdGhpcy5fbG9nTGluZVByZWZpeCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nTGluZVByZWZpeElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dMaW5lUHJlZml4O1xuICB9XG5cbiAgLy8gbG9nX21pbl9kdXJhdGlvbl9zdGF0ZW1lbnQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dNaW5EdXJhdGlvblN0YXRlbWVudD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbG9nTWluRHVyYXRpb25TdGF0ZW1lbnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsb2dfbWluX2R1cmF0aW9uX3N0YXRlbWVudCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nTWluRHVyYXRpb25TdGF0ZW1lbnQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2xvZ01pbkR1cmF0aW9uU3RhdGVtZW50ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nTWluRHVyYXRpb25TdGF0ZW1lbnQoKSB7XG4gICAgdGhpcy5fbG9nTWluRHVyYXRpb25TdGF0ZW1lbnQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ01pbkR1cmF0aW9uU3RhdGVtZW50SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ01pbkR1cmF0aW9uU3RhdGVtZW50O1xuICB9XG5cbiAgLy8gbWF4X2ZpbGVzX3Blcl9wcm9jZXNzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4RmlsZXNQZXJQcm9jZXNzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhGaWxlc1BlclByb2Nlc3MoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfZmlsZXNfcGVyX3Byb2Nlc3MnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heEZpbGVzUGVyUHJvY2Vzcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4RmlsZXNQZXJQcm9jZXNzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4RmlsZXNQZXJQcm9jZXNzKCkge1xuICAgIHRoaXMuX21heEZpbGVzUGVyUHJvY2VzcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4RmlsZXNQZXJQcm9jZXNzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heEZpbGVzUGVyUHJvY2VzcztcbiAgfVxuXG4gIC8vIG1heF9sb2Nrc19wZXJfdHJhbnNhY3Rpb24gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhMb2Nrc1BlclRyYW5zYWN0aW9uPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhMb2Nrc1BlclRyYW5zYWN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X2xvY2tzX3Blcl90cmFuc2FjdGlvbicpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4TG9ja3NQZXJUcmFuc2FjdGlvbih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4TG9ja3NQZXJUcmFuc2FjdGlvbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heExvY2tzUGVyVHJhbnNhY3Rpb24oKSB7XG4gICAgdGhpcy5fbWF4TG9ja3NQZXJUcmFuc2FjdGlvbiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4TG9ja3NQZXJUcmFuc2FjdGlvbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhMb2Nrc1BlclRyYW5zYWN0aW9uO1xuICB9XG5cbiAgLy8gbWF4X2xvZ2ljYWxfcmVwbGljYXRpb25fd29ya2VycyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfbG9naWNhbF9yZXBsaWNhdGlvbl93b3JrZXJzJyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2VycygpIHtcbiAgICB0aGlzLl9tYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnM7XG4gIH1cblxuICAvLyBtYXhfcGFyYWxsZWxfd29ya2VycyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFBhcmFsbGVsV29ya2Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4UGFyYWxsZWxXb3JrZXJzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X3BhcmFsbGVsX3dvcmtlcnMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFBhcmFsbGVsV29ya2Vycyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4UGFyYWxsZWxXb3JrZXJzKCkge1xuICAgIHRoaXMuX21heFBhcmFsbGVsV29ya2VycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4UGFyYWxsZWxXb3JrZXJzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heFBhcmFsbGVsV29ya2VycztcbiAgfVxuXG4gIC8vIG1heF9wYXJhbGxlbF93b3JrZXJzX3Blcl9nYXRoZXIgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXI/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlcigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9wYXJhbGxlbF93b3JrZXJzX3Blcl9nYXRoZXInKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlcih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyKCkge1xuICAgIHRoaXMuX21heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlciA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlcjtcbiAgfVxuXG4gIC8vIG1heF9wcmVkX2xvY2tzX3Blcl90cmFuc2FjdGlvbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhQcmVkTG9ja3NQZXJUcmFuc2FjdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9wcmVkX2xvY2tzX3Blcl90cmFuc2FjdGlvbicpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24odmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24oKSB7XG4gICAgdGhpcy5fbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uO1xuICB9XG5cbiAgLy8gbWF4X3ByZXBhcmVkX3RyYW5zYWN0aW9ucyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFByZXBhcmVkVHJhbnNhY3Rpb25zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhQcmVwYXJlZFRyYW5zYWN0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9wcmVwYXJlZF90cmFuc2FjdGlvbnMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFByZXBhcmVkVHJhbnNhY3Rpb25zKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhQcmVwYXJlZFRyYW5zYWN0aW9ucyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heFByZXBhcmVkVHJhbnNhY3Rpb25zKCkge1xuICAgIHRoaXMuX21heFByZXBhcmVkVHJhbnNhY3Rpb25zID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhQcmVwYXJlZFRyYW5zYWN0aW9uc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhQcmVwYXJlZFRyYW5zYWN0aW9ucztcbiAgfVxuXG4gIC8vIG1heF9yZXBsaWNhdGlvbl9zbG90cyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFJlcGxpY2F0aW9uU2xvdHM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFJlcGxpY2F0aW9uU2xvdHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfcmVwbGljYXRpb25fc2xvdHMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFJlcGxpY2F0aW9uU2xvdHModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heFJlcGxpY2F0aW9uU2xvdHMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhSZXBsaWNhdGlvblNsb3RzKCkge1xuICAgIHRoaXMuX21heFJlcGxpY2F0aW9uU2xvdHMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heFJlcGxpY2F0aW9uU2xvdHNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4UmVwbGljYXRpb25TbG90cztcbiAgfVxuXG4gIC8vIG1heF9zdGFja19kZXB0aCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFN0YWNrRGVwdGg/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFN0YWNrRGVwdGgoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfc3RhY2tfZGVwdGgnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFN0YWNrRGVwdGgodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heFN0YWNrRGVwdGggPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhTdGFja0RlcHRoKCkge1xuICAgIHRoaXMuX21heFN0YWNrRGVwdGggPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heFN0YWNrRGVwdGhJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4U3RhY2tEZXB0aDtcbiAgfVxuXG4gIC8vIG1heF9zdGFuZGJ5X2FyY2hpdmVfZGVsYXkgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhTdGFuZGJ5QXJjaGl2ZURlbGF5KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X3N0YW5kYnlfYXJjaGl2ZV9kZWxheScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4U3RhbmRieUFyY2hpdmVEZWxheSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4U3RhbmRieUFyY2hpdmVEZWxheSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heFN0YW5kYnlBcmNoaXZlRGVsYXkoKSB7XG4gICAgdGhpcy5fbWF4U3RhbmRieUFyY2hpdmVEZWxheSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4U3RhbmRieUFyY2hpdmVEZWxheUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5O1xuICB9XG5cbiAgLy8gbWF4X3N0YW5kYnlfc3RyZWFtaW5nX2RlbGF5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXkoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfc3RhbmRieV9zdHJlYW1pbmdfZGVsYXknKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFN0YW5kYnlTdHJlYW1pbmdEZWxheSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5KCkge1xuICAgIHRoaXMuX21heFN0YW5kYnlTdHJlYW1pbmdEZWxheSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heFN0YW5kYnlTdHJlYW1pbmdEZWxheTtcbiAgfVxuXG4gIC8vIG1heF93YWxfc2VuZGVycyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFdhbFNlbmRlcnM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFdhbFNlbmRlcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfd2FsX3NlbmRlcnMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heFdhbFNlbmRlcnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heFdhbFNlbmRlcnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhXYWxTZW5kZXJzKCkge1xuICAgIHRoaXMuX21heFdhbFNlbmRlcnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heFdhbFNlbmRlcnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4V2FsU2VuZGVycztcbiAgfVxuXG4gIC8vIG1heF93b3JrZXJfcHJvY2Vzc2VzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4V29ya2VyUHJvY2Vzc2VzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhXb3JrZXJQcm9jZXNzZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfd29ya2VyX3Byb2Nlc3NlcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4V29ya2VyUHJvY2Vzc2VzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhXb3JrZXJQcm9jZXNzZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhXb3JrZXJQcm9jZXNzZXMoKSB7XG4gICAgdGhpcy5fbWF4V29ya2VyUHJvY2Vzc2VzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhXb3JrZXJQcm9jZXNzZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4V29ya2VyUHJvY2Vzc2VzO1xuICB9XG5cbiAgLy8gcGdfcGFydG1hbl9iZ3dfaW50ZXJ2YWwgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9wZ1BhcnRtYW5CZ3dJbnRlcnZhbD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgcGdQYXJ0bWFuQmd3SW50ZXJ2YWwoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdwZ19wYXJ0bWFuX2Jnd19pbnRlcnZhbCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgcGdQYXJ0bWFuQmd3SW50ZXJ2YWwodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3BnUGFydG1hbkJnd0ludGVydmFsID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0UGdQYXJ0bWFuQmd3SW50ZXJ2YWwoKSB7XG4gICAgdGhpcy5fcGdQYXJ0bWFuQmd3SW50ZXJ2YWwgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHBnUGFydG1hbkJnd0ludGVydmFsSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BnUGFydG1hbkJnd0ludGVydmFsO1xuICB9XG5cbiAgLy8gcGdfcGFydG1hbl9iZ3dfcm9sZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3BnUGFydG1hbkJnd1JvbGU/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHBnUGFydG1hbkJnd1JvbGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdwZ19wYXJ0bWFuX2Jnd19yb2xlJyk7XG4gIH1cbiAgcHVibGljIHNldCBwZ1BhcnRtYW5CZ3dSb2xlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9wZ1BhcnRtYW5CZ3dSb2xlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0UGdQYXJ0bWFuQmd3Um9sZSgpIHtcbiAgICB0aGlzLl9wZ1BhcnRtYW5CZ3dSb2xlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBwZ1BhcnRtYW5CZ3dSb2xlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BnUGFydG1hbkJnd1JvbGU7XG4gIH1cblxuICAvLyBwZ19zdGF0X3N0YXRlbWVudHNfdHJhY2sgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9wZ1N0YXRTdGF0ZW1lbnRzVHJhY2s/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHBnU3RhdFN0YXRlbWVudHNUcmFjaygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3BnX3N0YXRfc3RhdGVtZW50c190cmFjaycpO1xuICB9XG4gIHB1YmxpYyBzZXQgcGdTdGF0U3RhdGVtZW50c1RyYWNrKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9wZ1N0YXRTdGF0ZW1lbnRzVHJhY2sgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQZ1N0YXRTdGF0ZW1lbnRzVHJhY2soKSB7XG4gICAgdGhpcy5fcGdTdGF0U3RhdGVtZW50c1RyYWNrID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBwZ1N0YXRTdGF0ZW1lbnRzVHJhY2tJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGdTdGF0U3RhdGVtZW50c1RyYWNrO1xuICB9XG5cbiAgLy8gc2hhcmVkX2J1ZmZlcnNfcGVyY2VudGFnZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBzaGFyZWRCdWZmZXJzUGVyY2VudGFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3NoYXJlZF9idWZmZXJzX3BlcmNlbnRhZ2UnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9zaGFyZWRCdWZmZXJzUGVyY2VudGFnZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFNoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlKCkge1xuICAgIHRoaXMuX3NoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzaGFyZWRCdWZmZXJzUGVyY2VudGFnZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9zaGFyZWRCdWZmZXJzUGVyY2VudGFnZTtcbiAgfVxuXG4gIC8vIHRlbXBfZmlsZV9saW1pdCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RlbXBGaWxlTGltaXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRlbXBGaWxlTGltaXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0ZW1wX2ZpbGVfbGltaXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRlbXBGaWxlTGltaXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RlbXBGaWxlTGltaXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUZW1wRmlsZUxpbWl0KCkge1xuICAgIHRoaXMuX3RlbXBGaWxlTGltaXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRlbXBGaWxlTGltaXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGVtcEZpbGVMaW1pdDtcbiAgfVxuXG4gIC8vIHRpbWV6b25lIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGltZXpvbmU/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHRpbWV6b25lKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgndGltZXpvbmUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRpbWV6b25lKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl90aW1lem9uZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRpbWV6b25lKCkge1xuICAgIHRoaXMuX3RpbWV6b25lID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aW1lem9uZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aW1lem9uZTtcbiAgfVxuXG4gIC8vIHRyYWNrX2FjdGl2aXR5X3F1ZXJ5X3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90cmFja0FjdGl2aXR5UXVlcnlTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0cmFja0FjdGl2aXR5UXVlcnlTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndHJhY2tfYWN0aXZpdHlfcXVlcnlfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRyYWNrQWN0aXZpdHlRdWVyeVNpemUoKSB7XG4gICAgdGhpcy5fdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90cmFja0FjdGl2aXR5UXVlcnlTaXplO1xuICB9XG5cbiAgLy8gdHJhY2tfY29tbWl0X3RpbWVzdGFtcCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RyYWNrQ29tbWl0VGltZXN0YW1wPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCB0cmFja0NvbW1pdFRpbWVzdGFtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3RyYWNrX2NvbW1pdF90aW1lc3RhbXAnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRyYWNrQ29tbWl0VGltZXN0YW1wKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl90cmFja0NvbW1pdFRpbWVzdGFtcCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRyYWNrQ29tbWl0VGltZXN0YW1wKCkge1xuICAgIHRoaXMuX3RyYWNrQ29tbWl0VGltZXN0YW1wID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0cmFja0NvbW1pdFRpbWVzdGFtcElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90cmFja0NvbW1pdFRpbWVzdGFtcDtcbiAgfVxuXG4gIC8vIHRyYWNrX2Z1bmN0aW9ucyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RyYWNrRnVuY3Rpb25zPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCB0cmFja0Z1bmN0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3RyYWNrX2Z1bmN0aW9ucycpO1xuICB9XG4gIHB1YmxpYyBzZXQgdHJhY2tGdW5jdGlvbnModmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3RyYWNrRnVuY3Rpb25zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VHJhY2tGdW5jdGlvbnMoKSB7XG4gICAgdGhpcy5fdHJhY2tGdW5jdGlvbnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRyYWNrRnVuY3Rpb25zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RyYWNrRnVuY3Rpb25zO1xuICB9XG5cbiAgLy8gdHJhY2tfaW9fdGltaW5nIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdHJhY2tJb1RpbWluZz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgdHJhY2tJb1RpbWluZygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3RyYWNrX2lvX3RpbWluZycpO1xuICB9XG4gIHB1YmxpYyBzZXQgdHJhY2tJb1RpbWluZyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fdHJhY2tJb1RpbWluZyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRyYWNrSW9UaW1pbmcoKSB7XG4gICAgdGhpcy5fdHJhY2tJb1RpbWluZyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdHJhY2tJb1RpbWluZ0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90cmFja0lvVGltaW5nO1xuICB9XG5cbiAgLy8gd2FsX3NlbmRlcl90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfd2FsU2VuZGVyVGltZW91dD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgd2FsU2VuZGVyVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3dhbF9zZW5kZXJfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgd2FsU2VuZGVyVGltZW91dCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fd2FsU2VuZGVyVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFdhbFNlbmRlclRpbWVvdXQoKSB7XG4gICAgdGhpcy5fd2FsU2VuZGVyVGltZW91dCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgd2FsU2VuZGVyVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl93YWxTZW5kZXJUaW1lb3V0O1xuICB9XG5cbiAgLy8gd2FsX3dyaXRlcl9kZWxheSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3dhbFdyaXRlckRlbGF5PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB3YWxXcml0ZXJEZWxheSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3dhbF93cml0ZXJfZGVsYXknKTtcbiAgfVxuICBwdWJsaWMgc2V0IHdhbFdyaXRlckRlbGF5KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl93YWxXcml0ZXJEZWxheSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFdhbFdyaXRlckRlbGF5KCkge1xuICAgIHRoaXMuX3dhbFdyaXRlckRlbGF5ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB3YWxXcml0ZXJEZWxheUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl93YWxXcml0ZXJEZWxheTtcbiAgfVxuXG4gIC8vIHdvcmtfbWVtIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfd29ya01lbT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgd29ya01lbSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3dvcmtfbWVtJyk7XG4gIH1cbiAgcHVibGljIHNldCB3b3JrTWVtKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl93b3JrTWVtID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0V29ya01lbSgpIHtcbiAgICB0aGlzLl93b3JrTWVtID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB3b3JrTWVtSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dvcmtNZW07XG4gIH1cblxuICAvLyBwZ2JvdW5jZXIgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfcGdib3VuY2VyID0gbmV3IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlckxpc3QodGhpcywgXCJwZ2JvdW5jZXJcIiwgZmFsc2UpO1xuICBwdWJsaWMgZ2V0IHBnYm91bmNlcigpIHtcbiAgICByZXR1cm4gdGhpcy5fcGdib3VuY2VyO1xuICB9XG4gIHB1YmxpYyBwdXRQZ2JvdW5jZXIodmFsdWU6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlcltdIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9wZ2JvdW5jZXIuaW50ZXJuYWxWYWx1ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFBnYm91bmNlcigpIHtcbiAgICB0aGlzLl9wZ2JvdW5jZXIuaW50ZXJuYWxWYWx1ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcGdib3VuY2VySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BnYm91bmNlci5pbnRlcm5hbFZhbHVlO1xuICB9XG5cbiAgLy8gdGltZXNjYWxlZGIgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGltZXNjYWxlZGIgPSBuZXcgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGJPdXRwdXRSZWZlcmVuY2UodGhpcywgXCJ0aW1lc2NhbGVkYlwiKTtcbiAgcHVibGljIGdldCB0aW1lc2NhbGVkYigpIHtcbiAgICByZXR1cm4gdGhpcy5fdGltZXNjYWxlZGI7XG4gIH1cbiAgcHVibGljIHB1dFRpbWVzY2FsZWRiKHZhbHVlOiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYikge1xuICAgIHRoaXMuX3RpbWVzY2FsZWRiLmludGVybmFsVmFsdWUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaW1lc2NhbGVkYigpIHtcbiAgICB0aGlzLl90aW1lc2NhbGVkYi5pbnRlcm5hbFZhbHVlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aW1lc2NhbGVkYklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aW1lc2NhbGVkYi5pbnRlcm5hbFZhbHVlO1xuICB9XG5cbiAgLy8gPT09PT09PT09XG4gIC8vIFNZTlRIRVNJU1xuICAvLyA9PT09PT09PT1cblxuICBwcm90ZWN0ZWQgc3ludGhlc2l6ZUF0dHJpYnV0ZXMoKTogeyBbbmFtZTogc3RyaW5nXTogYW55IH0ge1xuICAgIHJldHVybiB7XG4gICAgICBhdXRvdmFjdXVtX2FuYWx5emVfc2NhbGVfZmFjdG9yOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yKSxcbiAgICAgIGF1dG92YWN1dW1fYW5hbHl6ZV90aHJlc2hvbGQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1BbmFseXplVGhyZXNob2xkKSxcbiAgICAgIGF1dG92YWN1dW1fZnJlZXplX21heF9hZ2U6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1GcmVlemVNYXhBZ2UpLFxuICAgICAgYXV0b3ZhY3V1bV9tYXhfd29ya2VyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bU1heFdvcmtlcnMpLFxuICAgICAgYXV0b3ZhY3V1bV9uYXB0aW1lOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtTmFwdGltZSksXG4gICAgICBhdXRvdmFjdXVtX3ZhY3V1bV9jb3N0X2RlbGF5OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5KSxcbiAgICAgIGF1dG92YWN1dW1fdmFjdXVtX2Nvc3RfbGltaXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQpLFxuICAgICAgYXV0b3ZhY3V1bV92YWN1dW1fc2NhbGVfZmFjdG9yOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3IpLFxuICAgICAgYXV0b3ZhY3V1bV92YWN1dW1fdGhyZXNob2xkOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkKSxcbiAgICAgIGJhY2t1cF9ob3VyOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iYWNrdXBIb3VyKSxcbiAgICAgIGJhY2t1cF9taW51dGU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2JhY2t1cE1pbnV0ZSksXG4gICAgICBiZ3dyaXRlcl9kZWxheTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJEZWxheSksXG4gICAgICBiZ3dyaXRlcl9mbHVzaF9hZnRlcjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJGbHVzaEFmdGVyKSxcbiAgICAgIGJnd3JpdGVyX2xydV9tYXhwYWdlczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJMcnVNYXhwYWdlcyksXG4gICAgICBiZ3dyaXRlcl9scnVfbXVsdGlwbGllcjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJMcnVNdWx0aXBsaWVyKSxcbiAgICAgIGNsdXN0ZXJfaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICBkZWFkbG9ja190aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9kZWFkbG9ja1RpbWVvdXQpLFxuICAgICAgZGVmYXVsdF90b2FzdF9jb21wcmVzc2lvbjogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fZGVmYXVsdFRvYXN0Q29tcHJlc3Npb24pLFxuICAgICAgaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgIGlkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0KSxcbiAgICAgIGppdDogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2ppdCksXG4gICAgICBsb2dfYXV0b3ZhY3V1bV9taW5fZHVyYXRpb246IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbiksXG4gICAgICBsb2dfZXJyb3JfdmVyYm9zaXR5OiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9sb2dFcnJvclZlcmJvc2l0eSksXG4gICAgICBsb2dfbGluZV9wcmVmaXg6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2xvZ0xpbmVQcmVmaXgpLFxuICAgICAgbG9nX21pbl9kdXJhdGlvbl9zdGF0ZW1lbnQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2xvZ01pbkR1cmF0aW9uU3RhdGVtZW50KSxcbiAgICAgIG1heF9maWxlc19wZXJfcHJvY2VzczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4RmlsZXNQZXJQcm9jZXNzKSxcbiAgICAgIG1heF9sb2Nrc19wZXJfdHJhbnNhY3Rpb246IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heExvY2tzUGVyVHJhbnNhY3Rpb24pLFxuICAgICAgbWF4X2xvZ2ljYWxfcmVwbGljYXRpb25fd29ya2VyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2VycyksXG4gICAgICBtYXhfcGFyYWxsZWxfd29ya2VyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzKSxcbiAgICAgIG1heF9wYXJhbGxlbF93b3JrZXJzX3Blcl9nYXRoZXI6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlciksXG4gICAgICBtYXhfcHJlZF9sb2Nrc19wZXJfdHJhbnNhY3Rpb246IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uKSxcbiAgICAgIG1heF9wcmVwYXJlZF90cmFuc2FjdGlvbnM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFByZXBhcmVkVHJhbnNhY3Rpb25zKSxcbiAgICAgIG1heF9yZXBsaWNhdGlvbl9zbG90czogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4UmVwbGljYXRpb25TbG90cyksXG4gICAgICBtYXhfc3RhY2tfZGVwdGg6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFN0YWNrRGVwdGgpLFxuICAgICAgbWF4X3N0YW5kYnlfYXJjaGl2ZV9kZWxheTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4U3RhbmRieUFyY2hpdmVEZWxheSksXG4gICAgICBtYXhfc3RhbmRieV9zdHJlYW1pbmdfZGVsYXk6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFN0YW5kYnlTdHJlYW1pbmdEZWxheSksXG4gICAgICBtYXhfd2FsX3NlbmRlcnM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFdhbFNlbmRlcnMpLFxuICAgICAgbWF4X3dvcmtlcl9wcm9jZXNzZXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heFdvcmtlclByb2Nlc3NlcyksXG4gICAgICBwZ19wYXJ0bWFuX2Jnd19pbnRlcnZhbDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fcGdQYXJ0bWFuQmd3SW50ZXJ2YWwpLFxuICAgICAgcGdfcGFydG1hbl9iZ3dfcm9sZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fcGdQYXJ0bWFuQmd3Um9sZSksXG4gICAgICBwZ19zdGF0X3N0YXRlbWVudHNfdHJhY2s6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX3BnU3RhdFN0YXRlbWVudHNUcmFjayksXG4gICAgICBzaGFyZWRfYnVmZmVyc19wZXJjZW50YWdlOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9zaGFyZWRCdWZmZXJzUGVyY2VudGFnZSksXG4gICAgICB0ZW1wX2ZpbGVfbGltaXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RlbXBGaWxlTGltaXQpLFxuICAgICAgdGltZXpvbmU6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX3RpbWV6b25lKSxcbiAgICAgIHRyYWNrX2FjdGl2aXR5X3F1ZXJ5X3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RyYWNrQWN0aXZpdHlRdWVyeVNpemUpLFxuICAgICAgdHJhY2tfY29tbWl0X3RpbWVzdGFtcDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fdHJhY2tDb21taXRUaW1lc3RhbXApLFxuICAgICAgdHJhY2tfZnVuY3Rpb25zOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl90cmFja0Z1bmN0aW9ucyksXG4gICAgICB0cmFja19pb190aW1pbmc6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX3RyYWNrSW9UaW1pbmcpLFxuICAgICAgd2FsX3NlbmRlcl90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl93YWxTZW5kZXJUaW1lb3V0KSxcbiAgICAgIHdhbF93cml0ZXJfZGVsYXk6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3dhbFdyaXRlckRlbGF5KSxcbiAgICAgIHdvcmtfbWVtOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl93b3JrTWVtKSxcbiAgICAgIHBnYm91bmNlcjogY2RrdG4ubGlzdE1hcHBlcihkYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJUb1RlcnJhZm9ybSwgdHJ1ZSkodGhpcy5fcGdib3VuY2VyLmludGVybmFsVmFsdWUpLFxuICAgICAgdGltZXNjYWxlZGI6IGRhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiVG9UZXJyYWZvcm0odGhpcy5fdGltZXNjYWxlZGIuaW50ZXJuYWxWYWx1ZSksXG4gICAgfTtcbiAgfVxuXG4gIHByb3RlY3RlZCBzeW50aGVzaXplSGNsQXR0cmlidXRlcygpOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSB7XG4gICAgY29uc3QgYXR0cnMgPSB7XG4gICAgICBhdXRvdmFjdXVtX2FuYWx5emVfc2NhbGVfZmFjdG9yOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYXV0b3ZhY3V1bV9hbmFseXplX3RocmVzaG9sZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBhdXRvdmFjdXVtX2ZyZWV6ZV9tYXhfYWdlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtRnJlZXplTWF4QWdlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYXV0b3ZhY3V1bV9tYXhfd29ya2Vyczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bU1heFdvcmtlcnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBhdXRvdmFjdXVtX25hcHRpbWU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1OYXB0aW1lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9kZWxheToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGF1dG92YWN1dW1fdmFjdXVtX2Nvc3RfbGltaXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBhdXRvdmFjdXVtX3ZhY3V1bV9zY2FsZV9mYWN0b3I6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvciksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGF1dG92YWN1dW1fdmFjdXVtX3RocmVzaG9sZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGJhY2t1cF9ob3VyOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9iYWNrdXBIb3VyKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmFja3VwX21pbnV0ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYmFja3VwTWludXRlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmd3cml0ZXJfZGVsYXk6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2Jnd3JpdGVyRGVsYXkpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiZ3dyaXRlcl9mbHVzaF9hZnRlcjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJGbHVzaEFmdGVyKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmd3cml0ZXJfbHJ1X21heHBhZ2VzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9iZ3dyaXRlckxydU1heHBhZ2VzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmd3cml0ZXJfbHJ1X211bHRpcGxpZXI6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2Jnd3JpdGVyTHJ1TXVsdGlwbGllciksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGNsdXN0ZXJfaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGRlYWRsb2NrX3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2RlYWRsb2NrVGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGRlZmF1bHRfdG9hc3RfY29tcHJlc3Npb246IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2RlZmF1bHRUb2FzdENvbXByZXNzaW9uKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBqaXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9qaXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgbG9nX2F1dG92YWN1dW1fbWluX2R1cmF0aW9uOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dBdXRvdmFjdXVtTWluRHVyYXRpb24pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBsb2dfZXJyb3JfdmVyYm9zaXR5OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dFcnJvclZlcmJvc2l0eSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19saW5lX3ByZWZpeDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nTGluZVByZWZpeCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19taW5fZHVyYXRpb25fc3RhdGVtZW50OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dNaW5EdXJhdGlvblN0YXRlbWVudCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9maWxlc19wZXJfcHJvY2Vzczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4RmlsZXNQZXJQcm9jZXNzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X2xvY2tzX3Blcl90cmFuc2FjdGlvbjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4TG9ja3NQZXJUcmFuc2FjdGlvbiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9sb2dpY2FsX3JlcGxpY2F0aW9uX3dvcmtlcnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfcGFyYWxsZWxfd29ya2Vyczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3BhcmFsbGVsX3dvcmtlcnNfcGVyX2dhdGhlcjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3ByZWRfbG9ja3NfcGVyX3RyYW5zYWN0aW9uOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhQcmVkTG9ja3NQZXJUcmFuc2FjdGlvbiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9wcmVwYXJlZF90cmFuc2FjdGlvbnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heFByZXBhcmVkVHJhbnNhY3Rpb25zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3JlcGxpY2F0aW9uX3Nsb3RzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhSZXBsaWNhdGlvblNsb3RzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3N0YWNrX2RlcHRoOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhTdGFja0RlcHRoKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3N0YW5kYnlfYXJjaGl2ZV9kZWxheToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4U3RhbmRieUFyY2hpdmVEZWxheSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9zdGFuZGJ5X3N0cmVhbWluZ19kZWxheToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3dhbF9zZW5kZXJzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhXYWxTZW5kZXJzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3dvcmtlcl9wcm9jZXNzZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heFdvcmtlclByb2Nlc3NlcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHBnX3BhcnRtYW5fYmd3X2ludGVydmFsOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9wZ1BhcnRtYW5CZ3dJbnRlcnZhbCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHBnX3BhcnRtYW5fYmd3X3JvbGU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3BnUGFydG1hbkJnd1JvbGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBwZ19zdGF0X3N0YXRlbWVudHNfdHJhY2s6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3BnU3RhdFN0YXRlbWVudHNUcmFjayksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIHNoYXJlZF9idWZmZXJzX3BlcmNlbnRhZ2U6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3NoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGVtcF9maWxlX2xpbWl0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90ZW1wRmlsZUxpbWl0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGltZXpvbmU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3RpbWV6b25lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgdHJhY2tfYWN0aXZpdHlfcXVlcnlfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRyYWNrX2NvbW1pdF90aW1lc3RhbXA6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3RyYWNrQ29tbWl0VGltZXN0YW1wKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgdHJhY2tfZnVuY3Rpb25zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl90cmFja0Z1bmN0aW9ucyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIHRyYWNrX2lvX3RpbWluZzoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fdHJhY2tJb1RpbWluZyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIHdhbF9zZW5kZXJfdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fd2FsU2VuZGVyVGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHdhbF93cml0ZXJfZGVsYXk6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3dhbFdyaXRlckRlbGF5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgd29ya19tZW06IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3dvcmtNZW0pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBwZ2JvdW5jZXI6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmxpc3RNYXBwZXJIY2woZGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyVG9IY2xUZXJyYWZvcm0sIHRydWUpKHRoaXMuX3BnYm91bmNlci5pbnRlcm5hbFZhbHVlKSxcbiAgICAgICAgaXNCbG9jazogdHJ1ZSxcbiAgICAgICAgdHlwZTogXCJsaXN0XCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyTGlzdFwiLFxuICAgICAgfSxcbiAgICAgIHRpbWVzY2FsZWRiOiB7XG4gICAgICAgIHZhbHVlOiBkYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYlRvSGNsVGVycmFmb3JtKHRoaXMuX3RpbWVzY2FsZWRiLmludGVybmFsVmFsdWUpLFxuICAgICAgICBpc0Jsb2NrOiB0cnVlLFxuICAgICAgICB0eXBlOiBcImxpc3RcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYkxpc3RcIixcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIC8vIHJlbW92ZSB1bmRlZmluZWQgYXR0cmlidXRlc1xuICAgIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoYXR0cnMpLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS52YWx1ZSAhPT0gdW5kZWZpbmVkICkpXG4gIH1cbn1cbiJdfQ==