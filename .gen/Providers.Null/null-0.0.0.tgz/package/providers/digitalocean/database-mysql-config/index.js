"use strict";
// https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config
// generated from terraform resource schema
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseMysqlConfig = void 0;
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config digitalocean_database_mysql_config}
*/
class DatabaseMysqlConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseMysqlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseMysqlConfig to import
    * @param importFromId The id of the existing DatabaseMysqlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseMysqlConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_mysql_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config digitalocean_database_mysql_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseMysqlConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_mysql_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._backupHour = config.backupHour;
        this._backupMinute = config.backupMinute;
        this._binlogRetentionPeriod = config.binlogRetentionPeriod;
        this._clusterId = config.clusterId;
        this._connectTimeout = config.connectTimeout;
        this._defaultTimeZone = config.defaultTimeZone;
        this._groupConcatMaxLen = config.groupConcatMaxLen;
        this._id = config.id;
        this._informationSchemaStatsExpiry = config.informationSchemaStatsExpiry;
        this._innodbFtMinTokenSize = config.innodbFtMinTokenSize;
        this._innodbFtServerStopwordTable = config.innodbFtServerStopwordTable;
        this._innodbLockWaitTimeout = config.innodbLockWaitTimeout;
        this._innodbLogBufferSize = config.innodbLogBufferSize;
        this._innodbOnlineAlterLogMaxSize = config.innodbOnlineAlterLogMaxSize;
        this._innodbPrintAllDeadlocks = config.innodbPrintAllDeadlocks;
        this._innodbRollbackOnTimeout = config.innodbRollbackOnTimeout;
        this._interactiveTimeout = config.interactiveTimeout;
        this._internalTmpMemStorageEngine = config.internalTmpMemStorageEngine;
        this._longQueryTime = config.longQueryTime;
        this._maxAllowedPacket = config.maxAllowedPacket;
        this._maxHeapTableSize = config.maxHeapTableSize;
        this._netReadTimeout = config.netReadTimeout;
        this._netWriteTimeout = config.netWriteTimeout;
        this._slowQueryLog = config.slowQueryLog;
        this._sortBufferSize = config.sortBufferSize;
        this._sqlMode = config.sqlMode;
        this._sqlRequirePrimaryKey = config.sqlRequirePrimaryKey;
        this._tmpTableSize = config.tmpTableSize;
        this._waitTimeout = config.waitTimeout;
    }
    get backupHour() {
        return this.getNumberAttribute('backup_hour');
    }
    set backupHour(value) {
        this._backupHour = value;
    }
    resetBackupHour() {
        this._backupHour = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupHourInput() {
        return this._backupHour;
    }
    get backupMinute() {
        return this.getNumberAttribute('backup_minute');
    }
    set backupMinute(value) {
        this._backupMinute = value;
    }
    resetBackupMinute() {
        this._backupMinute = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupMinuteInput() {
        return this._backupMinute;
    }
    get binlogRetentionPeriod() {
        return this.getNumberAttribute('binlog_retention_period');
    }
    set binlogRetentionPeriod(value) {
        this._binlogRetentionPeriod = value;
    }
    resetBinlogRetentionPeriod() {
        this._binlogRetentionPeriod = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get binlogRetentionPeriodInput() {
        return this._binlogRetentionPeriod;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get connectTimeout() {
        return this.getNumberAttribute('connect_timeout');
    }
    set connectTimeout(value) {
        this._connectTimeout = value;
    }
    resetConnectTimeout() {
        this._connectTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get connectTimeoutInput() {
        return this._connectTimeout;
    }
    get defaultTimeZone() {
        return this.getStringAttribute('default_time_zone');
    }
    set defaultTimeZone(value) {
        this._defaultTimeZone = value;
    }
    resetDefaultTimeZone() {
        this._defaultTimeZone = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get defaultTimeZoneInput() {
        return this._defaultTimeZone;
    }
    get groupConcatMaxLen() {
        return this.getNumberAttribute('group_concat_max_len');
    }
    set groupConcatMaxLen(value) {
        this._groupConcatMaxLen = value;
    }
    resetGroupConcatMaxLen() {
        this._groupConcatMaxLen = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupConcatMaxLenInput() {
        return this._groupConcatMaxLen;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get informationSchemaStatsExpiry() {
        return this.getNumberAttribute('information_schema_stats_expiry');
    }
    set informationSchemaStatsExpiry(value) {
        this._informationSchemaStatsExpiry = value;
    }
    resetInformationSchemaStatsExpiry() {
        this._informationSchemaStatsExpiry = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get informationSchemaStatsExpiryInput() {
        return this._informationSchemaStatsExpiry;
    }
    get innodbFtMinTokenSize() {
        return this.getNumberAttribute('innodb_ft_min_token_size');
    }
    set innodbFtMinTokenSize(value) {
        this._innodbFtMinTokenSize = value;
    }
    resetInnodbFtMinTokenSize() {
        this._innodbFtMinTokenSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbFtMinTokenSizeInput() {
        return this._innodbFtMinTokenSize;
    }
    get innodbFtServerStopwordTable() {
        return this.getStringAttribute('innodb_ft_server_stopword_table');
    }
    set innodbFtServerStopwordTable(value) {
        this._innodbFtServerStopwordTable = value;
    }
    resetInnodbFtServerStopwordTable() {
        this._innodbFtServerStopwordTable = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbFtServerStopwordTableInput() {
        return this._innodbFtServerStopwordTable;
    }
    get innodbLockWaitTimeout() {
        return this.getNumberAttribute('innodb_lock_wait_timeout');
    }
    set innodbLockWaitTimeout(value) {
        this._innodbLockWaitTimeout = value;
    }
    resetInnodbLockWaitTimeout() {
        this._innodbLockWaitTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbLockWaitTimeoutInput() {
        return this._innodbLockWaitTimeout;
    }
    get innodbLogBufferSize() {
        return this.getNumberAttribute('innodb_log_buffer_size');
    }
    set innodbLogBufferSize(value) {
        this._innodbLogBufferSize = value;
    }
    resetInnodbLogBufferSize() {
        this._innodbLogBufferSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbLogBufferSizeInput() {
        return this._innodbLogBufferSize;
    }
    get innodbOnlineAlterLogMaxSize() {
        return this.getNumberAttribute('innodb_online_alter_log_max_size');
    }
    set innodbOnlineAlterLogMaxSize(value) {
        this._innodbOnlineAlterLogMaxSize = value;
    }
    resetInnodbOnlineAlterLogMaxSize() {
        this._innodbOnlineAlterLogMaxSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbOnlineAlterLogMaxSizeInput() {
        return this._innodbOnlineAlterLogMaxSize;
    }
    get innodbPrintAllDeadlocks() {
        return this.getBooleanAttribute('innodb_print_all_deadlocks');
    }
    set innodbPrintAllDeadlocks(value) {
        this._innodbPrintAllDeadlocks = value;
    }
    resetInnodbPrintAllDeadlocks() {
        this._innodbPrintAllDeadlocks = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbPrintAllDeadlocksInput() {
        return this._innodbPrintAllDeadlocks;
    }
    get innodbRollbackOnTimeout() {
        return this.getBooleanAttribute('innodb_rollback_on_timeout');
    }
    set innodbRollbackOnTimeout(value) {
        this._innodbRollbackOnTimeout = value;
    }
    resetInnodbRollbackOnTimeout() {
        this._innodbRollbackOnTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbRollbackOnTimeoutInput() {
        return this._innodbRollbackOnTimeout;
    }
    get interactiveTimeout() {
        return this.getNumberAttribute('interactive_timeout');
    }
    set interactiveTimeout(value) {
        this._interactiveTimeout = value;
    }
    resetInteractiveTimeout() {
        this._interactiveTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get interactiveTimeoutInput() {
        return this._interactiveTimeout;
    }
    get internalTmpMemStorageEngine() {
        return this.getStringAttribute('internal_tmp_mem_storage_engine');
    }
    set internalTmpMemStorageEngine(value) {
        this._internalTmpMemStorageEngine = value;
    }
    resetInternalTmpMemStorageEngine() {
        this._internalTmpMemStorageEngine = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get internalTmpMemStorageEngineInput() {
        return this._internalTmpMemStorageEngine;
    }
    get longQueryTime() {
        return this.getNumberAttribute('long_query_time');
    }
    set longQueryTime(value) {
        this._longQueryTime = value;
    }
    resetLongQueryTime() {
        this._longQueryTime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get longQueryTimeInput() {
        return this._longQueryTime;
    }
    get maxAllowedPacket() {
        return this.getNumberAttribute('max_allowed_packet');
    }
    set maxAllowedPacket(value) {
        this._maxAllowedPacket = value;
    }
    resetMaxAllowedPacket() {
        this._maxAllowedPacket = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxAllowedPacketInput() {
        return this._maxAllowedPacket;
    }
    get maxHeapTableSize() {
        return this.getNumberAttribute('max_heap_table_size');
    }
    set maxHeapTableSize(value) {
        this._maxHeapTableSize = value;
    }
    resetMaxHeapTableSize() {
        this._maxHeapTableSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxHeapTableSizeInput() {
        return this._maxHeapTableSize;
    }
    get netReadTimeout() {
        return this.getNumberAttribute('net_read_timeout');
    }
    set netReadTimeout(value) {
        this._netReadTimeout = value;
    }
    resetNetReadTimeout() {
        this._netReadTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get netReadTimeoutInput() {
        return this._netReadTimeout;
    }
    get netWriteTimeout() {
        return this.getNumberAttribute('net_write_timeout');
    }
    set netWriteTimeout(value) {
        this._netWriteTimeout = value;
    }
    resetNetWriteTimeout() {
        this._netWriteTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get netWriteTimeoutInput() {
        return this._netWriteTimeout;
    }
    get slowQueryLog() {
        return this.getBooleanAttribute('slow_query_log');
    }
    set slowQueryLog(value) {
        this._slowQueryLog = value;
    }
    resetSlowQueryLog() {
        this._slowQueryLog = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get slowQueryLogInput() {
        return this._slowQueryLog;
    }
    get sortBufferSize() {
        return this.getNumberAttribute('sort_buffer_size');
    }
    set sortBufferSize(value) {
        this._sortBufferSize = value;
    }
    resetSortBufferSize() {
        this._sortBufferSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sortBufferSizeInput() {
        return this._sortBufferSize;
    }
    get sqlMode() {
        return this.getStringAttribute('sql_mode');
    }
    set sqlMode(value) {
        this._sqlMode = value;
    }
    resetSqlMode() {
        this._sqlMode = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sqlModeInput() {
        return this._sqlMode;
    }
    get sqlRequirePrimaryKey() {
        return this.getBooleanAttribute('sql_require_primary_key');
    }
    set sqlRequirePrimaryKey(value) {
        this._sqlRequirePrimaryKey = value;
    }
    resetSqlRequirePrimaryKey() {
        this._sqlRequirePrimaryKey = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sqlRequirePrimaryKeyInput() {
        return this._sqlRequirePrimaryKey;
    }
    get tmpTableSize() {
        return this.getNumberAttribute('tmp_table_size');
    }
    set tmpTableSize(value) {
        this._tmpTableSize = value;
    }
    resetTmpTableSize() {
        this._tmpTableSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get tmpTableSizeInput() {
        return this._tmpTableSize;
    }
    get waitTimeout() {
        return this.getNumberAttribute('wait_timeout');
    }
    set waitTimeout(value) {
        this._waitTimeout = value;
    }
    resetWaitTimeout() {
        this._waitTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get waitTimeoutInput() {
        return this._waitTimeout;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            backup_hour: cdktn.numberToTerraform(this._backupHour),
            backup_minute: cdktn.numberToTerraform(this._backupMinute),
            binlog_retention_period: cdktn.numberToTerraform(this._binlogRetentionPeriod),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            connect_timeout: cdktn.numberToTerraform(this._connectTimeout),
            default_time_zone: cdktn.stringToTerraform(this._defaultTimeZone),
            group_concat_max_len: cdktn.numberToTerraform(this._groupConcatMaxLen),
            id: cdktn.stringToTerraform(this._id),
            information_schema_stats_expiry: cdktn.numberToTerraform(this._informationSchemaStatsExpiry),
            innodb_ft_min_token_size: cdktn.numberToTerraform(this._innodbFtMinTokenSize),
            innodb_ft_server_stopword_table: cdktn.stringToTerraform(this._innodbFtServerStopwordTable),
            innodb_lock_wait_timeout: cdktn.numberToTerraform(this._innodbLockWaitTimeout),
            innodb_log_buffer_size: cdktn.numberToTerraform(this._innodbLogBufferSize),
            innodb_online_alter_log_max_size: cdktn.numberToTerraform(this._innodbOnlineAlterLogMaxSize),
            innodb_print_all_deadlocks: cdktn.booleanToTerraform(this._innodbPrintAllDeadlocks),
            innodb_rollback_on_timeout: cdktn.booleanToTerraform(this._innodbRollbackOnTimeout),
            interactive_timeout: cdktn.numberToTerraform(this._interactiveTimeout),
            internal_tmp_mem_storage_engine: cdktn.stringToTerraform(this._internalTmpMemStorageEngine),
            long_query_time: cdktn.numberToTerraform(this._longQueryTime),
            max_allowed_packet: cdktn.numberToTerraform(this._maxAllowedPacket),
            max_heap_table_size: cdktn.numberToTerraform(this._maxHeapTableSize),
            net_read_timeout: cdktn.numberToTerraform(this._netReadTimeout),
            net_write_timeout: cdktn.numberToTerraform(this._netWriteTimeout),
            slow_query_log: cdktn.booleanToTerraform(this._slowQueryLog),
            sort_buffer_size: cdktn.numberToTerraform(this._sortBufferSize),
            sql_mode: cdktn.stringToTerraform(this._sqlMode),
            sql_require_primary_key: cdktn.booleanToTerraform(this._sqlRequirePrimaryKey),
            tmp_table_size: cdktn.numberToTerraform(this._tmpTableSize),
            wait_timeout: cdktn.numberToTerraform(this._waitTimeout),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            backup_hour: {
                value: cdktn.numberToHclTerraform(this._backupHour),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            backup_minute: {
                value: cdktn.numberToHclTerraform(this._backupMinute),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            binlog_retention_period: {
                value: cdktn.numberToHclTerraform(this._binlogRetentionPeriod),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            connect_timeout: {
                value: cdktn.numberToHclTerraform(this._connectTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            default_time_zone: {
                value: cdktn.stringToHclTerraform(this._defaultTimeZone),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            group_concat_max_len: {
                value: cdktn.numberToHclTerraform(this._groupConcatMaxLen),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            information_schema_stats_expiry: {
                value: cdktn.numberToHclTerraform(this._informationSchemaStatsExpiry),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_ft_min_token_size: {
                value: cdktn.numberToHclTerraform(this._innodbFtMinTokenSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_ft_server_stopword_table: {
                value: cdktn.stringToHclTerraform(this._innodbFtServerStopwordTable),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            innodb_lock_wait_timeout: {
                value: cdktn.numberToHclTerraform(this._innodbLockWaitTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_log_buffer_size: {
                value: cdktn.numberToHclTerraform(this._innodbLogBufferSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_online_alter_log_max_size: {
                value: cdktn.numberToHclTerraform(this._innodbOnlineAlterLogMaxSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_print_all_deadlocks: {
                value: cdktn.booleanToHclTerraform(this._innodbPrintAllDeadlocks),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            innodb_rollback_on_timeout: {
                value: cdktn.booleanToHclTerraform(this._innodbRollbackOnTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            interactive_timeout: {
                value: cdktn.numberToHclTerraform(this._interactiveTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            internal_tmp_mem_storage_engine: {
                value: cdktn.stringToHclTerraform(this._internalTmpMemStorageEngine),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            long_query_time: {
                value: cdktn.numberToHclTerraform(this._longQueryTime),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_allowed_packet: {
                value: cdktn.numberToHclTerraform(this._maxAllowedPacket),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_heap_table_size: {
                value: cdktn.numberToHclTerraform(this._maxHeapTableSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            net_read_timeout: {
                value: cdktn.numberToHclTerraform(this._netReadTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            net_write_timeout: {
                value: cdktn.numberToHclTerraform(this._netWriteTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            slow_query_log: {
                value: cdktn.booleanToHclTerraform(this._slowQueryLog),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            sort_buffer_size: {
                value: cdktn.numberToHclTerraform(this._sortBufferSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            sql_mode: {
                value: cdktn.stringToHclTerraform(this._sqlMode),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            sql_require_primary_key: {
                value: cdktn.booleanToHclTerraform(this._sqlRequirePrimaryKey),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            tmp_table_size: {
                value: cdktn.numberToHclTerraform(this._tmpTableSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            wait_timeout: {
                value: cdktn.numberToHclTerraform(this._waitTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseMysqlConfig = DatabaseMysqlConfig;
// =================
// STATIC PROPERTIES
// =================
DatabaseMysqlConfig.tfResourceType = "digitalocean_database_mysql_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsZ0hBQWdIO0FBQ2hILDJDQUEyQzs7O0FBRzNDLCtCQUErQjtBQThIL0I7O0VBRUU7QUFDRixNQUFhLG1CQUFvQixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPOUQsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLG9DQUFvQyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM1SixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBaUM7UUFDaEYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSxvQ0FBb0M7WUFDM0QsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDckMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7UUFDM0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUM3QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQztRQUMvQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzNELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxNQUFNLENBQUMsbUJBQW1CLENBQUM7UUFDdkQsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLHVCQUF1QixDQUFDO1FBQy9ELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQztRQUNyRCxJQUFJLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDO1FBQ3ZFLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQ2pELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUM7UUFDakQsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1FBQzdDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDO1FBQy9DLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUN6QyxJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7UUFDN0MsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQy9CLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQztJQUN6QyxDQUFDO0lBUUQsSUFBVyxVQUFVO1FBQ25CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDRCxJQUFXLFVBQVUsQ0FBQyxLQUFhO1FBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0lBQzNCLENBQUM7SUFDTSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDO0lBQy9CLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxlQUFlO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUMxQixDQUFDO0lBSUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFXLFlBQVksQ0FBQyxLQUFhO1FBQ25DLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFDTSxpQkFBaUI7UUFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7SUFDakMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDNUIsQ0FBQztJQUlELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUNELElBQVcscUJBQXFCLENBQUMsS0FBYTtRQUM1QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7SUFDTSwwQkFBMEI7UUFDL0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsQ0FBQztJQUMxQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JDLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBVyxjQUFjLENBQUMsS0FBYTtRQUNyQyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBQ00sbUJBQW1CO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO0lBQ25DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFJRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0QsSUFBVyxlQUFlLENBQUMsS0FBYTtRQUN0QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQ2hDLENBQUM7SUFDTSxvQkFBb0I7UUFDekIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFNBQVMsQ0FBQztJQUNwQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxFQUFFO1FBQ1gsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQVcsRUFBRSxDQUFDLEtBQWE7UUFDekIsSUFBSSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7SUFDbkIsQ0FBQztJQUNNLE9BQU87UUFDWixJQUFJLENBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQztJQUN2QixDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsT0FBTztRQUNoQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDbEIsQ0FBQztJQUlELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlDQUFpQyxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUNELElBQVcsNEJBQTRCLENBQUMsS0FBYTtRQUNuRCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFDTSxpQ0FBaUM7UUFDdEMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLFNBQVMsQ0FBQztJQUNqRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDO0lBQzVDLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQVcscUJBQXFCLENBQUMsS0FBYTtRQUM1QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7SUFDTSwwQkFBMEI7UUFDL0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsQ0FBQztJQUMxQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JDLENBQUM7SUFJRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG1CQUFtQixDQUFDLEtBQWE7UUFDMUMsSUFBSSxDQUFDLG9CQUFvQixHQUFHLEtBQUssQ0FBQztJQUNwQyxDQUFDO0lBQ00sd0JBQXdCO1FBQzdCLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxTQUFTLENBQUM7SUFDeEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUNuQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsa0NBQWtDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBa0M7UUFDbkUsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQztJQUN4QyxDQUFDO0lBQ00sNEJBQTRCO1FBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxTQUFTLENBQUM7SUFDNUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztJQUN2QyxDQUFDO0lBSUQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFrQztRQUNuRSxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFJRCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGdCQUFnQixDQUFDLEtBQWE7UUFDdkMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBQ00scUJBQXFCO1FBQzFCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxTQUFTLENBQUM7SUFDckMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHFCQUFxQjtRQUM5QixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztJQUNoQyxDQUFDO0lBSUQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDckQsQ0FBQztJQUNELElBQVcsY0FBYyxDQUFDLEtBQWE7UUFDckMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQUNNLG1CQUFtQjtRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztJQUNuQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsbUJBQW1CO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBSUQsSUFBVyxlQUFlO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUNELElBQVcsZUFBZSxDQUFDLEtBQWE7UUFDdEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztJQUNoQyxDQUFDO0lBQ00sb0JBQW9CO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxTQUFTLENBQUM7SUFDcEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUMvQixDQUFDO0lBSUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQVcsWUFBWSxDQUFDLEtBQWtDO1FBQ3hELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFDTSxpQkFBaUI7UUFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7SUFDakMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDNUIsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsT0FBTztRQUNoQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBVyxPQUFPLENBQUMsS0FBYTtRQUM5QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUN4QixDQUFDO0lBQ00sWUFBWTtRQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztJQUM1QixDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsWUFBWTtRQUNyQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDdkIsQ0FBQztJQUlELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQVcsb0JBQW9CLENBQUMsS0FBa0M7UUFDaEUsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQVcsWUFBWSxDQUFDLEtBQWE7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUNNLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUJBQWlCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBSUQsSUFBVyxXQUFXO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFXLFdBQVcsQ0FBQyxLQUFhO1FBQ2xDLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO0lBQzVCLENBQUM7SUFDTSxnQkFBZ0I7UUFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUM7SUFDaEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDM0IsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsV0FBVyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBQ3RELGFBQWEsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUMxRCx1QkFBdUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzdFLFVBQVUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUNwRCxlQUFlLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDOUQsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNqRSxvQkFBb0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3RFLEVBQUUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNyQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO1lBQzVGLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7WUFDN0UsK0JBQStCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUMzRix3QkFBd0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzlFLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDMUUsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUM1RiwwQkFBMEIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ25GLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7WUFDbkYsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN0RSwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO1lBQzNGLGVBQWUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUM3RCxrQkFBa0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ25FLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDcEUsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNqRSxjQUFjLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDNUQsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsUUFBUSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ2hELHVCQUF1QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7WUFDN0UsY0FBYyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQzNELFlBQVksRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUN6RCxDQUFDO0lBQ0osQ0FBQztJQUVTLHVCQUF1QjtRQUMvQixNQUFNLEtBQUssR0FBRztZQUNaLFdBQVcsRUFBRTtnQkFDWCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7Z0JBQ25ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsdUJBQXVCLEVBQUU7Z0JBQ3ZCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7Z0JBQ3ZELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQkFBaUIsRUFBRTtnQkFDakIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxFQUFFLEVBQUU7Z0JBQ0YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUMzQyxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsK0JBQStCLEVBQUU7Z0JBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO2dCQUNyRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsK0JBQStCLEVBQUU7Z0JBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsc0JBQXNCLEVBQUU7Z0JBQ3RCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO2dCQUM1RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZ0NBQWdDLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsMEJBQTBCLEVBQUU7Z0JBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO2dCQUNqRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsMEJBQTBCLEVBQUU7Z0JBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO2dCQUNqRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsK0JBQStCLEVBQUU7Z0JBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDekQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDekQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGdCQUFnQixFQUFFO2dCQUNoQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7Z0JBQ3ZELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQkFBaUIsRUFBRTtnQkFDakIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxjQUFjLEVBQUU7Z0JBQ2QsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUN0RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsZ0JBQWdCLEVBQUU7Z0JBQ2hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDdkQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFFBQVEsRUFBRTtnQkFDUixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ2hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCxjQUFjLEVBQUU7Z0JBQ2QsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDcEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtTQUNGLENBQUM7UUFFRiw4QkFBOEI7UUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUUsQ0FBQyxDQUFBO0lBQzVILENBQUM7O0FBMXZCSCxrREEydkJDO0FBenZCQyxvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNHLGtDQUFjLEdBQUcsb0NBQW9DLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnXG4vLyBnZW5lcmF0ZWQgZnJvbSB0ZXJyYWZvcm0gcmVzb3VyY2Ugc2NoZW1hXG5cbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0ICogYXMgY2RrdG4gZnJvbSAnY2RrdG4nO1xuXG4vLyBDb25maWd1cmF0aW9uXG5cbmV4cG9ydCBpbnRlcmZhY2UgRGF0YWJhc2VNeXNxbENvbmZpZ0NvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybU1ldGFBcmd1bWVudHMge1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjYmFja3VwX2hvdXIgRGF0YWJhc2VNeXNxbENvbmZpZyNiYWNrdXBfaG91cn1cbiAgKi9cbiAgcmVhZG9ubHkgYmFja3VwSG91cj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2JhY2t1cF9taW51dGUgRGF0YWJhc2VNeXNxbENvbmZpZyNiYWNrdXBfbWludXRlfVxuICAqL1xuICByZWFkb25seSBiYWNrdXBNaW51dGU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNiaW5sb2dfcmV0ZW50aW9uX3BlcmlvZCBEYXRhYmFzZU15c3FsQ29uZmlnI2JpbmxvZ19yZXRlbnRpb25fcGVyaW9kfVxuICAqL1xuICByZWFkb25seSBiaW5sb2dSZXRlbnRpb25QZXJpb2Q/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNjbHVzdGVyX2lkIERhdGFiYXNlTXlzcWxDb25maWcjY2x1c3Rlcl9pZH1cbiAgKi9cbiAgcmVhZG9ubHkgY2x1c3RlcklkOiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNjb25uZWN0X3RpbWVvdXQgRGF0YWJhc2VNeXNxbENvbmZpZyNjb25uZWN0X3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IGNvbm5lY3RUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjZGVmYXVsdF90aW1lX3pvbmUgRGF0YWJhc2VNeXNxbENvbmZpZyNkZWZhdWx0X3RpbWVfem9uZX1cbiAgKi9cbiAgcmVhZG9ubHkgZGVmYXVsdFRpbWVab25lPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjZ3JvdXBfY29uY2F0X21heF9sZW4gRGF0YWJhc2VNeXNxbENvbmZpZyNncm91cF9jb25jYXRfbWF4X2xlbn1cbiAgKi9cbiAgcmVhZG9ubHkgZ3JvdXBDb25jYXRNYXhMZW4/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpZCBEYXRhYmFzZU15c3FsQ29uZmlnI2lkfVxuICAqXG4gICogUGxlYXNlIGJlIGF3YXJlIHRoYXQgdGhlIGlkIGZpZWxkIGlzIGF1dG9tYXRpY2FsbHkgYWRkZWQgdG8gYWxsIHJlc291cmNlcyBpbiBUZXJyYWZvcm0gcHJvdmlkZXJzIHVzaW5nIGEgVGVycmFmb3JtIHByb3ZpZGVyIFNESyB2ZXJzaW9uIGJlbG93IDIuXG4gICogSWYgeW91IGV4cGVyaWVuY2UgcHJvYmxlbXMgc2V0dGluZyB0aGlzIHZhbHVlIGl0IG1pZ2h0IG5vdCBiZSBzZXR0YWJsZS4gUGxlYXNlIHRha2UgYSBsb29rIGF0IHRoZSBwcm92aWRlciBkb2N1bWVudGF0aW9uIHRvIGVuc3VyZSBpdCBzaG91bGQgYmUgc2V0dGFibGUuXG4gICovXG4gIHJlYWRvbmx5IGlkPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW5mb3JtYXRpb25fc2NoZW1hX3N0YXRzX2V4cGlyeSBEYXRhYmFzZU15c3FsQ29uZmlnI2luZm9ybWF0aW9uX3NjaGVtYV9zdGF0c19leHBpcnl9XG4gICovXG4gIHJlYWRvbmx5IGluZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnk/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbm5vZGJfZnRfbWluX3Rva2VuX3NpemUgRGF0YWJhc2VNeXNxbENvbmZpZyNpbm5vZGJfZnRfbWluX3Rva2VuX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IGlubm9kYkZ0TWluVG9rZW5TaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW5ub2RiX2Z0X3NlcnZlcl9zdG9wd29yZF90YWJsZSBEYXRhYmFzZU15c3FsQ29uZmlnI2lubm9kYl9mdF9zZXJ2ZXJfc3RvcHdvcmRfdGFibGV9XG4gICovXG4gIHJlYWRvbmx5IGlubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2lubm9kYl9sb2NrX3dhaXRfdGltZW91dCBEYXRhYmFzZU15c3FsQ29uZmlnI2lubm9kYl9sb2NrX3dhaXRfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgaW5ub2RiTG9ja1dhaXRUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW5ub2RiX2xvZ19idWZmZXJfc2l6ZSBEYXRhYmFzZU15c3FsQ29uZmlnI2lubm9kYl9sb2dfYnVmZmVyX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IGlubm9kYkxvZ0J1ZmZlclNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbm5vZGJfb25saW5lX2FsdGVyX2xvZ19tYXhfc2l6ZSBEYXRhYmFzZU15c3FsQ29uZmlnI2lubm9kYl9vbmxpbmVfYWx0ZXJfbG9nX21heF9zaXplfVxuICAqL1xuICByZWFkb25seSBpbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbm5vZGJfcHJpbnRfYWxsX2RlYWRsb2NrcyBEYXRhYmFzZU15c3FsQ29uZmlnI2lubm9kYl9wcmludF9hbGxfZGVhZGxvY2tzfVxuICAqL1xuICByZWFkb25seSBpbm5vZGJQcmludEFsbERlYWRsb2Nrcz86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2lubm9kYl9yb2xsYmFja19vbl90aW1lb3V0IERhdGFiYXNlTXlzcWxDb25maWcjaW5ub2RiX3JvbGxiYWNrX29uX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IGlubm9kYlJvbGxiYWNrT25UaW1lb3V0PzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW50ZXJhY3RpdmVfdGltZW91dCBEYXRhYmFzZU15c3FsQ29uZmlnI2ludGVyYWN0aXZlX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IGludGVyYWN0aXZlVGltZW91dD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2ludGVybmFsX3RtcF9tZW1fc3RvcmFnZV9lbmdpbmUgRGF0YWJhc2VNeXNxbENvbmZpZyNpbnRlcm5hbF90bXBfbWVtX3N0b3JhZ2VfZW5naW5lfVxuICAqL1xuICByZWFkb25seSBpbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmU/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNsb25nX3F1ZXJ5X3RpbWUgRGF0YWJhc2VNeXNxbENvbmZpZyNsb25nX3F1ZXJ5X3RpbWV9XG4gICovXG4gIHJlYWRvbmx5IGxvbmdRdWVyeVRpbWU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNtYXhfYWxsb3dlZF9wYWNrZXQgRGF0YWJhc2VNeXNxbENvbmZpZyNtYXhfYWxsb3dlZF9wYWNrZXR9XG4gICovXG4gIHJlYWRvbmx5IG1heEFsbG93ZWRQYWNrZXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNtYXhfaGVhcF90YWJsZV9zaXplIERhdGFiYXNlTXlzcWxDb25maWcjbWF4X2hlYXBfdGFibGVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgbWF4SGVhcFRhYmxlU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI25ldF9yZWFkX3RpbWVvdXQgRGF0YWJhc2VNeXNxbENvbmZpZyNuZXRfcmVhZF90aW1lb3V0fVxuICAqL1xuICByZWFkb25seSBuZXRSZWFkVGltZW91dD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI25ldF93cml0ZV90aW1lb3V0IERhdGFiYXNlTXlzcWxDb25maWcjbmV0X3dyaXRlX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IG5ldFdyaXRlVGltZW91dD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI3Nsb3dfcXVlcnlfbG9nIERhdGFiYXNlTXlzcWxDb25maWcjc2xvd19xdWVyeV9sb2d9XG4gICovXG4gIHJlYWRvbmx5IHNsb3dRdWVyeUxvZz86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI3NvcnRfYnVmZmVyX3NpemUgRGF0YWJhc2VNeXNxbENvbmZpZyNzb3J0X2J1ZmZlcl9zaXplfVxuICAqL1xuICByZWFkb25seSBzb3J0QnVmZmVyU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI3NxbF9tb2RlIERhdGFiYXNlTXlzcWxDb25maWcjc3FsX21vZGV9XG4gICovXG4gIHJlYWRvbmx5IHNxbE1vZGU/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNzcWxfcmVxdWlyZV9wcmltYXJ5X2tleSBEYXRhYmFzZU15c3FsQ29uZmlnI3NxbF9yZXF1aXJlX3ByaW1hcnlfa2V5fVxuICAqL1xuICByZWFkb25seSBzcWxSZXF1aXJlUHJpbWFyeUtleT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI3RtcF90YWJsZV9zaXplIERhdGFiYXNlTXlzcWxDb25maWcjdG1wX3RhYmxlX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRtcFRhYmxlU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI3dhaXRfdGltZW91dCBEYXRhYmFzZU15c3FsQ29uZmlnI3dhaXRfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgd2FpdFRpbWVvdXQ/OiBudW1iZXI7XG59XG5cbi8qKlxuKiBSZXByZXNlbnRzIGEge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX215c3FsX2NvbmZpZ31cbiovXG5leHBvcnQgY2xhc3MgRGF0YWJhc2VNeXNxbENvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybVJlc291cmNlIHtcblxuICAvLyA9PT09PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgUFJPUEVSVElFU1xuICAvLyA9PT09PT09PT09PT09PT09PVxuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IHRmUmVzb3VyY2VUeXBlID0gXCJkaWdpdGFsb2NlYW5fZGF0YWJhc2VfbXlzcWxfY29uZmlnXCI7XG5cbiAgLy8gPT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIE1ldGhvZHNcbiAgLy8gPT09PT09PT09PT09PT1cbiAgLyoqXG4gICogR2VuZXJhdGVzIENES1ROIGNvZGUgZm9yIGltcG9ydGluZyBhIERhdGFiYXNlTXlzcWxDb25maWcgcmVzb3VyY2UgdXBvbiBydW5uaW5nIFwiY2RrdG4gcGxhbiA8c3RhY2stbmFtZT5cIlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGltcG9ydFRvSWQgVGhlIGNvbnN0cnVjdCBpZCB1c2VkIGluIHRoZSBnZW5lcmF0ZWQgY29uZmlnIGZvciB0aGUgRGF0YWJhc2VNeXNxbENvbmZpZyB0byBpbXBvcnRcbiAgKiBAcGFyYW0gaW1wb3J0RnJvbUlkIFRoZSBpZCBvZiB0aGUgZXhpc3RpbmcgRGF0YWJhc2VNeXNxbENvbmZpZyB0aGF0IHNob3VsZCBiZSBpbXBvcnRlZC4gUmVmZXIgdG8gdGhlIHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2ltcG9ydCBpbXBvcnQgc2VjdGlvbn0gaW4gdGhlIGRvY3VtZW50YXRpb24gb2YgdGhpcyByZXNvdXJjZSBmb3IgdGhlIGlkIHRvIHVzZVxuICAqIEBwYXJhbSBwcm92aWRlcj8gT3B0aW9uYWwgaW5zdGFuY2Ugb2YgdGhlIHByb3ZpZGVyIHdoZXJlIHRoZSBEYXRhYmFzZU15c3FsQ29uZmlnIHRvIGltcG9ydCBpcyBmb3VuZFxuICAqL1xuICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQ29uZmlnRm9ySW1wb3J0KHNjb3BlOiBDb25zdHJ1Y3QsIGltcG9ydFRvSWQ6IHN0cmluZywgaW1wb3J0RnJvbUlkOiBzdHJpbmcsIHByb3ZpZGVyPzogY2RrdG4uVGVycmFmb3JtUHJvdmlkZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBjZGt0bi5JbXBvcnRhYmxlUmVzb3VyY2Uoc2NvcGUsIGltcG9ydFRvSWQsIHsgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9teXNxbF9jb25maWdcIiwgaW1wb3J0SWQ6IGltcG9ydEZyb21JZCwgcHJvdmlkZXIgfSk7XG4gICAgICB9XG5cbiAgLy8gPT09PT09PT09PT1cbiAgLy8gSU5JVElBTElaRVJcbiAgLy8gPT09PT09PT09PT1cblxuICAvKipcbiAgKiBDcmVhdGUgYSBuZXcge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX215c3FsX2NvbmZpZ30gUmVzb3VyY2VcbiAgKlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGlkIFRoZSBzY29wZWQgY29uc3RydWN0IElELiBNdXN0IGJlIHVuaXF1ZSBhbW9uZ3N0IHNpYmxpbmdzIGluIHRoZSBzYW1lIHNjb3BlXG4gICogQHBhcmFtIG9wdGlvbnMgRGF0YWJhc2VNeXNxbENvbmZpZ0NvbmZpZ1xuICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgY29uZmlnOiBEYXRhYmFzZU15c3FsQ29uZmlnQ29uZmlnKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6ICdkaWdpdGFsb2NlYW5fZGF0YWJhc2VfbXlzcWxfY29uZmlnJyxcbiAgICAgIHRlcnJhZm9ybUdlbmVyYXRvck1ldGFkYXRhOiB7XG4gICAgICAgIHByb3ZpZGVyTmFtZTogJ2RpZ2l0YWxvY2VhbicsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbjogJzIuODcuMCcsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbkNvbnN0cmFpbnQ6ICcyLjg3LjAnXG4gICAgICB9LFxuICAgICAgcHJvdmlkZXI6IGNvbmZpZy5wcm92aWRlcixcbiAgICAgIGRlcGVuZHNPbjogY29uZmlnLmRlcGVuZHNPbixcbiAgICAgIGNvdW50OiBjb25maWcuY291bnQsXG4gICAgICBsaWZlY3ljbGU6IGNvbmZpZy5saWZlY3ljbGUsXG4gICAgICBwcm92aXNpb25lcnM6IGNvbmZpZy5wcm92aXNpb25lcnMsXG4gICAgICBjb25uZWN0aW9uOiBjb25maWcuY29ubmVjdGlvbixcbiAgICAgIGZvckVhY2g6IGNvbmZpZy5mb3JFYWNoXG4gICAgfSk7XG4gICAgdGhpcy5fYmFja3VwSG91ciA9IGNvbmZpZy5iYWNrdXBIb3VyO1xuICAgIHRoaXMuX2JhY2t1cE1pbnV0ZSA9IGNvbmZpZy5iYWNrdXBNaW51dGU7XG4gICAgdGhpcy5fYmlubG9nUmV0ZW50aW9uUGVyaW9kID0gY29uZmlnLmJpbmxvZ1JldGVudGlvblBlcmlvZDtcbiAgICB0aGlzLl9jbHVzdGVySWQgPSBjb25maWcuY2x1c3RlcklkO1xuICAgIHRoaXMuX2Nvbm5lY3RUaW1lb3V0ID0gY29uZmlnLmNvbm5lY3RUaW1lb3V0O1xuICAgIHRoaXMuX2RlZmF1bHRUaW1lWm9uZSA9IGNvbmZpZy5kZWZhdWx0VGltZVpvbmU7XG4gICAgdGhpcy5fZ3JvdXBDb25jYXRNYXhMZW4gPSBjb25maWcuZ3JvdXBDb25jYXRNYXhMZW47XG4gICAgdGhpcy5faWQgPSBjb25maWcuaWQ7XG4gICAgdGhpcy5faW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSA9IGNvbmZpZy5pbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5O1xuICAgIHRoaXMuX2lubm9kYkZ0TWluVG9rZW5TaXplID0gY29uZmlnLmlubm9kYkZ0TWluVG9rZW5TaXplO1xuICAgIHRoaXMuX2lubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZSA9IGNvbmZpZy5pbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGU7XG4gICAgdGhpcy5faW5ub2RiTG9ja1dhaXRUaW1lb3V0ID0gY29uZmlnLmlubm9kYkxvY2tXYWl0VGltZW91dDtcbiAgICB0aGlzLl9pbm5vZGJMb2dCdWZmZXJTaXplID0gY29uZmlnLmlubm9kYkxvZ0J1ZmZlclNpemU7XG4gICAgdGhpcy5faW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplID0gY29uZmlnLmlubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZTtcbiAgICB0aGlzLl9pbm5vZGJQcmludEFsbERlYWRsb2NrcyA9IGNvbmZpZy5pbm5vZGJQcmludEFsbERlYWRsb2NrcztcbiAgICB0aGlzLl9pbm5vZGJSb2xsYmFja09uVGltZW91dCA9IGNvbmZpZy5pbm5vZGJSb2xsYmFja09uVGltZW91dDtcbiAgICB0aGlzLl9pbnRlcmFjdGl2ZVRpbWVvdXQgPSBjb25maWcuaW50ZXJhY3RpdmVUaW1lb3V0O1xuICAgIHRoaXMuX2ludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZSA9IGNvbmZpZy5pbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmU7XG4gICAgdGhpcy5fbG9uZ1F1ZXJ5VGltZSA9IGNvbmZpZy5sb25nUXVlcnlUaW1lO1xuICAgIHRoaXMuX21heEFsbG93ZWRQYWNrZXQgPSBjb25maWcubWF4QWxsb3dlZFBhY2tldDtcbiAgICB0aGlzLl9tYXhIZWFwVGFibGVTaXplID0gY29uZmlnLm1heEhlYXBUYWJsZVNpemU7XG4gICAgdGhpcy5fbmV0UmVhZFRpbWVvdXQgPSBjb25maWcubmV0UmVhZFRpbWVvdXQ7XG4gICAgdGhpcy5fbmV0V3JpdGVUaW1lb3V0ID0gY29uZmlnLm5ldFdyaXRlVGltZW91dDtcbiAgICB0aGlzLl9zbG93UXVlcnlMb2cgPSBjb25maWcuc2xvd1F1ZXJ5TG9nO1xuICAgIHRoaXMuX3NvcnRCdWZmZXJTaXplID0gY29uZmlnLnNvcnRCdWZmZXJTaXplO1xuICAgIHRoaXMuX3NxbE1vZGUgPSBjb25maWcuc3FsTW9kZTtcbiAgICB0aGlzLl9zcWxSZXF1aXJlUHJpbWFyeUtleSA9IGNvbmZpZy5zcWxSZXF1aXJlUHJpbWFyeUtleTtcbiAgICB0aGlzLl90bXBUYWJsZVNpemUgPSBjb25maWcudG1wVGFibGVTaXplO1xuICAgIHRoaXMuX3dhaXRUaW1lb3V0ID0gY29uZmlnLndhaXRUaW1lb3V0O1xuICB9XG5cbiAgLy8gPT09PT09PT09PVxuICAvLyBBVFRSSUJVVEVTXG4gIC8vID09PT09PT09PT1cblxuICAvLyBiYWNrdXBfaG91ciAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2JhY2t1cEhvdXI/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGJhY2t1cEhvdXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdiYWNrdXBfaG91cicpO1xuICB9XG4gIHB1YmxpYyBzZXQgYmFja3VwSG91cih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYmFja3VwSG91ciA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEJhY2t1cEhvdXIoKSB7XG4gICAgdGhpcy5fYmFja3VwSG91ciA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYmFja3VwSG91cklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9iYWNrdXBIb3VyO1xuICB9XG5cbiAgLy8gYmFja3VwX21pbnV0ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2JhY2t1cE1pbnV0ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmFja3VwTWludXRlKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYmFja3VwX21pbnV0ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgYmFja3VwTWludXRlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9iYWNrdXBNaW51dGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRCYWNrdXBNaW51dGUoKSB7XG4gICAgdGhpcy5fYmFja3VwTWludXRlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBiYWNrdXBNaW51dGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYmFja3VwTWludXRlO1xuICB9XG5cbiAgLy8gYmlubG9nX3JldGVudGlvbl9wZXJpb2QgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9iaW5sb2dSZXRlbnRpb25QZXJpb2Q/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGJpbmxvZ1JldGVudGlvblBlcmlvZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2JpbmxvZ19yZXRlbnRpb25fcGVyaW9kJyk7XG4gIH1cbiAgcHVibGljIHNldCBiaW5sb2dSZXRlbnRpb25QZXJpb2QodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2JpbmxvZ1JldGVudGlvblBlcmlvZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEJpbmxvZ1JldGVudGlvblBlcmlvZCgpIHtcbiAgICB0aGlzLl9iaW5sb2dSZXRlbnRpb25QZXJpb2QgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGJpbmxvZ1JldGVudGlvblBlcmlvZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9iaW5sb2dSZXRlbnRpb25QZXJpb2Q7XG4gIH1cblxuICAvLyBjbHVzdGVyX2lkIC0gY29tcHV0ZWQ6IGZhbHNlLCBvcHRpb25hbDogZmFsc2UsIHJlcXVpcmVkOiB0cnVlXG4gIHByaXZhdGUgX2NsdXN0ZXJJZD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgY2x1c3RlcklkKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnY2x1c3Rlcl9pZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgY2x1c3RlcklkKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9jbHVzdGVySWQgPSB2YWx1ZTtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgY2x1c3RlcklkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NsdXN0ZXJJZDtcbiAgfVxuXG4gIC8vIGNvbm5lY3RfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2Nvbm5lY3RUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBjb25uZWN0VGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2Nvbm5lY3RfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgY29ubmVjdFRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2Nvbm5lY3RUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Q29ubmVjdFRpbWVvdXQoKSB7XG4gICAgdGhpcy5fY29ubmVjdFRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGNvbm5lY3RUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm5lY3RUaW1lb3V0O1xuICB9XG5cbiAgLy8gZGVmYXVsdF90aW1lX3pvbmUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9kZWZhdWx0VGltZVpvbmU/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGRlZmF1bHRUaW1lWm9uZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2RlZmF1bHRfdGltZV96b25lJyk7XG4gIH1cbiAgcHVibGljIHNldCBkZWZhdWx0VGltZVpvbmUodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2RlZmF1bHRUaW1lWm9uZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldERlZmF1bHRUaW1lWm9uZSgpIHtcbiAgICB0aGlzLl9kZWZhdWx0VGltZVpvbmUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGRlZmF1bHRUaW1lWm9uZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9kZWZhdWx0VGltZVpvbmU7XG4gIH1cblxuICAvLyBncm91cF9jb25jYXRfbWF4X2xlbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2dyb3VwQ29uY2F0TWF4TGVuPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBncm91cENvbmNhdE1heExlbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2dyb3VwX2NvbmNhdF9tYXhfbGVuJyk7XG4gIH1cbiAgcHVibGljIHNldCBncm91cENvbmNhdE1heExlbih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fZ3JvdXBDb25jYXRNYXhMZW4gPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRHcm91cENvbmNhdE1heExlbigpIHtcbiAgICB0aGlzLl9ncm91cENvbmNhdE1heExlbiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgZ3JvdXBDb25jYXRNYXhMZW5JbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZ3JvdXBDb25jYXRNYXhMZW47XG4gIH1cblxuICAvLyBpZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBpZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5faWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJZCgpIHtcbiAgICB0aGlzLl9pZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWQ7XG4gIH1cblxuICAvLyBpbmZvcm1hdGlvbl9zY2hlbWFfc3RhdHNfZXhwaXJ5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZm9ybWF0aW9uX3NjaGVtYV9zdGF0c19leHBpcnknKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnkodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2luZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnkgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5KCkge1xuICAgIHRoaXMuX2luZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnkgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGluZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnlJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeTtcbiAgfVxuXG4gIC8vIGlubm9kYl9mdF9taW5fdG9rZW5fc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lubm9kYkZ0TWluVG9rZW5TaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbm5vZGJGdE1pblRva2VuU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lubm9kYl9mdF9taW5fdG9rZW5fc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5ub2RiRnRNaW5Ub2tlblNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2lubm9kYkZ0TWluVG9rZW5TaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5ub2RiRnRNaW5Ub2tlblNpemUoKSB7XG4gICAgdGhpcy5faW5ub2RiRnRNaW5Ub2tlblNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlubm9kYkZ0TWluVG9rZW5TaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lubm9kYkZ0TWluVG9rZW5TaXplO1xuICB9XG5cbiAgLy8gaW5ub2RiX2Z0X3NlcnZlcl9zdG9wd29yZF90YWJsZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgaW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnaW5ub2RiX2Z0X3NlcnZlcl9zdG9wd29yZF90YWJsZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9pbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUoKSB7XG4gICAgdGhpcy5faW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlO1xuICB9XG5cbiAgLy8gaW5ub2RiX2xvY2tfd2FpdF90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5ub2RiTG9ja1dhaXRUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbm5vZGJMb2NrV2FpdFRpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbm5vZGJfbG9ja193YWl0X3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlubm9kYkxvY2tXYWl0VGltZW91dCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5ub2RiTG9ja1dhaXRUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5ub2RiTG9ja1dhaXRUaW1lb3V0KCkge1xuICAgIHRoaXMuX2lubm9kYkxvY2tXYWl0VGltZW91dCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5ub2RiTG9ja1dhaXRUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lubm9kYkxvY2tXYWl0VGltZW91dDtcbiAgfVxuXG4gIC8vIGlubm9kYl9sb2dfYnVmZmVyX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbm5vZGJMb2dCdWZmZXJTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbm5vZGJMb2dCdWZmZXJTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5ub2RiX2xvZ19idWZmZXJfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5ub2RiTG9nQnVmZmVyU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5ub2RiTG9nQnVmZmVyU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElubm9kYkxvZ0J1ZmZlclNpemUoKSB7XG4gICAgdGhpcy5faW5ub2RiTG9nQnVmZmVyU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5ub2RiTG9nQnVmZmVyU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbm5vZGJMb2dCdWZmZXJTaXplO1xuICB9XG5cbiAgLy8gaW5ub2RiX29ubGluZV9hbHRlcl9sb2dfbWF4X3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGlubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lubm9kYl9vbmxpbmVfYWx0ZXJfbG9nX21heF9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2lubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZSgpIHtcbiAgICB0aGlzLl9pbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemU7XG4gIH1cblxuICAvLyBpbm5vZGJfcHJpbnRfYWxsX2RlYWRsb2NrcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lubm9kYlByaW50QWxsRGVhZGxvY2tzPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBpbm5vZGJQcmludEFsbERlYWRsb2NrcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdpbm5vZGJfcHJpbnRfYWxsX2RlYWRsb2NrcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5ub2RiUHJpbnRBbGxEZWFkbG9ja3ModmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2lubm9kYlByaW50QWxsRGVhZGxvY2tzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5ub2RiUHJpbnRBbGxEZWFkbG9ja3MoKSB7XG4gICAgdGhpcy5faW5ub2RiUHJpbnRBbGxEZWFkbG9ja3MgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlubm9kYlByaW50QWxsRGVhZGxvY2tzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lubm9kYlByaW50QWxsRGVhZGxvY2tzO1xuICB9XG5cbiAgLy8gaW5ub2RiX3JvbGxiYWNrX29uX3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbm5vZGJSb2xsYmFja09uVGltZW91dD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgaW5ub2RiUm9sbGJhY2tPblRpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnaW5ub2RiX3JvbGxiYWNrX29uX3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlubm9kYlJvbGxiYWNrT25UaW1lb3V0KHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9pbm5vZGJSb2xsYmFja09uVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElubm9kYlJvbGxiYWNrT25UaW1lb3V0KCkge1xuICAgIHRoaXMuX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbm5vZGJSb2xsYmFja09uVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbm5vZGJSb2xsYmFja09uVGltZW91dDtcbiAgfVxuXG4gIC8vIGludGVyYWN0aXZlX3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbnRlcmFjdGl2ZVRpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGludGVyYWN0aXZlVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2ludGVyYWN0aXZlX3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGludGVyYWN0aXZlVGltZW91dCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW50ZXJhY3RpdmVUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW50ZXJhY3RpdmVUaW1lb3V0KCkge1xuICAgIHRoaXMuX2ludGVyYWN0aXZlVGltZW91dCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW50ZXJhY3RpdmVUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2ludGVyYWN0aXZlVGltZW91dDtcbiAgfVxuXG4gIC8vIGludGVybmFsX3RtcF9tZW1fc3RvcmFnZV9lbmdpbmUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmU/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2ludGVybmFsX3RtcF9tZW1fc3RvcmFnZV9lbmdpbmUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5faW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lKCkge1xuICAgIHRoaXMuX2ludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2ludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZTtcbiAgfVxuXG4gIC8vIGxvbmdfcXVlcnlfdGltZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvbmdRdWVyeVRpbWU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGxvbmdRdWVyeVRpbWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsb25nX3F1ZXJ5X3RpbWUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvbmdRdWVyeVRpbWUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2xvbmdRdWVyeVRpbWUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb25nUXVlcnlUaW1lKCkge1xuICAgIHRoaXMuX2xvbmdRdWVyeVRpbWUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvbmdRdWVyeVRpbWVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9uZ1F1ZXJ5VGltZTtcbiAgfVxuXG4gIC8vIG1heF9hbGxvd2VkX3BhY2tldCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heEFsbG93ZWRQYWNrZXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heEFsbG93ZWRQYWNrZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfYWxsb3dlZF9wYWNrZXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heEFsbG93ZWRQYWNrZXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heEFsbG93ZWRQYWNrZXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhBbGxvd2VkUGFja2V0KCkge1xuICAgIHRoaXMuX21heEFsbG93ZWRQYWNrZXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heEFsbG93ZWRQYWNrZXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4QWxsb3dlZFBhY2tldDtcbiAgfVxuXG4gIC8vIG1heF9oZWFwX3RhYmxlX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhIZWFwVGFibGVTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhIZWFwVGFibGVTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X2hlYXBfdGFibGVfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4SGVhcFRhYmxlU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4SGVhcFRhYmxlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heEhlYXBUYWJsZVNpemUoKSB7XG4gICAgdGhpcy5fbWF4SGVhcFRhYmxlU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4SGVhcFRhYmxlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhIZWFwVGFibGVTaXplO1xuICB9XG5cbiAgLy8gbmV0X3JlYWRfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX25ldFJlYWRUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBuZXRSZWFkVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ25ldF9yZWFkX3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG5ldFJlYWRUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9uZXRSZWFkVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE5ldFJlYWRUaW1lb3V0KCkge1xuICAgIHRoaXMuX25ldFJlYWRUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBuZXRSZWFkVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9uZXRSZWFkVGltZW91dDtcbiAgfVxuXG4gIC8vIG5ldF93cml0ZV90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbmV0V3JpdGVUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBuZXRXcml0ZVRpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCduZXRfd3JpdGVfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgbmV0V3JpdGVUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9uZXRXcml0ZVRpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXROZXRXcml0ZVRpbWVvdXQoKSB7XG4gICAgdGhpcy5fbmV0V3JpdGVUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBuZXRXcml0ZVRpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbmV0V3JpdGVUaW1lb3V0O1xuICB9XG5cbiAgLy8gc2xvd19xdWVyeV9sb2cgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9zbG93UXVlcnlMb2c/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IHNsb3dRdWVyeUxvZygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdzbG93X3F1ZXJ5X2xvZycpO1xuICB9XG4gIHB1YmxpYyBzZXQgc2xvd1F1ZXJ5TG9nKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9zbG93UXVlcnlMb2cgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTbG93UXVlcnlMb2coKSB7XG4gICAgdGhpcy5fc2xvd1F1ZXJ5TG9nID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzbG93UXVlcnlMb2dJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc2xvd1F1ZXJ5TG9nO1xuICB9XG5cbiAgLy8gc29ydF9idWZmZXJfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NvcnRCdWZmZXJTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBzb3J0QnVmZmVyU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3NvcnRfYnVmZmVyX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNvcnRCdWZmZXJTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9zb3J0QnVmZmVyU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFNvcnRCdWZmZXJTaXplKCkge1xuICAgIHRoaXMuX3NvcnRCdWZmZXJTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzb3J0QnVmZmVyU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9zb3J0QnVmZmVyU2l6ZTtcbiAgfVxuXG4gIC8vIHNxbF9tb2RlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc3FsTW9kZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgc3FsTW9kZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3NxbF9tb2RlJyk7XG4gIH1cbiAgcHVibGljIHNldCBzcWxNb2RlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9zcWxNb2RlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U3FsTW9kZSgpIHtcbiAgICB0aGlzLl9zcWxNb2RlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzcWxNb2RlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NxbE1vZGU7XG4gIH1cblxuICAvLyBzcWxfcmVxdWlyZV9wcmltYXJ5X2tleSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NxbFJlcXVpcmVQcmltYXJ5S2V5PzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBzcWxSZXF1aXJlUHJpbWFyeUtleSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdzcWxfcmVxdWlyZV9wcmltYXJ5X2tleScpO1xuICB9XG4gIHB1YmxpYyBzZXQgc3FsUmVxdWlyZVByaW1hcnlLZXkodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX3NxbFJlcXVpcmVQcmltYXJ5S2V5ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U3FsUmVxdWlyZVByaW1hcnlLZXkoKSB7XG4gICAgdGhpcy5fc3FsUmVxdWlyZVByaW1hcnlLZXkgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNxbFJlcXVpcmVQcmltYXJ5S2V5SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NxbFJlcXVpcmVQcmltYXJ5S2V5O1xuICB9XG5cbiAgLy8gdG1wX3RhYmxlX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90bXBUYWJsZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRtcFRhYmxlU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RtcF90YWJsZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0bXBUYWJsZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RtcFRhYmxlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRtcFRhYmxlU2l6ZSgpIHtcbiAgICB0aGlzLl90bXBUYWJsZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRtcFRhYmxlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90bXBUYWJsZVNpemU7XG4gIH1cblxuICAvLyB3YWl0X3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF93YWl0VGltZW91dD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgd2FpdFRpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd3YWl0X3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHdhaXRUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl93YWl0VGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFdhaXRUaW1lb3V0KCkge1xuICAgIHRoaXMuX3dhaXRUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB3YWl0VGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl93YWl0VGltZW91dDtcbiAgfVxuXG4gIC8vID09PT09PT09PVxuICAvLyBTWU5USEVTSVNcbiAgLy8gPT09PT09PT09XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICByZXR1cm4ge1xuICAgICAgYmFja3VwX2hvdXI6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2JhY2t1cEhvdXIpLFxuICAgICAgYmFja3VwX21pbnV0ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmFja3VwTWludXRlKSxcbiAgICAgIGJpbmxvZ19yZXRlbnRpb25fcGVyaW9kOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iaW5sb2dSZXRlbnRpb25QZXJpb2QpLFxuICAgICAgY2x1c3Rlcl9pZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgIGNvbm5lY3RfdGltZW91dDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fY29ubmVjdFRpbWVvdXQpLFxuICAgICAgZGVmYXVsdF90aW1lX3pvbmU6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2RlZmF1bHRUaW1lWm9uZSksXG4gICAgICBncm91cF9jb25jYXRfbWF4X2xlbjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fZ3JvdXBDb25jYXRNYXhMZW4pLFxuICAgICAgaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgIGluZm9ybWF0aW9uX3NjaGVtYV9zdGF0c19leHBpcnk6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnkpLFxuICAgICAgaW5ub2RiX2Z0X21pbl90b2tlbl9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJGdE1pblRva2VuU2l6ZSksXG4gICAgICBpbm5vZGJfZnRfc2VydmVyX3N0b3B3b3JkX3RhYmxlOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUpLFxuICAgICAgaW5ub2RiX2xvY2tfd2FpdF90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJMb2NrV2FpdFRpbWVvdXQpLFxuICAgICAgaW5ub2RiX2xvZ19idWZmZXJfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW5ub2RiTG9nQnVmZmVyU2l6ZSksXG4gICAgICBpbm5vZGJfb25saW5lX2FsdGVyX2xvZ19tYXhfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplKSxcbiAgICAgIGlubm9kYl9wcmludF9hbGxfZGVhZGxvY2tzOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5faW5ub2RiUHJpbnRBbGxEZWFkbG9ja3MpLFxuICAgICAgaW5ub2RiX3JvbGxiYWNrX29uX3RpbWVvdXQ6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJSb2xsYmFja09uVGltZW91dCksXG4gICAgICBpbnRlcmFjdGl2ZV90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbnRlcmFjdGl2ZVRpbWVvdXQpLFxuICAgICAgaW50ZXJuYWxfdG1wX21lbV9zdG9yYWdlX2VuZ2luZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5faW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lKSxcbiAgICAgIGxvbmdfcXVlcnlfdGltZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbG9uZ1F1ZXJ5VGltZSksXG4gICAgICBtYXhfYWxsb3dlZF9wYWNrZXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX21heEFsbG93ZWRQYWNrZXQpLFxuICAgICAgbWF4X2hlYXBfdGFibGVfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4SGVhcFRhYmxlU2l6ZSksXG4gICAgICBuZXRfcmVhZF90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9uZXRSZWFkVGltZW91dCksXG4gICAgICBuZXRfd3JpdGVfdGltZW91dDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbmV0V3JpdGVUaW1lb3V0KSxcbiAgICAgIHNsb3dfcXVlcnlfbG9nOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fc2xvd1F1ZXJ5TG9nKSxcbiAgICAgIHNvcnRfYnVmZmVyX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3NvcnRCdWZmZXJTaXplKSxcbiAgICAgIHNxbF9tb2RlOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9zcWxNb2RlKSxcbiAgICAgIHNxbF9yZXF1aXJlX3ByaW1hcnlfa2V5OiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fc3FsUmVxdWlyZVByaW1hcnlLZXkpLFxuICAgICAgdG1wX3RhYmxlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RtcFRhYmxlU2l6ZSksXG4gICAgICB3YWl0X3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3dhaXRUaW1lb3V0KSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVIY2xBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICBjb25zdCBhdHRycyA9IHtcbiAgICAgIGJhY2t1cF9ob3VyOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9iYWNrdXBIb3VyKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmFja3VwX21pbnV0ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYmFja3VwTWludXRlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmlubG9nX3JldGVudGlvbl9wZXJpb2Q6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2JpbmxvZ1JldGVudGlvblBlcmlvZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGNsdXN0ZXJfaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGNvbm5lY3RfdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fY29ubmVjdFRpbWVvdXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBkZWZhdWx0X3RpbWVfem9uZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fZGVmYXVsdFRpbWVab25lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgZ3JvdXBfY29uY2F0X21heF9sZW46IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2dyb3VwQ29uY2F0TWF4TGVuKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgaW5mb3JtYXRpb25fc2NoZW1hX3N0YXRzX2V4cGlyeToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlubm9kYl9mdF9taW5fdG9rZW5fc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5ub2RiRnRNaW5Ub2tlblNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpbm5vZGJfZnRfc2VydmVyX3N0b3B3b3JkX3RhYmxlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBpbm5vZGJfbG9ja193YWl0X3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lubm9kYkxvY2tXYWl0VGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlubm9kYl9sb2dfYnVmZmVyX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lubm9kYkxvZ0J1ZmZlclNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpbm5vZGJfb25saW5lX2FsdGVyX2xvZ19tYXhfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5ub2RiX3ByaW50X2FsbF9kZWFkbG9ja3M6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9pbm5vZGJQcmludEFsbERlYWRsb2NrcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBpbm5vZGJfcm9sbGJhY2tfb25fdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGludGVyYWN0aXZlX3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2ludGVyYWN0aXZlVGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGludGVybmFsX3RtcF9tZW1fc3RvcmFnZV9lbmdpbmU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2ludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvbmdfcXVlcnlfdGltZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9uZ1F1ZXJ5VGltZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9hbGxvd2VkX3BhY2tldDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4QWxsb3dlZFBhY2tldCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9oZWFwX3RhYmxlX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heEhlYXBUYWJsZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBuZXRfcmVhZF90aW1lb3V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9uZXRSZWFkVGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG5ldF93cml0ZV90aW1lb3V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9uZXRXcml0ZVRpbWVvdXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBzbG93X3F1ZXJ5X2xvZzoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX3Nsb3dRdWVyeUxvZyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBzb3J0X2J1ZmZlcl9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9zb3J0QnVmZmVyU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHNxbF9tb2RlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9zcWxNb2RlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgc3FsX3JlcXVpcmVfcHJpbWFyeV9rZXk6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9zcWxSZXF1aXJlUHJpbWFyeUtleSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICB0bXBfdGFibGVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdG1wVGFibGVTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgd2FpdF90aW1lb3V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl93YWl0VGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgLy8gcmVtb3ZlIHVuZGVmaW5lZCBhdHRyaWJ1dGVzXG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhhdHRycykuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnZhbHVlICE9PSB1bmRlZmluZWQgKSlcbiAgfVxufVxuIl19