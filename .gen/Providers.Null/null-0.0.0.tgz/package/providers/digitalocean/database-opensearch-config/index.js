"use strict";
// https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config
// generated from terraform resource schema
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseOpensearchConfig = void 0;
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config digitalocean_database_opensearch_config}
*/
class DatabaseOpensearchConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseOpensearchConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseOpensearchConfig to import
    * @param importFromId The id of the existing DatabaseOpensearchConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseOpensearchConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_opensearch_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config digitalocean_database_opensearch_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseOpensearchConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_opensearch_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._actionAutoCreateIndexEnabled = config.actionAutoCreateIndexEnabled;
        this._actionDestructiveRequiresName = config.actionDestructiveRequiresName;
        this._clusterId = config.clusterId;
        this._clusterMaxShardsPerNode = config.clusterMaxShardsPerNode;
        this._clusterRoutingAllocationNodeConcurrentRecoveries = config.clusterRoutingAllocationNodeConcurrentRecoveries;
        this._enableSecurityAudit = config.enableSecurityAudit;
        this._httpMaxContentLengthBytes = config.httpMaxContentLengthBytes;
        this._httpMaxHeaderSizeBytes = config.httpMaxHeaderSizeBytes;
        this._httpMaxInitialLineLengthBytes = config.httpMaxInitialLineLengthBytes;
        this._id = config.id;
        this._indicesFielddataCacheSizePercentage = config.indicesFielddataCacheSizePercentage;
        this._indicesMemoryIndexBufferSizePercentage = config.indicesMemoryIndexBufferSizePercentage;
        this._indicesMemoryMaxIndexBufferSizeMb = config.indicesMemoryMaxIndexBufferSizeMb;
        this._indicesMemoryMinIndexBufferSizeMb = config.indicesMemoryMinIndexBufferSizeMb;
        this._indicesQueriesCacheSizePercentage = config.indicesQueriesCacheSizePercentage;
        this._indicesQueryBoolMaxClauseCount = config.indicesQueryBoolMaxClauseCount;
        this._indicesRecoveryMaxConcurrentFileChunks = config.indicesRecoveryMaxConcurrentFileChunks;
        this._indicesRecoveryMaxMbPerSec = config.indicesRecoveryMaxMbPerSec;
        this._ismEnabled = config.ismEnabled;
        this._ismHistoryEnabled = config.ismHistoryEnabled;
        this._ismHistoryMaxAgeHours = config.ismHistoryMaxAgeHours;
        this._ismHistoryMaxDocs = config.ismHistoryMaxDocs;
        this._ismHistoryRolloverCheckPeriodHours = config.ismHistoryRolloverCheckPeriodHours;
        this._ismHistoryRolloverRetentionPeriodDays = config.ismHistoryRolloverRetentionPeriodDays;
        this._overrideMainResponseVersion = config.overrideMainResponseVersion;
        this._pluginsAlertingFilterByBackendRolesEnabled = config.pluginsAlertingFilterByBackendRolesEnabled;
        this._reindexRemoteWhitelist = config.reindexRemoteWhitelist;
        this._scriptMaxCompilationsRate = config.scriptMaxCompilationsRate;
        this._searchMaxBuckets = config.searchMaxBuckets;
        this._threadPoolAnalyzeQueueSize = config.threadPoolAnalyzeQueueSize;
        this._threadPoolAnalyzeSize = config.threadPoolAnalyzeSize;
        this._threadPoolForceMergeSize = config.threadPoolForceMergeSize;
        this._threadPoolGetQueueSize = config.threadPoolGetQueueSize;
        this._threadPoolGetSize = config.threadPoolGetSize;
        this._threadPoolSearchQueueSize = config.threadPoolSearchQueueSize;
        this._threadPoolSearchSize = config.threadPoolSearchSize;
        this._threadPoolSearchThrottledQueueSize = config.threadPoolSearchThrottledQueueSize;
        this._threadPoolSearchThrottledSize = config.threadPoolSearchThrottledSize;
        this._threadPoolWriteQueueSize = config.threadPoolWriteQueueSize;
        this._threadPoolWriteSize = config.threadPoolWriteSize;
    }
    get actionAutoCreateIndexEnabled() {
        return this.getBooleanAttribute('action_auto_create_index_enabled');
    }
    set actionAutoCreateIndexEnabled(value) {
        this._actionAutoCreateIndexEnabled = value;
    }
    resetActionAutoCreateIndexEnabled() {
        this._actionAutoCreateIndexEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get actionAutoCreateIndexEnabledInput() {
        return this._actionAutoCreateIndexEnabled;
    }
    get actionDestructiveRequiresName() {
        return this.getBooleanAttribute('action_destructive_requires_name');
    }
    set actionDestructiveRequiresName(value) {
        this._actionDestructiveRequiresName = value;
    }
    resetActionDestructiveRequiresName() {
        this._actionDestructiveRequiresName = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get actionDestructiveRequiresNameInput() {
        return this._actionDestructiveRequiresName;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get clusterMaxShardsPerNode() {
        return this.getNumberAttribute('cluster_max_shards_per_node');
    }
    set clusterMaxShardsPerNode(value) {
        this._clusterMaxShardsPerNode = value;
    }
    resetClusterMaxShardsPerNode() {
        this._clusterMaxShardsPerNode = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get clusterMaxShardsPerNodeInput() {
        return this._clusterMaxShardsPerNode;
    }
    get clusterRoutingAllocationNodeConcurrentRecoveries() {
        return this.getNumberAttribute('cluster_routing_allocation_node_concurrent_recoveries');
    }
    set clusterRoutingAllocationNodeConcurrentRecoveries(value) {
        this._clusterRoutingAllocationNodeConcurrentRecoveries = value;
    }
    resetClusterRoutingAllocationNodeConcurrentRecoveries() {
        this._clusterRoutingAllocationNodeConcurrentRecoveries = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get clusterRoutingAllocationNodeConcurrentRecoveriesInput() {
        return this._clusterRoutingAllocationNodeConcurrentRecoveries;
    }
    get enableSecurityAudit() {
        return this.getBooleanAttribute('enable_security_audit');
    }
    set enableSecurityAudit(value) {
        this._enableSecurityAudit = value;
    }
    resetEnableSecurityAudit() {
        this._enableSecurityAudit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get enableSecurityAuditInput() {
        return this._enableSecurityAudit;
    }
    get httpMaxContentLengthBytes() {
        return this.getNumberAttribute('http_max_content_length_bytes');
    }
    set httpMaxContentLengthBytes(value) {
        this._httpMaxContentLengthBytes = value;
    }
    resetHttpMaxContentLengthBytes() {
        this._httpMaxContentLengthBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpMaxContentLengthBytesInput() {
        return this._httpMaxContentLengthBytes;
    }
    get httpMaxHeaderSizeBytes() {
        return this.getNumberAttribute('http_max_header_size_bytes');
    }
    set httpMaxHeaderSizeBytes(value) {
        this._httpMaxHeaderSizeBytes = value;
    }
    resetHttpMaxHeaderSizeBytes() {
        this._httpMaxHeaderSizeBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpMaxHeaderSizeBytesInput() {
        return this._httpMaxHeaderSizeBytes;
    }
    get httpMaxInitialLineLengthBytes() {
        return this.getNumberAttribute('http_max_initial_line_length_bytes');
    }
    set httpMaxInitialLineLengthBytes(value) {
        this._httpMaxInitialLineLengthBytes = value;
    }
    resetHttpMaxInitialLineLengthBytes() {
        this._httpMaxInitialLineLengthBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpMaxInitialLineLengthBytesInput() {
        return this._httpMaxInitialLineLengthBytes;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get indicesFielddataCacheSizePercentage() {
        return this.getNumberAttribute('indices_fielddata_cache_size_percentage');
    }
    set indicesFielddataCacheSizePercentage(value) {
        this._indicesFielddataCacheSizePercentage = value;
    }
    resetIndicesFielddataCacheSizePercentage() {
        this._indicesFielddataCacheSizePercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesFielddataCacheSizePercentageInput() {
        return this._indicesFielddataCacheSizePercentage;
    }
    get indicesMemoryIndexBufferSizePercentage() {
        return this.getNumberAttribute('indices_memory_index_buffer_size_percentage');
    }
    set indicesMemoryIndexBufferSizePercentage(value) {
        this._indicesMemoryIndexBufferSizePercentage = value;
    }
    resetIndicesMemoryIndexBufferSizePercentage() {
        this._indicesMemoryIndexBufferSizePercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesMemoryIndexBufferSizePercentageInput() {
        return this._indicesMemoryIndexBufferSizePercentage;
    }
    get indicesMemoryMaxIndexBufferSizeMb() {
        return this.getNumberAttribute('indices_memory_max_index_buffer_size_mb');
    }
    set indicesMemoryMaxIndexBufferSizeMb(value) {
        this._indicesMemoryMaxIndexBufferSizeMb = value;
    }
    resetIndicesMemoryMaxIndexBufferSizeMb() {
        this._indicesMemoryMaxIndexBufferSizeMb = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesMemoryMaxIndexBufferSizeMbInput() {
        return this._indicesMemoryMaxIndexBufferSizeMb;
    }
    get indicesMemoryMinIndexBufferSizeMb() {
        return this.getNumberAttribute('indices_memory_min_index_buffer_size_mb');
    }
    set indicesMemoryMinIndexBufferSizeMb(value) {
        this._indicesMemoryMinIndexBufferSizeMb = value;
    }
    resetIndicesMemoryMinIndexBufferSizeMb() {
        this._indicesMemoryMinIndexBufferSizeMb = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesMemoryMinIndexBufferSizeMbInput() {
        return this._indicesMemoryMinIndexBufferSizeMb;
    }
    get indicesQueriesCacheSizePercentage() {
        return this.getNumberAttribute('indices_queries_cache_size_percentage');
    }
    set indicesQueriesCacheSizePercentage(value) {
        this._indicesQueriesCacheSizePercentage = value;
    }
    resetIndicesQueriesCacheSizePercentage() {
        this._indicesQueriesCacheSizePercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesQueriesCacheSizePercentageInput() {
        return this._indicesQueriesCacheSizePercentage;
    }
    get indicesQueryBoolMaxClauseCount() {
        return this.getNumberAttribute('indices_query_bool_max_clause_count');
    }
    set indicesQueryBoolMaxClauseCount(value) {
        this._indicesQueryBoolMaxClauseCount = value;
    }
    resetIndicesQueryBoolMaxClauseCount() {
        this._indicesQueryBoolMaxClauseCount = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesQueryBoolMaxClauseCountInput() {
        return this._indicesQueryBoolMaxClauseCount;
    }
    get indicesRecoveryMaxConcurrentFileChunks() {
        return this.getNumberAttribute('indices_recovery_max_concurrent_file_chunks');
    }
    set indicesRecoveryMaxConcurrentFileChunks(value) {
        this._indicesRecoveryMaxConcurrentFileChunks = value;
    }
    resetIndicesRecoveryMaxConcurrentFileChunks() {
        this._indicesRecoveryMaxConcurrentFileChunks = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesRecoveryMaxConcurrentFileChunksInput() {
        return this._indicesRecoveryMaxConcurrentFileChunks;
    }
    get indicesRecoveryMaxMbPerSec() {
        return this.getNumberAttribute('indices_recovery_max_mb_per_sec');
    }
    set indicesRecoveryMaxMbPerSec(value) {
        this._indicesRecoveryMaxMbPerSec = value;
    }
    resetIndicesRecoveryMaxMbPerSec() {
        this._indicesRecoveryMaxMbPerSec = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesRecoveryMaxMbPerSecInput() {
        return this._indicesRecoveryMaxMbPerSec;
    }
    get ismEnabled() {
        return this.getBooleanAttribute('ism_enabled');
    }
    set ismEnabled(value) {
        this._ismEnabled = value;
    }
    resetIsmEnabled() {
        this._ismEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismEnabledInput() {
        return this._ismEnabled;
    }
    get ismHistoryEnabled() {
        return this.getBooleanAttribute('ism_history_enabled');
    }
    set ismHistoryEnabled(value) {
        this._ismHistoryEnabled = value;
    }
    resetIsmHistoryEnabled() {
        this._ismHistoryEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryEnabledInput() {
        return this._ismHistoryEnabled;
    }
    get ismHistoryMaxAgeHours() {
        return this.getNumberAttribute('ism_history_max_age_hours');
    }
    set ismHistoryMaxAgeHours(value) {
        this._ismHistoryMaxAgeHours = value;
    }
    resetIsmHistoryMaxAgeHours() {
        this._ismHistoryMaxAgeHours = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryMaxAgeHoursInput() {
        return this._ismHistoryMaxAgeHours;
    }
    get ismHistoryMaxDocs() {
        return this.getNumberAttribute('ism_history_max_docs');
    }
    set ismHistoryMaxDocs(value) {
        this._ismHistoryMaxDocs = value;
    }
    resetIsmHistoryMaxDocs() {
        this._ismHistoryMaxDocs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryMaxDocsInput() {
        return this._ismHistoryMaxDocs;
    }
    get ismHistoryRolloverCheckPeriodHours() {
        return this.getNumberAttribute('ism_history_rollover_check_period_hours');
    }
    set ismHistoryRolloverCheckPeriodHours(value) {
        this._ismHistoryRolloverCheckPeriodHours = value;
    }
    resetIsmHistoryRolloverCheckPeriodHours() {
        this._ismHistoryRolloverCheckPeriodHours = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryRolloverCheckPeriodHoursInput() {
        return this._ismHistoryRolloverCheckPeriodHours;
    }
    get ismHistoryRolloverRetentionPeriodDays() {
        return this.getNumberAttribute('ism_history_rollover_retention_period_days');
    }
    set ismHistoryRolloverRetentionPeriodDays(value) {
        this._ismHistoryRolloverRetentionPeriodDays = value;
    }
    resetIsmHistoryRolloverRetentionPeriodDays() {
        this._ismHistoryRolloverRetentionPeriodDays = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryRolloverRetentionPeriodDaysInput() {
        return this._ismHistoryRolloverRetentionPeriodDays;
    }
    get overrideMainResponseVersion() {
        return this.getBooleanAttribute('override_main_response_version');
    }
    set overrideMainResponseVersion(value) {
        this._overrideMainResponseVersion = value;
    }
    resetOverrideMainResponseVersion() {
        this._overrideMainResponseVersion = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get overrideMainResponseVersionInput() {
        return this._overrideMainResponseVersion;
    }
    get pluginsAlertingFilterByBackendRolesEnabled() {
        return this.getBooleanAttribute('plugins_alerting_filter_by_backend_roles_enabled');
    }
    set pluginsAlertingFilterByBackendRolesEnabled(value) {
        this._pluginsAlertingFilterByBackendRolesEnabled = value;
    }
    resetPluginsAlertingFilterByBackendRolesEnabled() {
        this._pluginsAlertingFilterByBackendRolesEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pluginsAlertingFilterByBackendRolesEnabledInput() {
        return this._pluginsAlertingFilterByBackendRolesEnabled;
    }
    get reindexRemoteWhitelist() {
        return cdktn.Fn.tolist(this.getListAttribute('reindex_remote_whitelist'));
    }
    set reindexRemoteWhitelist(value) {
        this._reindexRemoteWhitelist = value;
    }
    resetReindexRemoteWhitelist() {
        this._reindexRemoteWhitelist = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get reindexRemoteWhitelistInput() {
        return this._reindexRemoteWhitelist;
    }
    get scriptMaxCompilationsRate() {
        return this.getStringAttribute('script_max_compilations_rate');
    }
    set scriptMaxCompilationsRate(value) {
        this._scriptMaxCompilationsRate = value;
    }
    resetScriptMaxCompilationsRate() {
        this._scriptMaxCompilationsRate = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get scriptMaxCompilationsRateInput() {
        return this._scriptMaxCompilationsRate;
    }
    get searchMaxBuckets() {
        return this.getNumberAttribute('search_max_buckets');
    }
    set searchMaxBuckets(value) {
        this._searchMaxBuckets = value;
    }
    resetSearchMaxBuckets() {
        this._searchMaxBuckets = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get searchMaxBucketsInput() {
        return this._searchMaxBuckets;
    }
    get threadPoolAnalyzeQueueSize() {
        return this.getNumberAttribute('thread_pool_analyze_queue_size');
    }
    set threadPoolAnalyzeQueueSize(value) {
        this._threadPoolAnalyzeQueueSize = value;
    }
    resetThreadPoolAnalyzeQueueSize() {
        this._threadPoolAnalyzeQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolAnalyzeQueueSizeInput() {
        return this._threadPoolAnalyzeQueueSize;
    }
    get threadPoolAnalyzeSize() {
        return this.getNumberAttribute('thread_pool_analyze_size');
    }
    set threadPoolAnalyzeSize(value) {
        this._threadPoolAnalyzeSize = value;
    }
    resetThreadPoolAnalyzeSize() {
        this._threadPoolAnalyzeSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolAnalyzeSizeInput() {
        return this._threadPoolAnalyzeSize;
    }
    get threadPoolForceMergeSize() {
        return this.getNumberAttribute('thread_pool_force_merge_size');
    }
    set threadPoolForceMergeSize(value) {
        this._threadPoolForceMergeSize = value;
    }
    resetThreadPoolForceMergeSize() {
        this._threadPoolForceMergeSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolForceMergeSizeInput() {
        return this._threadPoolForceMergeSize;
    }
    get threadPoolGetQueueSize() {
        return this.getNumberAttribute('thread_pool_get_queue_size');
    }
    set threadPoolGetQueueSize(value) {
        this._threadPoolGetQueueSize = value;
    }
    resetThreadPoolGetQueueSize() {
        this._threadPoolGetQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolGetQueueSizeInput() {
        return this._threadPoolGetQueueSize;
    }
    get threadPoolGetSize() {
        return this.getNumberAttribute('thread_pool_get_size');
    }
    set threadPoolGetSize(value) {
        this._threadPoolGetSize = value;
    }
    resetThreadPoolGetSize() {
        this._threadPoolGetSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolGetSizeInput() {
        return this._threadPoolGetSize;
    }
    get threadPoolSearchQueueSize() {
        return this.getNumberAttribute('thread_pool_search_queue_size');
    }
    set threadPoolSearchQueueSize(value) {
        this._threadPoolSearchQueueSize = value;
    }
    resetThreadPoolSearchQueueSize() {
        this._threadPoolSearchQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchQueueSizeInput() {
        return this._threadPoolSearchQueueSize;
    }
    get threadPoolSearchSize() {
        return this.getNumberAttribute('thread_pool_search_size');
    }
    set threadPoolSearchSize(value) {
        this._threadPoolSearchSize = value;
    }
    resetThreadPoolSearchSize() {
        this._threadPoolSearchSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchSizeInput() {
        return this._threadPoolSearchSize;
    }
    get threadPoolSearchThrottledQueueSize() {
        return this.getNumberAttribute('thread_pool_search_throttled_queue_size');
    }
    set threadPoolSearchThrottledQueueSize(value) {
        this._threadPoolSearchThrottledQueueSize = value;
    }
    resetThreadPoolSearchThrottledQueueSize() {
        this._threadPoolSearchThrottledQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchThrottledQueueSizeInput() {
        return this._threadPoolSearchThrottledQueueSize;
    }
    get threadPoolSearchThrottledSize() {
        return this.getNumberAttribute('thread_pool_search_throttled_size');
    }
    set threadPoolSearchThrottledSize(value) {
        this._threadPoolSearchThrottledSize = value;
    }
    resetThreadPoolSearchThrottledSize() {
        this._threadPoolSearchThrottledSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchThrottledSizeInput() {
        return this._threadPoolSearchThrottledSize;
    }
    get threadPoolWriteQueueSize() {
        return this.getNumberAttribute('thread_pool_write_queue_size');
    }
    set threadPoolWriteQueueSize(value) {
        this._threadPoolWriteQueueSize = value;
    }
    resetThreadPoolWriteQueueSize() {
        this._threadPoolWriteQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolWriteQueueSizeInput() {
        return this._threadPoolWriteQueueSize;
    }
    get threadPoolWriteSize() {
        return this.getNumberAttribute('thread_pool_write_size');
    }
    set threadPoolWriteSize(value) {
        this._threadPoolWriteSize = value;
    }
    resetThreadPoolWriteSize() {
        this._threadPoolWriteSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolWriteSizeInput() {
        return this._threadPoolWriteSize;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            action_auto_create_index_enabled: cdktn.booleanToTerraform(this._actionAutoCreateIndexEnabled),
            action_destructive_requires_name: cdktn.booleanToTerraform(this._actionDestructiveRequiresName),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            cluster_max_shards_per_node: cdktn.numberToTerraform(this._clusterMaxShardsPerNode),
            cluster_routing_allocation_node_concurrent_recoveries: cdktn.numberToTerraform(this._clusterRoutingAllocationNodeConcurrentRecoveries),
            enable_security_audit: cdktn.booleanToTerraform(this._enableSecurityAudit),
            http_max_content_length_bytes: cdktn.numberToTerraform(this._httpMaxContentLengthBytes),
            http_max_header_size_bytes: cdktn.numberToTerraform(this._httpMaxHeaderSizeBytes),
            http_max_initial_line_length_bytes: cdktn.numberToTerraform(this._httpMaxInitialLineLengthBytes),
            id: cdktn.stringToTerraform(this._id),
            indices_fielddata_cache_size_percentage: cdktn.numberToTerraform(this._indicesFielddataCacheSizePercentage),
            indices_memory_index_buffer_size_percentage: cdktn.numberToTerraform(this._indicesMemoryIndexBufferSizePercentage),
            indices_memory_max_index_buffer_size_mb: cdktn.numberToTerraform(this._indicesMemoryMaxIndexBufferSizeMb),
            indices_memory_min_index_buffer_size_mb: cdktn.numberToTerraform(this._indicesMemoryMinIndexBufferSizeMb),
            indices_queries_cache_size_percentage: cdktn.numberToTerraform(this._indicesQueriesCacheSizePercentage),
            indices_query_bool_max_clause_count: cdktn.numberToTerraform(this._indicesQueryBoolMaxClauseCount),
            indices_recovery_max_concurrent_file_chunks: cdktn.numberToTerraform(this._indicesRecoveryMaxConcurrentFileChunks),
            indices_recovery_max_mb_per_sec: cdktn.numberToTerraform(this._indicesRecoveryMaxMbPerSec),
            ism_enabled: cdktn.booleanToTerraform(this._ismEnabled),
            ism_history_enabled: cdktn.booleanToTerraform(this._ismHistoryEnabled),
            ism_history_max_age_hours: cdktn.numberToTerraform(this._ismHistoryMaxAgeHours),
            ism_history_max_docs: cdktn.numberToTerraform(this._ismHistoryMaxDocs),
            ism_history_rollover_check_period_hours: cdktn.numberToTerraform(this._ismHistoryRolloverCheckPeriodHours),
            ism_history_rollover_retention_period_days: cdktn.numberToTerraform(this._ismHistoryRolloverRetentionPeriodDays),
            override_main_response_version: cdktn.booleanToTerraform(this._overrideMainResponseVersion),
            plugins_alerting_filter_by_backend_roles_enabled: cdktn.booleanToTerraform(this._pluginsAlertingFilterByBackendRolesEnabled),
            reindex_remote_whitelist: cdktn.listMapper(cdktn.stringToTerraform, false)(this._reindexRemoteWhitelist),
            script_max_compilations_rate: cdktn.stringToTerraform(this._scriptMaxCompilationsRate),
            search_max_buckets: cdktn.numberToTerraform(this._searchMaxBuckets),
            thread_pool_analyze_queue_size: cdktn.numberToTerraform(this._threadPoolAnalyzeQueueSize),
            thread_pool_analyze_size: cdktn.numberToTerraform(this._threadPoolAnalyzeSize),
            thread_pool_force_merge_size: cdktn.numberToTerraform(this._threadPoolForceMergeSize),
            thread_pool_get_queue_size: cdktn.numberToTerraform(this._threadPoolGetQueueSize),
            thread_pool_get_size: cdktn.numberToTerraform(this._threadPoolGetSize),
            thread_pool_search_queue_size: cdktn.numberToTerraform(this._threadPoolSearchQueueSize),
            thread_pool_search_size: cdktn.numberToTerraform(this._threadPoolSearchSize),
            thread_pool_search_throttled_queue_size: cdktn.numberToTerraform(this._threadPoolSearchThrottledQueueSize),
            thread_pool_search_throttled_size: cdktn.numberToTerraform(this._threadPoolSearchThrottledSize),
            thread_pool_write_queue_size: cdktn.numberToTerraform(this._threadPoolWriteQueueSize),
            thread_pool_write_size: cdktn.numberToTerraform(this._threadPoolWriteSize),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            action_auto_create_index_enabled: {
                value: cdktn.booleanToHclTerraform(this._actionAutoCreateIndexEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            action_destructive_requires_name: {
                value: cdktn.booleanToHclTerraform(this._actionDestructiveRequiresName),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            cluster_max_shards_per_node: {
                value: cdktn.numberToHclTerraform(this._clusterMaxShardsPerNode),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            cluster_routing_allocation_node_concurrent_recoveries: {
                value: cdktn.numberToHclTerraform(this._clusterRoutingAllocationNodeConcurrentRecoveries),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            enable_security_audit: {
                value: cdktn.booleanToHclTerraform(this._enableSecurityAudit),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            http_max_content_length_bytes: {
                value: cdktn.numberToHclTerraform(this._httpMaxContentLengthBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            http_max_header_size_bytes: {
                value: cdktn.numberToHclTerraform(this._httpMaxHeaderSizeBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            http_max_initial_line_length_bytes: {
                value: cdktn.numberToHclTerraform(this._httpMaxInitialLineLengthBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            indices_fielddata_cache_size_percentage: {
                value: cdktn.numberToHclTerraform(this._indicesFielddataCacheSizePercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_memory_index_buffer_size_percentage: {
                value: cdktn.numberToHclTerraform(this._indicesMemoryIndexBufferSizePercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_memory_max_index_buffer_size_mb: {
                value: cdktn.numberToHclTerraform(this._indicesMemoryMaxIndexBufferSizeMb),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_memory_min_index_buffer_size_mb: {
                value: cdktn.numberToHclTerraform(this._indicesMemoryMinIndexBufferSizeMb),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_queries_cache_size_percentage: {
                value: cdktn.numberToHclTerraform(this._indicesQueriesCacheSizePercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_query_bool_max_clause_count: {
                value: cdktn.numberToHclTerraform(this._indicesQueryBoolMaxClauseCount),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_recovery_max_concurrent_file_chunks: {
                value: cdktn.numberToHclTerraform(this._indicesRecoveryMaxConcurrentFileChunks),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_recovery_max_mb_per_sec: {
                value: cdktn.numberToHclTerraform(this._indicesRecoveryMaxMbPerSec),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_enabled: {
                value: cdktn.booleanToHclTerraform(this._ismEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            ism_history_enabled: {
                value: cdktn.booleanToHclTerraform(this._ismHistoryEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            ism_history_max_age_hours: {
                value: cdktn.numberToHclTerraform(this._ismHistoryMaxAgeHours),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_history_max_docs: {
                value: cdktn.numberToHclTerraform(this._ismHistoryMaxDocs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_history_rollover_check_period_hours: {
                value: cdktn.numberToHclTerraform(this._ismHistoryRolloverCheckPeriodHours),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_history_rollover_retention_period_days: {
                value: cdktn.numberToHclTerraform(this._ismHistoryRolloverRetentionPeriodDays),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            override_main_response_version: {
                value: cdktn.booleanToHclTerraform(this._overrideMainResponseVersion),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            plugins_alerting_filter_by_backend_roles_enabled: {
                value: cdktn.booleanToHclTerraform(this._pluginsAlertingFilterByBackendRolesEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            reindex_remote_whitelist: {
                value: cdktn.listMapperHcl(cdktn.stringToHclTerraform, false)(this._reindexRemoteWhitelist),
                isBlock: false,
                type: "set",
                storageClassType: "stringList",
            },
            script_max_compilations_rate: {
                value: cdktn.stringToHclTerraform(this._scriptMaxCompilationsRate),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            search_max_buckets: {
                value: cdktn.numberToHclTerraform(this._searchMaxBuckets),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_analyze_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolAnalyzeQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_analyze_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolAnalyzeSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_force_merge_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolForceMergeSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_get_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolGetQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_get_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolGetSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_throttled_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchThrottledQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_throttled_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchThrottledSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_write_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolWriteQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_write_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolWriteSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseOpensearchConfig = DatabaseOpensearchConfig;
// =================
// STATIC PROPERTIES
// =================
DatabaseOpensearchConfig.tfResourceType = "digitalocean_database_opensearch_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEscUhBQXFIO0FBQ3JILDJDQUEyQzs7O0FBRzNDLCtCQUErQjtBQTBLL0I7O0VBRUU7QUFDRixNQUFhLHdCQUF5QixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPbkUsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLHlDQUF5QyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUNqSyxDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBc0M7UUFDckYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSx5Q0FBeUM7WUFDaEUsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsNkJBQTZCLENBQUM7UUFDM0UsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ25DLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLGlEQUFpRCxHQUFHLE1BQU0sQ0FBQyxnREFBZ0QsQ0FBQztRQUNqSCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDLG1CQUFtQixDQUFDO1FBQ3ZELElBQUksQ0FBQywwQkFBMEIsR0FBRyxNQUFNLENBQUMseUJBQXlCLENBQUM7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsOEJBQThCLEdBQUcsTUFBTSxDQUFDLDZCQUE2QixDQUFDO1FBQzNFLElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsb0NBQW9DLEdBQUcsTUFBTSxDQUFDLG1DQUFtQyxDQUFDO1FBQ3ZGLElBQUksQ0FBQyx1Q0FBdUMsR0FBRyxNQUFNLENBQUMsc0NBQXNDLENBQUM7UUFDN0YsSUFBSSxDQUFDLGtDQUFrQyxHQUFHLE1BQU0sQ0FBQyxpQ0FBaUMsQ0FBQztRQUNuRixJQUFJLENBQUMsa0NBQWtDLEdBQUcsTUFBTSxDQUFDLGlDQUFpQyxDQUFDO1FBQ25GLElBQUksQ0FBQyxrQ0FBa0MsR0FBRyxNQUFNLENBQUMsaUNBQWlDLENBQUM7UUFDbkYsSUFBSSxDQUFDLCtCQUErQixHQUFHLE1BQU0sQ0FBQyw4QkFBOEIsQ0FBQztRQUM3RSxJQUFJLENBQUMsdUNBQXVDLEdBQUcsTUFBTSxDQUFDLHNDQUFzQyxDQUFDO1FBQzdGLElBQUksQ0FBQywyQkFBMkIsR0FBRyxNQUFNLENBQUMsMEJBQTBCLENBQUM7UUFDckUsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxNQUFNLENBQUMsa0NBQWtDLENBQUM7UUFDckYsSUFBSSxDQUFDLHNDQUFzQyxHQUFHLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQztRQUMzRixJQUFJLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDO1FBQ3ZFLElBQUksQ0FBQywyQ0FBMkMsR0FBRyxNQUFNLENBQUMsMENBQTBDLENBQUM7UUFDckcsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsTUFBTSxDQUFDLHlCQUF5QixDQUFDO1FBQ25FLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUM7UUFDakQsSUFBSSxDQUFDLDJCQUEyQixHQUFHLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQztRQUNyRSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzNELElBQUksQ0FBQyx5QkFBeUIsR0FBRyxNQUFNLENBQUMsd0JBQXdCLENBQUM7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQywwQkFBMEIsR0FBRyxNQUFNLENBQUMseUJBQXlCLENBQUM7UUFDbkUsSUFBSSxDQUFDLHFCQUFxQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztRQUN6RCxJQUFJLENBQUMsbUNBQW1DLEdBQUcsTUFBTSxDQUFDLGtDQUFrQyxDQUFDO1FBQ3JGLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsNkJBQTZCLENBQUM7UUFDM0UsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQztRQUNqRSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDLG1CQUFtQixDQUFDO0lBQ3pELENBQUM7SUFRRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFDRCxJQUFXLDRCQUE0QixDQUFDLEtBQWtDO1FBQ3hFLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxLQUFLLENBQUM7SUFDN0MsQ0FBQztJQUNNLGlDQUFpQztRQUN0QyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsU0FBUyxDQUFDO0lBQ2pELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxpQ0FBaUM7UUFDMUMsT0FBTyxJQUFJLENBQUMsNkJBQTZCLENBQUM7SUFDNUMsQ0FBQztJQUlELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGtDQUFrQyxDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUNELElBQVcsNkJBQTZCLENBQUMsS0FBa0M7UUFDekUsSUFBSSxDQUFDLDhCQUE4QixHQUFHLEtBQUssQ0FBQztJQUM5QyxDQUFDO0lBQ00sa0NBQWtDO1FBQ3ZDLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxTQUFTLENBQUM7SUFDbEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtDQUFrQztRQUMzQyxPQUFPLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztJQUM3QyxDQUFDO0lBSUQsSUFBVyxTQUFTO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFXLFNBQVMsQ0FBQyxLQUFhO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN6QixDQUFDO0lBSUQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsNkJBQTZCLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFhO1FBQzlDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUNNLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0lBQzVDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw0QkFBNEI7UUFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUlELElBQVcsZ0RBQWdEO1FBQ3pELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVEQUF1RCxDQUFDLENBQUM7SUFDMUYsQ0FBQztJQUNELElBQVcsZ0RBQWdELENBQUMsS0FBYTtRQUN2RSxJQUFJLENBQUMsaURBQWlELEdBQUcsS0FBSyxDQUFDO0lBQ2pFLENBQUM7SUFDTSxxREFBcUQ7UUFDMUQsSUFBSSxDQUFDLGlEQUFpRCxHQUFHLFNBQVMsQ0FBQztJQUNyRSxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscURBQXFEO1FBQzlELE9BQU8sSUFBSSxDQUFDLGlEQUFpRCxDQUFDO0lBQ2hFLENBQUM7SUFJRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG1CQUFtQixDQUFDLEtBQWtDO1FBQy9ELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUNNLHdCQUF3QjtRQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFDbkMsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLCtCQUErQixDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWE7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyw2QkFBNkI7UUFDdEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsb0NBQW9DLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBQ0QsSUFBVyw2QkFBNkIsQ0FBQyxLQUFhO1FBQ3BELElBQUksQ0FBQyw4QkFBOEIsR0FBRyxLQUFLLENBQUM7SUFDOUMsQ0FBQztJQUNNLGtDQUFrQztRQUN2QyxJQUFJLENBQUMsOEJBQThCLEdBQUcsU0FBUyxDQUFDO0lBQ2xELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsOEJBQThCLENBQUM7SUFDN0MsQ0FBQztJQUlELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFXLEVBQUUsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFDTSxPQUFPO1FBQ1osSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2xCLENBQUM7SUFJRCxJQUFXLG1DQUFtQztRQUM1QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDRCxJQUFXLG1DQUFtQyxDQUFDLEtBQWE7UUFDMUQsSUFBSSxDQUFDLG9DQUFvQyxHQUFHLEtBQUssQ0FBQztJQUNwRCxDQUFDO0lBQ00sd0NBQXdDO1FBQzdDLElBQUksQ0FBQyxvQ0FBb0MsR0FBRyxTQUFTLENBQUM7SUFDeEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHdDQUF3QztRQUNqRCxPQUFPLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQztJQUNuRCxDQUFDO0lBSUQsSUFBVyxzQ0FBc0M7UUFDL0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsNkNBQTZDLENBQUMsQ0FBQztJQUNoRixDQUFDO0lBQ0QsSUFBVyxzQ0FBc0MsQ0FBQyxLQUFhO1FBQzdELElBQUksQ0FBQyx1Q0FBdUMsR0FBRyxLQUFLLENBQUM7SUFDdkQsQ0FBQztJQUNNLDJDQUEyQztRQUNoRCxJQUFJLENBQUMsdUNBQXVDLEdBQUcsU0FBUyxDQUFDO0lBQzNELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQ0FBMkM7UUFDcEQsT0FBTyxJQUFJLENBQUMsdUNBQXVDLENBQUM7SUFDdEQsQ0FBQztJQUlELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHlDQUF5QyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUNELElBQVcsaUNBQWlDLENBQUMsS0FBYTtRQUN4RCxJQUFJLENBQUMsa0NBQWtDLEdBQUcsS0FBSyxDQUFDO0lBQ2xELENBQUM7SUFDTSxzQ0FBc0M7UUFDM0MsSUFBSSxDQUFDLGtDQUFrQyxHQUFHLFNBQVMsQ0FBQztJQUN0RCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsc0NBQXNDO1FBQy9DLE9BQU8sSUFBSSxDQUFDLGtDQUFrQyxDQUFDO0lBQ2pELENBQUM7SUFJRCxJQUFXLGlDQUFpQztRQUMxQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDRCxJQUFXLGlDQUFpQyxDQUFDLEtBQWE7UUFDeEQsSUFBSSxDQUFDLGtDQUFrQyxHQUFHLEtBQUssQ0FBQztJQUNsRCxDQUFDO0lBQ00sc0NBQXNDO1FBQzNDLElBQUksQ0FBQyxrQ0FBa0MsR0FBRyxTQUFTLENBQUM7SUFDdEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNDQUFzQztRQUMvQyxPQUFPLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQztJQUNqRCxDQUFDO0lBSUQsSUFBVyxpQ0FBaUM7UUFDMUMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUNBQXVDLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBQ0QsSUFBVyxpQ0FBaUMsQ0FBQyxLQUFhO1FBQ3hELElBQUksQ0FBQyxrQ0FBa0MsR0FBRyxLQUFLLENBQUM7SUFDbEQsQ0FBQztJQUNNLHNDQUFzQztRQUMzQyxJQUFJLENBQUMsa0NBQWtDLEdBQUcsU0FBUyxDQUFDO0lBQ3RELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQ0FBc0M7UUFDL0MsT0FBTyxJQUFJLENBQUMsa0NBQWtDLENBQUM7SUFDakQsQ0FBQztJQUlELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUNELElBQVcsOEJBQThCLENBQUMsS0FBYTtRQUNyRCxJQUFJLENBQUMsK0JBQStCLEdBQUcsS0FBSyxDQUFDO0lBQy9DLENBQUM7SUFDTSxtQ0FBbUM7UUFDeEMsSUFBSSxDQUFDLCtCQUErQixHQUFHLFNBQVMsQ0FBQztJQUNuRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsbUNBQW1DO1FBQzVDLE9BQU8sSUFBSSxDQUFDLCtCQUErQixDQUFDO0lBQzlDLENBQUM7SUFJRCxJQUFXLHNDQUFzQztRQUMvQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO0lBQ2hGLENBQUM7SUFDRCxJQUFXLHNDQUFzQyxDQUFDLEtBQWE7UUFDN0QsSUFBSSxDQUFDLHVDQUF1QyxHQUFHLEtBQUssQ0FBQztJQUN2RCxDQUFDO0lBQ00sMkNBQTJDO1FBQ2hELElBQUksQ0FBQyx1Q0FBdUMsR0FBRyxTQUFTLENBQUM7SUFDM0QsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJDQUEyQztRQUNwRCxPQUFPLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQztJQUN0RCxDQUFDO0lBSUQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywwQkFBMEIsQ0FBQyxLQUFhO1FBQ2pELElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUM7SUFDM0MsQ0FBQztJQUNNLCtCQUErQjtRQUNwQyxJQUFJLENBQUMsMkJBQTJCLEdBQUcsU0FBUyxDQUFDO0lBQy9DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywrQkFBK0I7UUFDeEMsT0FBTyxJQUFJLENBQUMsMkJBQTJCLENBQUM7SUFDMUMsQ0FBQztJQUlELElBQVcsVUFBVTtRQUNuQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsSUFBVyxVQUFVLENBQUMsS0FBa0M7UUFDdEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7SUFDM0IsQ0FBQztJQUNNLGVBQWU7UUFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7SUFDL0IsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWtDO1FBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcscUJBQXFCLENBQUMsS0FBYTtRQUM1QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7SUFDTSwwQkFBMEI7UUFDL0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsQ0FBQztJQUMxQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JDLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBQ0QsSUFBVyxrQ0FBa0MsQ0FBQyxLQUFhO1FBQ3pELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUM7SUFDbkQsQ0FBQztJQUNNLHVDQUF1QztRQUM1QyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsU0FBUyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1Q0FBdUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsbUNBQW1DLENBQUM7SUFDbEQsQ0FBQztJQUlELElBQVcscUNBQXFDO1FBQzlDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUNELElBQVcscUNBQXFDLENBQUMsS0FBYTtRQUM1RCxJQUFJLENBQUMsc0NBQXNDLEdBQUcsS0FBSyxDQUFDO0lBQ3RELENBQUM7SUFDTSwwQ0FBMEM7UUFDL0MsSUFBSSxDQUFDLHNDQUFzQyxHQUFHLFNBQVMsQ0FBQztJQUMxRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMENBQTBDO1FBQ25ELE9BQU8sSUFBSSxDQUFDLHNDQUFzQyxDQUFDO0lBQ3JELENBQUM7SUFJRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDRCxJQUFXLDJCQUEyQixDQUFDLEtBQWtDO1FBQ3ZFLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsMENBQTBDO1FBQ25ELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGtEQUFrRCxDQUFDLENBQUM7SUFDdEYsQ0FBQztJQUNELElBQVcsMENBQTBDLENBQUMsS0FBa0M7UUFDdEYsSUFBSSxDQUFDLDJDQUEyQyxHQUFHLEtBQUssQ0FBQztJQUMzRCxDQUFDO0lBQ00sK0NBQStDO1FBQ3BELElBQUksQ0FBQywyQ0FBMkMsR0FBRyxTQUFTLENBQUM7SUFDL0QsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLCtDQUErQztRQUN4RCxPQUFPLElBQUksQ0FBQywyQ0FBMkMsQ0FBQztJQUMxRCxDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWU7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyx5QkFBeUI7UUFDbEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ0QsSUFBVyx5QkFBeUIsQ0FBQyxLQUFhO1FBQ2hELElBQUksQ0FBQywwQkFBMEIsR0FBRyxLQUFLLENBQUM7SUFDMUMsQ0FBQztJQUNNLDhCQUE4QjtRQUNuQyxJQUFJLENBQUMsMEJBQTBCLEdBQUcsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw4QkFBOEI7UUFDdkMsT0FBTyxJQUFJLENBQUMsMEJBQTBCLENBQUM7SUFDekMsQ0FBQztJQUlELElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFJRCxJQUFXLDBCQUEwQjtRQUNuQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFDRCxJQUFXLDBCQUEwQixDQUFDLEtBQWE7UUFDakQsSUFBSSxDQUFDLDJCQUEyQixHQUFHLEtBQUssQ0FBQztJQUMzQyxDQUFDO0lBQ00sK0JBQStCO1FBQ3BDLElBQUksQ0FBQywyQkFBMkIsR0FBRyxTQUFTLENBQUM7SUFDL0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLCtCQUErQjtRQUN4QyxPQUFPLElBQUksQ0FBQywyQkFBMkIsQ0FBQztJQUMxQyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUlELElBQVcsd0JBQXdCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNELElBQVcsd0JBQXdCLENBQUMsS0FBYTtRQUMvQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO0lBQ3pDLENBQUM7SUFDTSw2QkFBNkI7UUFDbEMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLFNBQVMsQ0FBQztJQUM3QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixDQUFDO0lBQ3hDLENBQUM7SUFJRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWE7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLCtCQUErQixDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBQ0QsSUFBVyxrQ0FBa0MsQ0FBQyxLQUFhO1FBQ3pELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUM7SUFDbkQsQ0FBQztJQUNNLHVDQUF1QztRQUM1QyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsU0FBUyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1Q0FBdUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsbUNBQW1DLENBQUM7SUFDbEQsQ0FBQztJQUlELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUNELElBQVcsNkJBQTZCLENBQUMsS0FBYTtRQUNwRCxJQUFJLENBQUMsOEJBQThCLEdBQUcsS0FBSyxDQUFDO0lBQzlDLENBQUM7SUFDTSxrQ0FBa0M7UUFDdkMsSUFBSSxDQUFDLDhCQUE4QixHQUFHLFNBQVMsQ0FBQztJQUNsRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsa0NBQWtDO1FBQzNDLE9BQU8sSUFBSSxDQUFDLDhCQUE4QixDQUFDO0lBQzdDLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0QsSUFBVyxtQkFBbUIsQ0FBQyxLQUFhO1FBQzFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUNNLHdCQUF3QjtRQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFDbkMsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztZQUM5RixnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO1lBQy9GLFVBQVUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUNwRCwyQkFBMkIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ25GLHFEQUFxRCxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaURBQWlELENBQUM7WUFDdEkscUJBQXFCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUMxRSw2QkFBNkIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDO1lBQ3ZGLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDakYsa0NBQWtDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztZQUNoRyxFQUFFLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDckMsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQztZQUMzRywyQ0FBMkMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVDQUF1QyxDQUFDO1lBQ2xILHVDQUF1QyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7WUFDekcsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQztZQUN6RyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxDQUFDO1lBQ3ZHLG1DQUFtQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7WUFDbEcsMkNBQTJDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQztZQUNsSCwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDO1lBQzFGLFdBQVcsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUN2RCxtQkFBbUIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3RFLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7WUFDL0Usb0JBQW9CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUN0RSx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDO1lBQzFHLDBDQUEwQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0NBQXNDLENBQUM7WUFDaEgsOEJBQThCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUMzRixnREFBZ0QsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLDJDQUEyQyxDQUFDO1lBQzVILHdCQUF3QixFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN4Ryw0QkFBNEIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDO1lBQ3RGLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDbkUsOEJBQThCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQztZQUN6Rix3QkFBd0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzlFLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7WUFDckYsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUNqRixvQkFBb0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3RFLDZCQUE2QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUM7WUFDdkYsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUM1RSx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDO1lBQzFHLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUM7WUFDL0YsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUNyRixzQkFBc0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1NBQzNFLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCO1FBQy9CLE1BQU0sS0FBSyxHQUFHO1lBQ1osZ0NBQWdDLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO2dCQUN0RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsZ0NBQWdDLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO2dCQUN2RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztnQkFDaEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHFEQUFxRCxFQUFFO2dCQUNyRCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpREFBaUQsQ0FBQztnQkFDekYsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHFCQUFxQixFQUFFO2dCQUNyQixLQUFLLEVBQUUsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztnQkFDN0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELDZCQUE2QixFQUFFO2dCQUM3QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDBCQUEwQixFQUFFO2dCQUMxQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztnQkFDL0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtDQUFrQyxFQUFFO2dCQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztnQkFDdEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELEVBQUUsRUFBRTtnQkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0NBQW9DLENBQUM7Z0JBQzVFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwyQ0FBMkMsRUFBRTtnQkFDM0MsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUNBQXVDLENBQUM7Z0JBQy9FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQ0FBcUMsRUFBRTtnQkFDckMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxtQ0FBbUMsRUFBRTtnQkFDbkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7Z0JBQ3ZFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwyQ0FBMkMsRUFBRTtnQkFDM0MsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUNBQXVDLENBQUM7Z0JBQy9FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ25FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxXQUFXLEVBQUU7Z0JBQ1gsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUNwRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsb0JBQW9CLEVBQUU7Z0JBQ3BCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsdUNBQXVDLEVBQUU7Z0JBQ3ZDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDO2dCQUMzRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsMENBQTBDLEVBQUU7Z0JBQzFDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNDQUFzQyxDQUFDO2dCQUM5RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsOEJBQThCLEVBQUU7Z0JBQzlCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNyRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsZ0RBQWdELEVBQUU7Z0JBQ2hELEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDJDQUEyQyxDQUFDO2dCQUNwRixPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0Qsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQzNGLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxLQUFLO2dCQUNYLGdCQUFnQixFQUFFLFlBQVk7YUFDL0I7WUFDRCw0QkFBNEIsRUFBRTtnQkFDNUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUM7Z0JBQ2xFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxrQkFBa0IsRUFBRTtnQkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7Z0JBQ3pELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw4QkFBOEIsRUFBRTtnQkFDOUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ25FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx3QkFBd0IsRUFBRTtnQkFDeEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw0QkFBNEIsRUFBRTtnQkFDNUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwwQkFBMEIsRUFBRTtnQkFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw2QkFBNkIsRUFBRTtnQkFDN0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUM7Z0JBQ2xFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzdELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUNBQW1DLENBQUM7Z0JBQzNFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQ0FBaUMsRUFBRTtnQkFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUM7Z0JBQ3RFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw0QkFBNEIsRUFBRTtnQkFDNUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxzQkFBc0IsRUFBRTtnQkFDdEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7Z0JBQzVELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7U0FDRixDQUFDO1FBRUYsOEJBQThCO1FBQzlCLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFFLENBQUMsQ0FBQTtJQUM1SCxDQUFDOztBQWxnQ0gsNERBbWdDQztBQWpnQ0Msb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNwQixvQkFBb0I7QUFDRyx1Q0FBYyxHQUFHLHlDQUF5QyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnXG4vLyBnZW5lcmF0ZWQgZnJvbSB0ZXJyYWZvcm0gcmVzb3VyY2Ugc2NoZW1hXG5cbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0ICogYXMgY2RrdG4gZnJvbSAnY2RrdG4nO1xuXG4vLyBDb25maWd1cmF0aW9uXG5cbmV4cG9ydCBpbnRlcmZhY2UgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtTWV0YUFyZ3VtZW50cyB7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2FjdGlvbl9hdXRvX2NyZWF0ZV9pbmRleF9lbmFibGVkIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNhY3Rpb25fYXV0b19jcmVhdGVfaW5kZXhfZW5hYmxlZH1cbiAgKi9cbiAgcmVhZG9ubHkgYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjYWN0aW9uX2Rlc3RydWN0aXZlX3JlcXVpcmVzX25hbWUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2FjdGlvbl9kZXN0cnVjdGl2ZV9yZXF1aXJlc19uYW1lfVxuICAqL1xuICByZWFkb25seSBhY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjY2x1c3Rlcl9pZCBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjY2x1c3Rlcl9pZH1cbiAgKi9cbiAgcmVhZG9ubHkgY2x1c3RlcklkOiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2NsdXN0ZXJfbWF4X3NoYXJkc19wZXJfbm9kZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjY2x1c3Rlcl9tYXhfc2hhcmRzX3Blcl9ub2RlfVxuICAqL1xuICByZWFkb25seSBjbHVzdGVyTWF4U2hhcmRzUGVyTm9kZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjY2x1c3Rlcl9yb3V0aW5nX2FsbG9jYXRpb25fbm9kZV9jb25jdXJyZW50X3JlY292ZXJpZXMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2NsdXN0ZXJfcm91dGluZ19hbGxvY2F0aW9uX25vZGVfY29uY3VycmVudF9yZWNvdmVyaWVzfVxuICAqL1xuICByZWFkb25seSBjbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2VuYWJsZV9zZWN1cml0eV9hdWRpdCBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjZW5hYmxlX3NlY3VyaXR5X2F1ZGl0fVxuICAqL1xuICByZWFkb25seSBlbmFibGVTZWN1cml0eUF1ZGl0PzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNodHRwX21heF9jb250ZW50X2xlbmd0aF9ieXRlcyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaHR0cF9tYXhfY29udGVudF9sZW5ndGhfYnl0ZXN9XG4gICovXG4gIHJlYWRvbmx5IGh0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2h0dHBfbWF4X2hlYWRlcl9zaXplX2J5dGVzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNodHRwX21heF9oZWFkZXJfc2l6ZV9ieXRlc31cbiAgKi9cbiAgcmVhZG9ubHkgaHR0cE1heEhlYWRlclNpemVCeXRlcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaHR0cF9tYXhfaW5pdGlhbF9saW5lX2xlbmd0aF9ieXRlcyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaHR0cF9tYXhfaW5pdGlhbF9saW5lX2xlbmd0aF9ieXRlc31cbiAgKi9cbiAgcmVhZG9ubHkgaHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lkIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpZH1cbiAgKlxuICAqIFBsZWFzZSBiZSBhd2FyZSB0aGF0IHRoZSBpZCBmaWVsZCBpcyBhdXRvbWF0aWNhbGx5IGFkZGVkIHRvIGFsbCByZXNvdXJjZXMgaW4gVGVycmFmb3JtIHByb3ZpZGVycyB1c2luZyBhIFRlcnJhZm9ybSBwcm92aWRlciBTREsgdmVyc2lvbiBiZWxvdyAyLlxuICAqIElmIHlvdSBleHBlcmllbmNlIHByb2JsZW1zIHNldHRpbmcgdGhpcyB2YWx1ZSBpdCBtaWdodCBub3QgYmUgc2V0dGFibGUuIFBsZWFzZSB0YWtlIGEgbG9vayBhdCB0aGUgcHJvdmlkZXIgZG9jdW1lbnRhdGlvbiB0byBlbnN1cmUgaXQgc2hvdWxkIGJlIHNldHRhYmxlLlxuICAqL1xuICByZWFkb25seSBpZD86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW5kaWNlc19maWVsZGRhdGFfY2FjaGVfc2l6ZV9wZXJjZW50YWdlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX2ZpZWxkZGF0YV9jYWNoZV9zaXplX3BlcmNlbnRhZ2V9XG4gICovXG4gIHJlYWRvbmx5IGluZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX21lbW9yeV9pbmRleF9idWZmZXJfc2l6ZV9wZXJjZW50YWdlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX21lbW9yeV9pbmRleF9idWZmZXJfc2l6ZV9wZXJjZW50YWdlfVxuICAqL1xuICByZWFkb25seSBpbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW5kaWNlc19tZW1vcnlfbWF4X2luZGV4X2J1ZmZlcl9zaXplX21iIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX21lbW9yeV9tYXhfaW5kZXhfYnVmZmVyX3NpemVfbWJ9XG4gICovXG4gIHJlYWRvbmx5IGluZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW5kaWNlc19tZW1vcnlfbWluX2luZGV4X2J1ZmZlcl9zaXplX21iIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX21lbW9yeV9taW5faW5kZXhfYnVmZmVyX3NpemVfbWJ9XG4gICovXG4gIHJlYWRvbmx5IGluZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW5kaWNlc19xdWVyaWVzX2NhY2hlX3NpemVfcGVyY2VudGFnZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaW5kaWNlc19xdWVyaWVzX2NhY2hlX3NpemVfcGVyY2VudGFnZX1cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX3F1ZXJ5X2Jvb2xfbWF4X2NsYXVzZV9jb3VudCBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaW5kaWNlc19xdWVyeV9ib29sX21heF9jbGF1c2VfY291bnR9XG4gICovXG4gIHJlYWRvbmx5IGluZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW5kaWNlc19yZWNvdmVyeV9tYXhfY29uY3VycmVudF9maWxlX2NodW5rcyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaW5kaWNlc19yZWNvdmVyeV9tYXhfY29uY3VycmVudF9maWxlX2NodW5rc31cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc1JlY292ZXJ5TWF4Q29uY3VycmVudEZpbGVDaHVua3M/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2luZGljZXNfcmVjb3ZlcnlfbWF4X21iX3Blcl9zZWMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2luZGljZXNfcmVjb3ZlcnlfbWF4X21iX3Blcl9zZWN9XG4gICovXG4gIHJlYWRvbmx5IGluZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpc21fZW5hYmxlZCBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaXNtX2VuYWJsZWR9XG4gICovXG4gIHJlYWRvbmx5IGlzbUVuYWJsZWQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lzbV9oaXN0b3J5X2VuYWJsZWQgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2lzbV9oaXN0b3J5X2VuYWJsZWR9XG4gICovXG4gIHJlYWRvbmx5IGlzbUhpc3RvcnlFbmFibGVkPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpc21faGlzdG9yeV9tYXhfYWdlX2hvdXJzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpc21faGlzdG9yeV9tYXhfYWdlX2hvdXJzfVxuICAqL1xuICByZWFkb25seSBpc21IaXN0b3J5TWF4QWdlSG91cnM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lzbV9oaXN0b3J5X21heF9kb2NzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpc21faGlzdG9yeV9tYXhfZG9jc31cbiAgKi9cbiAgcmVhZG9ubHkgaXNtSGlzdG9yeU1heERvY3M/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lzbV9oaXN0b3J5X3JvbGxvdmVyX2NoZWNrX3BlcmlvZF9ob3VycyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaXNtX2hpc3Rvcnlfcm9sbG92ZXJfY2hlY2tfcGVyaW9kX2hvdXJzfVxuICAqL1xuICByZWFkb25seSBpc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpc21faGlzdG9yeV9yb2xsb3Zlcl9yZXRlbnRpb25fcGVyaW9kX2RheXMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2lzbV9oaXN0b3J5X3JvbGxvdmVyX3JldGVudGlvbl9wZXJpb2RfZGF5c31cbiAgKi9cbiAgcmVhZG9ubHkgaXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjb3ZlcnJpZGVfbWFpbl9yZXNwb25zZV92ZXJzaW9uIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNvdmVycmlkZV9tYWluX3Jlc3BvbnNlX3ZlcnNpb259XG4gICovXG4gIHJlYWRvbmx5IG92ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjcGx1Z2luc19hbGVydGluZ19maWx0ZXJfYnlfYmFja2VuZF9yb2xlc19lbmFibGVkIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNwbHVnaW5zX2FsZXJ0aW5nX2ZpbHRlcl9ieV9iYWNrZW5kX3JvbGVzX2VuYWJsZWR9XG4gICovXG4gIHJlYWRvbmx5IHBsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjcmVpbmRleF9yZW1vdGVfd2hpdGVsaXN0IERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNyZWluZGV4X3JlbW90ZV93aGl0ZWxpc3R9XG4gICovXG4gIHJlYWRvbmx5IHJlaW5kZXhSZW1vdGVXaGl0ZWxpc3Q/OiBzdHJpbmdbXTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjc2NyaXB0X21heF9jb21waWxhdGlvbnNfcmF0ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjc2NyaXB0X21heF9jb21waWxhdGlvbnNfcmF0ZX1cbiAgKi9cbiAgcmVhZG9ubHkgc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjc2VhcmNoX21heF9idWNrZXRzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNzZWFyY2hfbWF4X2J1Y2tldHN9XG4gICovXG4gIHJlYWRvbmx5IHNlYXJjaE1heEJ1Y2tldHM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI3RocmVhZF9wb29sX2FuYWx5emVfcXVldWVfc2l6ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjdGhyZWFkX3Bvb2xfYW5hbHl6ZV9xdWV1ZV9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfYW5hbHl6ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9hbmFseXplX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xBbmFseXplU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfZm9yY2VfbWVyZ2Vfc2l6ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjdGhyZWFkX3Bvb2xfZm9yY2VfbWVyZ2Vfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF9nZXRfcXVldWVfc2l6ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjdGhyZWFkX3Bvb2xfZ2V0X3F1ZXVlX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xHZXRRdWV1ZVNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI3RocmVhZF9wb29sX2dldF9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9nZXRfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbEdldFNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI3RocmVhZF9wb29sX3NlYXJjaF9xdWV1ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9zZWFyY2hfcXVldWVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfc2VhcmNoX3NpemUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3RocmVhZF9wb29sX3NlYXJjaF9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sU2VhcmNoU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9xdWV1ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3F1ZXVlX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI3RocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfc2l6ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjdGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfd3JpdGVfcXVldWVfc2l6ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjdGhyZWFkX3Bvb2xfd3JpdGVfcXVldWVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF93cml0ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF93cml0ZV9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sV3JpdGVTaXplPzogbnVtYmVyO1xufVxuXG4vKipcbiogUmVwcmVzZW50cyBhIHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnfVxuKi9cbmV4cG9ydCBjbGFzcyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcgZXh0ZW5kcyBjZGt0bi5UZXJyYWZvcm1SZXNvdXJjZSB7XG5cbiAgLy8gPT09PT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIFBST1BFUlRJRVNcbiAgLy8gPT09PT09PT09PT09PT09PT1cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSB0ZlJlc291cmNlVHlwZSA9IFwiZGlnaXRhbG9jZWFuX2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnXCI7XG5cbiAgLy8gPT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIE1ldGhvZHNcbiAgLy8gPT09PT09PT09PT09PT1cbiAgLyoqXG4gICogR2VuZXJhdGVzIENES1ROIGNvZGUgZm9yIGltcG9ydGluZyBhIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyByZXNvdXJjZSB1cG9uIHJ1bm5pbmcgXCJjZGt0biBwbGFuIDxzdGFjay1uYW1lPlwiXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaW1wb3J0VG9JZCBUaGUgY29uc3RydWN0IGlkIHVzZWQgaW4gdGhlIGdlbmVyYXRlZCBjb25maWcgZm9yIHRoZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcgdG8gaW1wb3J0XG4gICogQHBhcmFtIGltcG9ydEZyb21JZCBUaGUgaWQgb2YgdGhlIGV4aXN0aW5nIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyB0aGF0IHNob3VsZCBiZSBpbXBvcnRlZC4gUmVmZXIgdG8gdGhlIHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW1wb3J0IGltcG9ydCBzZWN0aW9ufSBpbiB0aGUgZG9jdW1lbnRhdGlvbiBvZiB0aGlzIHJlc291cmNlIGZvciB0aGUgaWQgdG8gdXNlXG4gICogQHBhcmFtIHByb3ZpZGVyPyBPcHRpb25hbCBpbnN0YW5jZSBvZiB0aGUgcHJvdmlkZXIgd2hlcmUgdGhlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyB0byBpbXBvcnQgaXMgZm91bmRcbiAgKi9cbiAgcHVibGljIHN0YXRpYyBnZW5lcmF0ZUNvbmZpZ0ZvckltcG9ydChzY29wZTogQ29uc3RydWN0LCBpbXBvcnRUb0lkOiBzdHJpbmcsIGltcG9ydEZyb21JZDogc3RyaW5nLCBwcm92aWRlcj86IGNka3RuLlRlcnJhZm9ybVByb3ZpZGVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgY2RrdG4uSW1wb3J0YWJsZVJlc291cmNlKHNjb3BlLCBpbXBvcnRUb0lkLCB7IHRlcnJhZm9ybVJlc291cmNlVHlwZTogXCJkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWdcIiwgaW1wb3J0SWQ6IGltcG9ydEZyb21JZCwgcHJvdmlkZXIgfSk7XG4gICAgICB9XG5cbiAgLy8gPT09PT09PT09PT1cbiAgLy8gSU5JVElBTElaRVJcbiAgLy8gPT09PT09PT09PT1cblxuICAvKipcbiAgKiBDcmVhdGUgYSBuZXcge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWd9IFJlc291cmNlXG4gICpcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpZCBUaGUgc2NvcGVkIGNvbnN0cnVjdCBJRC4gTXVzdCBiZSB1bmlxdWUgYW1vbmdzdCBzaWJsaW5ncyBpbiB0aGUgc2FtZSBzY29wZVxuICAqIEBwYXJhbSBvcHRpb25zIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZ0NvbmZpZ1xuICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgY29uZmlnOiBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWdDb25maWcpIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIHRlcnJhZm9ybVJlc291cmNlVHlwZTogJ2RpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZycsXG4gICAgICB0ZXJyYWZvcm1HZW5lcmF0b3JNZXRhZGF0YToge1xuICAgICAgICBwcm92aWRlck5hbWU6ICdkaWdpdGFsb2NlYW4nLFxuICAgICAgICBwcm92aWRlclZlcnNpb246ICcyLjg3LjAnLFxuICAgICAgICBwcm92aWRlclZlcnNpb25Db25zdHJhaW50OiAnMi44Ny4wJ1xuICAgICAgfSxcbiAgICAgIHByb3ZpZGVyOiBjb25maWcucHJvdmlkZXIsXG4gICAgICBkZXBlbmRzT246IGNvbmZpZy5kZXBlbmRzT24sXG4gICAgICBjb3VudDogY29uZmlnLmNvdW50LFxuICAgICAgbGlmZWN5Y2xlOiBjb25maWcubGlmZWN5Y2xlLFxuICAgICAgcHJvdmlzaW9uZXJzOiBjb25maWcucHJvdmlzaW9uZXJzLFxuICAgICAgY29ubmVjdGlvbjogY29uZmlnLmNvbm5lY3Rpb24sXG4gICAgICBmb3JFYWNoOiBjb25maWcuZm9yRWFjaFxuICAgIH0pO1xuICAgIHRoaXMuX2FjdGlvbkF1dG9DcmVhdGVJbmRleEVuYWJsZWQgPSBjb25maWcuYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZDtcbiAgICB0aGlzLl9hY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZSA9IGNvbmZpZy5hY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZTtcbiAgICB0aGlzLl9jbHVzdGVySWQgPSBjb25maWcuY2x1c3RlcklkO1xuICAgIHRoaXMuX2NsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlID0gY29uZmlnLmNsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlO1xuICAgIHRoaXMuX2NsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3ZlcmllcyA9IGNvbmZpZy5jbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXM7XG4gICAgdGhpcy5fZW5hYmxlU2VjdXJpdHlBdWRpdCA9IGNvbmZpZy5lbmFibGVTZWN1cml0eUF1ZGl0O1xuICAgIHRoaXMuX2h0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXMgPSBjb25maWcuaHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcztcbiAgICB0aGlzLl9odHRwTWF4SGVhZGVyU2l6ZUJ5dGVzID0gY29uZmlnLmh0dHBNYXhIZWFkZXJTaXplQnl0ZXM7XG4gICAgdGhpcy5faHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXMgPSBjb25maWcuaHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXM7XG4gICAgdGhpcy5faWQgPSBjb25maWcuaWQ7XG4gICAgdGhpcy5faW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2UgPSBjb25maWcuaW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2U7XG4gICAgdGhpcy5faW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2UgPSBjb25maWcuaW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2U7XG4gICAgdGhpcy5faW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iID0gY29uZmlnLmluZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYjtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWIgPSBjb25maWcuaW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iO1xuICAgIHRoaXMuX2luZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZSA9IGNvbmZpZy5pbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2U7XG4gICAgdGhpcy5faW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50ID0gY29uZmlnLmluZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudDtcbiAgICB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcyA9IGNvbmZpZy5pbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcztcbiAgICB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYyA9IGNvbmZpZy5pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYztcbiAgICB0aGlzLl9pc21FbmFibGVkID0gY29uZmlnLmlzbUVuYWJsZWQ7XG4gICAgdGhpcy5faXNtSGlzdG9yeUVuYWJsZWQgPSBjb25maWcuaXNtSGlzdG9yeUVuYWJsZWQ7XG4gICAgdGhpcy5faXNtSGlzdG9yeU1heEFnZUhvdXJzID0gY29uZmlnLmlzbUhpc3RvcnlNYXhBZ2VIb3VycztcbiAgICB0aGlzLl9pc21IaXN0b3J5TWF4RG9jcyA9IGNvbmZpZy5pc21IaXN0b3J5TWF4RG9jcztcbiAgICB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzID0gY29uZmlnLmlzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnM7XG4gICAgdGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cyA9IGNvbmZpZy5pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzO1xuICAgIHRoaXMuX292ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbiA9IGNvbmZpZy5vdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb247XG4gICAgdGhpcy5fcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkID0gY29uZmlnLnBsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZDtcbiAgICB0aGlzLl9yZWluZGV4UmVtb3RlV2hpdGVsaXN0ID0gY29uZmlnLnJlaW5kZXhSZW1vdGVXaGl0ZWxpc3Q7XG4gICAgdGhpcy5fc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZSA9IGNvbmZpZy5zY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlO1xuICAgIHRoaXMuX3NlYXJjaE1heEJ1Y2tldHMgPSBjb25maWcuc2VhcmNoTWF4QnVja2V0cztcbiAgICB0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVNpemUgPSBjb25maWcudGhyZWFkUG9vbEFuYWx5emVTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sRm9yY2VNZXJnZVNpemU7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sR2V0UXVldWVTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xHZXRTaXplID0gY29uZmlnLnRocmVhZFBvb2xHZXRTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUgPSBjb25maWcudGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sU2VhcmNoU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sU2VhcmNoU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkUXVldWVTaXplID0gY29uZmlnLnRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemU7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemUgPSBjb25maWcudGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemU7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplID0gY29uZmlnLnRocmVhZFBvb2xXcml0ZVF1ZXVlU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sV3JpdGVTaXplID0gY29uZmlnLnRocmVhZFBvb2xXcml0ZVNpemU7XG4gIH1cblxuICAvLyA9PT09PT09PT09XG4gIC8vIEFUVFJJQlVURVNcbiAgLy8gPT09PT09PT09PVxuXG4gIC8vIGFjdGlvbl9hdXRvX2NyZWF0ZV9pbmRleF9lbmFibGVkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdhY3Rpb25fYXV0b19jcmVhdGVfaW5kZXhfZW5hYmxlZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEFjdGlvbkF1dG9DcmVhdGVJbmRleEVuYWJsZWQoKSB7XG4gICAgdGhpcy5fYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkO1xuICB9XG5cbiAgLy8gYWN0aW9uX2Rlc3RydWN0aXZlX3JlcXVpcmVzX25hbWUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgYWN0aW9uRGVzdHJ1Y3RpdmVSZXF1aXJlc05hbWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnYWN0aW9uX2Rlc3RydWN0aXZlX3JlcXVpcmVzX25hbWUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGFjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9hY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEFjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lKCkge1xuICAgIHRoaXMuX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZTtcbiAgfVxuXG4gIC8vIGNsdXN0ZXJfaWQgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiBmYWxzZSwgcmVxdWlyZWQ6IHRydWVcbiAgcHJpdmF0ZSBfY2x1c3RlcklkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBjbHVzdGVySWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdjbHVzdGVyX2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBjbHVzdGVySWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IHZhbHVlO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVySWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3RlcklkO1xuICB9XG5cbiAgLy8gY2x1c3Rlcl9tYXhfc2hhcmRzX3Blcl9ub2RlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfY2x1c3Rlck1heFNoYXJkc1Blck5vZGU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnY2x1c3Rlcl9tYXhfc2hhcmRzX3Blcl9ub2RlJyk7XG4gIH1cbiAgcHVibGljIHNldCBjbHVzdGVyTWF4U2hhcmRzUGVyTm9kZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fY2x1c3Rlck1heFNoYXJkc1Blck5vZGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRDbHVzdGVyTWF4U2hhcmRzUGVyTm9kZSgpIHtcbiAgICB0aGlzLl9jbHVzdGVyTWF4U2hhcmRzUGVyTm9kZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgY2x1c3Rlck1heFNoYXJkc1Blck5vZGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3Rlck1heFNoYXJkc1Blck5vZGU7XG4gIH1cblxuICAvLyBjbHVzdGVyX3JvdXRpbmdfYWxsb2NhdGlvbl9ub2RlX2NvbmN1cnJlbnRfcmVjb3ZlcmllcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2NsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3Zlcmllcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnY2x1c3Rlcl9yb3V0aW5nX2FsbG9jYXRpb25fbm9kZV9jb25jdXJyZW50X3JlY292ZXJpZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGNsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3Zlcmllcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Q2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzKCkge1xuICAgIHRoaXMuX2NsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3ZlcmllcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3ZlcmllcztcbiAgfVxuXG4gIC8vIGVuYWJsZV9zZWN1cml0eV9hdWRpdCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2VuYWJsZVNlY3VyaXR5QXVkaXQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IGVuYWJsZVNlY3VyaXR5QXVkaXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnZW5hYmxlX3NlY3VyaXR5X2F1ZGl0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBlbmFibGVTZWN1cml0eUF1ZGl0KHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9lbmFibGVTZWN1cml0eUF1ZGl0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0RW5hYmxlU2VjdXJpdHlBdWRpdCgpIHtcbiAgICB0aGlzLl9lbmFibGVTZWN1cml0eUF1ZGl0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBlbmFibGVTZWN1cml0eUF1ZGl0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2VuYWJsZVNlY3VyaXR5QXVkaXQ7XG4gIH1cblxuICAvLyBodHRwX21heF9jb250ZW50X2xlbmd0aF9ieXRlcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2h0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGh0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdodHRwX21heF9jb250ZW50X2xlbmd0aF9ieXRlcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEh0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXMoKSB7XG4gICAgdGhpcy5faHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaHR0cE1heENvbnRlbnRMZW5ndGhCeXRlc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9odHRwTWF4Q29udGVudExlbmd0aEJ5dGVzO1xuICB9XG5cbiAgLy8gaHR0cF9tYXhfaGVhZGVyX3NpemVfYnl0ZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9odHRwTWF4SGVhZGVyU2l6ZUJ5dGVzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBodHRwTWF4SGVhZGVyU2l6ZUJ5dGVzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaHR0cF9tYXhfaGVhZGVyX3NpemVfYnl0ZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGh0dHBNYXhIZWFkZXJTaXplQnl0ZXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2h0dHBNYXhIZWFkZXJTaXplQnl0ZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRIdHRwTWF4SGVhZGVyU2l6ZUJ5dGVzKCkge1xuICAgIHRoaXMuX2h0dHBNYXhIZWFkZXJTaXplQnl0ZXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGh0dHBNYXhIZWFkZXJTaXplQnl0ZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faHR0cE1heEhlYWRlclNpemVCeXRlcztcbiAgfVxuXG4gIC8vIGh0dHBfbWF4X2luaXRpYWxfbGluZV9sZW5ndGhfYnl0ZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdodHRwX21heF9pbml0aWFsX2xpbmVfbGVuZ3RoX2J5dGVzJyk7XG4gIH1cbiAgcHVibGljIHNldCBodHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRIdHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcygpIHtcbiAgICB0aGlzLl9odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXM7XG4gIH1cblxuICAvLyBpZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBpZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5faWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJZCgpIHtcbiAgICB0aGlzLl9pZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWQ7XG4gIH1cblxuICAvLyBpbmRpY2VzX2ZpZWxkZGF0YV9jYWNoZV9zaXplX3BlcmNlbnRhZ2UgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbmRpY2VzX2ZpZWxkZGF0YV9jYWNoZV9zaXplX3BlcmNlbnRhZ2UnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlKCkge1xuICAgIHRoaXMuX2luZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZTtcbiAgfVxuXG4gIC8vIGluZGljZXNfbWVtb3J5X2luZGV4X2J1ZmZlcl9zaXplX3BlcmNlbnRhZ2UgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbmRpY2VzX21lbW9yeV9pbmRleF9idWZmZXJfc2l6ZV9wZXJjZW50YWdlJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2UgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSgpIHtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2VJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2U7XG4gIH1cblxuICAvLyBpbmRpY2VzX21lbW9yeV9tYXhfaW5kZXhfYnVmZmVyX3NpemVfbWIgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWI/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGluZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfbWVtb3J5X21heF9pbmRleF9idWZmZXJfc2l6ZV9tYicpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWIgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWIoKSB7XG4gICAgdGhpcy5faW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWJJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iO1xuICB9XG5cbiAgLy8gaW5kaWNlc19tZW1vcnlfbWluX2luZGV4X2J1ZmZlcl9zaXplX21iIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWIoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbmRpY2VzX21lbW9yeV9taW5faW5kZXhfYnVmZmVyX3NpemVfbWInKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iKCkge1xuICAgIHRoaXMuX2luZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2luZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYjtcbiAgfVxuXG4gIC8vIGluZGljZXNfcXVlcmllc19jYWNoZV9zaXplX3BlcmNlbnRhZ2UgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2U/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGluZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfcXVlcmllc19jYWNoZV9zaXplX3BlcmNlbnRhZ2UnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlKCkge1xuICAgIHRoaXMuX2luZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2luZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZTtcbiAgfVxuXG4gIC8vIGluZGljZXNfcXVlcnlfYm9vbF9tYXhfY2xhdXNlX2NvdW50IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbmRpY2VzX3F1ZXJ5X2Jvb2xfbWF4X2NsYXVzZV9jb3VudCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQoKSB7XG4gICAgdGhpcy5faW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50O1xuICB9XG5cbiAgLy8gaW5kaWNlc19yZWNvdmVyeV9tYXhfY29uY3VycmVudF9maWxlX2NodW5rcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfcmVjb3ZlcnlfbWF4X2NvbmN1cnJlbnRfZmlsZV9jaHVua3MnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzKCkge1xuICAgIHRoaXMuX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcztcbiAgfVxuXG4gIC8vIGluZGljZXNfcmVjb3ZlcnlfbWF4X21iX3Blcl9zZWMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5kaWNlc1JlY292ZXJ5TWF4TWJQZXJTZWMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbmRpY2VzX3JlY292ZXJ5X21heF9tYl9wZXJfc2VjJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5kaWNlc1JlY292ZXJ5TWF4TWJQZXJTZWMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYygpIHtcbiAgICB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5kaWNlc1JlY292ZXJ5TWF4TWJQZXJTZWNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5kaWNlc1JlY292ZXJ5TWF4TWJQZXJTZWM7XG4gIH1cblxuICAvLyBpc21fZW5hYmxlZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lzbUVuYWJsZWQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IGlzbUVuYWJsZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnaXNtX2VuYWJsZWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlzbUVuYWJsZWQodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2lzbUVuYWJsZWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJc21FbmFibGVkKCkge1xuICAgIHRoaXMuX2lzbUVuYWJsZWQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlzbUVuYWJsZWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faXNtRW5hYmxlZDtcbiAgfVxuXG4gIC8vIGlzbV9oaXN0b3J5X2VuYWJsZWQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pc21IaXN0b3J5RW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeUVuYWJsZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnaXNtX2hpc3RvcnlfZW5hYmxlZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaXNtSGlzdG9yeUVuYWJsZWQodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2lzbUhpc3RvcnlFbmFibGVkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SXNtSGlzdG9yeUVuYWJsZWQoKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeUVuYWJsZWQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlzbUhpc3RvcnlFbmFibGVkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lzbUhpc3RvcnlFbmFibGVkO1xuICB9XG5cbiAgLy8gaXNtX2hpc3RvcnlfbWF4X2FnZV9ob3VycyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lzbUhpc3RvcnlNYXhBZ2VIb3Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeU1heEFnZUhvdXJzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaXNtX2hpc3RvcnlfbWF4X2FnZV9ob3VycycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaXNtSGlzdG9yeU1heEFnZUhvdXJzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5TWF4QWdlSG91cnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJc21IaXN0b3J5TWF4QWdlSG91cnMoKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeU1heEFnZUhvdXJzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpc21IaXN0b3J5TWF4QWdlSG91cnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faXNtSGlzdG9yeU1heEFnZUhvdXJzO1xuICB9XG5cbiAgLy8gaXNtX2hpc3RvcnlfbWF4X2RvY3MgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pc21IaXN0b3J5TWF4RG9jcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeU1heERvY3MoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpc21faGlzdG9yeV9tYXhfZG9jcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaXNtSGlzdG9yeU1heERvY3ModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2lzbUhpc3RvcnlNYXhEb2NzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SXNtSGlzdG9yeU1heERvY3MoKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeU1heERvY3MgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlzbUhpc3RvcnlNYXhEb2NzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lzbUhpc3RvcnlNYXhEb2NzO1xuICB9XG5cbiAgLy8gaXNtX2hpc3Rvcnlfcm9sbG92ZXJfY2hlY2tfcGVyaW9kX2hvdXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3VycygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lzbV9oaXN0b3J5X3JvbGxvdmVyX2NoZWNrX3BlcmlvZF9ob3VycycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3Vycyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3VycyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnMoKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3VycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3Vyc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzO1xuICB9XG5cbiAgLy8gaXNtX2hpc3Rvcnlfcm9sbG92ZXJfcmV0ZW50aW9uX3BlcmlvZF9kYXlzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lzbV9oaXN0b3J5X3JvbGxvdmVyX3JldGVudGlvbl9wZXJpb2RfZGF5cycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElzbUhpc3RvcnlSb2xsb3ZlclJldGVudGlvblBlcmlvZERheXMoKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5c0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzO1xuICB9XG5cbiAgLy8gb3ZlcnJpZGVfbWFpbl9yZXNwb25zZV92ZXJzaW9uIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfb3ZlcnJpZGVNYWluUmVzcG9uc2VWZXJzaW9uPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBvdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnb3ZlcnJpZGVfbWFpbl9yZXNwb25zZV92ZXJzaW9uJyk7XG4gIH1cbiAgcHVibGljIHNldCBvdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb24odmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX292ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE92ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbigpIHtcbiAgICB0aGlzLl9vdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb24gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG92ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9vdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb247XG4gIH1cblxuICAvLyBwbHVnaW5zX2FsZXJ0aW5nX2ZpbHRlcl9ieV9iYWNrZW5kX3JvbGVzX2VuYWJsZWQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9wbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IHBsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdwbHVnaW5zX2FsZXJ0aW5nX2ZpbHRlcl9ieV9iYWNrZW5kX3JvbGVzX2VuYWJsZWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHBsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0UGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkKCkge1xuICAgIHRoaXMuX3BsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZDtcbiAgfVxuXG4gIC8vIHJlaW5kZXhfcmVtb3RlX3doaXRlbGlzdCAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9yZWluZGV4UmVtb3RlV2hpdGVsaXN0Pzogc3RyaW5nW107IFxuICBwdWJsaWMgZ2V0IHJlaW5kZXhSZW1vdGVXaGl0ZWxpc3QoKSB7XG4gICAgcmV0dXJuIGNka3RuLkZuLnRvbGlzdCh0aGlzLmdldExpc3RBdHRyaWJ1dGUoJ3JlaW5kZXhfcmVtb3RlX3doaXRlbGlzdCcpKTtcbiAgfVxuICBwdWJsaWMgc2V0IHJlaW5kZXhSZW1vdGVXaGl0ZWxpc3QodmFsdWU6IHN0cmluZ1tdKSB7XG4gICAgdGhpcy5fcmVpbmRleFJlbW90ZVdoaXRlbGlzdCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFJlaW5kZXhSZW1vdGVXaGl0ZWxpc3QoKSB7XG4gICAgdGhpcy5fcmVpbmRleFJlbW90ZVdoaXRlbGlzdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcmVpbmRleFJlbW90ZVdoaXRlbGlzdElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9yZWluZGV4UmVtb3RlV2hpdGVsaXN0O1xuICB9XG5cbiAgLy8gc2NyaXB0X21heF9jb21waWxhdGlvbnNfcmF0ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NjcmlwdE1heENvbXBpbGF0aW9uc1JhdGU/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHNjcmlwdE1heENvbXBpbGF0aW9uc1JhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdzY3JpcHRfbWF4X2NvbXBpbGF0aW9uc19yYXRlJyk7XG4gIH1cbiAgcHVibGljIHNldCBzY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9zY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZSgpIHtcbiAgICB0aGlzLl9zY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NjcmlwdE1heENvbXBpbGF0aW9uc1JhdGU7XG4gIH1cblxuICAvLyBzZWFyY2hfbWF4X2J1Y2tldHMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9zZWFyY2hNYXhCdWNrZXRzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBzZWFyY2hNYXhCdWNrZXRzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnc2VhcmNoX21heF9idWNrZXRzJyk7XG4gIH1cbiAgcHVibGljIHNldCBzZWFyY2hNYXhCdWNrZXRzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9zZWFyY2hNYXhCdWNrZXRzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U2VhcmNoTWF4QnVja2V0cygpIHtcbiAgICB0aGlzLl9zZWFyY2hNYXhCdWNrZXRzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzZWFyY2hNYXhCdWNrZXRzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NlYXJjaE1heEJ1Y2tldHM7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF9hbmFseXplX3F1ZXVlX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEFuYWx5emVRdWV1ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9hbmFseXplX3F1ZXVlX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xBbmFseXplUXVldWVTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xBbmFseXplUXVldWVTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xBbmFseXplUXVldWVTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZTtcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX2FuYWx5emVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xBbmFseXplU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEFuYWx5emVTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndGhyZWFkX3Bvb2xfYW5hbHl6ZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sQW5hbHl6ZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xBbmFseXplU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xBbmFseXplU2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xBbmFseXplU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVNpemU7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF9mb3JjZV9tZXJnZV9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sRm9yY2VNZXJnZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9mb3JjZV9tZXJnZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sRm9yY2VNZXJnZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sRm9yY2VNZXJnZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sRm9yY2VNZXJnZVNpemU7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF9nZXRfcXVldWVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xHZXRRdWV1ZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xHZXRRdWV1ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9nZXRfcXVldWVfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xHZXRRdWV1ZVNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sR2V0UXVldWVTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfZ2V0X3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aHJlYWRQb29sR2V0U2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEdldFNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9nZXRfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbEdldFNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xHZXRTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbEdldFNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEdldFNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xHZXRTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xHZXRTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfc2VhcmNoX3F1ZXVlX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aHJlYWRQb29sU2VhcmNoUXVldWVTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sU2VhcmNoUXVldWVTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndGhyZWFkX3Bvb2xfc2VhcmNoX3F1ZXVlX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaHJlYWRQb29sU2VhcmNoUXVldWVTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZTtcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX3NlYXJjaF9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbFNlYXJjaFNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndGhyZWFkX3Bvb2xfc2VhcmNoX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xTZWFyY2hTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sU2VhcmNoU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xTZWFyY2hTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aHJlYWRQb29sU2VhcmNoU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sU2VhcmNoU2l6ZTtcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfcXVldWVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3F1ZXVlX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkUXVldWVTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZTtcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfd3JpdGVfcXVldWVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xXcml0ZVF1ZXVlU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndGhyZWFkX3Bvb2xfd3JpdGVfcXVldWVfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaHJlYWRQb29sV3JpdGVRdWV1ZVNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aHJlYWRQb29sV3JpdGVRdWV1ZVNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfd3JpdGVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xXcml0ZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xXcml0ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF93cml0ZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sV3JpdGVTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sV3JpdGVTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbFdyaXRlU2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sV3JpdGVTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aHJlYWRQb29sV3JpdGVTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xXcml0ZVNpemU7XG4gIH1cblxuICAvLyA9PT09PT09PT1cbiAgLy8gU1lOVEhFU0lTXG4gIC8vID09PT09PT09PVxuXG4gIHByb3RlY3RlZCBzeW50aGVzaXplQXR0cmlidXRlcygpOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFjdGlvbl9hdXRvX2NyZWF0ZV9pbmRleF9lbmFibGVkOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCksXG4gICAgICBhY3Rpb25fZGVzdHJ1Y3RpdmVfcmVxdWlyZXNfbmFtZTogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lKSxcbiAgICAgIGNsdXN0ZXJfaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICBjbHVzdGVyX21heF9zaGFyZHNfcGVyX25vZGU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlKSxcbiAgICAgIGNsdXN0ZXJfcm91dGluZ19hbGxvY2F0aW9uX25vZGVfY29uY3VycmVudF9yZWNvdmVyaWVzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9jbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXMpLFxuICAgICAgZW5hYmxlX3NlY3VyaXR5X2F1ZGl0OiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fZW5hYmxlU2VjdXJpdHlBdWRpdCksXG4gICAgICBodHRwX21heF9jb250ZW50X2xlbmd0aF9ieXRlczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcyksXG4gICAgICBodHRwX21heF9oZWFkZXJfc2l6ZV9ieXRlczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faHR0cE1heEhlYWRlclNpemVCeXRlcyksXG4gICAgICBodHRwX21heF9pbml0aWFsX2xpbmVfbGVuZ3RoX2J5dGVzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcyksXG4gICAgICBpZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgaW5kaWNlc19maWVsZGRhdGFfY2FjaGVfc2l6ZV9wZXJjZW50YWdlOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZSksXG4gICAgICBpbmRpY2VzX21lbW9yeV9pbmRleF9idWZmZXJfc2l6ZV9wZXJjZW50YWdlOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSksXG4gICAgICBpbmRpY2VzX21lbW9yeV9tYXhfaW5kZXhfYnVmZmVyX3NpemVfbWI6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYiksXG4gICAgICBpbmRpY2VzX21lbW9yeV9taW5faW5kZXhfYnVmZmVyX3NpemVfbWI6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYiksXG4gICAgICBpbmRpY2VzX3F1ZXJpZXNfY2FjaGVfc2l6ZV9wZXJjZW50YWdlOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2UpLFxuICAgICAgaW5kaWNlc19xdWVyeV9ib29sX21heF9jbGF1c2VfY291bnQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudCksXG4gICAgICBpbmRpY2VzX3JlY292ZXJ5X21heF9jb25jdXJyZW50X2ZpbGVfY2h1bmtzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcyksXG4gICAgICBpbmRpY2VzX3JlY292ZXJ5X21heF9tYl9wZXJfc2VjOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYyksXG4gICAgICBpc21fZW5hYmxlZDogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2lzbUVuYWJsZWQpLFxuICAgICAgaXNtX2hpc3RvcnlfZW5hYmxlZDogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlFbmFibGVkKSxcbiAgICAgIGlzbV9oaXN0b3J5X21heF9hZ2VfaG91cnM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlNYXhBZ2VIb3VycyksXG4gICAgICBpc21faGlzdG9yeV9tYXhfZG9jczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeU1heERvY3MpLFxuICAgICAgaXNtX2hpc3Rvcnlfcm9sbG92ZXJfY2hlY2tfcGVyaW9kX2hvdXJzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzKSxcbiAgICAgIGlzbV9oaXN0b3J5X3JvbGxvdmVyX3JldGVudGlvbl9wZXJpb2RfZGF5czogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cyksXG4gICAgICBvdmVycmlkZV9tYWluX3Jlc3BvbnNlX3ZlcnNpb246IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9vdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb24pLFxuICAgICAgcGx1Z2luc19hbGVydGluZ19maWx0ZXJfYnlfYmFja2VuZF9yb2xlc19lbmFibGVkOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkKSxcbiAgICAgIHJlaW5kZXhfcmVtb3RlX3doaXRlbGlzdDogY2RrdG4ubGlzdE1hcHBlcihjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSwgZmFsc2UpKHRoaXMuX3JlaW5kZXhSZW1vdGVXaGl0ZWxpc3QpLFxuICAgICAgc2NyaXB0X21heF9jb21waWxhdGlvbnNfcmF0ZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZSksXG4gICAgICBzZWFyY2hfbWF4X2J1Y2tldHM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3NlYXJjaE1heEJ1Y2tldHMpLFxuICAgICAgdGhyZWFkX3Bvb2xfYW5hbHl6ZV9xdWV1ZV9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF9hbmFseXplX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xBbmFseXplU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF9mb3JjZV9tZXJnZV9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sRm9yY2VNZXJnZVNpemUpLFxuICAgICAgdGhyZWFkX3Bvb2xfZ2V0X3F1ZXVlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xHZXRRdWV1ZVNpemUpLFxuICAgICAgdGhyZWFkX3Bvb2xfZ2V0X3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xHZXRTaXplKSxcbiAgICAgIHRocmVhZF9wb29sX3NlYXJjaF9xdWV1ZV9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sU2VhcmNoUXVldWVTaXplKSxcbiAgICAgIHRocmVhZF9wb29sX3NlYXJjaF9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sU2VhcmNoU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3F1ZXVlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUpLFxuICAgICAgdGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF93cml0ZV9xdWV1ZV9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUpLFxuICAgICAgdGhyZWFkX3Bvb2xfd3JpdGVfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFdyaXRlU2l6ZSksXG4gICAgfTtcbiAgfVxuXG4gIHByb3RlY3RlZCBzeW50aGVzaXplSGNsQXR0cmlidXRlcygpOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSB7XG4gICAgY29uc3QgYXR0cnMgPSB7XG4gICAgICBhY3Rpb25fYXV0b19jcmVhdGVfaW5kZXhfZW5hYmxlZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2FjdGlvbkF1dG9DcmVhdGVJbmRleEVuYWJsZWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgYWN0aW9uX2Rlc3RydWN0aXZlX3JlcXVpcmVzX25hbWU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9hY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBjbHVzdGVyX2lkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9jbHVzdGVySWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBjbHVzdGVyX21heF9zaGFyZHNfcGVyX25vZGU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgY2x1c3Rlcl9yb3V0aW5nX2FsbG9jYXRpb25fbm9kZV9jb25jdXJyZW50X3JlY292ZXJpZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3ZlcmllcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGVuYWJsZV9zZWN1cml0eV9hdWRpdDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2VuYWJsZVNlY3VyaXR5QXVkaXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgaHR0cF9tYXhfY29udGVudF9sZW5ndGhfYnl0ZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2h0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBodHRwX21heF9oZWFkZXJfc2l6ZV9ieXRlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faHR0cE1heEhlYWRlclNpemVCeXRlcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGh0dHBfbWF4X2luaXRpYWxfbGluZV9sZW5ndGhfYnl0ZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2h0dHBNYXhJbml0aWFsTGluZUxlbmd0aEJ5dGVzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgaW5kaWNlc19maWVsZGRhdGFfY2FjaGVfc2l6ZV9wZXJjZW50YWdlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGluZGljZXNfbWVtb3J5X2luZGV4X2J1ZmZlcl9zaXplX3BlcmNlbnRhZ2U6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5kaWNlc19tZW1vcnlfbWF4X2luZGV4X2J1ZmZlcl9zaXplX21iOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWIpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpbmRpY2VzX21lbW9yeV9taW5faW5kZXhfYnVmZmVyX3NpemVfbWI6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGluZGljZXNfcXVlcmllc19jYWNoZV9zaXplX3BlcmNlbnRhZ2U6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGluZGljZXNfcXVlcnlfYm9vbF9tYXhfY2xhdXNlX2NvdW50OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpbmRpY2VzX3JlY292ZXJ5X21heF9jb25jdXJyZW50X2ZpbGVfY2h1bmtzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGluZGljZXNfcmVjb3ZlcnlfbWF4X21iX3Blcl9zZWM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaXNtX2VuYWJsZWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9pc21FbmFibGVkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGlzbV9oaXN0b3J5X2VuYWJsZWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9pc21IaXN0b3J5RW5hYmxlZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBpc21faGlzdG9yeV9tYXhfYWdlX2hvdXJzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pc21IaXN0b3J5TWF4QWdlSG91cnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpc21faGlzdG9yeV9tYXhfZG9jczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeU1heERvY3MpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpc21faGlzdG9yeV9yb2xsb3Zlcl9jaGVja19wZXJpb2RfaG91cnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpc21faGlzdG9yeV9yb2xsb3Zlcl9yZXRlbnRpb25fcGVyaW9kX2RheXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlSb2xsb3ZlclJldGVudGlvblBlcmlvZERheXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBvdmVycmlkZV9tYWluX3Jlc3BvbnNlX3ZlcnNpb246IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9vdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb24pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgcGx1Z2luc19hbGVydGluZ19maWx0ZXJfYnlfYmFja2VuZF9yb2xlc19lbmFibGVkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIHJlaW5kZXhfcmVtb3RlX3doaXRlbGlzdDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubGlzdE1hcHBlckhjbChjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSwgZmFsc2UpKHRoaXMuX3JlaW5kZXhSZW1vdGVXaGl0ZWxpc3QpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzZXRcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdMaXN0XCIsXG4gICAgICB9LFxuICAgICAgc2NyaXB0X21heF9jb21waWxhdGlvbnNfcmF0ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIHNlYXJjaF9tYXhfYnVja2V0czoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fc2VhcmNoTWF4QnVja2V0cyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX2FuYWx5emVfcXVldWVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEFuYWx5emVRdWV1ZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF9hbmFseXplX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xBbmFseXplU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX2ZvcmNlX21lcmdlX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX2dldF9xdWV1ZV9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sR2V0UXVldWVTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfZ2V0X3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xHZXRTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfc2VhcmNoX3F1ZXVlX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF9zZWFyY2hfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFNlYXJjaFNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3F1ZXVlX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfd3JpdGVfcXVldWVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfd3JpdGVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFdyaXRlU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgLy8gcmVtb3ZlIHVuZGVmaW5lZCBhdHRyaWJ1dGVzXG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhhdHRycykuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnZhbHVlICE9PSB1bmRlZmluZWQgKSlcbiAgfVxufVxuIl19