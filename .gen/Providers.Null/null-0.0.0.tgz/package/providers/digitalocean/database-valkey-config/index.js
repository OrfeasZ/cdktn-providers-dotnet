"use strict";
// https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config
// generated from terraform resource schema
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseValkeyConfig = void 0;
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config digitalocean_database_valkey_config}
*/
class DatabaseValkeyConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseValkeyConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseValkeyConfig to import
    * @param importFromId The id of the existing DatabaseValkeyConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseValkeyConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_valkey_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config digitalocean_database_valkey_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseValkeyConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_valkey_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._aclChannelsDefault = config.aclChannelsDefault;
        this._clusterId = config.clusterId;
        this._frequentSnapshots = config.frequentSnapshots;
        this._id = config.id;
        this._ioThreads = config.ioThreads;
        this._lfuDecayTime = config.lfuDecayTime;
        this._lfuLogFactor = config.lfuLogFactor;
        this._notifyKeyspaceEvents = config.notifyKeyspaceEvents;
        this._numberOfDatabases = config.numberOfDatabases;
        this._persistence = config.persistence;
        this._pubsubClientOutputBufferLimit = config.pubsubClientOutputBufferLimit;
        this._ssl = config.ssl;
        this._timeout = config.timeout;
        this._valkeyActiveExpireEffort = config.valkeyActiveExpireEffort;
        this._valkeyMaxmemoryPolicy = config.valkeyMaxmemoryPolicy;
    }
    get aclChannelsDefault() {
        return this.getStringAttribute('acl_channels_default');
    }
    set aclChannelsDefault(value) {
        this._aclChannelsDefault = value;
    }
    resetAclChannelsDefault() {
        this._aclChannelsDefault = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get aclChannelsDefaultInput() {
        return this._aclChannelsDefault;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get frequentSnapshots() {
        return this.getBooleanAttribute('frequent_snapshots');
    }
    set frequentSnapshots(value) {
        this._frequentSnapshots = value;
    }
    resetFrequentSnapshots() {
        this._frequentSnapshots = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get frequentSnapshotsInput() {
        return this._frequentSnapshots;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get ioThreads() {
        return this.getNumberAttribute('io_threads');
    }
    set ioThreads(value) {
        this._ioThreads = value;
    }
    resetIoThreads() {
        this._ioThreads = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ioThreadsInput() {
        return this._ioThreads;
    }
    get lfuDecayTime() {
        return this.getNumberAttribute('lfu_decay_time');
    }
    set lfuDecayTime(value) {
        this._lfuDecayTime = value;
    }
    resetLfuDecayTime() {
        this._lfuDecayTime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get lfuDecayTimeInput() {
        return this._lfuDecayTime;
    }
    get lfuLogFactor() {
        return this.getNumberAttribute('lfu_log_factor');
    }
    set lfuLogFactor(value) {
        this._lfuLogFactor = value;
    }
    resetLfuLogFactor() {
        this._lfuLogFactor = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get lfuLogFactorInput() {
        return this._lfuLogFactor;
    }
    get notifyKeyspaceEvents() {
        return this.getStringAttribute('notify_keyspace_events');
    }
    set notifyKeyspaceEvents(value) {
        this._notifyKeyspaceEvents = value;
    }
    resetNotifyKeyspaceEvents() {
        this._notifyKeyspaceEvents = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get notifyKeyspaceEventsInput() {
        return this._notifyKeyspaceEvents;
    }
    get numberOfDatabases() {
        return this.getNumberAttribute('number_of_databases');
    }
    set numberOfDatabases(value) {
        this._numberOfDatabases = value;
    }
    resetNumberOfDatabases() {
        this._numberOfDatabases = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get numberOfDatabasesInput() {
        return this._numberOfDatabases;
    }
    get persistence() {
        return this.getStringAttribute('persistence');
    }
    set persistence(value) {
        this._persistence = value;
    }
    resetPersistence() {
        this._persistence = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get persistenceInput() {
        return this._persistence;
    }
    get pubsubClientOutputBufferLimit() {
        return this.getNumberAttribute('pubsub_client_output_buffer_limit');
    }
    set pubsubClientOutputBufferLimit(value) {
        this._pubsubClientOutputBufferLimit = value;
    }
    resetPubsubClientOutputBufferLimit() {
        this._pubsubClientOutputBufferLimit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pubsubClientOutputBufferLimitInput() {
        return this._pubsubClientOutputBufferLimit;
    }
    get ssl() {
        return this.getBooleanAttribute('ssl');
    }
    set ssl(value) {
        this._ssl = value;
    }
    resetSsl() {
        this._ssl = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sslInput() {
        return this._ssl;
    }
    get timeout() {
        return this.getNumberAttribute('timeout');
    }
    set timeout(value) {
        this._timeout = value;
    }
    resetTimeout() {
        this._timeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get timeoutInput() {
        return this._timeout;
    }
    get valkeyActiveExpireEffort() {
        return this.getNumberAttribute('valkey_active_expire_effort');
    }
    set valkeyActiveExpireEffort(value) {
        this._valkeyActiveExpireEffort = value;
    }
    resetValkeyActiveExpireEffort() {
        this._valkeyActiveExpireEffort = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get valkeyActiveExpireEffortInput() {
        return this._valkeyActiveExpireEffort;
    }
    get valkeyMaxmemoryPolicy() {
        return this.getStringAttribute('valkey_maxmemory_policy');
    }
    set valkeyMaxmemoryPolicy(value) {
        this._valkeyMaxmemoryPolicy = value;
    }
    resetValkeyMaxmemoryPolicy() {
        this._valkeyMaxmemoryPolicy = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get valkeyMaxmemoryPolicyInput() {
        return this._valkeyMaxmemoryPolicy;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            acl_channels_default: cdktn.stringToTerraform(this._aclChannelsDefault),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            frequent_snapshots: cdktn.booleanToTerraform(this._frequentSnapshots),
            id: cdktn.stringToTerraform(this._id),
            io_threads: cdktn.numberToTerraform(this._ioThreads),
            lfu_decay_time: cdktn.numberToTerraform(this._lfuDecayTime),
            lfu_log_factor: cdktn.numberToTerraform(this._lfuLogFactor),
            notify_keyspace_events: cdktn.stringToTerraform(this._notifyKeyspaceEvents),
            number_of_databases: cdktn.numberToTerraform(this._numberOfDatabases),
            persistence: cdktn.stringToTerraform(this._persistence),
            pubsub_client_output_buffer_limit: cdktn.numberToTerraform(this._pubsubClientOutputBufferLimit),
            ssl: cdktn.booleanToTerraform(this._ssl),
            timeout: cdktn.numberToTerraform(this._timeout),
            valkey_active_expire_effort: cdktn.numberToTerraform(this._valkeyActiveExpireEffort),
            valkey_maxmemory_policy: cdktn.stringToTerraform(this._valkeyMaxmemoryPolicy),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            acl_channels_default: {
                value: cdktn.stringToHclTerraform(this._aclChannelsDefault),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            frequent_snapshots: {
                value: cdktn.booleanToHclTerraform(this._frequentSnapshots),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            io_threads: {
                value: cdktn.numberToHclTerraform(this._ioThreads),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            lfu_decay_time: {
                value: cdktn.numberToHclTerraform(this._lfuDecayTime),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            lfu_log_factor: {
                value: cdktn.numberToHclTerraform(this._lfuLogFactor),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            notify_keyspace_events: {
                value: cdktn.stringToHclTerraform(this._notifyKeyspaceEvents),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            number_of_databases: {
                value: cdktn.numberToHclTerraform(this._numberOfDatabases),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            persistence: {
                value: cdktn.stringToHclTerraform(this._persistence),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            pubsub_client_output_buffer_limit: {
                value: cdktn.numberToHclTerraform(this._pubsubClientOutputBufferLimit),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ssl: {
                value: cdktn.booleanToHclTerraform(this._ssl),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            timeout: {
                value: cdktn.numberToHclTerraform(this._timeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            valkey_active_expire_effort: {
                value: cdktn.numberToHclTerraform(this._valkeyActiveExpireEffort),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            valkey_maxmemory_policy: {
                value: cdktn.stringToHclTerraform(this._valkeyMaxmemoryPolicy),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseValkeyConfig = DatabaseValkeyConfig;
// =================
// STATIC PROPERTIES
// =================
DatabaseValkeyConfig.tfResourceType = "digitalocean_database_valkey_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsaUhBQWlIO0FBQ2pILDJDQUEyQzs7O0FBRzNDLCtCQUErQjtBQWtIL0I7O0VBRUU7QUFDRixNQUFhLG9CQUFxQixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPL0QsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLHFDQUFxQyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM3SixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBa0M7UUFDakYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSxxQ0FBcUM7WUFDNUQsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDO1FBQ3JELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUN6QyxJQUFJLENBQUMscUJBQXFCLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixDQUFDO1FBQ3pELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsNkJBQTZCLENBQUM7UUFDM0UsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUMvQixJQUFJLENBQUMseUJBQXlCLEdBQUcsTUFBTSxDQUFDLHdCQUF3QixDQUFDO1FBQ2pFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7SUFDN0QsQ0FBQztJQVFELElBQVcsa0JBQWtCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNELElBQVcsa0JBQWtCLENBQUMsS0FBYTtRQUN6QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO0lBQ25DLENBQUM7SUFDTSx1QkFBdUI7UUFDNUIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLFNBQVMsQ0FBQztJQUN2QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDO0lBQ2xDLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWtDO1FBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFXLEVBQUUsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFDTSxPQUFPO1FBQ1osSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2xCLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNNLGNBQWM7UUFDbkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUM7SUFDOUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBQ0QsSUFBVyxZQUFZLENBQUMsS0FBYTtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBQ00saUJBQWlCO1FBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzVCLENBQUM7SUFJRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBQ0QsSUFBVyxZQUFZLENBQUMsS0FBYTtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBQ00saUJBQWlCO1FBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzVCLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsV0FBVztRQUNwQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBVyxXQUFXLENBQUMsS0FBYTtRQUNsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBQ00sZ0JBQWdCO1FBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDO0lBQ2hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFJRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFDRCxJQUFXLDZCQUE2QixDQUFDLEtBQWE7UUFDcEQsSUFBSSxDQUFDLDhCQUE4QixHQUFHLEtBQUssQ0FBQztJQUM5QyxDQUFDO0lBQ00sa0NBQWtDO1FBQ3ZDLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxTQUFTLENBQUM7SUFDbEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtDQUFrQztRQUMzQyxPQUFPLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztJQUM3QyxDQUFDO0lBSUQsSUFBVyxHQUFHO1FBQ1osT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQVcsR0FBRyxDQUFDLEtBQWtDO1FBQy9DLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLENBQUM7SUFDTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7SUFDeEIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25CLENBQUM7SUFJRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQVcsT0FBTyxDQUFDLEtBQWE7UUFDOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDeEIsQ0FBQztJQUNNLFlBQVk7UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7SUFDNUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUJBQXlCLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN2RSxVQUFVLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDcEQsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNyRSxFQUFFLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDckMsVUFBVSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3BELGNBQWMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUMzRCxjQUFjLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDM0Qsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUMzRSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3JFLFdBQVcsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUN2RCxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO1lBQy9GLEdBQUcsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN4QyxPQUFPLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDL0MsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUNwRix1QkFBdUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1NBQzlFLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCO1FBQy9CLE1BQU0sS0FBSyxHQUFHO1lBQ1osb0JBQW9CLEVBQUU7Z0JBQ3BCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDM0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELEVBQUUsRUFBRTtnQkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxVQUFVLEVBQUU7Z0JBQ1YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dCQUNsRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsY0FBYyxFQUFFO2dCQUNkLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztnQkFDckQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGNBQWMsRUFBRTtnQkFDZCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQ3JELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxzQkFBc0IsRUFBRTtnQkFDdEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzdELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxtQkFBbUIsRUFBRTtnQkFDbkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxXQUFXLEVBQUU7Z0JBQ1gsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNwRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsaUNBQWlDLEVBQUU7Z0JBQ2pDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO2dCQUN0RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsR0FBRyxFQUFFO2dCQUNILEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDN0MsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELE9BQU8sRUFBRTtnQkFDUCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ2hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwyQkFBMkIsRUFBRTtnQkFDM0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7U0FDRixDQUFDO1FBRUYsOEJBQThCO1FBQzlCLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFFLENBQUMsQ0FBQTtJQUM1SCxDQUFDOztBQTFhSCxvREEyYUM7QUF6YUMsb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNwQixvQkFBb0I7QUFDRyxtQ0FBYyxHQUFHLHFDQUFxQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWdcbi8vIGdlbmVyYXRlZCBmcm9tIHRlcnJhZm9ybSByZXNvdXJjZSBzY2hlbWFcblxuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBjZGt0biBmcm9tICdjZGt0bic7XG5cbi8vIENvbmZpZ3VyYXRpb25cblxuZXhwb3J0IGludGVyZmFjZSBEYXRhYmFzZVZhbGtleUNvbmZpZ0NvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybU1ldGFBcmd1bWVudHMge1xuICAvKipcbiAgKiBEZXRlcm1pbmVzIGRlZmF1bHQgcHViL3N1YiBjaGFubmVscycgQUNMIGZvciBuZXcgdXNlcnMgaWYgQUNMIGlzIG5vdCBzdXBwbGllZC4gV2hlbiB0aGlzIG9wdGlvbiBpcyBub3QgZGVmaW5lZCwgYWxsX2NoYW5uZWxzIGlzIGFzc3VtZWQgdG8ga2VlcCBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LiBUaGlzIG9wdGlvbiBkb2Vzbid0IGFmZmVjdCBWYWxrZXkgY29uZmlndXJhdGlvbiBhY2wtcHVic3ViLWRlZmF1bHQuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2FjbF9jaGFubmVsc19kZWZhdWx0IERhdGFiYXNlVmFsa2V5Q29uZmlnI2FjbF9jaGFubmVsc19kZWZhdWx0fVxuICAqL1xuICByZWFkb25seSBhY2xDaGFubmVsc0RlZmF1bHQ/OiBzdHJpbmc7XG4gIC8qKlxuICAqIEEgdW5pcXVlIGlkZW50aWZpZXIgZm9yIHRoZSBkYXRhYmFzZSBjbHVzdGVyLlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNjbHVzdGVyX2lkIERhdGFiYXNlVmFsa2V5Q29uZmlnI2NsdXN0ZXJfaWR9XG4gICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJJZDogc3RyaW5nO1xuICAvKipcbiAgKiBGcmVxdWVudCBSREIgc25hcHNob3RzLiBXaGVuIGVuYWJsZWQsIFZhbGtleSB3aWxsIGNyZWF0ZSBmcmVxdWVudCBsb2NhbCBSREIgc25hcHNob3RzLiBXaGVuIGRpc2FibGVkLCBWYWxrZXkgd2lsbCBvbmx5IHRha2UgUkRCIHNuYXBzaG90cyB3aGVuIGEgYmFja3VwIGlzIGNyZWF0ZWQsIGJhc2VkIG9uIHRoZSBiYWNrdXAgc2NoZWR1bGUuIFRoaXMgc2V0dGluZyBpcyBpZ25vcmVkIHdoZW4gdmFsa2V5X3BlcnNpc3RlbmNlIGlzIHNldCB0byBvZmYuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2ZyZXF1ZW50X3NuYXBzaG90cyBEYXRhYmFzZVZhbGtleUNvbmZpZyNmcmVxdWVudF9zbmFwc2hvdHN9XG4gICovXG4gIHJlYWRvbmx5IGZyZXF1ZW50U25hcHNob3RzPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2lkIERhdGFiYXNlVmFsa2V5Q29uZmlnI2lkfVxuICAqXG4gICogUGxlYXNlIGJlIGF3YXJlIHRoYXQgdGhlIGlkIGZpZWxkIGlzIGF1dG9tYXRpY2FsbHkgYWRkZWQgdG8gYWxsIHJlc291cmNlcyBpbiBUZXJyYWZvcm0gcHJvdmlkZXJzIHVzaW5nIGEgVGVycmFmb3JtIHByb3ZpZGVyIFNESyB2ZXJzaW9uIGJlbG93IDIuXG4gICogSWYgeW91IGV4cGVyaWVuY2UgcHJvYmxlbXMgc2V0dGluZyB0aGlzIHZhbHVlIGl0IG1pZ2h0IG5vdCBiZSBzZXR0YWJsZS4gUGxlYXNlIHRha2UgYSBsb29rIGF0IHRoZSBwcm92aWRlciBkb2N1bWVudGF0aW9uIHRvIGVuc3VyZSBpdCBzaG91bGQgYmUgc2V0dGFibGUuXG4gICovXG4gIHJlYWRvbmx5IGlkPzogc3RyaW5nO1xuICAvKipcbiAgKiBUaGUgbnVtYmVyIG9mIElPIHRocmVhZHMgdXNlZCBieSBWYWxrZXkuIE11c3QgYmUgYmV0d2VlbiAxIGFuZCAzMi5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjaW9fdGhyZWFkcyBEYXRhYmFzZVZhbGtleUNvbmZpZyNpb190aHJlYWRzfVxuICAqL1xuICByZWFkb25seSBpb1RocmVhZHM/OiBudW1iZXI7XG4gIC8qKlxuICAqIFRoZSBkZWNheSB0aW1lIGZvciBWYWxrZXkncyBMRlUgY2FjaGUgZXZpY3Rpb24uIE11c3QgYmUgYmV0d2VlbiAxIGFuZCAxMjAuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2xmdV9kZWNheV90aW1lIERhdGFiYXNlVmFsa2V5Q29uZmlnI2xmdV9kZWNheV90aW1lfVxuICAqL1xuICByZWFkb25seSBsZnVEZWNheVRpbWU/OiBudW1iZXI7XG4gIC8qKlxuICAqIFRoZSBsb2cgZmFjdG9yIGZvciBWYWxrZXkncyBMRlUgKExlYXN0IEZyZXF1ZW50bHkgVXNlZCkgY2FjaGUgZXZpY3Rpb24uIE11c3QgYmUgYmV0d2VlbiAxIGFuZCAxMDAuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2xmdV9sb2dfZmFjdG9yIERhdGFiYXNlVmFsa2V5Q29uZmlnI2xmdV9sb2dfZmFjdG9yfVxuICAqL1xuICByZWFkb25seSBsZnVMb2dGYWN0b3I/OiBudW1iZXI7XG4gIC8qKlxuICAqIFNldCBub3RpZnkta2V5c3BhY2UtZXZlbnRzIG9wdGlvbi4gUmVxdWlyZXMgYXQgbGVhc3QgSyBvciBFIGFuZCBhY2NlcHRzIGFueSBjb21iaW5hdGlvbiBvZiB0aGUgZm9sbG93aW5nIG9wdGlvbnMuIFNldHRpbmcgdGhlIHBhcmFtZXRlciB0byBcIlwiIGRpc2FibGVzIG5vdGlmaWNhdGlvbnMuXG4gICogXG4gICogSyDigJQgS2V5c3BhY2UgZXZlbnRzXG4gICogRSDigJQgS2V5ZXZlbnQgZXZlbnRzXG4gICogZyDigJQgR2VuZXJpYyBjb21tYW5kcyAoZS5nLiBERUwsIEVYUElSRSwgUkVOQU1FLCAuLi4pXG4gICogJCDigJQgU3RyaW5nIGNvbW1hbmRzXG4gICogbCDigJQgTGlzdCBjb21tYW5kc1xuICAqIHMg4oCUIFNldCBjb21tYW5kc1xuICAqIGgg4oCUIEhhc2ggY29tbWFuZHNcbiAgKiB6IOKAlCBTb3J0ZWQgc2V0IGNvbW1hbmRzXG4gICogdCDigJQgU3RyZWFtIGNvbW1hbmRzXG4gICogZCDigJQgTW9kdWxlIGtleSB0eXBlIGV2ZW50c1xuICAqIHgg4oCUIEV4cGlyZWQgZXZlbnRzXG4gICogZSDigJQgRXZpY3RlZCBldmVudHNcbiAgKiBtIOKAlCBLZXkgbWlzcyBldmVudHNcbiAgKiBuIOKAlCBOZXcga2V5IGV2ZW50c1xuICAqIEEg4oCUIEFsaWFzIGZvciBcImckbHNoenR4ZWRcIlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNub3RpZnlfa2V5c3BhY2VfZXZlbnRzIERhdGFiYXNlVmFsa2V5Q29uZmlnI25vdGlmeV9rZXlzcGFjZV9ldmVudHN9XG4gICovXG4gIHJlYWRvbmx5IG5vdGlmeUtleXNwYWNlRXZlbnRzPzogc3RyaW5nO1xuICAvKipcbiAgKiBUaGUgbnVtYmVyIG9mIGxvZ2ljYWwgZGF0YWJhc2VzIGluIHRoZSBWYWxrZXkgY2x1c3Rlci4gTXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDEyOC5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjbnVtYmVyX29mX2RhdGFiYXNlcyBEYXRhYmFzZVZhbGtleUNvbmZpZyNudW1iZXJfb2ZfZGF0YWJhc2VzfVxuICAqL1xuICByZWFkb25seSBudW1iZXJPZkRhdGFiYXNlcz86IG51bWJlcjtcbiAgLyoqXG4gICogV2hlbiBwZXJzaXN0ZW5jZSBpcyAncmRiJywgVmFsa2V5IGRvZXMgUkRCIGR1bXBzIGVhY2ggMTAgbWludXRlcyBpZiBhbnkga2V5IGlzIGNoYW5nZWQuIEFsc28gUkRCIGR1bXBzIGFyZSBkb25lIGFjY29yZGluZyB0byBiYWNrdXAgc2NoZWR1bGUgZm9yIGJhY2t1cCBwdXJwb3Nlcy4gV2hlbiBwZXJzaXN0ZW5jZSBpcyAnb2ZmJywgbm8gUkRCIGR1bXBzIGFuZCBiYWNrdXBzIGFyZSBkb25lLCBzbyBkYXRhIGNhbiBiZSBsb3N0IGF0IGFueSBtb21lbnQgaWYgc2VydmljZSBpcyByZXN0YXJ0ZWQgZm9yIGFueSByZWFzb24sIG9yIGlmIHNlcnZpY2UgaXMgcG93ZXJlZCBvZmYuIEFsc28gc2VydmljZSBjYW4ndCBiZSBmb3JrZWQuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI3BlcnNpc3RlbmNlIERhdGFiYXNlVmFsa2V5Q29uZmlnI3BlcnNpc3RlbmNlfVxuICAqL1xuICByZWFkb25seSBwZXJzaXN0ZW5jZT86IHN0cmluZztcbiAgLyoqXG4gICogU2V0IG91dHB1dCBidWZmZXIgbGltaXQgZm9yIHB1YiAvIHN1YiBjbGllbnRzIGluIE1CLiBUaGUgdmFsdWUgaXMgdGhlIGhhcmQgbGltaXQsIHRoZSBzb2Z0IGxpbWl0IGlzIDEvNCBvZiB0aGUgaGFyZCBsaW1pdC4gV2hlbiBzZXR0aW5nIHRoZSBsaW1pdCwgYmUgbWluZGZ1bCBvZiB0aGUgYXZhaWxhYmxlIG1lbW9yeSBpbiB0aGUgc2VsZWN0ZWQgc2VydmljZSBwbGFuLlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNwdWJzdWJfY2xpZW50X291dHB1dF9idWZmZXJfbGltaXQgRGF0YWJhc2VWYWxrZXlDb25maWcjcHVic3ViX2NsaWVudF9vdXRwdXRfYnVmZmVyX2xpbWl0fVxuICAqL1xuICByZWFkb25seSBwdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdD86IG51bWJlcjtcbiAgLyoqXG4gICogV2hldGhlciB0byBlbmFibGUgU1NML1RMUyBmb3IgY29ubmVjdGlvbnMgdG8gdGhlIFZhbGtleSBjbHVzdGVyLlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNzc2wgRGF0YWJhc2VWYWxrZXlDb25maWcjc3NsfVxuICAqL1xuICByZWFkb25seSBzc2w/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIFRoZSB0aW1lb3V0IChpbiBzZWNvbmRzKSBmb3IgVmFsa2V5IGNsaWVudCBjb25uZWN0aW9ucy5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjdGltZW91dCBEYXRhYmFzZVZhbGtleUNvbmZpZyN0aW1lb3V0fVxuICAqL1xuICByZWFkb25seSB0aW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBBY3RpdmUgZXhwaXJlIGVmZm9ydC4gVmFsa2V5IHJlY2xhaW1zIGV4cGlyZWQga2V5cyBib3RoIHdoZW4gYWNjZXNzZWQgYW5kIGluIHRoZSBiYWNrZ3JvdW5kLiBUaGUgYmFja2dyb3VuZCBwcm9jZXNzIHNjYW5zIGZvciBleHBpcmVkIGtleXMgdG8gZnJlZSBtZW1vcnkuIEluY3JlYXNpbmcgdGhlIGFjdGl2ZS1leHBpcmUtZWZmb3J0IHNldHRpbmcgKGRlZmF1bHQgMSwgbWF4IDEwKSB1c2VzIG1vcmUgQ1BVIHRvIHJlY2xhaW0gZXhwaXJlZCBrZXlzIGZhc3RlciwgcmVkdWNpbmcgbWVtb3J5IHVzYWdlIGJ1dCBwb3RlbnRpYWxseSBpbmNyZWFzaW5nIGxhdGVuY3kuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI3ZhbGtleV9hY3RpdmVfZXhwaXJlX2VmZm9ydCBEYXRhYmFzZVZhbGtleUNvbmZpZyN2YWxrZXlfYWN0aXZlX2V4cGlyZV9lZmZvcnR9XG4gICovXG4gIHJlYWRvbmx5IHZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydD86IG51bWJlcjtcbiAgLyoqXG4gICogQSBzdHJpbmcgc3BlY2lmeWluZyB0aGUgZGVzaXJlZCBldmljdGlvbiBwb2xpY3kgZm9yIGEgQ2FjaGluZyBvciBWYWxrZXkgY2x1c3Rlci5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjdmFsa2V5X21heG1lbW9yeV9wb2xpY3kgRGF0YWJhc2VWYWxrZXlDb25maWcjdmFsa2V5X21heG1lbW9yeV9wb2xpY3l9XG4gICovXG4gIHJlYWRvbmx5IHZhbGtleU1heG1lbW9yeVBvbGljeT86IHN0cmluZztcbn1cblxuLyoqXG4qIFJlcHJlc2VudHMgYSB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3ZhbGtleV9jb25maWd9XG4qL1xuZXhwb3J0IGNsYXNzIERhdGFiYXNlVmFsa2V5Q29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtUmVzb3VyY2Uge1xuXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIC8vIFNUQVRJQyBQUk9QRVJUSUVTXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgdGZSZXNvdXJjZVR5cGUgPSBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV92YWxrZXlfY29uZmlnXCI7XG5cbiAgLy8gPT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIE1ldGhvZHNcbiAgLy8gPT09PT09PT09PT09PT1cbiAgLyoqXG4gICogR2VuZXJhdGVzIENES1ROIGNvZGUgZm9yIGltcG9ydGluZyBhIERhdGFiYXNlVmFsa2V5Q29uZmlnIHJlc291cmNlIHVwb24gcnVubmluZyBcImNka3RuIHBsYW4gPHN0YWNrLW5hbWU+XCJcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpbXBvcnRUb0lkIFRoZSBjb25zdHJ1Y3QgaWQgdXNlZCBpbiB0aGUgZ2VuZXJhdGVkIGNvbmZpZyBmb3IgdGhlIERhdGFiYXNlVmFsa2V5Q29uZmlnIHRvIGltcG9ydFxuICAqIEBwYXJhbSBpbXBvcnRGcm9tSWQgVGhlIGlkIG9mIHRoZSBleGlzdGluZyBEYXRhYmFzZVZhbGtleUNvbmZpZyB0aGF0IHNob3VsZCBiZSBpbXBvcnRlZC4gUmVmZXIgdG8gdGhlIHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNpbXBvcnQgaW1wb3J0IHNlY3Rpb259IGluIHRoZSBkb2N1bWVudGF0aW9uIG9mIHRoaXMgcmVzb3VyY2UgZm9yIHRoZSBpZCB0byB1c2VcbiAgKiBAcGFyYW0gcHJvdmlkZXI/IE9wdGlvbmFsIGluc3RhbmNlIG9mIHRoZSBwcm92aWRlciB3aGVyZSB0aGUgRGF0YWJhc2VWYWxrZXlDb25maWcgdG8gaW1wb3J0IGlzIGZvdW5kXG4gICovXG4gIHB1YmxpYyBzdGF0aWMgZ2VuZXJhdGVDb25maWdGb3JJbXBvcnQoc2NvcGU6IENvbnN0cnVjdCwgaW1wb3J0VG9JZDogc3RyaW5nLCBpbXBvcnRGcm9tSWQ6IHN0cmluZywgcHJvdmlkZXI/OiBjZGt0bi5UZXJyYWZvcm1Qcm92aWRlcikge1xuICAgICAgICByZXR1cm4gbmV3IGNka3RuLkltcG9ydGFibGVSZXNvdXJjZShzY29wZSwgaW1wb3J0VG9JZCwgeyB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6IFwiZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3ZhbGtleV9jb25maWdcIiwgaW1wb3J0SWQ6IGltcG9ydEZyb21JZCwgcHJvdmlkZXIgfSk7XG4gICAgICB9XG5cbiAgLy8gPT09PT09PT09PT1cbiAgLy8gSU5JVElBTElaRVJcbiAgLy8gPT09PT09PT09PT1cblxuICAvKipcbiAgKiBDcmVhdGUgYSBuZXcge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnIGRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV92YWxrZXlfY29uZmlnfSBSZXNvdXJjZVxuICAqXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaWQgVGhlIHNjb3BlZCBjb25zdHJ1Y3QgSUQuIE11c3QgYmUgdW5pcXVlIGFtb25nc3Qgc2libGluZ3MgaW4gdGhlIHNhbWUgc2NvcGVcbiAgKiBAcGFyYW0gb3B0aW9ucyBEYXRhYmFzZVZhbGtleUNvbmZpZ0NvbmZpZ1xuICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgY29uZmlnOiBEYXRhYmFzZVZhbGtleUNvbmZpZ0NvbmZpZykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiAnZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3ZhbGtleV9jb25maWcnLFxuICAgICAgdGVycmFmb3JtR2VuZXJhdG9yTWV0YWRhdGE6IHtcbiAgICAgICAgcHJvdmlkZXJOYW1lOiAnZGlnaXRhbG9jZWFuJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uOiAnMi44Ny4wJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uQ29uc3RyYWludDogJzIuODcuMCdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcjogY29uZmlnLnByb3ZpZGVyLFxuICAgICAgZGVwZW5kc09uOiBjb25maWcuZGVwZW5kc09uLFxuICAgICAgY291bnQ6IGNvbmZpZy5jb3VudCxcbiAgICAgIGxpZmVjeWNsZTogY29uZmlnLmxpZmVjeWNsZSxcbiAgICAgIHByb3Zpc2lvbmVyczogY29uZmlnLnByb3Zpc2lvbmVycyxcbiAgICAgIGNvbm5lY3Rpb246IGNvbmZpZy5jb25uZWN0aW9uLFxuICAgICAgZm9yRWFjaDogY29uZmlnLmZvckVhY2hcbiAgICB9KTtcbiAgICB0aGlzLl9hY2xDaGFubmVsc0RlZmF1bHQgPSBjb25maWcuYWNsQ2hhbm5lbHNEZWZhdWx0O1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IGNvbmZpZy5jbHVzdGVySWQ7XG4gICAgdGhpcy5fZnJlcXVlbnRTbmFwc2hvdHMgPSBjb25maWcuZnJlcXVlbnRTbmFwc2hvdHM7XG4gICAgdGhpcy5faWQgPSBjb25maWcuaWQ7XG4gICAgdGhpcy5faW9UaHJlYWRzID0gY29uZmlnLmlvVGhyZWFkcztcbiAgICB0aGlzLl9sZnVEZWNheVRpbWUgPSBjb25maWcubGZ1RGVjYXlUaW1lO1xuICAgIHRoaXMuX2xmdUxvZ0ZhY3RvciA9IGNvbmZpZy5sZnVMb2dGYWN0b3I7XG4gICAgdGhpcy5fbm90aWZ5S2V5c3BhY2VFdmVudHMgPSBjb25maWcubm90aWZ5S2V5c3BhY2VFdmVudHM7XG4gICAgdGhpcy5fbnVtYmVyT2ZEYXRhYmFzZXMgPSBjb25maWcubnVtYmVyT2ZEYXRhYmFzZXM7XG4gICAgdGhpcy5fcGVyc2lzdGVuY2UgPSBjb25maWcucGVyc2lzdGVuY2U7XG4gICAgdGhpcy5fcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQgPSBjb25maWcucHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQ7XG4gICAgdGhpcy5fc3NsID0gY29uZmlnLnNzbDtcbiAgICB0aGlzLl90aW1lb3V0ID0gY29uZmlnLnRpbWVvdXQ7XG4gICAgdGhpcy5fdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0ID0gY29uZmlnLnZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydDtcbiAgICB0aGlzLl92YWxrZXlNYXhtZW1vcnlQb2xpY3kgPSBjb25maWcudmFsa2V5TWF4bWVtb3J5UG9saWN5O1xuICB9XG5cbiAgLy8gPT09PT09PT09PVxuICAvLyBBVFRSSUJVVEVTXG4gIC8vID09PT09PT09PT1cblxuICAvLyBhY2xfY2hhbm5lbHNfZGVmYXVsdCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2FjbENoYW5uZWxzRGVmYXVsdD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgYWNsQ2hhbm5lbHNEZWZhdWx0KCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnYWNsX2NoYW5uZWxzX2RlZmF1bHQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGFjbENoYW5uZWxzRGVmYXVsdCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fYWNsQ2hhbm5lbHNEZWZhdWx0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QWNsQ2hhbm5lbHNEZWZhdWx0KCkge1xuICAgIHRoaXMuX2FjbENoYW5uZWxzRGVmYXVsdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYWNsQ2hhbm5lbHNEZWZhdWx0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FjbENoYW5uZWxzRGVmYXVsdDtcbiAgfVxuXG4gIC8vIGNsdXN0ZXJfaWQgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiBmYWxzZSwgcmVxdWlyZWQ6IHRydWVcbiAgcHJpdmF0ZSBfY2x1c3RlcklkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBjbHVzdGVySWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdjbHVzdGVyX2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBjbHVzdGVySWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IHZhbHVlO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVySWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3RlcklkO1xuICB9XG5cbiAgLy8gZnJlcXVlbnRfc25hcHNob3RzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZnJlcXVlbnRTbmFwc2hvdHM/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IGZyZXF1ZW50U25hcHNob3RzKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2ZyZXF1ZW50X3NuYXBzaG90cycpO1xuICB9XG4gIHB1YmxpYyBzZXQgZnJlcXVlbnRTbmFwc2hvdHModmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2ZyZXF1ZW50U25hcHNob3RzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0RnJlcXVlbnRTbmFwc2hvdHMoKSB7XG4gICAgdGhpcy5fZnJlcXVlbnRTbmFwc2hvdHMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGZyZXF1ZW50U25hcHNob3RzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2ZyZXF1ZW50U25hcHNob3RzO1xuICB9XG5cbiAgLy8gaWQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pZD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdpZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2lkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SWQoKSB7XG4gICAgdGhpcy5faWQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lkO1xuICB9XG5cbiAgLy8gaW9fdGhyZWFkcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lvVGhyZWFkcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW9UaHJlYWRzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW9fdGhyZWFkcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW9UaHJlYWRzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pb1RocmVhZHMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJb1RocmVhZHMoKSB7XG4gICAgdGhpcy5faW9UaHJlYWRzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpb1RocmVhZHNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW9UaHJlYWRzO1xuICB9XG5cbiAgLy8gbGZ1X2RlY2F5X3RpbWUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sZnVEZWNheVRpbWU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGxmdURlY2F5VGltZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xmdV9kZWNheV90aW1lJyk7XG4gIH1cbiAgcHVibGljIHNldCBsZnVEZWNheVRpbWUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2xmdURlY2F5VGltZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExmdURlY2F5VGltZSgpIHtcbiAgICB0aGlzLl9sZnVEZWNheVRpbWUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxmdURlY2F5VGltZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sZnVEZWNheVRpbWU7XG4gIH1cblxuICAvLyBsZnVfbG9nX2ZhY3RvciAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xmdUxvZ0ZhY3Rvcj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbGZ1TG9nRmFjdG9yKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbGZ1X2xvZ19mYWN0b3InKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxmdUxvZ0ZhY3Rvcih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbGZ1TG9nRmFjdG9yID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TGZ1TG9nRmFjdG9yKCkge1xuICAgIHRoaXMuX2xmdUxvZ0ZhY3RvciA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbGZ1TG9nRmFjdG9ySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xmdUxvZ0ZhY3RvcjtcbiAgfVxuXG4gIC8vIG5vdGlmeV9rZXlzcGFjZV9ldmVudHMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9ub3RpZnlLZXlzcGFjZUV2ZW50cz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgbm90aWZ5S2V5c3BhY2VFdmVudHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdub3RpZnlfa2V5c3BhY2VfZXZlbnRzJyk7XG4gIH1cbiAgcHVibGljIHNldCBub3RpZnlLZXlzcGFjZUV2ZW50cyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fbm90aWZ5S2V5c3BhY2VFdmVudHMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXROb3RpZnlLZXlzcGFjZUV2ZW50cygpIHtcbiAgICB0aGlzLl9ub3RpZnlLZXlzcGFjZUV2ZW50cyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbm90aWZ5S2V5c3BhY2VFdmVudHNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbm90aWZ5S2V5c3BhY2VFdmVudHM7XG4gIH1cblxuICAvLyBudW1iZXJfb2ZfZGF0YWJhc2VzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbnVtYmVyT2ZEYXRhYmFzZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG51bWJlck9mRGF0YWJhc2VzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbnVtYmVyX29mX2RhdGFiYXNlcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbnVtYmVyT2ZEYXRhYmFzZXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX251bWJlck9mRGF0YWJhc2VzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TnVtYmVyT2ZEYXRhYmFzZXMoKSB7XG4gICAgdGhpcy5fbnVtYmVyT2ZEYXRhYmFzZXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG51bWJlck9mRGF0YWJhc2VzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX251bWJlck9mRGF0YWJhc2VzO1xuICB9XG5cbiAgLy8gcGVyc2lzdGVuY2UgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9wZXJzaXN0ZW5jZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgcGVyc2lzdGVuY2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdwZXJzaXN0ZW5jZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgcGVyc2lzdGVuY2UodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3BlcnNpc3RlbmNlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0UGVyc2lzdGVuY2UoKSB7XG4gICAgdGhpcy5fcGVyc2lzdGVuY2UgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHBlcnNpc3RlbmNlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BlcnNpc3RlbmNlO1xuICB9XG5cbiAgLy8gcHVic3ViX2NsaWVudF9vdXRwdXRfYnVmZmVyX2xpbWl0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHB1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgncHVic3ViX2NsaWVudF9vdXRwdXRfYnVmZmVyX2xpbWl0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBwdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdCgpIHtcbiAgICB0aGlzLl9wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQ7XG4gIH1cblxuICAvLyBzc2wgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9zc2w/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IHNzbCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdzc2wnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNzbCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fc3NsID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U3NsKCkge1xuICAgIHRoaXMuX3NzbCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgc3NsSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NzbDtcbiAgfVxuXG4gIC8vIHRpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGltZW91dCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRpbWVvdXQoKSB7XG4gICAgdGhpcy5fdGltZW91dCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aW1lb3V0O1xuICB9XG5cbiAgLy8gdmFsa2V5X2FjdGl2ZV9leHBpcmVfZWZmb3J0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB2YWxrZXlBY3RpdmVFeHBpcmVFZmZvcnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd2YWxrZXlfYWN0aXZlX2V4cGlyZV9lZmZvcnQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0KCkge1xuICAgIHRoaXMuX3ZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydDtcbiAgfVxuXG4gIC8vIHZhbGtleV9tYXhtZW1vcnlfcG9saWN5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdmFsa2V5TWF4bWVtb3J5UG9saWN5Pzogc3RyaW5nOyBcbiAgcHVibGljIGdldCB2YWxrZXlNYXhtZW1vcnlQb2xpY3koKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCd2YWxrZXlfbWF4bWVtb3J5X3BvbGljeScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdmFsa2V5TWF4bWVtb3J5UG9saWN5KHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl92YWxrZXlNYXhtZW1vcnlQb2xpY3kgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRWYWxrZXlNYXhtZW1vcnlQb2xpY3koKSB7XG4gICAgdGhpcy5fdmFsa2V5TWF4bWVtb3J5UG9saWN5ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB2YWxrZXlNYXhtZW1vcnlQb2xpY3lJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdmFsa2V5TWF4bWVtb3J5UG9saWN5O1xuICB9XG5cbiAgLy8gPT09PT09PT09XG4gIC8vIFNZTlRIRVNJU1xuICAvLyA9PT09PT09PT1cblxuICBwcm90ZWN0ZWQgc3ludGhlc2l6ZUF0dHJpYnV0ZXMoKTogeyBbbmFtZTogc3RyaW5nXTogYW55IH0ge1xuICAgIHJldHVybiB7XG4gICAgICBhY2xfY2hhbm5lbHNfZGVmYXVsdDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fYWNsQ2hhbm5lbHNEZWZhdWx0KSxcbiAgICAgIGNsdXN0ZXJfaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICBmcmVxdWVudF9zbmFwc2hvdHM6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9mcmVxdWVudFNuYXBzaG90cyksXG4gICAgICBpZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgaW9fdGhyZWFkczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW9UaHJlYWRzKSxcbiAgICAgIGxmdV9kZWNheV90aW1lOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9sZnVEZWNheVRpbWUpLFxuICAgICAgbGZ1X2xvZ19mYWN0b3I6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2xmdUxvZ0ZhY3RvciksXG4gICAgICBub3RpZnlfa2V5c3BhY2VfZXZlbnRzOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9ub3RpZnlLZXlzcGFjZUV2ZW50cyksXG4gICAgICBudW1iZXJfb2ZfZGF0YWJhc2VzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9udW1iZXJPZkRhdGFiYXNlcyksXG4gICAgICBwZXJzaXN0ZW5jZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fcGVyc2lzdGVuY2UpLFxuICAgICAgcHVic3ViX2NsaWVudF9vdXRwdXRfYnVmZmVyX2xpbWl0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdCksXG4gICAgICBzc2w6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9zc2wpLFxuICAgICAgdGltZW91dDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGltZW91dCksXG4gICAgICB2YWxrZXlfYWN0aXZlX2V4cGlyZV9lZmZvcnQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3ZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydCksXG4gICAgICB2YWxrZXlfbWF4bWVtb3J5X3BvbGljeTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fdmFsa2V5TWF4bWVtb3J5UG9saWN5KSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVIY2xBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICBjb25zdCBhdHRycyA9IHtcbiAgICAgIGFjbF9jaGFubmVsc19kZWZhdWx0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9hY2xDaGFubmVsc0RlZmF1bHQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBjbHVzdGVyX2lkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9jbHVzdGVySWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBmcmVxdWVudF9zbmFwc2hvdHM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9mcmVxdWVudFNuYXBzaG90cyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBpZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBpb190aHJlYWRzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pb1RocmVhZHMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBsZnVfZGVjYXlfdGltZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbGZ1RGVjYXlUaW1lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbGZ1X2xvZ19mYWN0b3I6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2xmdUxvZ0ZhY3RvciksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG5vdGlmeV9rZXlzcGFjZV9ldmVudHM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX25vdGlmeUtleXNwYWNlRXZlbnRzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbnVtYmVyX29mX2RhdGFiYXNlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbnVtYmVyT2ZEYXRhYmFzZXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBwZXJzaXN0ZW5jZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fcGVyc2lzdGVuY2UpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBwdWJzdWJfY2xpZW50X291dHB1dF9idWZmZXJfbGltaXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3B1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgc3NsOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fc3NsKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIHRpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RpbWVvdXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB2YWxrZXlfYWN0aXZlX2V4cGlyZV9lZmZvcnQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3ZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHZhbGtleV9tYXhtZW1vcnlfcG9saWN5OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl92YWxrZXlNYXhtZW1vcnlQb2xpY3kpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIC8vIHJlbW92ZSB1bmRlZmluZWQgYXR0cmlidXRlc1xuICAgIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoYXR0cnMpLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS52YWx1ZSAhPT0gdW5kZWZpbmVkICkpXG4gIH1cbn1cbiJdfQ==