import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudLoadBalancerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancer#id DataHcloudLoadBalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancer#name DataHcloudLoadBalancer#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancer#with_selector DataHcloudLoadBalancer#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudLoadBalancerAlgorithm {
}
export declare function dataHcloudLoadBalancerAlgorithmToTerraform(struct?: DataHcloudLoadBalancerAlgorithm): any;
export declare function dataHcloudLoadBalancerAlgorithmToHclTerraform(struct?: DataHcloudLoadBalancerAlgorithm): any;
export declare class DataHcloudLoadBalancerAlgorithmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerAlgorithm | undefined;
    set internalValue(value: DataHcloudLoadBalancerAlgorithm | undefined);
    get type(): string;
}
export declare class DataHcloudLoadBalancerAlgorithmList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerAlgorithmOutputReference;
}
export interface DataHcloudLoadBalancerServiceHealthCheckHttp {
}
export declare function dataHcloudLoadBalancerServiceHealthCheckHttpToTerraform(struct?: DataHcloudLoadBalancerServiceHealthCheckHttp): any;
export declare function dataHcloudLoadBalancerServiceHealthCheckHttpToHclTerraform(struct?: DataHcloudLoadBalancerServiceHealthCheckHttp): any;
export declare class DataHcloudLoadBalancerServiceHealthCheckHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerServiceHealthCheckHttp | undefined;
    set internalValue(value: DataHcloudLoadBalancerServiceHealthCheckHttp | undefined);
    get domain(): string;
    get path(): string;
    get response(): string;
    get statusCodes(): number[];
    get tls(): cdktn.IResolvable;
}
export declare class DataHcloudLoadBalancerServiceHealthCheckHttpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerServiceHealthCheckHttpOutputReference;
}
export interface DataHcloudLoadBalancerServiceHealthCheck {
}
export declare function dataHcloudLoadBalancerServiceHealthCheckToTerraform(struct?: DataHcloudLoadBalancerServiceHealthCheck): any;
export declare function dataHcloudLoadBalancerServiceHealthCheckToHclTerraform(struct?: DataHcloudLoadBalancerServiceHealthCheck): any;
export declare class DataHcloudLoadBalancerServiceHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerServiceHealthCheck | undefined;
    set internalValue(value: DataHcloudLoadBalancerServiceHealthCheck | undefined);
    private _http;
    get http(): DataHcloudLoadBalancerServiceHealthCheckHttpList;
    get interval(): number;
    get port(): number;
    get protocol(): string;
    get retries(): number;
    get timeout(): number;
}
export declare class DataHcloudLoadBalancerServiceHealthCheckList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerServiceHealthCheckOutputReference;
}
export interface DataHcloudLoadBalancerServiceHttp {
}
export declare function dataHcloudLoadBalancerServiceHttpToTerraform(struct?: DataHcloudLoadBalancerServiceHttp): any;
export declare function dataHcloudLoadBalancerServiceHttpToHclTerraform(struct?: DataHcloudLoadBalancerServiceHttp): any;
export declare class DataHcloudLoadBalancerServiceHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerServiceHttp | undefined;
    set internalValue(value: DataHcloudLoadBalancerServiceHttp | undefined);
    get certificates(): string[];
    get cookieLifetime(): number;
    get cookieName(): string;
    get redirectHttp(): cdktn.IResolvable;
    get stickySessions(): cdktn.IResolvable;
    get timeoutIdle(): number;
}
export declare class DataHcloudLoadBalancerServiceHttpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerServiceHttpOutputReference;
}
export interface DataHcloudLoadBalancerService {
}
export declare function dataHcloudLoadBalancerServiceToTerraform(struct?: DataHcloudLoadBalancerService): any;
export declare function dataHcloudLoadBalancerServiceToHclTerraform(struct?: DataHcloudLoadBalancerService): any;
export declare class DataHcloudLoadBalancerServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerService | undefined;
    set internalValue(value: DataHcloudLoadBalancerService | undefined);
    get destinationPort(): number;
    private _healthCheck;
    get healthCheck(): DataHcloudLoadBalancerServiceHealthCheckList;
    private _http;
    get http(): DataHcloudLoadBalancerServiceHttpList;
    get listenPort(): number;
    get protocol(): string;
    get proxyprotocol(): cdktn.IResolvable;
}
export declare class DataHcloudLoadBalancerServiceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerServiceOutputReference;
}
export interface DataHcloudLoadBalancerTarget {
}
export declare function dataHcloudLoadBalancerTargetToTerraform(struct?: DataHcloudLoadBalancerTarget): any;
export declare function dataHcloudLoadBalancerTargetToHclTerraform(struct?: DataHcloudLoadBalancerTarget): any;
export declare class DataHcloudLoadBalancerTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerTarget | undefined;
    set internalValue(value: DataHcloudLoadBalancerTarget | undefined);
    get labelSelector(): string;
    get serverId(): number;
    get type(): string;
}
export declare class DataHcloudLoadBalancerTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerTargetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancer hcloud_load_balancer}
*/
export declare class DataHcloudLoadBalancer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_load_balancer";
    /**
    * Generates CDKTN code for importing a DataHcloudLoadBalancer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudLoadBalancer to import
    * @param importFromId The id of the existing DataHcloudLoadBalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudLoadBalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancer hcloud_load_balancer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudLoadBalancerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudLoadBalancerConfig);
    private _algorithm;
    get algorithm(): DataHcloudLoadBalancerAlgorithmList;
    get deleteProtection(): cdktn.IResolvable;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get ipv4(): string;
    get ipv6(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get loadBalancerType(): string;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get networkId(): number;
    get networkIp(): string;
    get networkZone(): string;
    private _service;
    get service(): DataHcloudLoadBalancerServiceList;
    private _target;
    get target(): DataHcloudLoadBalancerTargetList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
