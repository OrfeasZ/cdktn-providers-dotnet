import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudServerTypesConfig extends cdktn.TerraformMetaArguments {
}
export interface DataHcloudServerTypesServerTypesLocations {
}
export declare function dataHcloudServerTypesServerTypesLocationsToTerraform(struct?: DataHcloudServerTypesServerTypesLocations): any;
export declare function dataHcloudServerTypesServerTypesLocationsToHclTerraform(struct?: DataHcloudServerTypesServerTypesLocations): any;
export declare class DataHcloudServerTypesServerTypesLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudServerTypesServerTypesLocations | undefined;
    set internalValue(value: DataHcloudServerTypesServerTypesLocations | undefined);
    get available(): cdktn.IResolvable;
    get deprecationAnnounced(): string;
    get id(): number;
    get isDeprecated(): cdktn.IResolvable;
    get name(): string;
    get recommended(): cdktn.IResolvable;
    get unavailableAfter(): string;
}
export declare class DataHcloudServerTypesServerTypesLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudServerTypesServerTypesLocationsOutputReference;
}
export interface DataHcloudServerTypesServerTypes {
}
export declare function dataHcloudServerTypesServerTypesToTerraform(struct?: DataHcloudServerTypesServerTypes): any;
export declare function dataHcloudServerTypesServerTypesToHclTerraform(struct?: DataHcloudServerTypesServerTypes): any;
export declare class DataHcloudServerTypesServerTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudServerTypesServerTypes | undefined;
    set internalValue(value: DataHcloudServerTypesServerTypes | undefined);
    get architecture(): string;
    get category(): string;
    get cores(): number;
    get cpuType(): string;
    get deprecationAnnounced(): string;
    get description(): string;
    get disk(): number;
    get id(): number;
    get includedTraffic(): number;
    get isDeprecated(): cdktn.IResolvable;
    private _locations;
    get locations(): DataHcloudServerTypesServerTypesLocationsList;
    get memory(): number;
    get name(): string;
    get storageType(): string;
    get unavailableAfter(): string;
}
export declare class DataHcloudServerTypesServerTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudServerTypesServerTypesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server_types hcloud_server_types}
*/
export declare class DataHcloudServerTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_server_types";
    /**
    * Generates CDKTN code for importing a DataHcloudServerTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudServerTypes to import
    * @param importFromId The id of the existing DataHcloudServerTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudServerTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server_types hcloud_server_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudServerTypesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudServerTypesConfig);
    get descriptions(): string[];
    get id(): string;
    get names(): string[];
    get serverTypeIds(): string[];
    private _serverTypes;
    get serverTypes(): DataHcloudServerTypesServerTypesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
