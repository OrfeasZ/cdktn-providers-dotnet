import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudVolumesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/volumes#id DataHcloudVolumes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/volumes#with_selector DataHcloudVolumes#with_selector}
    */
    readonly withSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/volumes#with_status DataHcloudVolumes#with_status}
    */
    readonly withStatus?: string[];
}
export interface DataHcloudVolumesVolumes {
}
export declare function dataHcloudVolumesVolumesToTerraform(struct?: DataHcloudVolumesVolumes): any;
export declare function dataHcloudVolumesVolumesToHclTerraform(struct?: DataHcloudVolumesVolumes): any;
export declare class DataHcloudVolumesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudVolumesVolumes | undefined;
    set internalValue(value: DataHcloudVolumesVolumes | undefined);
    get deleteProtection(): cdktn.IResolvable;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get linuxDevice(): string;
    get location(): string;
    get name(): string;
    get serverId(): number;
    get size(): number;
}
export declare class DataHcloudVolumesVolumesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudVolumesVolumesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/volumes hcloud_volumes}
*/
export declare class DataHcloudVolumes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_volumes";
    /**
    * Generates CDKTN code for importing a DataHcloudVolumes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudVolumes to import
    * @param importFromId The id of the existing DataHcloudVolumes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/volumes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudVolumes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/volumes hcloud_volumes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudVolumesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudVolumesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _volumes;
    get volumes(): DataHcloudVolumesVolumesList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _withStatus?;
    get withStatus(): string[];
    set withStatus(value: string[]);
    resetWithStatus(): void;
    get withStatusInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
