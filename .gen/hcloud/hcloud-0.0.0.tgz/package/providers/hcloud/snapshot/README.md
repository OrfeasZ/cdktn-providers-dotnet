# `hcloud_snapshot`

Refer to the Terraform Registry for docs: [`hcloud_snapshot`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/snapshot).
