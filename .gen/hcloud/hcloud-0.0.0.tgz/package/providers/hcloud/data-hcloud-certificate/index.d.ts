import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificate#id DataHcloudCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificate#name DataHcloudCertificate#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificate#with_selector DataHcloudCertificate#with_selector}
    */
    readonly withSelector?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificate hcloud_certificate}
*/
export declare class DataHcloudCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_certificate";
    /**
    * Generates CDKTN code for importing a DataHcloudCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudCertificate to import
    * @param importFromId The id of the existing DataHcloudCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificate hcloud_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudCertificateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudCertificateConfig);
    get certificate(): string;
    get created(): string;
    get domainNames(): string[];
    get fingerprint(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get notValidAfter(): string;
    get notValidBefore(): string;
    get type(): string;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
