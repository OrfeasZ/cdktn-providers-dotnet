import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudPlacementGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/placement_groups#id DataHcloudPlacementGroups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/placement_groups#most_recent DataHcloudPlacementGroups#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/placement_groups#with_selector DataHcloudPlacementGroups#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudPlacementGroupsPlacementGroups {
}
export declare function dataHcloudPlacementGroupsPlacementGroupsToTerraform(struct?: DataHcloudPlacementGroupsPlacementGroups): any;
export declare function dataHcloudPlacementGroupsPlacementGroupsToHclTerraform(struct?: DataHcloudPlacementGroupsPlacementGroups): any;
export declare class DataHcloudPlacementGroupsPlacementGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudPlacementGroupsPlacementGroups | undefined;
    set internalValue(value: DataHcloudPlacementGroupsPlacementGroups | undefined);
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get servers(): number[];
    get type(): string;
}
export declare class DataHcloudPlacementGroupsPlacementGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudPlacementGroupsPlacementGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/placement_groups hcloud_placement_groups}
*/
export declare class DataHcloudPlacementGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_placement_groups";
    /**
    * Generates CDKTN code for importing a DataHcloudPlacementGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudPlacementGroups to import
    * @param importFromId The id of the existing DataHcloudPlacementGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/placement_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudPlacementGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/placement_groups hcloud_placement_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudPlacementGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudPlacementGroupsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _placementGroups;
    get placementGroups(): DataHcloudPlacementGroupsPlacementGroupsList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
