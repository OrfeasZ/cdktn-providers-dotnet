# `data_hcloud_placement_groups`

Refer to the Terraform Registry for docs: [`data_hcloud_placement_groups`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/placement_groups).
