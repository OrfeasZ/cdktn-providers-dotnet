import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageBoxConfig extends cdktn.TerraformMetaArguments {
    /**
    * Access settings of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#access_settings StorageBox#access_settings}
    */
    readonly accessSettings?: StorageBoxAccessSettings;
    /**
    * Prevent the Storage Box from being accidentally deleted outside of Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#delete_protection StorageBox#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#labels StorageBox#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the Location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#location StorageBox#location}
    */
    readonly location: string;
    /**
    * Name of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#name StorageBox#name}
    */
    readonly name: string;
    /**
    * Password of the Storage Box. For more details, see the [Storage Boxes password policy](https://docs.hetzner.cloud/reference/hetzner#storage-boxes-password-policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#password StorageBox#password}
    */
    readonly password: string;
    /**
    * Details of the active snapshot plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#snapshot_plan StorageBox#snapshot_plan}
    */
    readonly snapshotPlan?: StorageBoxSnapshotPlan;
    /**
    * SSH public keys in OpenSSH format to inject into the Storage Box. It is not possible to update the SSH Keys through the API, so changing this attribute forces a replace of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#ssh_keys StorageBox#ssh_keys}
    */
    readonly sshKeys?: string[];
    /**
    * Name of the Storage Box Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#storage_box_type StorageBox#storage_box_type}
    */
    readonly storageBoxType: string;
}
export interface StorageBoxAccessSettings {
    /**
    * Whether access from outside the Hetzner network is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#reachable_externally StorageBox#reachable_externally}
    */
    readonly reachableExternally?: boolean | cdktn.IResolvable;
    /**
    * Whether the Samba subsystem is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#samba_enabled StorageBox#samba_enabled}
    */
    readonly sambaEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether the SSH subsystem is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#ssh_enabled StorageBox#ssh_enabled}
    */
    readonly sshEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether the WebDAV subsystem is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#webdav_enabled StorageBox#webdav_enabled}
    */
    readonly webdavEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether the ZFS snapshot folder is visible.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#zfs_enabled StorageBox#zfs_enabled}
    */
    readonly zfsEnabled?: boolean | cdktn.IResolvable;
}
export declare function storageBoxAccessSettingsToTerraform(struct?: StorageBoxAccessSettings | cdktn.IResolvable): any;
export declare function storageBoxAccessSettingsToHclTerraform(struct?: StorageBoxAccessSettings | cdktn.IResolvable): any;
export declare class StorageBoxAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageBoxAccessSettings | cdktn.IResolvable | undefined;
    set internalValue(value: StorageBoxAccessSettings | cdktn.IResolvable | undefined);
    private _reachableExternally?;
    get reachableExternally(): boolean | cdktn.IResolvable;
    set reachableExternally(value: boolean | cdktn.IResolvable);
    resetReachableExternally(): void;
    get reachableExternallyInput(): boolean | cdktn.IResolvable | undefined;
    private _sambaEnabled?;
    get sambaEnabled(): boolean | cdktn.IResolvable;
    set sambaEnabled(value: boolean | cdktn.IResolvable);
    resetSambaEnabled(): void;
    get sambaEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sshEnabled?;
    get sshEnabled(): boolean | cdktn.IResolvable;
    set sshEnabled(value: boolean | cdktn.IResolvable);
    resetSshEnabled(): void;
    get sshEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _webdavEnabled?;
    get webdavEnabled(): boolean | cdktn.IResolvable;
    set webdavEnabled(value: boolean | cdktn.IResolvable);
    resetWebdavEnabled(): void;
    get webdavEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _zfsEnabled?;
    get zfsEnabled(): boolean | cdktn.IResolvable;
    set zfsEnabled(value: boolean | cdktn.IResolvable);
    resetZfsEnabled(): void;
    get zfsEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface StorageBoxSnapshotPlan {
    /**
    * Day of the month when the Snapshot Plan is executed. Null means every day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#day_of_month StorageBox#day_of_month}
    */
    readonly dayOfMonth?: number;
    /**
    * Day of the week when the Snapshot Plan is executed. Starts at 0 for Sunday til 6 for Saturday. Note that this differs from the API, which uses 1 (Monday) through 7 (Sunday). Null means every day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#day_of_week StorageBox#day_of_week}
    */
    readonly dayOfWeek?: number;
    /**
    * Hour when the Snapshot Plan is executed (UTC).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#hour StorageBox#hour}
    */
    readonly hour: number;
    /**
    * Maximum amount of Snapshots that will be created by this Snapshot Plan. Older Snapshots will be deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#max_snapshots StorageBox#max_snapshots}
    */
    readonly maxSnapshots: number;
    /**
    * Minute when the Snapshot Plan is executed (UTC).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#minute StorageBox#minute}
    */
    readonly minute: number;
}
export declare function storageBoxSnapshotPlanToTerraform(struct?: StorageBoxSnapshotPlan | cdktn.IResolvable): any;
export declare function storageBoxSnapshotPlanToHclTerraform(struct?: StorageBoxSnapshotPlan | cdktn.IResolvable): any;
export declare class StorageBoxSnapshotPlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageBoxSnapshotPlan | cdktn.IResolvable | undefined;
    set internalValue(value: StorageBoxSnapshotPlan | cdktn.IResolvable | undefined);
    private _dayOfMonth?;
    get dayOfMonth(): number;
    set dayOfMonth(value: number);
    resetDayOfMonth(): void;
    get dayOfMonthInput(): number | undefined;
    private _dayOfWeek?;
    get dayOfWeek(): number;
    set dayOfWeek(value: number);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): number | undefined;
    private _hour?;
    get hour(): number;
    set hour(value: number);
    get hourInput(): number | undefined;
    private _maxSnapshots?;
    get maxSnapshots(): number;
    set maxSnapshots(value: number);
    get maxSnapshotsInput(): number | undefined;
    private _minute?;
    get minute(): number;
    set minute(value: number);
    get minuteInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box hcloud_storage_box}
*/
export declare class StorageBox extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_storage_box";
    /**
    * Generates CDKTN code for importing a StorageBox resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageBox to import
    * @param importFromId The id of the existing StorageBox that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageBox to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box hcloud_storage_box} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageBoxConfig
    */
    constructor(scope: Construct, id: string, config: StorageBoxConfig);
    private _accessSettings;
    get accessSettings(): StorageBoxAccessSettingsOutputReference;
    putAccessSettings(value: StorageBoxAccessSettings): void;
    resetAccessSettings(): void;
    get accessSettingsInput(): cdktn.IResolvable | StorageBoxAccessSettings | undefined;
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    get id(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    get server(): string;
    private _snapshotPlan;
    get snapshotPlan(): StorageBoxSnapshotPlanOutputReference;
    putSnapshotPlan(value: StorageBoxSnapshotPlan): void;
    resetSnapshotPlan(): void;
    get snapshotPlanInput(): cdktn.IResolvable | StorageBoxSnapshotPlan | undefined;
    private _sshKeys?;
    get sshKeys(): string[];
    set sshKeys(value: string[]);
    resetSshKeys(): void;
    get sshKeysInput(): string[] | undefined;
    private _storageBoxType?;
    get storageBoxType(): string;
    set storageBoxType(value: string);
    get storageBoxTypeInput(): string | undefined;
    get systemAttribute(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
