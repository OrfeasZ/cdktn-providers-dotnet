# `hcloud_storage_box`

Refer to the Terraform Registry for docs: [`hcloud_storage_box`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box).
