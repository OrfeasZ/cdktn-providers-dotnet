import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#id DataHcloudServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#name DataHcloudServer#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#placement_group_id DataHcloudServer#placement_group_id}
    */
    readonly placementGroupId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#selector DataHcloudServer#selector}
    */
    readonly selector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#with_selector DataHcloudServer#with_selector}
    */
    readonly withSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#with_status DataHcloudServer#with_status}
    */
    readonly withStatus?: string[];
    /**
    * network block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#network DataHcloudServer#network}
    */
    readonly network?: DataHcloudServerNetwork[] | cdktn.IResolvable;
}
export interface DataHcloudServerNetwork {
}
export declare function dataHcloudServerNetworkToTerraform(struct?: DataHcloudServerNetwork | cdktn.IResolvable): any;
export declare function dataHcloudServerNetworkToHclTerraform(struct?: DataHcloudServerNetwork | cdktn.IResolvable): any;
export declare class DataHcloudServerNetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudServerNetwork | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcloudServerNetwork | cdktn.IResolvable | undefined);
    get aliasIps(): string[];
    get ip(): string;
    get macAddress(): string;
    get networkId(): number;
}
export declare class DataHcloudServerNetworkList extends cdktn.ComplexList {
    internalValue?: DataHcloudServerNetwork[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudServerNetworkOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server hcloud_server}
*/
export declare class DataHcloudServer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_server";
    /**
    * Generates CDKTN code for importing a DataHcloudServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudServer to import
    * @param importFromId The id of the existing DataHcloudServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/server hcloud_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudServerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudServerConfig);
    get backupWindow(): string;
    get backups(): cdktn.IResolvable;
    get datacenter(): string;
    get deleteProtection(): cdktn.IResolvable;
    get firewallIds(): number[];
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get image(): string;
    get ipv4Address(): string;
    get ipv6Address(): string;
    get ipv6Network(): string;
    get iso(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _placementGroupId?;
    get placementGroupId(): number;
    set placementGroupId(value: number);
    resetPlacementGroupId(): void;
    get placementGroupIdInput(): number | undefined;
    get primaryDiskSize(): number;
    get rebuildProtection(): cdktn.IResolvable;
    get rescue(): string;
    private _selector?;
    get selector(): string;
    set selector(value: string);
    resetSelector(): void;
    get selectorInput(): string | undefined;
    get serverType(): string;
    get status(): string;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _withStatus?;
    get withStatus(): string[];
    set withStatus(value: string[]);
    resetWithStatus(): void;
    get withStatusInput(): string[] | undefined;
    private _network;
    get network(): DataHcloudServerNetworkList;
    putNetwork(value: DataHcloudServerNetwork[] | cdktn.IResolvable): void;
    resetNetwork(): void;
    get networkInput(): cdktn.IResolvable | DataHcloudServerNetwork[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
