import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerTargetAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#id LoadBalancerTargetA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#ip LoadBalancerTargetA#ip}
    */
    readonly ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#label_selector LoadBalancerTargetA#label_selector}
    */
    readonly labelSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#load_balancer_id LoadBalancerTargetA#load_balancer_id}
    */
    readonly loadBalancerId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#server_id LoadBalancerTargetA#server_id}
    */
    readonly serverId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#type LoadBalancerTargetA#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#use_private_ip LoadBalancerTargetA#use_private_ip}
    */
    readonly usePrivateIp?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target hcloud_load_balancer_target}
*/
export declare class LoadBalancerTargetA extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_load_balancer_target";
    /**
    * Generates CDKTN code for importing a LoadBalancerTargetA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancerTargetA to import
    * @param importFromId The id of the existing LoadBalancerTargetA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancerTargetA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/load_balancer_target hcloud_load_balancer_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerTargetAConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerTargetAConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _labelSelector?;
    get labelSelector(): string;
    set labelSelector(value: string);
    resetLabelSelector(): void;
    get labelSelectorInput(): string | undefined;
    private _loadBalancerId?;
    get loadBalancerId(): number;
    set loadBalancerId(value: number);
    get loadBalancerIdInput(): number | undefined;
    private _serverId?;
    get serverId(): number;
    set serverId(value: number);
    resetServerId(): void;
    get serverIdInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _usePrivateIp?;
    get usePrivateIp(): boolean | cdktn.IResolvable;
    set usePrivateIp(value: boolean | cdktn.IResolvable);
    resetUsePrivateIp(): void;
    get usePrivateIpInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
