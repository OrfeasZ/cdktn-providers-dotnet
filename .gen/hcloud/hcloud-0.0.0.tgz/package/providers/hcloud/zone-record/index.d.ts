import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ZoneRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Comment of the Zone Record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record#comment ZoneRecord#comment}
    */
    readonly comment?: string;
    /**
    * Name of the Zone Record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record#name ZoneRecord#name}
    */
    readonly name: string;
    /**
    * Type of the Zone Record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record#type ZoneRecord#type}
    */
    readonly type: string;
    /**
    * Value of the Zone Record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record#value ZoneRecord#value}
    */
    readonly value: string;
    /**
    * ID or Name of the parent Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record#zone ZoneRecord#zone}
    */
    readonly zone: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record hcloud_zone_record}
*/
export declare class ZoneRecord extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_zone_record";
    /**
    * Generates CDKTN code for importing a ZoneRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ZoneRecord to import
    * @param importFromId The id of the existing ZoneRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ZoneRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone_record hcloud_zone_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneRecordConfig
    */
    constructor(scope: Construct, id: string, config: ZoneRecordConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
