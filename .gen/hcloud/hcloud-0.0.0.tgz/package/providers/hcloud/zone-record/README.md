# `hcloud_zone_record`

Refer to the Terraform Registry for docs: [`hcloud_zone_record`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/zone_record).
