import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone#id DataHcloudZone#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone#name DataHcloudZone#name}
    */
    readonly name?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone#with_selector DataHcloudZone#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudZoneAuthoritativeNameservers {
}
export declare function dataHcloudZoneAuthoritativeNameserversToTerraform(struct?: DataHcloudZoneAuthoritativeNameservers): any;
export declare function dataHcloudZoneAuthoritativeNameserversToHclTerraform(struct?: DataHcloudZoneAuthoritativeNameservers): any;
export declare class DataHcloudZoneAuthoritativeNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudZoneAuthoritativeNameservers | undefined;
    set internalValue(value: DataHcloudZoneAuthoritativeNameservers | undefined);
    get assigned(): string[];
}
export interface DataHcloudZonePrimaryNameservers {
}
export declare function dataHcloudZonePrimaryNameserversToTerraform(struct?: DataHcloudZonePrimaryNameservers): any;
export declare function dataHcloudZonePrimaryNameserversToHclTerraform(struct?: DataHcloudZonePrimaryNameservers): any;
export declare class DataHcloudZonePrimaryNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudZonePrimaryNameservers | undefined;
    set internalValue(value: DataHcloudZonePrimaryNameservers | undefined);
    get address(): string;
    get port(): number;
    get tsigAlgorithm(): string;
    get tsigKey(): string;
}
export declare class DataHcloudZonePrimaryNameserversList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudZonePrimaryNameserversOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone hcloud_zone}
*/
export declare class DataHcloudZone extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_zone";
    /**
    * Generates CDKTN code for importing a DataHcloudZone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudZone to import
    * @param importFromId The id of the existing DataHcloudZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone hcloud_zone} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudZoneConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudZoneConfig);
    private _authoritativeNameservers;
    get authoritativeNameservers(): DataHcloudZoneAuthoritativeNameserversOutputReference;
    get deleteProtection(): cdktn.IResolvable;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    get mode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryNameservers;
    get primaryNameservers(): DataHcloudZonePrimaryNameserversList;
    get registrar(): string;
    get ttl(): number;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
