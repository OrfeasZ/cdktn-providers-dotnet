import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudNetworksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/networks#id DataHcloudNetworks#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/networks#with_selector DataHcloudNetworks#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudNetworksNetworks {
}
export declare function dataHcloudNetworksNetworksToTerraform(struct?: DataHcloudNetworksNetworks): any;
export declare function dataHcloudNetworksNetworksToHclTerraform(struct?: DataHcloudNetworksNetworks): any;
export declare class DataHcloudNetworksNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudNetworksNetworks | undefined;
    set internalValue(value: DataHcloudNetworksNetworks | undefined);
    get deleteProtection(): cdktn.IResolvable;
    get exposeRoutesToVswitch(): cdktn.IResolvable;
    get id(): number;
    get ipRange(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
}
export declare class DataHcloudNetworksNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudNetworksNetworksOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/networks hcloud_networks}
*/
export declare class DataHcloudNetworks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_networks";
    /**
    * Generates CDKTN code for importing a DataHcloudNetworks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudNetworks to import
    * @param importFromId The id of the existing DataHcloudNetworks that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/networks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudNetworks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/networks hcloud_networks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudNetworksConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudNetworksConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networks;
    get networks(): DataHcloudNetworksNetworksList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
