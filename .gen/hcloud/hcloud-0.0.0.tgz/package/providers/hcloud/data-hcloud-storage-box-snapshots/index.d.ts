import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxSnapshotsConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_snapshots#storage_box_id DataHcloudStorageBoxSnapshots#storage_box_id}
    */
    readonly storageBoxId: number;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_snapshots#with_selector DataHcloudStorageBoxSnapshots#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudStorageBoxSnapshotsSnapshotsStats {
}
export declare function dataHcloudStorageBoxSnapshotsSnapshotsStatsToTerraform(struct?: DataHcloudStorageBoxSnapshotsSnapshotsStats): any;
export declare function dataHcloudStorageBoxSnapshotsSnapshotsStatsToHclTerraform(struct?: DataHcloudStorageBoxSnapshotsSnapshotsStats): any;
export declare class DataHcloudStorageBoxSnapshotsSnapshotsStatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxSnapshotsSnapshotsStats | undefined;
    set internalValue(value: DataHcloudStorageBoxSnapshotsSnapshotsStats | undefined);
    get size(): number;
    get sizeFilesystem(): number;
}
export interface DataHcloudStorageBoxSnapshotsSnapshots {
}
export declare function dataHcloudStorageBoxSnapshotsSnapshotsToTerraform(struct?: DataHcloudStorageBoxSnapshotsSnapshots): any;
export declare function dataHcloudStorageBoxSnapshotsSnapshotsToHclTerraform(struct?: DataHcloudStorageBoxSnapshotsSnapshots): any;
export declare class DataHcloudStorageBoxSnapshotsSnapshotsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudStorageBoxSnapshotsSnapshots | undefined;
    set internalValue(value: DataHcloudStorageBoxSnapshotsSnapshots | undefined);
    get description(): string;
    get id(): number;
    get isAutomatic(): cdktn.IResolvable;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    private _stats;
    get stats(): DataHcloudStorageBoxSnapshotsSnapshotsStatsOutputReference;
    get storageBoxId(): number;
}
export declare class DataHcloudStorageBoxSnapshotsSnapshotsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudStorageBoxSnapshotsSnapshotsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_snapshots hcloud_storage_box_snapshots}
*/
export declare class DataHcloudStorageBoxSnapshots extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box_snapshots";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxSnapshots resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxSnapshots to import
    * @param importFromId The id of the existing DataHcloudStorageBoxSnapshots that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_snapshots#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxSnapshots to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_snapshots hcloud_storage_box_snapshots} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxSnapshotsConfig
    */
    constructor(scope: Construct, id: string, config: DataHcloudStorageBoxSnapshotsConfig);
    private _snapshots;
    get snapshots(): DataHcloudStorageBoxSnapshotsSnapshotsList;
    private _storageBoxId?;
    get storageBoxId(): number;
    set storageBoxId(value: number);
    get storageBoxIdInput(): number | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
