# `data_hcloud_storage_box`

Refer to the Terraform Registry for docs: [`data_hcloud_storage_box`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box).
