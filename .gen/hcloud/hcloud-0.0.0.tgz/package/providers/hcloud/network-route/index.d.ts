import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NetworkRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route#destination NetworkRoute#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route#gateway NetworkRoute#gateway}
    */
    readonly gateway: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route#id NetworkRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route#network_id NetworkRoute#network_id}
    */
    readonly networkId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route hcloud_network_route}
*/
export declare class NetworkRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_network_route";
    /**
    * Generates CDKTN code for importing a NetworkRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkRoute to import
    * @param importFromId The id of the existing NetworkRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/network_route hcloud_network_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkRouteConfig
    */
    constructor(scope: Construct, id: string, config: NetworkRouteConfig);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _gateway?;
    get gateway(): string;
    set gateway(value: string);
    get gatewayInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networkId?;
    get networkId(): number;
    set networkId(value: number);
    get networkIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
