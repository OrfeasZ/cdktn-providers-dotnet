# `data_hcloud_load_balancer_type`

Refer to the Terraform Registry for docs: [`data_hcloud_load_balancer_type`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/load_balancer_type).
