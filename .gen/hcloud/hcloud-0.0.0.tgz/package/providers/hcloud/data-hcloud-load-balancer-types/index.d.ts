import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudLoadBalancerTypesConfig extends cdktn.TerraformMetaArguments {
}
export interface DataHcloudLoadBalancerTypesLoadBalancerTypes {
}
export declare function dataHcloudLoadBalancerTypesLoadBalancerTypesToTerraform(struct?: DataHcloudLoadBalancerTypesLoadBalancerTypes): any;
export declare function dataHcloudLoadBalancerTypesLoadBalancerTypesToHclTerraform(struct?: DataHcloudLoadBalancerTypesLoadBalancerTypes): any;
export declare class DataHcloudLoadBalancerTypesLoadBalancerTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancerTypesLoadBalancerTypes | undefined;
    set internalValue(value: DataHcloudLoadBalancerTypesLoadBalancerTypes | undefined);
    get description(): string;
    get id(): number;
    get maxAssignedCertificates(): number;
    get maxConnections(): number;
    get maxServices(): number;
    get maxTargets(): number;
    get name(): string;
}
export declare class DataHcloudLoadBalancerTypesLoadBalancerTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancerTypesLoadBalancerTypesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/load_balancer_types hcloud_load_balancer_types}
*/
export declare class DataHcloudLoadBalancerTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_load_balancer_types";
    /**
    * Generates CDKTN code for importing a DataHcloudLoadBalancerTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudLoadBalancerTypes to import
    * @param importFromId The id of the existing DataHcloudLoadBalancerTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/load_balancer_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudLoadBalancerTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/load_balancer_types hcloud_load_balancer_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudLoadBalancerTypesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudLoadBalancerTypesConfig);
    get id(): string;
    private _loadBalancerTypes;
    get loadBalancerTypes(): DataHcloudLoadBalancerTypesLoadBalancerTypesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
