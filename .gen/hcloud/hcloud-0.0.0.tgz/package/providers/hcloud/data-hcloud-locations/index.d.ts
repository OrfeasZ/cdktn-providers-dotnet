import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudLocationsConfig extends cdktn.TerraformMetaArguments {
}
export interface DataHcloudLocationsLocations {
}
export declare function dataHcloudLocationsLocationsToTerraform(struct?: DataHcloudLocationsLocations): any;
export declare function dataHcloudLocationsLocationsToHclTerraform(struct?: DataHcloudLocationsLocations): any;
export declare class DataHcloudLocationsLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLocationsLocations | undefined;
    set internalValue(value: DataHcloudLocationsLocations | undefined);
    get city(): string;
    get country(): string;
    get description(): string;
    get id(): number;
    get latitude(): number;
    get longitude(): number;
    get name(): string;
    get networkZone(): string;
}
export declare class DataHcloudLocationsLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLocationsLocationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/locations hcloud_locations}
*/
export declare class DataHcloudLocations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_locations";
    /**
    * Generates CDKTN code for importing a DataHcloudLocations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudLocations to import
    * @param importFromId The id of the existing DataHcloudLocations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/locations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudLocations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/locations hcloud_locations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudLocationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudLocationsConfig);
    get descriptions(): string[];
    get id(): string;
    get locationIds(): string[];
    private _locations;
    get locations(): DataHcloudLocationsLocationsList;
    get names(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
