import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudImagesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#id DataHcloudImages#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#include_deprecated DataHcloudImages#include_deprecated}
    */
    readonly includeDeprecated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#most_recent DataHcloudImages#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#with_architecture DataHcloudImages#with_architecture}
    */
    readonly withArchitecture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#with_selector DataHcloudImages#with_selector}
    */
    readonly withSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#with_status DataHcloudImages#with_status}
    */
    readonly withStatus?: string[];
}
export interface DataHcloudImagesImages {
}
export declare function dataHcloudImagesImagesToTerraform(struct?: DataHcloudImagesImages): any;
export declare function dataHcloudImagesImagesToHclTerraform(struct?: DataHcloudImagesImages): any;
export declare class DataHcloudImagesImagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudImagesImages | undefined;
    set internalValue(value: DataHcloudImagesImages | undefined);
    get architecture(): string;
    get created(): string;
    get deprecated(): string;
    get description(): string;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get osFlavor(): string;
    get osVersion(): string;
    get rapidDeploy(): cdktn.IResolvable;
    get selector(): string;
    get type(): string;
}
export declare class DataHcloudImagesImagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudImagesImagesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images hcloud_images}
*/
export declare class DataHcloudImages extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_images";
    /**
    * Generates CDKTN code for importing a DataHcloudImages resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudImages to import
    * @param importFromId The id of the existing DataHcloudImages that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudImages to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/images hcloud_images} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudImagesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudImagesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _images;
    get images(): DataHcloudImagesImagesList;
    private _includeDeprecated?;
    get includeDeprecated(): boolean | cdktn.IResolvable;
    set includeDeprecated(value: boolean | cdktn.IResolvable);
    resetIncludeDeprecated(): void;
    get includeDeprecatedInput(): boolean | cdktn.IResolvable | undefined;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _withArchitecture?;
    get withArchitecture(): string[];
    set withArchitecture(value: string[]);
    resetWithArchitecture(): void;
    get withArchitectureInput(): string[] | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _withStatus?;
    get withStatus(): string[];
    set withStatus(value: string[]);
    resetWithStatus(): void;
    get withStatusInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
