import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#delete_protection LoadBalancer#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#id LoadBalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#labels LoadBalancer#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#load_balancer_type LoadBalancer#load_balancer_type}
    */
    readonly loadBalancerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#location LoadBalancer#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#name LoadBalancer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#network_zone LoadBalancer#network_zone}
    */
    readonly networkZone?: string;
    /**
    * algorithm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#algorithm LoadBalancer#algorithm}
    */
    readonly algorithm?: LoadBalancerAlgorithm;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#target LoadBalancer#target}
    */
    readonly target?: LoadBalancerTarget[] | cdktn.IResolvable;
}
export interface LoadBalancerAlgorithm {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#type LoadBalancer#type}
    */
    readonly type?: string;
}
export declare function loadBalancerAlgorithmToTerraform(struct?: LoadBalancerAlgorithmOutputReference | LoadBalancerAlgorithm): any;
export declare function loadBalancerAlgorithmToHclTerraform(struct?: LoadBalancerAlgorithmOutputReference | LoadBalancerAlgorithm): any;
export declare class LoadBalancerAlgorithmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadBalancerAlgorithm | undefined;
    set internalValue(value: LoadBalancerAlgorithm | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface LoadBalancerTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#server_id LoadBalancer#server_id}
    */
    readonly serverId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#type LoadBalancer#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#use_private_ip LoadBalancer#use_private_ip}
    */
    readonly usePrivateIp?: boolean | cdktn.IResolvable;
}
export declare function loadBalancerTargetToTerraform(struct?: LoadBalancerTarget | cdktn.IResolvable): any;
export declare function loadBalancerTargetToHclTerraform(struct?: LoadBalancerTarget | cdktn.IResolvable): any;
export declare class LoadBalancerTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerTarget | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerTarget | cdktn.IResolvable | undefined);
    private _serverId?;
    get serverId(): number;
    set serverId(value: number);
    resetServerId(): void;
    get serverIdInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _usePrivateIp?;
    get usePrivateIp(): boolean | cdktn.IResolvable;
    set usePrivateIp(value: boolean | cdktn.IResolvable);
    resetUsePrivateIp(): void;
    get usePrivateIpInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class LoadBalancerTargetList extends cdktn.ComplexList {
    internalValue?: LoadBalancerTarget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerTargetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer hcloud_load_balancer}
*/
export declare class LoadBalancer extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_load_balancer";
    /**
    * Generates CDKTN code for importing a LoadBalancer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancer to import
    * @param importFromId The id of the existing LoadBalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/load_balancer hcloud_load_balancer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerConfig);
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipv4(): string;
    get ipv6(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _loadBalancerType?;
    get loadBalancerType(): string;
    set loadBalancerType(value: string);
    get loadBalancerTypeInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkId(): number;
    get networkIp(): string;
    private _networkZone?;
    get networkZone(): string;
    set networkZone(value: string);
    resetNetworkZone(): void;
    get networkZoneInput(): string | undefined;
    private _algorithm;
    get algorithm(): LoadBalancerAlgorithmOutputReference;
    putAlgorithm(value: LoadBalancerAlgorithm): void;
    resetAlgorithm(): void;
    get algorithmInput(): LoadBalancerAlgorithm | undefined;
    private _target;
    get target(): LoadBalancerTargetList;
    putTarget(value: LoadBalancerTarget[] | cdktn.IResolvable): void;
    resetTarget(): void;
    get targetInput(): cdktn.IResolvable | LoadBalancerTarget[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
