# `data_hcloud_location`

Refer to the Terraform Registry for docs: [`data_hcloud_location`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/location).
