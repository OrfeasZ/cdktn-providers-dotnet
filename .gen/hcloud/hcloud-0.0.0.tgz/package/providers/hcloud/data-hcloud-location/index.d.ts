import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/location#id DataHcloudLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/location#name DataHcloudLocation#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/location hcloud_location}
*/
export declare class DataHcloudLocation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_location";
    /**
    * Generates CDKTN code for importing a DataHcloudLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudLocation to import
    * @param importFromId The id of the existing DataHcloudLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/location hcloud_location} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudLocationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudLocationConfig);
    get city(): string;
    get country(): string;
    get description(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get latitude(): number;
    get longitude(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get networkZone(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
