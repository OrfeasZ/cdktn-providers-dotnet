# `data_hcloud_servers`

Refer to the Terraform Registry for docs: [`data_hcloud_servers`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/servers).
