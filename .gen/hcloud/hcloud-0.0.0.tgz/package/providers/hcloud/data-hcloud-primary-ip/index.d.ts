import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudPrimaryIpConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Primary IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip#id DataHcloudPrimaryIp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * IP address of the Primary IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip#ip_address DataHcloudPrimaryIp#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Name of the Primary IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip#name DataHcloudPrimaryIp#name}
    */
    readonly name?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip#with_selector DataHcloudPrimaryIp#with_selector}
    */
    readonly withSelector?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip hcloud_primary_ip}
*/
export declare class DataHcloudPrimaryIp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_primary_ip";
    /**
    * Generates CDKTN code for importing a DataHcloudPrimaryIp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudPrimaryIp to import
    * @param importFromId The id of the existing DataHcloudPrimaryIp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudPrimaryIp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/primary_ip hcloud_primary_ip} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudPrimaryIpConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudPrimaryIpConfig);
    get assigneeId(): number;
    get assigneeType(): string;
    get autoDelete(): cdktn.IResolvable;
    get datacenter(): string;
    get deleteProtection(): cdktn.IResolvable;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    get ipNetwork(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get type(): string;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
