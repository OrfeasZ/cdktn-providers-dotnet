import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudDatacentersConfig extends cdktn.TerraformMetaArguments {
}
export interface DataHcloudDatacentersDatacenters {
}
export declare function dataHcloudDatacentersDatacentersToTerraform(struct?: DataHcloudDatacentersDatacenters): any;
export declare function dataHcloudDatacentersDatacentersToHclTerraform(struct?: DataHcloudDatacentersDatacenters): any;
export declare class DataHcloudDatacentersDatacentersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudDatacentersDatacenters | undefined;
    set internalValue(value: DataHcloudDatacentersDatacenters | undefined);
    get availableServerTypeIds(): number[];
    get description(): string;
    get id(): number;
    private _location;
    get location(): cdktn.StringMap;
    get name(): string;
    get supportedServerTypeIds(): number[];
}
export declare class DataHcloudDatacentersDatacentersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudDatacentersDatacentersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/datacenters hcloud_datacenters}
*/
export declare class DataHcloudDatacenters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_datacenters";
    /**
    * Generates CDKTN code for importing a DataHcloudDatacenters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudDatacenters to import
    * @param importFromId The id of the existing DataHcloudDatacenters that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/datacenters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudDatacenters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/datacenters hcloud_datacenters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudDatacentersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudDatacentersConfig);
    get datacenterIds(): string[];
    private _datacenters;
    get datacenters(): DataHcloudDatacentersDatacentersList;
    get descriptions(): string[];
    get id(): string;
    get names(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
