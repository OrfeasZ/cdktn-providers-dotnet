import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudCertificatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificates#id DataHcloudCertificates#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificates#with_selector DataHcloudCertificates#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudCertificatesCertificates {
}
export declare function dataHcloudCertificatesCertificatesToTerraform(struct?: DataHcloudCertificatesCertificates): any;
export declare function dataHcloudCertificatesCertificatesToHclTerraform(struct?: DataHcloudCertificatesCertificates): any;
export declare class DataHcloudCertificatesCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudCertificatesCertificates | undefined;
    set internalValue(value: DataHcloudCertificatesCertificates | undefined);
    get certificate(): string;
    get created(): string;
    get domainNames(): string[];
    get fingerprint(): string;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get notValidAfter(): string;
    get notValidBefore(): string;
    get type(): string;
}
export declare class DataHcloudCertificatesCertificatesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudCertificatesCertificatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificates hcloud_certificates}
*/
export declare class DataHcloudCertificates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_certificates";
    /**
    * Generates CDKTN code for importing a DataHcloudCertificates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudCertificates to import
    * @param importFromId The id of the existing DataHcloudCertificates that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudCertificates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/certificates hcloud_certificates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudCertificatesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudCertificatesConfig);
    private _certificates;
    get certificates(): DataHcloudCertificatesCertificatesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
