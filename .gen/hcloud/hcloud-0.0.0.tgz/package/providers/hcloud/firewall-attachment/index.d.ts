import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FirewallAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment#firewall_id FirewallAttachment#firewall_id}
    */
    readonly firewallId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment#id FirewallAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment#label_selectors FirewallAttachment#label_selectors}
    */
    readonly labelSelectors?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment#server_ids FirewallAttachment#server_ids}
    */
    readonly serverIds?: number[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment hcloud_firewall_attachment}
*/
export declare class FirewallAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_firewall_attachment";
    /**
    * Generates CDKTN code for importing a FirewallAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FirewallAttachment to import
    * @param importFromId The id of the existing FirewallAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FirewallAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/firewall_attachment hcloud_firewall_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FirewallAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: FirewallAttachmentConfig);
    private _firewallId?;
    get firewallId(): number;
    set firewallId(value: number);
    get firewallIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labelSelectors?;
    get labelSelectors(): string[];
    set labelSelectors(value: string[]);
    resetLabelSelectors(): void;
    get labelSelectorsInput(): string[] | undefined;
    private _serverIds?;
    get serverIds(): number[];
    set serverIds(value: number[]);
    resetServerIds(): void;
    get serverIdsInput(): number[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
