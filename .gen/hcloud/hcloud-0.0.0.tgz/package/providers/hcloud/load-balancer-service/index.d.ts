import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#destination_port LoadBalancerService#destination_port}
    */
    readonly destinationPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#id LoadBalancerService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#listen_port LoadBalancerService#listen_port}
    */
    readonly listenPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#load_balancer_id LoadBalancerService#load_balancer_id}
    */
    readonly loadBalancerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#protocol LoadBalancerService#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#proxyprotocol LoadBalancerService#proxyprotocol}
    */
    readonly proxyprotocol?: boolean | cdktn.IResolvable;
    /**
    * health_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#health_check LoadBalancerService#health_check}
    */
    readonly healthCheck?: LoadBalancerServiceHealthCheck;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#http LoadBalancerService#http}
    */
    readonly http?: LoadBalancerServiceHttp;
}
export interface LoadBalancerServiceHealthCheckHttp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#domain LoadBalancerService#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#path LoadBalancerService#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#response LoadBalancerService#response}
    */
    readonly response?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#status_codes LoadBalancerService#status_codes}
    */
    readonly statusCodes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#tls LoadBalancerService#tls}
    */
    readonly tls?: boolean | cdktn.IResolvable;
}
export declare function loadBalancerServiceHealthCheckHttpToTerraform(struct?: LoadBalancerServiceHealthCheckHttpOutputReference | LoadBalancerServiceHealthCheckHttp): any;
export declare function loadBalancerServiceHealthCheckHttpToHclTerraform(struct?: LoadBalancerServiceHealthCheckHttpOutputReference | LoadBalancerServiceHealthCheckHttp): any;
export declare class LoadBalancerServiceHealthCheckHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadBalancerServiceHealthCheckHttp | undefined;
    set internalValue(value: LoadBalancerServiceHealthCheckHttp | undefined);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _response?;
    get response(): string;
    set response(value: string);
    resetResponse(): void;
    get responseInput(): string | undefined;
    private _statusCodes?;
    get statusCodes(): string[];
    set statusCodes(value: string[]);
    resetStatusCodes(): void;
    get statusCodesInput(): string[] | undefined;
    private _tls?;
    get tls(): boolean | cdktn.IResolvable;
    set tls(value: boolean | cdktn.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LoadBalancerServiceHealthCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#interval LoadBalancerService#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#port LoadBalancerService#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#protocol LoadBalancerService#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#retries LoadBalancerService#retries}
    */
    readonly retries: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#timeout LoadBalancerService#timeout}
    */
    readonly timeout: number;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#http LoadBalancerService#http}
    */
    readonly http?: LoadBalancerServiceHealthCheckHttp;
}
export declare function loadBalancerServiceHealthCheckToTerraform(struct?: LoadBalancerServiceHealthCheckOutputReference | LoadBalancerServiceHealthCheck): any;
export declare function loadBalancerServiceHealthCheckToHclTerraform(struct?: LoadBalancerServiceHealthCheckOutputReference | LoadBalancerServiceHealthCheck): any;
export declare class LoadBalancerServiceHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadBalancerServiceHealthCheck | undefined;
    set internalValue(value: LoadBalancerServiceHealthCheck | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    get retriesInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    get timeoutInput(): number | undefined;
    private _http;
    get http(): LoadBalancerServiceHealthCheckHttpOutputReference;
    putHttp(value: LoadBalancerServiceHealthCheckHttp): void;
    resetHttp(): void;
    get httpInput(): LoadBalancerServiceHealthCheckHttp | undefined;
}
export interface LoadBalancerServiceHttp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#certificates LoadBalancerService#certificates}
    */
    readonly certificates?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#cookie_lifetime LoadBalancerService#cookie_lifetime}
    */
    readonly cookieLifetime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#cookie_name LoadBalancerService#cookie_name}
    */
    readonly cookieName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#redirect_http LoadBalancerService#redirect_http}
    */
    readonly redirectHttp?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#sticky_sessions LoadBalancerService#sticky_sessions}
    */
    readonly stickySessions?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#timeout_idle LoadBalancerService#timeout_idle}
    */
    readonly timeoutIdle?: number;
}
export declare function loadBalancerServiceHttpToTerraform(struct?: LoadBalancerServiceHttpOutputReference | LoadBalancerServiceHttp): any;
export declare function loadBalancerServiceHttpToHclTerraform(struct?: LoadBalancerServiceHttpOutputReference | LoadBalancerServiceHttp): any;
export declare class LoadBalancerServiceHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadBalancerServiceHttp | undefined;
    set internalValue(value: LoadBalancerServiceHttp | undefined);
    private _certificates?;
    get certificates(): number[];
    set certificates(value: number[]);
    resetCertificates(): void;
    get certificatesInput(): number[] | undefined;
    private _cookieLifetime?;
    get cookieLifetime(): number;
    set cookieLifetime(value: number);
    resetCookieLifetime(): void;
    get cookieLifetimeInput(): number | undefined;
    private _cookieName?;
    get cookieName(): string;
    set cookieName(value: string);
    resetCookieName(): void;
    get cookieNameInput(): string | undefined;
    private _redirectHttp?;
    get redirectHttp(): boolean | cdktn.IResolvable;
    set redirectHttp(value: boolean | cdktn.IResolvable);
    resetRedirectHttp(): void;
    get redirectHttpInput(): boolean | cdktn.IResolvable | undefined;
    private _stickySessions?;
    get stickySessions(): boolean | cdktn.IResolvable;
    set stickySessions(value: boolean | cdktn.IResolvable);
    resetStickySessions(): void;
    get stickySessionsInput(): boolean | cdktn.IResolvable | undefined;
    private _timeoutIdle?;
    get timeoutIdle(): number;
    set timeoutIdle(value: number);
    resetTimeoutIdle(): void;
    get timeoutIdleInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service hcloud_load_balancer_service}
*/
export declare class LoadBalancerService extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_load_balancer_service";
    /**
    * Generates CDKTN code for importing a LoadBalancerService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancerService to import
    * @param importFromId The id of the existing LoadBalancerService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancerService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/load_balancer_service hcloud_load_balancer_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerServiceConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerServiceConfig);
    private _destinationPort?;
    get destinationPort(): number;
    set destinationPort(value: number);
    resetDestinationPort(): void;
    get destinationPortInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenPort?;
    get listenPort(): number;
    set listenPort(value: number);
    resetListenPort(): void;
    get listenPortInput(): number | undefined;
    private _loadBalancerId?;
    get loadBalancerId(): string;
    set loadBalancerId(value: string);
    get loadBalancerIdInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _proxyprotocol?;
    get proxyprotocol(): boolean | cdktn.IResolvable;
    set proxyprotocol(value: boolean | cdktn.IResolvable);
    resetProxyprotocol(): void;
    get proxyprotocolInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheck;
    get healthCheck(): LoadBalancerServiceHealthCheckOutputReference;
    putHealthCheck(value: LoadBalancerServiceHealthCheck): void;
    resetHealthCheck(): void;
    get healthCheckInput(): LoadBalancerServiceHealthCheck | undefined;
    private _http;
    get http(): LoadBalancerServiceHttpOutputReference;
    putHttp(value: LoadBalancerServiceHttp): void;
    resetHttp(): void;
    get httpInput(): LoadBalancerServiceHttp | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
