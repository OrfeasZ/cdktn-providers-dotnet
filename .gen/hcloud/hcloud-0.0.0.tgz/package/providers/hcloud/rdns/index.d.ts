import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RdnsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Domain name `ip_address` should point to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#dns_ptr Rdns#dns_ptr}
    */
    readonly dnsPtr: string;
    /**
    * ID of the Floating IP the `ip_address` belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#floating_ip_id Rdns#floating_ip_id}
    */
    readonly floatingIpId?: number;
    /**
    * IP address that should point to `dns_ptr`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#ip_address Rdns#ip_address}
    */
    readonly ipAddress: string;
    /**
    * ID of the Load Balancer the `ip_address` belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#load_balancer_id Rdns#load_balancer_id}
    */
    readonly loadBalancerId?: number;
    /**
    * ID of the Primary IP the `ip_address` belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#primary_ip_id Rdns#primary_ip_id}
    */
    readonly primaryIpId?: number;
    /**
    * ID of the Server the `ip_address` belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#server_id Rdns#server_id}
    */
    readonly serverId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns hcloud_rdns}
*/
export declare class Rdns extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_rdns";
    /**
    * Generates CDKTN code for importing a Rdns resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Rdns to import
    * @param importFromId The id of the existing Rdns that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Rdns to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns hcloud_rdns} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RdnsConfig
    */
    constructor(scope: Construct, id: string, config: RdnsConfig);
    private _dnsPtr?;
    get dnsPtr(): string;
    set dnsPtr(value: string);
    get dnsPtrInput(): string | undefined;
    private _floatingIpId?;
    get floatingIpId(): number;
    set floatingIpId(value: number);
    resetFloatingIpId(): void;
    get floatingIpIdInput(): number | undefined;
    get id(): string;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    get ipAddressInput(): string | undefined;
    private _loadBalancerId?;
    get loadBalancerId(): number;
    set loadBalancerId(value: number);
    resetLoadBalancerId(): void;
    get loadBalancerIdInput(): number | undefined;
    private _primaryIpId?;
    get primaryIpId(): number;
    set primaryIpId(value: number);
    resetPrimaryIpId(): void;
    get primaryIpIdInput(): number | undefined;
    private _serverId?;
    get serverId(): number;
    set serverId(value: number);
    resetServerId(): void;
    get serverIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
