# `hcloud_rdns`

Refer to the Terraform Registry for docs: [`hcloud_rdns`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/rdns).
