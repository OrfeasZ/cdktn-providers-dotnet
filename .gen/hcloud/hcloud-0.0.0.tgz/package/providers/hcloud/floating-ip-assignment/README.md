# `hcloud_floating_ip_assignment`

Refer to the Terraform Registry for docs: [`hcloud_floating_ip_assignment`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment).
