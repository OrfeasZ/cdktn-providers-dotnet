import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FloatingIpAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment#floating_ip_id FloatingIpAssignment#floating_ip_id}
    */
    readonly floatingIpId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment#id FloatingIpAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment#server_id FloatingIpAssignment#server_id}
    */
    readonly serverId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment hcloud_floating_ip_assignment}
*/
export declare class FloatingIpAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_floating_ip_assignment";
    /**
    * Generates CDKTN code for importing a FloatingIpAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FloatingIpAssignment to import
    * @param importFromId The id of the existing FloatingIpAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FloatingIpAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/floating_ip_assignment hcloud_floating_ip_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FloatingIpAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: FloatingIpAssignmentConfig);
    private _floatingIpId?;
    get floatingIpId(): number;
    set floatingIpId(value: number);
    get floatingIpIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _serverId?;
    get serverId(): number;
    set serverId(value: number);
    get serverIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
