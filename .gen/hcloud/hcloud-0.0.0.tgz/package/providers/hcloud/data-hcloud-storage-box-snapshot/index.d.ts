import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Storage Box Snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot#id DataHcloudStorageBoxSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Storage Box Snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot#name DataHcloudStorageBoxSnapshot#name}
    */
    readonly name?: string;
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot#storage_box_id DataHcloudStorageBoxSnapshot#storage_box_id}
    */
    readonly storageBoxId: number;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/hetzner#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot#with_selector DataHcloudStorageBoxSnapshot#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudStorageBoxSnapshotStats {
}
export declare function dataHcloudStorageBoxSnapshotStatsToTerraform(struct?: DataHcloudStorageBoxSnapshotStats): any;
export declare function dataHcloudStorageBoxSnapshotStatsToHclTerraform(struct?: DataHcloudStorageBoxSnapshotStats): any;
export declare class DataHcloudStorageBoxSnapshotStatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxSnapshotStats | undefined;
    set internalValue(value: DataHcloudStorageBoxSnapshotStats | undefined);
    get size(): number;
    get sizeFilesystem(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot hcloud_storage_box_snapshot}
*/
export declare class DataHcloudStorageBoxSnapshot extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box_snapshot";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxSnapshot to import
    * @param importFromId The id of the existing DataHcloudStorageBoxSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot hcloud_storage_box_snapshot} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: DataHcloudStorageBoxSnapshotConfig);
    get description(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get isAutomatic(): cdktn.IResolvable;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _stats;
    get stats(): DataHcloudStorageBoxSnapshotStatsOutputReference;
    private _storageBoxId?;
    get storageBoxId(): number;
    set storageBoxId(value: number);
    get storageBoxIdInput(): number | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
