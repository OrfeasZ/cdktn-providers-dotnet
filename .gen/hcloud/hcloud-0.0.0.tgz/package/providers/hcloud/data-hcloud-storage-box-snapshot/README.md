# `data_hcloud_storage_box_snapshot`

Refer to the Terraform Registry for docs: [`data_hcloud_storage_box_snapshot`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_snapshot).
