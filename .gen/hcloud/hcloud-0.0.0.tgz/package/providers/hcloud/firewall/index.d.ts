import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#id Firewall#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#labels Firewall#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#name Firewall#name}
    */
    readonly name: string;
    /**
    * apply_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#apply_to Firewall#apply_to}
    */
    readonly applyTo?: FirewallApplyTo[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#rule Firewall#rule}
    */
    readonly rule?: FirewallRule[] | cdktn.IResolvable;
}
export interface FirewallApplyTo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#label_selector Firewall#label_selector}
    */
    readonly labelSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#server Firewall#server}
    */
    readonly server?: number;
}
export declare function firewallApplyToToTerraform(struct?: FirewallApplyTo | cdktn.IResolvable): any;
export declare function firewallApplyToToHclTerraform(struct?: FirewallApplyTo | cdktn.IResolvable): any;
export declare class FirewallApplyToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FirewallApplyTo | cdktn.IResolvable | undefined;
    set internalValue(value: FirewallApplyTo | cdktn.IResolvable | undefined);
    private _labelSelector?;
    get labelSelector(): string;
    set labelSelector(value: string);
    resetLabelSelector(): void;
    get labelSelectorInput(): string | undefined;
    private _server?;
    get server(): number;
    set server(value: number);
    resetServer(): void;
    get serverInput(): number | undefined;
}
export declare class FirewallApplyToList extends cdktn.ComplexList {
    internalValue?: FirewallApplyTo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FirewallApplyToOutputReference;
}
export interface FirewallRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#description Firewall#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#destination_ips Firewall#destination_ips}
    */
    readonly destinationIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#direction Firewall#direction}
    */
    readonly direction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#port Firewall#port}
    */
    readonly port?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#protocol Firewall#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#source_ips Firewall#source_ips}
    */
    readonly sourceIps?: string[];
}
export declare function firewallRuleToTerraform(struct?: FirewallRule | cdktn.IResolvable): any;
export declare function firewallRuleToHclTerraform(struct?: FirewallRule | cdktn.IResolvable): any;
export declare class FirewallRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FirewallRule | cdktn.IResolvable | undefined;
    set internalValue(value: FirewallRule | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationIps?;
    get destinationIps(): string[];
    set destinationIps(value: string[]);
    resetDestinationIps(): void;
    get destinationIpsInput(): string[] | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _sourceIps?;
    get sourceIps(): string[];
    set sourceIps(value: string[]);
    resetSourceIps(): void;
    get sourceIpsInput(): string[] | undefined;
}
export declare class FirewallRuleList extends cdktn.ComplexList {
    internalValue?: FirewallRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FirewallRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall hcloud_firewall}
*/
export declare class Firewall extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_firewall";
    /**
    * Generates CDKTN code for importing a Firewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Firewall to import
    * @param importFromId The id of the existing Firewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Firewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/firewall hcloud_firewall} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FirewallConfig
    */
    constructor(scope: Construct, id: string, config: FirewallConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _applyTo;
    get applyTo(): FirewallApplyToList;
    putApplyTo(value: FirewallApplyTo[] | cdktn.IResolvable): void;
    resetApplyTo(): void;
    get applyToInput(): cdktn.IResolvable | FirewallApplyTo[] | undefined;
    private _rule;
    get rule(): FirewallRuleList;
    putRule(value: FirewallRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | FirewallRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
