import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NetworkSubnetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#id NetworkSubnet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#ip_range NetworkSubnet#ip_range}
    */
    readonly ipRange: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#network_id NetworkSubnet#network_id}
    */
    readonly networkId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#network_zone NetworkSubnet#network_zone}
    */
    readonly networkZone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#type NetworkSubnet#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#vswitch_id NetworkSubnet#vswitch_id}
    */
    readonly vswitchId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet hcloud_network_subnet}
*/
export declare class NetworkSubnet extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_network_subnet";
    /**
    * Generates CDKTN code for importing a NetworkSubnet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkSubnet to import
    * @param importFromId The id of the existing NetworkSubnet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkSubnet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/network_subnet hcloud_network_subnet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkSubnetConfig
    */
    constructor(scope: Construct, id: string, config: NetworkSubnetConfig);
    get gateway(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipRange?;
    get ipRange(): string;
    set ipRange(value: string);
    get ipRangeInput(): string | undefined;
    private _networkId?;
    get networkId(): number;
    set networkId(value: number);
    get networkIdInput(): number | undefined;
    private _networkZone?;
    get networkZone(): string;
    set networkZone(value: string);
    get networkZoneInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _vswitchId?;
    get vswitchId(): number;
    set vswitchId(value: number);
    resetVswitchId(): void;
    get vswitchIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
