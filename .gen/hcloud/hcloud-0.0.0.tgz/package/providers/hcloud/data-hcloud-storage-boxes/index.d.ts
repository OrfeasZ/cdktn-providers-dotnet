import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_boxes#with_selector DataHcloudStorageBoxes#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudStorageBoxesStorageBoxesAccessSettings {
}
export declare function dataHcloudStorageBoxesStorageBoxesAccessSettingsToTerraform(struct?: DataHcloudStorageBoxesStorageBoxesAccessSettings): any;
export declare function dataHcloudStorageBoxesStorageBoxesAccessSettingsToHclTerraform(struct?: DataHcloudStorageBoxesStorageBoxesAccessSettings): any;
export declare class DataHcloudStorageBoxesStorageBoxesAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxesStorageBoxesAccessSettings | undefined;
    set internalValue(value: DataHcloudStorageBoxesStorageBoxesAccessSettings | undefined);
    get reachableExternally(): cdktn.IResolvable;
    get sambaEnabled(): cdktn.IResolvable;
    get sshEnabled(): cdktn.IResolvable;
    get webdavEnabled(): cdktn.IResolvable;
    get zfsEnabled(): cdktn.IResolvable;
}
export interface DataHcloudStorageBoxesStorageBoxesSnapshotPlan {
}
export declare function dataHcloudStorageBoxesStorageBoxesSnapshotPlanToTerraform(struct?: DataHcloudStorageBoxesStorageBoxesSnapshotPlan): any;
export declare function dataHcloudStorageBoxesStorageBoxesSnapshotPlanToHclTerraform(struct?: DataHcloudStorageBoxesStorageBoxesSnapshotPlan): any;
export declare class DataHcloudStorageBoxesStorageBoxesSnapshotPlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxesStorageBoxesSnapshotPlan | undefined;
    set internalValue(value: DataHcloudStorageBoxesStorageBoxesSnapshotPlan | undefined);
    get dayOfMonth(): number;
    get dayOfWeek(): number;
    get hour(): number;
    get maxSnapshots(): number;
    get minute(): number;
}
export interface DataHcloudStorageBoxesStorageBoxes {
}
export declare function dataHcloudStorageBoxesStorageBoxesToTerraform(struct?: DataHcloudStorageBoxesStorageBoxes): any;
export declare function dataHcloudStorageBoxesStorageBoxesToHclTerraform(struct?: DataHcloudStorageBoxesStorageBoxes): any;
export declare class DataHcloudStorageBoxesStorageBoxesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudStorageBoxesStorageBoxes | undefined;
    set internalValue(value: DataHcloudStorageBoxesStorageBoxes | undefined);
    private _accessSettings;
    get accessSettings(): DataHcloudStorageBoxesStorageBoxesAccessSettingsOutputReference;
    get deleteProtection(): cdktn.IResolvable;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get server(): string;
    private _snapshotPlan;
    get snapshotPlan(): DataHcloudStorageBoxesStorageBoxesSnapshotPlanOutputReference;
    get storageBoxType(): string;
    get systemAttribute(): string;
    get username(): string;
}
export declare class DataHcloudStorageBoxesStorageBoxesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudStorageBoxesStorageBoxesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_boxes hcloud_storage_boxes}
*/
export declare class DataHcloudStorageBoxes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_boxes";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxes to import
    * @param importFromId The id of the existing DataHcloudStorageBoxes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_boxes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_boxes hcloud_storage_boxes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudStorageBoxesConfig);
    private _storageBoxes;
    get storageBoxes(): DataHcloudStorageBoxesStorageBoxesList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
