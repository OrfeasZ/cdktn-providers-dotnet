import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxSubaccountsConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_subaccounts#storage_box_id DataHcloudStorageBoxSubaccounts#storage_box_id}
    */
    readonly storageBoxId: number;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_subaccounts#with_selector DataHcloudStorageBoxSubaccounts#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudStorageBoxSubaccountsSubaccountsAccessSettings {
}
export declare function dataHcloudStorageBoxSubaccountsSubaccountsAccessSettingsToTerraform(struct?: DataHcloudStorageBoxSubaccountsSubaccountsAccessSettings): any;
export declare function dataHcloudStorageBoxSubaccountsSubaccountsAccessSettingsToHclTerraform(struct?: DataHcloudStorageBoxSubaccountsSubaccountsAccessSettings): any;
export declare class DataHcloudStorageBoxSubaccountsSubaccountsAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxSubaccountsSubaccountsAccessSettings | undefined;
    set internalValue(value: DataHcloudStorageBoxSubaccountsSubaccountsAccessSettings | undefined);
    get reachableExternally(): cdktn.IResolvable;
    get readonly(): cdktn.IResolvable;
    get sambaEnabled(): cdktn.IResolvable;
    get sshEnabled(): cdktn.IResolvable;
    get webdavEnabled(): cdktn.IResolvable;
}
export interface DataHcloudStorageBoxSubaccountsSubaccounts {
}
export declare function dataHcloudStorageBoxSubaccountsSubaccountsToTerraform(struct?: DataHcloudStorageBoxSubaccountsSubaccounts): any;
export declare function dataHcloudStorageBoxSubaccountsSubaccountsToHclTerraform(struct?: DataHcloudStorageBoxSubaccountsSubaccounts): any;
export declare class DataHcloudStorageBoxSubaccountsSubaccountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudStorageBoxSubaccountsSubaccounts | undefined;
    set internalValue(value: DataHcloudStorageBoxSubaccountsSubaccounts | undefined);
    private _accessSettings;
    get accessSettings(): DataHcloudStorageBoxSubaccountsSubaccountsAccessSettingsOutputReference;
    get description(): string;
    get homeDirectory(): string;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get server(): string;
    get storageBoxId(): number;
    get username(): string;
}
export declare class DataHcloudStorageBoxSubaccountsSubaccountsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudStorageBoxSubaccountsSubaccountsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_subaccounts hcloud_storage_box_subaccounts}
*/
export declare class DataHcloudStorageBoxSubaccounts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box_subaccounts";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxSubaccounts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxSubaccounts to import
    * @param importFromId The id of the existing DataHcloudStorageBoxSubaccounts that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_subaccounts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxSubaccounts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/storage_box_subaccounts hcloud_storage_box_subaccounts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxSubaccountsConfig
    */
    constructor(scope: Construct, id: string, config: DataHcloudStorageBoxSubaccountsConfig);
    private _storageBoxId?;
    get storageBoxId(): number;
    set storageBoxId(value: number);
    get storageBoxIdInput(): number | undefined;
    private _subaccounts;
    get subaccounts(): DataHcloudStorageBoxSubaccountsSubaccountsList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
