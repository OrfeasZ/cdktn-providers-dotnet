import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HcloudProviderConfig {
    /**
    * The Hetzner Cloud API endpoint, can be used to override the default API Endpoint https://api.hetzner.cloud/v1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#endpoint HcloudProvider#endpoint}
    */
    readonly endpoint?: string;
    /**
    * The Hetzner API endpoint, can be used to override the default API Endpoint https://api.hetzner.com/v1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#endpoint_hetzner HcloudProvider#endpoint_hetzner}
    */
    readonly endpointHetzner?: string;
    /**
    * The type of function to be used during the polling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#poll_function HcloudProvider#poll_function}
    */
    readonly pollFunction?: string;
    /**
    * The interval at which actions are polled by the client. Default `500ms`. Increase this interval if you run into rate limiting errors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#poll_interval HcloudProvider#poll_interval}
    */
    readonly pollInterval?: string;
    /**
    * The Hetzner Cloud API token, can also be specified with the HCLOUD_TOKEN environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#token HcloudProvider#token}
    */
    readonly token?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#alias HcloudProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs hcloud}
*/
export declare class HcloudProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "hcloud";
    /**
    * Generates CDKTN code for importing a HcloudProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HcloudProvider to import
    * @param importFromId The id of the existing HcloudProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HcloudProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs hcloud} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HcloudProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: HcloudProviderConfig);
    private _endpoint?;
    get endpoint(): string | undefined;
    set endpoint(value: string | undefined);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _endpointHetzner?;
    get endpointHetzner(): string | undefined;
    set endpointHetzner(value: string | undefined);
    resetEndpointHetzner(): void;
    get endpointHetznerInput(): string | undefined;
    private _pollFunction?;
    get pollFunction(): string | undefined;
    set pollFunction(value: string | undefined);
    resetPollFunction(): void;
    get pollFunctionInput(): string | undefined;
    private _pollInterval?;
    get pollInterval(): string | undefined;
    set pollInterval(value: string | undefined);
    resetPollInterval(): void;
    get pollIntervalInput(): string | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
