import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#id DataHcloudImage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#include_deprecated DataHcloudImage#include_deprecated}
    */
    readonly includeDeprecated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#most_recent DataHcloudImage#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#name DataHcloudImage#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#selector DataHcloudImage#selector}
    */
    readonly selector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#with_architecture DataHcloudImage#with_architecture}
    */
    readonly withArchitecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#with_selector DataHcloudImage#with_selector}
    */
    readonly withSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#with_status DataHcloudImage#with_status}
    */
    readonly withStatus?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image hcloud_image}
*/
export declare class DataHcloudImage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_image";
    /**
    * Generates CDKTN code for importing a DataHcloudImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudImage to import
    * @param importFromId The id of the existing DataHcloudImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/image hcloud_image} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudImageConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudImageConfig);
    get architecture(): string;
    get created(): string;
    get deprecated(): string;
    get description(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _includeDeprecated?;
    get includeDeprecated(): boolean | cdktn.IResolvable;
    set includeDeprecated(value: boolean | cdktn.IResolvable);
    resetIncludeDeprecated(): void;
    get includeDeprecatedInput(): boolean | cdktn.IResolvable | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get osFlavor(): string;
    get osVersion(): string;
    get rapidDeploy(): cdktn.IResolvable;
    private _selector?;
    get selector(): string;
    set selector(value: string);
    resetSelector(): void;
    get selectorInput(): string | undefined;
    get type(): string;
    private _withArchitecture?;
    get withArchitecture(): string;
    set withArchitecture(value: string);
    resetWithArchitecture(): void;
    get withArchitectureInput(): string | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _withStatus?;
    get withStatus(): string[];
    set withStatus(value: string[]);
    resetWithStatus(): void;
    get withStatusInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
