import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServerNetworkAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Additional IPs to assign to the Server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network#alias_ips ServerNetworkA#alias_ips}
    */
    readonly aliasIps?: string[];
    /**
    * IP to assign to the Server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network#ip ServerNetworkA#ip}
    */
    readonly ip?: string;
    /**
    * ID of the Network to attach the Server to. Using `subnet_id` is preferred. Required if `subnet_id` is not set. If `subnet_id` or `ip` are not set, the Server will be attached to the last subnet (ordered by `ip_range`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network#network_id ServerNetworkA#network_id}
    */
    readonly networkId?: number;
    /**
    * ID of the Server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network#server_id ServerNetworkA#server_id}
    */
    readonly serverId: number;
    /**
    * ID of the Subnet to attach the Server to. Required if `network_id` is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network#subnet_id ServerNetworkA#subnet_id}
    */
    readonly subnetId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network hcloud_server_network}
*/
export declare class ServerNetworkA extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_server_network";
    /**
    * Generates CDKTN code for importing a ServerNetworkA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerNetworkA to import
    * @param importFromId The id of the existing ServerNetworkA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerNetworkA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/server_network hcloud_server_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerNetworkAConfig
    */
    constructor(scope: Construct, id: string, config: ServerNetworkAConfig);
    private _aliasIps?;
    get aliasIps(): string[];
    set aliasIps(value: string[]);
    resetAliasIps(): void;
    get aliasIpsInput(): string[] | undefined;
    get id(): string;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    get macAddress(): string;
    private _networkId?;
    get networkId(): number;
    set networkId(value: number);
    resetNetworkId(): void;
    get networkIdInput(): number | undefined;
    private _serverId?;
    get serverId(): number;
    set serverId(value: number);
    get serverIdInput(): number | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
