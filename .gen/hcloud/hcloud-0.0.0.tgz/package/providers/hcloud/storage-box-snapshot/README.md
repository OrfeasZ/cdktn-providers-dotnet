# `hcloud_storage_box_snapshot`

Refer to the Terraform Registry for docs: [`hcloud_storage_box_snapshot`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot).
