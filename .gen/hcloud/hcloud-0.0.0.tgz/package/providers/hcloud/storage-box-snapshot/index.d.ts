import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageBoxSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the Storage Box Snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot#description StorageBoxSnapshot#description}
    */
    readonly description?: string;
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot#labels StorageBoxSnapshot#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot#storage_box_id StorageBoxSnapshot#storage_box_id}
    */
    readonly storageBoxId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot hcloud_storage_box_snapshot}
*/
export declare class StorageBoxSnapshot extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_storage_box_snapshot";
    /**
    * Generates CDKTN code for importing a StorageBoxSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageBoxSnapshot to import
    * @param importFromId The id of the existing StorageBoxSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageBoxSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/storage_box_snapshot hcloud_storage_box_snapshot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageBoxSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: StorageBoxSnapshotConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): number;
    get isAutomatic(): cdktn.IResolvable;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get name(): string;
    private _storageBoxId?;
    get storageBoxId(): number;
    set storageBoxId(value: number);
    get storageBoxIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
