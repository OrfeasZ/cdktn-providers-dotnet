# `hcloud_volume`

Refer to the Terraform Registry for docs: [`hcloud_volume`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/resources/volume).
