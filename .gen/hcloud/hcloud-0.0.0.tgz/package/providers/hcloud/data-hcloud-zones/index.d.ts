import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudZonesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zones#with_selector DataHcloudZones#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudZonesZonesAuthoritativeNameservers {
}
export declare function dataHcloudZonesZonesAuthoritativeNameserversToTerraform(struct?: DataHcloudZonesZonesAuthoritativeNameservers): any;
export declare function dataHcloudZonesZonesAuthoritativeNameserversToHclTerraform(struct?: DataHcloudZonesZonesAuthoritativeNameservers): any;
export declare class DataHcloudZonesZonesAuthoritativeNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudZonesZonesAuthoritativeNameservers | undefined;
    set internalValue(value: DataHcloudZonesZonesAuthoritativeNameservers | undefined);
    get assigned(): string[];
}
export interface DataHcloudZonesZonesPrimaryNameservers {
}
export declare function dataHcloudZonesZonesPrimaryNameserversToTerraform(struct?: DataHcloudZonesZonesPrimaryNameservers): any;
export declare function dataHcloudZonesZonesPrimaryNameserversToHclTerraform(struct?: DataHcloudZonesZonesPrimaryNameservers): any;
export declare class DataHcloudZonesZonesPrimaryNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudZonesZonesPrimaryNameservers | undefined;
    set internalValue(value: DataHcloudZonesZonesPrimaryNameservers | undefined);
    get address(): string;
    get port(): number;
    get tsigAlgorithm(): string;
    get tsigKey(): string;
}
export declare class DataHcloudZonesZonesPrimaryNameserversList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudZonesZonesPrimaryNameserversOutputReference;
}
export interface DataHcloudZonesZones {
}
export declare function dataHcloudZonesZonesToTerraform(struct?: DataHcloudZonesZones): any;
export declare function dataHcloudZonesZonesToHclTerraform(struct?: DataHcloudZonesZones): any;
export declare class DataHcloudZonesZonesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudZonesZones | undefined;
    set internalValue(value: DataHcloudZonesZones | undefined);
    private _authoritativeNameservers;
    get authoritativeNameservers(): DataHcloudZonesZonesAuthoritativeNameserversOutputReference;
    get deleteProtection(): cdktn.IResolvable;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get mode(): string;
    get name(): string;
    private _primaryNameservers;
    get primaryNameservers(): DataHcloudZonesZonesPrimaryNameserversList;
    get registrar(): string;
    get ttl(): number;
}
export declare class DataHcloudZonesZonesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudZonesZonesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zones hcloud_zones}
*/
export declare class DataHcloudZones extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_zones";
    /**
    * Generates CDKTN code for importing a DataHcloudZones resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudZones to import
    * @param importFromId The id of the existing DataHcloudZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zones hcloud_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudZonesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudZonesConfig);
    get id(): string;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _zones;
    get zones(): DataHcloudZonesZonesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
