import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PrimaryIpConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the resource the Primary IP should be assigned to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#assignee_id PrimaryIp#assignee_id}
    */
    readonly assigneeId?: number;
    /**
    * Type of the resource the Primary IP should be assigned to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#assignee_type PrimaryIp#assignee_type}
    */
    readonly assigneeType?: string;
    /**
    * Whether auto delete is enabled. Setting `auto_delete` to `false` is recommended, because if a server assigned to the managed ip is getting deleted, it will also delete the primary IP which will break the terraform state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#auto_delete PrimaryIp#auto_delete}
    */
    readonly autoDelete: boolean | cdktn.IResolvable;
    /**
    * Name of the Datacenter for the Primary IP. See the [Hetzner Docs](https://docs.hetzner.com/cloud/general/locations/#what-datacenters-are-there) for more details about datacenters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#datacenter PrimaryIp#datacenter}
    */
    readonly datacenter?: string;
    /**
    *  Whether delete protection is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#delete_protection PrimaryIp#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#labels PrimaryIp#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the Location for the Primary IP. See the [Hetzner Docs](https://docs.hetzner.com/cloud/general/locations/#what-locations-are-there) for more details about locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#location PrimaryIp#location}
    */
    readonly location?: string;
    /**
    * Name of the Primary IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#name PrimaryIp#name}
    */
    readonly name: string;
    /**
    * Type of the Primary IP (`ipv4` or `ipv6`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#type PrimaryIp#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip hcloud_primary_ip}
*/
export declare class PrimaryIp extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_primary_ip";
    /**
    * Generates CDKTN code for importing a PrimaryIp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrimaryIp to import
    * @param importFromId The id of the existing PrimaryIp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrimaryIp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip hcloud_primary_ip} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrimaryIpConfig
    */
    constructor(scope: Construct, id: string, config: PrimaryIpConfig);
    private _assigneeId?;
    get assigneeId(): number;
    set assigneeId(value: number);
    resetAssigneeId(): void;
    get assigneeIdInput(): number | undefined;
    private _assigneeType?;
    get assigneeType(): string;
    set assigneeType(value: string);
    resetAssigneeType(): void;
    get assigneeTypeInput(): string | undefined;
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _datacenter?;
    get datacenter(): string;
    set datacenter(value: string);
    resetDatacenter(): void;
    get datacenterInput(): string | undefined;
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    get id(): number;
    get ipAddress(): string;
    get ipNetwork(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
