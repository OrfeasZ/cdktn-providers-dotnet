# `hcloud_primary_ip`

Refer to the Terraform Registry for docs: [`hcloud_primary_ip`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/primary_ip).
