import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageBoxSubaccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Access settings for the Subaccount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#access_settings StorageBoxSubaccount#access_settings}
    */
    readonly accessSettings?: StorageBoxSubaccountAccessSettings;
    /**
    * A description of the Storage Box Subaccount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#description StorageBoxSubaccount#description}
    */
    readonly description?: string;
    /**
    * Home directory of the Storage Box Subaccount. The directory will be created if it doesn't exist yet. Must not include a leading slash (`/`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#home_directory StorageBoxSubaccount#home_directory}
    */
    readonly homeDirectory: string;
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#labels StorageBoxSubaccount#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the Storage Box Subaccount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#name StorageBoxSubaccount#name}
    */
    readonly name?: string;
    /**
    * Password of the Storage Box. For more details, see the [Storage Boxes password policy](https://docs.hetzner.cloud/reference/hetzner#storage-boxes-password-policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#password StorageBoxSubaccount#password}
    */
    readonly password: string;
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#storage_box_id StorageBoxSubaccount#storage_box_id}
    */
    readonly storageBoxId: number;
}
export interface StorageBoxSubaccountAccessSettings {
    /**
    * Whether access from outside the Hetzner network is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#reachable_externally StorageBoxSubaccount#reachable_externally}
    */
    readonly reachableExternally?: boolean | cdktn.IResolvable;
    /**
    * Whether the Subaccount is read-only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#readonly StorageBoxSubaccount#readonly}
    */
    readonly readonly?: boolean | cdktn.IResolvable;
    /**
    * Whether the Samba subsystem is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#samba_enabled StorageBoxSubaccount#samba_enabled}
    */
    readonly sambaEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether the SSH subsystem is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#ssh_enabled StorageBoxSubaccount#ssh_enabled}
    */
    readonly sshEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether the WebDAV subsystem is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#webdav_enabled StorageBoxSubaccount#webdav_enabled}
    */
    readonly webdavEnabled?: boolean | cdktn.IResolvable;
}
export declare function storageBoxSubaccountAccessSettingsToTerraform(struct?: StorageBoxSubaccountAccessSettings | cdktn.IResolvable): any;
export declare function storageBoxSubaccountAccessSettingsToHclTerraform(struct?: StorageBoxSubaccountAccessSettings | cdktn.IResolvable): any;
export declare class StorageBoxSubaccountAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageBoxSubaccountAccessSettings | cdktn.IResolvable | undefined;
    set internalValue(value: StorageBoxSubaccountAccessSettings | cdktn.IResolvable | undefined);
    private _reachableExternally?;
    get reachableExternally(): boolean | cdktn.IResolvable;
    set reachableExternally(value: boolean | cdktn.IResolvable);
    resetReachableExternally(): void;
    get reachableExternallyInput(): boolean | cdktn.IResolvable | undefined;
    private _readonly?;
    get readonly(): boolean | cdktn.IResolvable;
    set readonly(value: boolean | cdktn.IResolvable);
    resetReadonly(): void;
    get readonlyInput(): boolean | cdktn.IResolvable | undefined;
    private _sambaEnabled?;
    get sambaEnabled(): boolean | cdktn.IResolvable;
    set sambaEnabled(value: boolean | cdktn.IResolvable);
    resetSambaEnabled(): void;
    get sambaEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sshEnabled?;
    get sshEnabled(): boolean | cdktn.IResolvable;
    set sshEnabled(value: boolean | cdktn.IResolvable);
    resetSshEnabled(): void;
    get sshEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _webdavEnabled?;
    get webdavEnabled(): boolean | cdktn.IResolvable;
    set webdavEnabled(value: boolean | cdktn.IResolvable);
    resetWebdavEnabled(): void;
    get webdavEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount hcloud_storage_box_subaccount}
*/
export declare class StorageBoxSubaccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_storage_box_subaccount";
    /**
    * Generates CDKTN code for importing a StorageBoxSubaccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageBoxSubaccount to import
    * @param importFromId The id of the existing StorageBoxSubaccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageBoxSubaccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/storage_box_subaccount hcloud_storage_box_subaccount} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageBoxSubaccountConfig
    */
    constructor(scope: Construct, id: string, config: StorageBoxSubaccountConfig);
    private _accessSettings;
    get accessSettings(): StorageBoxSubaccountAccessSettingsOutputReference;
    putAccessSettings(value: StorageBoxSubaccountAccessSettings): void;
    resetAccessSettings(): void;
    get accessSettingsInput(): cdktn.IResolvable | StorageBoxSubaccountAccessSettings | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _homeDirectory?;
    get homeDirectory(): string;
    set homeDirectory(value: string);
    get homeDirectoryInput(): string | undefined;
    get id(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    get server(): string;
    private _storageBoxId?;
    get storageBoxId(): number;
    set storageBoxId(value: number);
    get storageBoxIdInput(): number | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
