import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudServerTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Server Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/server_type#id DataHcloudServerType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Server Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/server_type#name DataHcloudServerType#name}
    */
    readonly name?: string;
}
export interface DataHcloudServerTypeLocations {
}
export declare function dataHcloudServerTypeLocationsToTerraform(struct?: DataHcloudServerTypeLocations): any;
export declare function dataHcloudServerTypeLocationsToHclTerraform(struct?: DataHcloudServerTypeLocations): any;
export declare class DataHcloudServerTypeLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudServerTypeLocations | undefined;
    set internalValue(value: DataHcloudServerTypeLocations | undefined);
    get available(): cdktn.IResolvable;
    get deprecationAnnounced(): string;
    get id(): number;
    get isDeprecated(): cdktn.IResolvable;
    get name(): string;
    get recommended(): cdktn.IResolvable;
    get unavailableAfter(): string;
}
export declare class DataHcloudServerTypeLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudServerTypeLocationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/server_type hcloud_server_type}
*/
export declare class DataHcloudServerType extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_server_type";
    /**
    * Generates CDKTN code for importing a DataHcloudServerType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudServerType to import
    * @param importFromId The id of the existing DataHcloudServerType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/server_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudServerType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.62.0/docs/data-sources/server_type hcloud_server_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudServerTypeConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudServerTypeConfig);
    get architecture(): string;
    get category(): string;
    get cores(): number;
    get cpuType(): string;
    get deprecationAnnounced(): string;
    get description(): string;
    get disk(): number;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get includedTraffic(): number;
    get isDeprecated(): cdktn.IResolvable;
    private _locations;
    get locations(): DataHcloudServerTypeLocationsList;
    get memory(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get storageType(): string;
    get unavailableAfter(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
