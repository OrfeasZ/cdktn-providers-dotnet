# `data_hcloud_zone_rrsets`

Refer to the Terraform Registry for docs: [`data_hcloud_zone_rrsets`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/zone_rrsets).
