import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether delete protection is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#delete_protection Zone#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#labels Zone#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Mode of the Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#mode Zone#mode}
    */
    readonly mode: string;
    /**
    * Name of the Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#name Zone#name}
    */
    readonly name: string;
    /**
    * Primary nameservers of the Zone. Forbidden when mode is primary and required when mode is secondary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#primary_nameservers Zone#primary_nameservers}
    */
    readonly primaryNameservers?: ZonePrimaryNameservers[] | cdktn.IResolvable;
    /**
    * Default Time To Live (TTL) of the Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#ttl Zone#ttl}
    */
    readonly ttl?: number;
}
export interface ZoneAuthoritativeNameservers {
}
export declare function zoneAuthoritativeNameserversToTerraform(struct?: ZoneAuthoritativeNameservers): any;
export declare function zoneAuthoritativeNameserversToHclTerraform(struct?: ZoneAuthoritativeNameservers): any;
export declare class ZoneAuthoritativeNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ZoneAuthoritativeNameservers | undefined;
    set internalValue(value: ZoneAuthoritativeNameservers | undefined);
    get assigned(): string[];
}
export interface ZonePrimaryNameservers {
    /**
    * Public IPv4 or IPv6 address of the primary nameserver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#address Zone#address}
    */
    readonly address: string;
    /**
    * Port of the primary nameserver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#port Zone#port}
    */
    readonly port?: number;
    /**
    * Transaction signature (TSIG) algorithm used to generate the TSIG key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#tsig_algorithm Zone#tsig_algorithm}
    */
    readonly tsigAlgorithm?: string;
    /**
    * Transaction signature (TSIG) key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#tsig_key Zone#tsig_key}
    */
    readonly tsigKey?: string;
}
export declare function zonePrimaryNameserversToTerraform(struct?: ZonePrimaryNameservers | cdktn.IResolvable): any;
export declare function zonePrimaryNameserversToHclTerraform(struct?: ZonePrimaryNameservers | cdktn.IResolvable): any;
export declare class ZonePrimaryNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZonePrimaryNameservers | cdktn.IResolvable | undefined;
    set internalValue(value: ZonePrimaryNameservers | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _tsigAlgorithm?;
    get tsigAlgorithm(): string;
    set tsigAlgorithm(value: string);
    resetTsigAlgorithm(): void;
    get tsigAlgorithmInput(): string | undefined;
    private _tsigKey?;
    get tsigKey(): string;
    set tsigKey(value: string);
    resetTsigKey(): void;
    get tsigKeyInput(): string | undefined;
}
export declare class ZonePrimaryNameserversList extends cdktn.ComplexList {
    internalValue?: ZonePrimaryNameservers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZonePrimaryNameserversOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone hcloud_zone}
*/
export declare class Zone extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_zone";
    /**
    * Generates CDKTN code for importing a Zone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Zone to import
    * @param importFromId The id of the existing Zone that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Zone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone hcloud_zone} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneConfig
    */
    constructor(scope: Construct, id: string, config: ZoneConfig);
    private _authoritativeNameservers;
    get authoritativeNameservers(): ZoneAuthoritativeNameserversOutputReference;
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    get id(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryNameservers;
    get primaryNameservers(): ZonePrimaryNameserversList;
    putPrimaryNameservers(value: ZonePrimaryNameservers[] | cdktn.IResolvable): void;
    resetPrimaryNameservers(): void;
    get primaryNameserversInput(): cdktn.IResolvable | ZonePrimaryNameservers[] | undefined;
    get registrar(): string;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
