# `hcloud_zone`

Refer to the Terraform Registry for docs: [`hcloud_zone`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/zone).
