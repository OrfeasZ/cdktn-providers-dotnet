import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudLoadBalancersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancers#id DataHcloudLoadBalancers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancers#with_selector DataHcloudLoadBalancers#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudLoadBalancersLoadBalancersAlgorithm {
}
export declare function dataHcloudLoadBalancersLoadBalancersAlgorithmToTerraform(struct?: DataHcloudLoadBalancersLoadBalancersAlgorithm): any;
export declare function dataHcloudLoadBalancersLoadBalancersAlgorithmToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancersAlgorithm): any;
export declare class DataHcloudLoadBalancersLoadBalancersAlgorithmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancersAlgorithm | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancersAlgorithm | undefined);
    get type(): string;
}
export declare class DataHcloudLoadBalancersLoadBalancersAlgorithmList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersAlgorithmOutputReference;
}
export interface DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttp {
}
export declare function dataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttpToTerraform(struct?: DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttp): any;
export declare function dataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttpToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttp): any;
export declare class DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttp | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttp | undefined);
    get domain(): string;
    get path(): string;
    get response(): string;
    get statusCodes(): number[];
    get tls(): cdktn.IResolvable;
}
export declare class DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttpOutputReference;
}
export interface DataHcloudLoadBalancersLoadBalancersServiceHealthCheck {
}
export declare function dataHcloudLoadBalancersLoadBalancersServiceHealthCheckToTerraform(struct?: DataHcloudLoadBalancersLoadBalancersServiceHealthCheck): any;
export declare function dataHcloudLoadBalancersLoadBalancersServiceHealthCheckToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancersServiceHealthCheck): any;
export declare class DataHcloudLoadBalancersLoadBalancersServiceHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancersServiceHealthCheck | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancersServiceHealthCheck | undefined);
    private _http;
    get http(): DataHcloudLoadBalancersLoadBalancersServiceHealthCheckHttpList;
    get interval(): number;
    get port(): number;
    get protocol(): string;
    get retries(): number;
    get timeout(): number;
}
export declare class DataHcloudLoadBalancersLoadBalancersServiceHealthCheckList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersServiceHealthCheckOutputReference;
}
export interface DataHcloudLoadBalancersLoadBalancersServiceHttp {
}
export declare function dataHcloudLoadBalancersLoadBalancersServiceHttpToTerraform(struct?: DataHcloudLoadBalancersLoadBalancersServiceHttp): any;
export declare function dataHcloudLoadBalancersLoadBalancersServiceHttpToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancersServiceHttp): any;
export declare class DataHcloudLoadBalancersLoadBalancersServiceHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancersServiceHttp | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancersServiceHttp | undefined);
    get certificates(): string[];
    get cookieLifetime(): number;
    get cookieName(): string;
    get redirectHttp(): cdktn.IResolvable;
    get stickySessions(): cdktn.IResolvable;
    get timeoutIdle(): number;
}
export declare class DataHcloudLoadBalancersLoadBalancersServiceHttpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersServiceHttpOutputReference;
}
export interface DataHcloudLoadBalancersLoadBalancersService {
}
export declare function dataHcloudLoadBalancersLoadBalancersServiceToTerraform(struct?: DataHcloudLoadBalancersLoadBalancersService): any;
export declare function dataHcloudLoadBalancersLoadBalancersServiceToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancersService): any;
export declare class DataHcloudLoadBalancersLoadBalancersServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancersService | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancersService | undefined);
    get destinationPort(): number;
    private _healthCheck;
    get healthCheck(): DataHcloudLoadBalancersLoadBalancersServiceHealthCheckList;
    private _http;
    get http(): DataHcloudLoadBalancersLoadBalancersServiceHttpList;
    get listenPort(): number;
    get protocol(): string;
    get proxyprotocol(): cdktn.IResolvable;
}
export declare class DataHcloudLoadBalancersLoadBalancersServiceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersServiceOutputReference;
}
export interface DataHcloudLoadBalancersLoadBalancersTarget {
}
export declare function dataHcloudLoadBalancersLoadBalancersTargetToTerraform(struct?: DataHcloudLoadBalancersLoadBalancersTarget): any;
export declare function dataHcloudLoadBalancersLoadBalancersTargetToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancersTarget): any;
export declare class DataHcloudLoadBalancersLoadBalancersTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancersTarget | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancersTarget | undefined);
    get labelSelector(): string;
    get serverId(): number;
    get type(): string;
}
export declare class DataHcloudLoadBalancersLoadBalancersTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersTargetOutputReference;
}
export interface DataHcloudLoadBalancersLoadBalancers {
}
export declare function dataHcloudLoadBalancersLoadBalancersToTerraform(struct?: DataHcloudLoadBalancersLoadBalancers): any;
export declare function dataHcloudLoadBalancersLoadBalancersToHclTerraform(struct?: DataHcloudLoadBalancersLoadBalancers): any;
export declare class DataHcloudLoadBalancersLoadBalancersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudLoadBalancersLoadBalancers | undefined;
    set internalValue(value: DataHcloudLoadBalancersLoadBalancers | undefined);
    private _algorithm;
    get algorithm(): DataHcloudLoadBalancersLoadBalancersAlgorithmList;
    get deleteProtection(): cdktn.IResolvable;
    get id(): number;
    get ipv4(): string;
    get ipv6(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get loadBalancerType(): string;
    get location(): string;
    get name(): string;
    get networkId(): number;
    get networkIp(): string;
    get networkZone(): string;
    private _service;
    get service(): DataHcloudLoadBalancersLoadBalancersServiceList;
    private _target;
    get target(): DataHcloudLoadBalancersLoadBalancersTargetList;
}
export declare class DataHcloudLoadBalancersLoadBalancersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudLoadBalancersLoadBalancersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancers hcloud_load_balancers}
*/
export declare class DataHcloudLoadBalancers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_load_balancers";
    /**
    * Generates CDKTN code for importing a DataHcloudLoadBalancers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudLoadBalancers to import
    * @param importFromId The id of the existing DataHcloudLoadBalancers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudLoadBalancers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/data-sources/load_balancers hcloud_load_balancers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudLoadBalancersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudLoadBalancersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loadBalancers;
    get loadBalancers(): DataHcloudLoadBalancersLoadBalancersList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
