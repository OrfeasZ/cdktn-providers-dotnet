import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudSshKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Fingerprint of the SSH Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key#fingerprint DataHcloudSshKey#fingerprint}
    */
    readonly fingerprint?: string;
    /**
    * ID of the SSH Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key#id DataHcloudSshKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the SSH Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key#name DataHcloudSshKey#name}
    */
    readonly name?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key#selector DataHcloudSshKey#selector}
    */
    readonly selector?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key#with_selector DataHcloudSshKey#with_selector}
    */
    readonly withSelector?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key hcloud_ssh_key}
*/
export declare class DataHcloudSshKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_ssh_key";
    /**
    * Generates CDKTN code for importing a DataHcloudSshKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudSshKey to import
    * @param importFromId The id of the existing DataHcloudSshKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudSshKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/ssh_key hcloud_ssh_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudSshKeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudSshKeyConfig);
    private _fingerprint?;
    get fingerprint(): string;
    set fingerprint(value: string);
    resetFingerprint(): void;
    get fingerprintInput(): string | undefined;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get publicKey(): string;
    private _selector?;
    get selector(): string;
    set selector(value: string);
    resetSelector(): void;
    get selectorInput(): string | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
