import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Storage Box Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_type#id DataHcloudStorageBoxType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Storage Box Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_type#name DataHcloudStorageBoxType#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_type hcloud_storage_box_type}
*/
export declare class DataHcloudStorageBoxType extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box_type";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxType to import
    * @param importFromId The id of the existing DataHcloudStorageBoxType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/data-sources/storage_box_type hcloud_storage_box_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxTypeConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudStorageBoxTypeConfig);
    get automaticSnapshotLimit(): number;
    get deprecationAnnounced(): string;
    get description(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get isDeprecated(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get size(): number;
    get snapshotLimit(): number;
    get subaccountsLimit(): number;
    get unavailableAfter(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
