import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ZoneRrsetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether change protection is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#change_protection ZoneRrset#change_protection}
    */
    readonly changeProtection?: boolean | cdktn.IResolvable;
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#labels ZoneRrset#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#name ZoneRrset#name}
    */
    readonly name: string;
    /**
    * Records of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#records ZoneRrset#records}
    */
    readonly records: ZoneRrsetRecords[] | cdktn.IResolvable;
    /**
    * Time To Live (TTL) of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#ttl ZoneRrset#ttl}
    */
    readonly ttl?: number;
    /**
    * Type of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#type ZoneRrset#type}
    */
    readonly type: string;
    /**
    * ID or Name of the parent Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#zone ZoneRrset#zone}
    */
    readonly zone: string;
}
export interface ZoneRrsetRecords {
    /**
    * Comment of the record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#comment ZoneRrset#comment}
    */
    readonly comment?: string;
    /**
    * Value of the record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#value ZoneRrset#value}
    */
    readonly value: string;
}
export declare function zoneRrsetRecordsToTerraform(struct?: ZoneRrsetRecords | cdktn.IResolvable): any;
export declare function zoneRrsetRecordsToHclTerraform(struct?: ZoneRrsetRecords | cdktn.IResolvable): any;
export declare class ZoneRrsetRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZoneRrsetRecords | cdktn.IResolvable | undefined;
    set internalValue(value: ZoneRrsetRecords | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ZoneRrsetRecordsList extends cdktn.ComplexList {
    internalValue?: ZoneRrsetRecords[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZoneRrsetRecordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset hcloud_zone_rrset}
*/
export declare class ZoneRrset extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_zone_rrset";
    /**
    * Generates CDKTN code for importing a ZoneRrset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ZoneRrset to import
    * @param importFromId The id of the existing ZoneRrset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ZoneRrset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.63.0/docs/resources/zone_rrset hcloud_zone_rrset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneRrsetConfig
    */
    constructor(scope: Construct, id: string, config: ZoneRrsetConfig);
    private _changeProtection?;
    get changeProtection(): boolean | cdktn.IResolvable;
    set changeProtection(value: boolean | cdktn.IResolvable);
    resetChangeProtection(): void;
    get changeProtectionInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _records;
    get records(): ZoneRrsetRecordsList;
    putRecords(value: ZoneRrsetRecords[] | cdktn.IResolvable): void;
    get recordsInput(): cdktn.IResolvable | ZoneRrsetRecords[] | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
