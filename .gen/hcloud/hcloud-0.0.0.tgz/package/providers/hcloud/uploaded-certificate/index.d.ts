import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UploadedCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate#certificate UploadedCertificate#certificate}
    */
    readonly certificate: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate#id UploadedCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate#labels UploadedCertificate#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate#name UploadedCertificate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate#private_key UploadedCertificate#private_key}
    */
    readonly privateKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate hcloud_uploaded_certificate}
*/
export declare class UploadedCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_uploaded_certificate";
    /**
    * Generates CDKTN code for importing a UploadedCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UploadedCertificate to import
    * @param importFromId The id of the existing UploadedCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UploadedCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.64.0/docs/resources/uploaded_certificate hcloud_uploaded_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UploadedCertificateConfig
    */
    constructor(scope: Construct, id: string, config: UploadedCertificateConfig);
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    get certificateInput(): string | undefined;
    get created(): string;
    get domainNames(): string[];
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get notValidAfter(): string;
    get notValidBefore(): string;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
