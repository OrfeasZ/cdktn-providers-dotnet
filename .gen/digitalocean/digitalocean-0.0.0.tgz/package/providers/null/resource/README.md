# `null_resource`

Refer to the Terraform Registry for docs: [`null_resource`](https://registry.terraform.io/providers/hashicorp/null/3.3.0/docs/resources/resource).
