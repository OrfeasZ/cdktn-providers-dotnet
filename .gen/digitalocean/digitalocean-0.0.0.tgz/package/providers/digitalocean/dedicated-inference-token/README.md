# `digitalocean_dedicated_inference_token`

Refer to the Terraform Registry for docs: [`digitalocean_dedicated_inference_token`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token).
