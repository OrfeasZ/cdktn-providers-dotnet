import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DedicatedInferenceTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the dedicated inference endpoint this token belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token#dedicated_inference_id DedicatedInferenceToken#dedicated_inference_id}
    */
    readonly dedicatedInferenceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token#id DedicatedInferenceToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A human-readable name for the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token#name DedicatedInferenceToken#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token digitalocean_dedicated_inference_token}
*/
export declare class DedicatedInferenceToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_dedicated_inference_token";
    /**
    * Generates CDKTN code for importing a DedicatedInferenceToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DedicatedInferenceToken to import
    * @param importFromId The id of the existing DedicatedInferenceToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DedicatedInferenceToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference_token digitalocean_dedicated_inference_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DedicatedInferenceTokenConfig
    */
    constructor(scope: Construct, id: string, config: DedicatedInferenceTokenConfig);
    get createdAt(): string;
    private _dedicatedInferenceId?;
    get dedicatedInferenceId(): string;
    set dedicatedInferenceId(value: string);
    get dedicatedInferenceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get token(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
