# `data_digitalocean_gradientai_knowledge_base_data_sources`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_knowledge_base_data_sources`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base_data_sources).
