import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiKnowledgeBaseDataSourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_knowledge_base_data_sources#id DataDigitaloceanGradientaiKnowledgeBaseDataSources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_knowledge_base_data_sources#knowledge_base_uuid DataDigitaloceanGradientaiKnowledgeBaseDataSources#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource | undefined);
    get originalFileName(): string;
    get sizeInBytes(): string;
    get storedObjectKey(): string;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource | undefined);
    get bucketName(): string;
    get itemPath(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource | undefined);
    get baseUrl(): string;
    get crawlingOption(): string;
    get embedMedia(): cdktn.IResolvable;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasources {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasources): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasources): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasources | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasources | undefined);
    get createdAt(): string;
    private _fileUploadDataSource;
    get fileUploadDataSource(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceList;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobList;
    private _spacesDataSource;
    get spacesDataSource(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceList;
    get updatedAt(): string;
    get uuid(): string;
    private _webCrawlerDataSource;
    get webCrawlerDataSource(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceList;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_knowledge_base_data_sources digitalocean_gradientai_knowledge_base_data_sources}
*/
export declare class DataDigitaloceanGradientaiKnowledgeBaseDataSources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_knowledge_base_data_sources";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiKnowledgeBaseDataSources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiKnowledgeBaseDataSources to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiKnowledgeBaseDataSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_knowledge_base_data_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiKnowledgeBaseDataSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_knowledge_base_data_sources digitalocean_gradientai_knowledge_base_data_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiKnowledgeBaseDataSourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiKnowledgeBaseDataSourcesConfig);
    private _datasources;
    get datasources(): DataDigitaloceanGradientaiKnowledgeBaseDataSourcesDatasourcesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
