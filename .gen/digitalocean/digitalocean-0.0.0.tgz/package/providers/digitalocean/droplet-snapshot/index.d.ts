import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DropletSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/droplet_snapshot#droplet_id DropletSnapshot#droplet_id}
    */
    readonly dropletId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/droplet_snapshot#id DropletSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/droplet_snapshot#name DropletSnapshot#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/droplet_snapshot digitalocean_droplet_snapshot}
*/
export declare class DropletSnapshot extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_droplet_snapshot";
    /**
    * Generates CDKTN code for importing a DropletSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DropletSnapshot to import
    * @param importFromId The id of the existing DropletSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/droplet_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DropletSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/droplet_snapshot digitalocean_droplet_snapshot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DropletSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: DropletSnapshotConfig);
    get createdAt(): string;
    private _dropletId?;
    get dropletId(): string;
    set dropletId(value: string);
    get dropletIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get minDiskSize(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get regions(): string[];
    get size(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
