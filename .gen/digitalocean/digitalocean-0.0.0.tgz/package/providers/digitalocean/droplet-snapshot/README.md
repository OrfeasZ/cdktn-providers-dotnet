# `digitalocean_droplet_snapshot`

Refer to the Terraform Registry for docs: [`digitalocean_droplet_snapshot`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_snapshot).
