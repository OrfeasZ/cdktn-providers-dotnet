# `digitalocean_container_registry`

Refer to the Terraform Registry for docs: [`digitalocean_container_registry`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/container_registry).
