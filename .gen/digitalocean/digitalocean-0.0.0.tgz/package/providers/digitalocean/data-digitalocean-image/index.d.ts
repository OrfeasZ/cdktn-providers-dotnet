import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * id of the image
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image#id DataDigitaloceanImage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * name of the image
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image#name DataDigitaloceanImage#name}
    */
    readonly name?: string;
    /**
    * slug of the image
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image#slug DataDigitaloceanImage#slug}
    */
    readonly slug?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image#source DataDigitaloceanImage#source}
    */
    readonly source?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image digitalocean_image}
*/
export declare class DataDigitaloceanImage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_image";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanImage to import
    * @param importFromId The id of the existing DataDigitaloceanImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/image digitalocean_image} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanImageConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanImageConfig);
    get created(): string;
    get description(): string;
    get distribution(): string;
    get errorMessage(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get image(): string;
    get minDiskSize(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get private(): cdktn.IResolvable;
    get regions(): string[];
    get sizeGigabytes(): number;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    resetSlug(): void;
    get slugInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    get status(): string;
    get tags(): string[];
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
