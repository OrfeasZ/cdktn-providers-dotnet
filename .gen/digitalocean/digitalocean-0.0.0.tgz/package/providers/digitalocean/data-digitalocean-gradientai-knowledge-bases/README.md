# `data_digitalocean_gradientai_knowledge_bases`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_knowledge_bases`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases).
