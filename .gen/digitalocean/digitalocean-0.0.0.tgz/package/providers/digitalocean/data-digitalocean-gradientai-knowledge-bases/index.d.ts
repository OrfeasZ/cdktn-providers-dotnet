import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiKnowledgeBasesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#id DataDigitaloceanGradientaiKnowledgeBases#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#filter DataDigitaloceanGradientaiKnowledgeBases#filter}
    */
    readonly filter?: DataDigitaloceanGradientaiKnowledgeBasesFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#sort DataDigitaloceanGradientaiKnowledgeBases#sort}
    */
    readonly sort?: DataDigitaloceanGradientaiKnowledgeBasesSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBases {
}
export declare function dataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBases): any;
export declare function dataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBases): any;
export declare class DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktn.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBasesFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#all DataDigitaloceanGradientaiKnowledgeBases#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#key DataDigitaloceanGradientaiKnowledgeBases#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#match_by DataDigitaloceanGradientaiKnowledgeBases#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#values DataDigitaloceanGradientaiKnowledgeBases#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGradientaiKnowledgeBasesFilterToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiKnowledgeBasesFilterToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiKnowledgeBasesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBasesFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBasesFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGradientaiKnowledgeBasesFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiKnowledgeBasesFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBasesFilterOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBasesSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#direction DataDigitaloceanGradientaiKnowledgeBases#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#key DataDigitaloceanGradientaiKnowledgeBases#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGradientaiKnowledgeBasesSortToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiKnowledgeBasesSortToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBasesSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiKnowledgeBasesSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBasesSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBasesSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiKnowledgeBasesSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiKnowledgeBasesSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBasesSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases digitalocean_gradientai_knowledge_bases}
*/
export declare class DataDigitaloceanGradientaiKnowledgeBases extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_knowledge_bases";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiKnowledgeBases resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiKnowledgeBases to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiKnowledgeBases that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiKnowledgeBases to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_bases digitalocean_gradientai_knowledge_bases} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiKnowledgeBasesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGradientaiKnowledgeBasesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiKnowledgeBasesKnowledgeBasesList;
    private _filter;
    get filter(): DataDigitaloceanGradientaiKnowledgeBasesFilterList;
    putFilter(value: DataDigitaloceanGradientaiKnowledgeBasesFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanGradientaiKnowledgeBasesFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGradientaiKnowledgeBasesSortList;
    putSort(value: DataDigitaloceanGradientaiKnowledgeBasesSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanGradientaiKnowledgeBasesSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
