import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the GradientAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#agent_id GradientaiFunction#agent_id}
    */
    readonly agentId: string;
    /**
    * The region where the GradientAI resource will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#description GradientaiFunction#description}
    */
    readonly description: string;
    /**
    * The model to use for the GradientAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#faas_name GradientaiFunction#faas_name}
    */
    readonly faasName?: string;
    /**
    * The current status of the GradientAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#faas_namespace GradientaiFunction#faas_namespace}
    */
    readonly faasNamespace: string;
    /**
    * The creation timestamp of the GradientAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#function_name GradientaiFunction#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#id GradientaiFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The input schema of the GradientAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#input_schema GradientaiFunction#input_schema}
    */
    readonly inputSchema: string;
    /**
    * The output schema of the GradientAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#output_schema GradientaiFunction#output_schema}
    */
    readonly outputSchema?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function digitalocean_gradientai_function}
*/
export declare class GradientaiFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_function";
    /**
    * Generates CDKTN code for importing a GradientaiFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiFunction to import
    * @param importFromId The id of the existing GradientaiFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_function digitalocean_gradientai_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiFunctionConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiFunctionConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _faasName?;
    get faasName(): string;
    set faasName(value: string);
    resetFaasName(): void;
    get faasNameInput(): string | undefined;
    private _faasNamespace?;
    get faasNamespace(): string;
    set faasNamespace(value: string);
    get faasNamespaceInput(): string | undefined;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    get functionUuid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputSchema?;
    get inputSchema(): string;
    set inputSchema(value: string);
    get inputSchemaInput(): string | undefined;
    private _outputSchema?;
    get outputSchema(): string;
    set outputSchema(value: string);
    resetOutputSchema(): void;
    get outputSchemaInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
