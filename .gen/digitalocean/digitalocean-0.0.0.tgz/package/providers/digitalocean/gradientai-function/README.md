# `digitalocean_gradientai_function`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_function`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_function).
