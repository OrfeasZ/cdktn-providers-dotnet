# `digitalocean_gradientai_function`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_function`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_function).
