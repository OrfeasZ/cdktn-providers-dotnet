import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FloatingIpConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip#droplet_id FloatingIp#droplet_id}
    */
    readonly dropletId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip#id FloatingIp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip#ip_address FloatingIp#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip#region FloatingIp#region}
    */
    readonly region: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip digitalocean_floating_ip}
*/
export declare class FloatingIp extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_floating_ip";
    /**
    * Generates CDKTN code for importing a FloatingIp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FloatingIp to import
    * @param importFromId The id of the existing FloatingIp that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FloatingIp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/floating_ip digitalocean_floating_ip} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FloatingIpConfig
    */
    constructor(scope: Construct, id: string, config: FloatingIpConfig);
    private _dropletId?;
    get dropletId(): number;
    set dropletId(value: number);
    resetDropletId(): void;
    get dropletIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
