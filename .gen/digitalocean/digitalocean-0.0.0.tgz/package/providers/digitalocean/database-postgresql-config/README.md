# `digitalocean_database_postgresql_config`

Refer to the Terraform Registry for docs: [`digitalocean_database_postgresql_config`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_postgresql_config).
