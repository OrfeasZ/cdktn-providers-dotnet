import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabasePostgresqlConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_analyze_scale_factor DatabasePostgresqlConfig#autovacuum_analyze_scale_factor}
    */
    readonly autovacuumAnalyzeScaleFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_analyze_threshold DatabasePostgresqlConfig#autovacuum_analyze_threshold}
    */
    readonly autovacuumAnalyzeThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_freeze_max_age DatabasePostgresqlConfig#autovacuum_freeze_max_age}
    */
    readonly autovacuumFreezeMaxAge?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_max_workers DatabasePostgresqlConfig#autovacuum_max_workers}
    */
    readonly autovacuumMaxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_naptime DatabasePostgresqlConfig#autovacuum_naptime}
    */
    readonly autovacuumNaptime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_vacuum_cost_delay DatabasePostgresqlConfig#autovacuum_vacuum_cost_delay}
    */
    readonly autovacuumVacuumCostDelay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_vacuum_cost_limit DatabasePostgresqlConfig#autovacuum_vacuum_cost_limit}
    */
    readonly autovacuumVacuumCostLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_vacuum_scale_factor DatabasePostgresqlConfig#autovacuum_vacuum_scale_factor}
    */
    readonly autovacuumVacuumScaleFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autovacuum_vacuum_threshold DatabasePostgresqlConfig#autovacuum_vacuum_threshold}
    */
    readonly autovacuumVacuumThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#backup_hour DatabasePostgresqlConfig#backup_hour}
    */
    readonly backupHour?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#backup_minute DatabasePostgresqlConfig#backup_minute}
    */
    readonly backupMinute?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#bgwriter_delay DatabasePostgresqlConfig#bgwriter_delay}
    */
    readonly bgwriterDelay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#bgwriter_flush_after DatabasePostgresqlConfig#bgwriter_flush_after}
    */
    readonly bgwriterFlushAfter?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#bgwriter_lru_maxpages DatabasePostgresqlConfig#bgwriter_lru_maxpages}
    */
    readonly bgwriterLruMaxpages?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#bgwriter_lru_multiplier DatabasePostgresqlConfig#bgwriter_lru_multiplier}
    */
    readonly bgwriterLruMultiplier?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#cluster_id DatabasePostgresqlConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#deadlock_timeout DatabasePostgresqlConfig#deadlock_timeout}
    */
    readonly deadlockTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#default_toast_compression DatabasePostgresqlConfig#default_toast_compression}
    */
    readonly defaultToastCompression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#id DatabasePostgresqlConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#idle_in_transaction_session_timeout DatabasePostgresqlConfig#idle_in_transaction_session_timeout}
    */
    readonly idleInTransactionSessionTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#jit DatabasePostgresqlConfig#jit}
    */
    readonly jit?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#log_autovacuum_min_duration DatabasePostgresqlConfig#log_autovacuum_min_duration}
    */
    readonly logAutovacuumMinDuration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#log_error_verbosity DatabasePostgresqlConfig#log_error_verbosity}
    */
    readonly logErrorVerbosity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#log_line_prefix DatabasePostgresqlConfig#log_line_prefix}
    */
    readonly logLinePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#log_min_duration_statement DatabasePostgresqlConfig#log_min_duration_statement}
    */
    readonly logMinDurationStatement?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_files_per_process DatabasePostgresqlConfig#max_files_per_process}
    */
    readonly maxFilesPerProcess?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_locks_per_transaction DatabasePostgresqlConfig#max_locks_per_transaction}
    */
    readonly maxLocksPerTransaction?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_logical_replication_workers DatabasePostgresqlConfig#max_logical_replication_workers}
    */
    readonly maxLogicalReplicationWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_parallel_workers DatabasePostgresqlConfig#max_parallel_workers}
    */
    readonly maxParallelWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_parallel_workers_per_gather DatabasePostgresqlConfig#max_parallel_workers_per_gather}
    */
    readonly maxParallelWorkersPerGather?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_pred_locks_per_transaction DatabasePostgresqlConfig#max_pred_locks_per_transaction}
    */
    readonly maxPredLocksPerTransaction?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_prepared_transactions DatabasePostgresqlConfig#max_prepared_transactions}
    */
    readonly maxPreparedTransactions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_replication_slots DatabasePostgresqlConfig#max_replication_slots}
    */
    readonly maxReplicationSlots?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_stack_depth DatabasePostgresqlConfig#max_stack_depth}
    */
    readonly maxStackDepth?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_standby_archive_delay DatabasePostgresqlConfig#max_standby_archive_delay}
    */
    readonly maxStandbyArchiveDelay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_standby_streaming_delay DatabasePostgresqlConfig#max_standby_streaming_delay}
    */
    readonly maxStandbyStreamingDelay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_wal_senders DatabasePostgresqlConfig#max_wal_senders}
    */
    readonly maxWalSenders?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_worker_processes DatabasePostgresqlConfig#max_worker_processes}
    */
    readonly maxWorkerProcesses?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#pg_partman_bgw_interval DatabasePostgresqlConfig#pg_partman_bgw_interval}
    */
    readonly pgPartmanBgwInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#pg_partman_bgw_role DatabasePostgresqlConfig#pg_partman_bgw_role}
    */
    readonly pgPartmanBgwRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#pg_stat_statements_track DatabasePostgresqlConfig#pg_stat_statements_track}
    */
    readonly pgStatStatementsTrack?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#shared_buffers_percentage DatabasePostgresqlConfig#shared_buffers_percentage}
    */
    readonly sharedBuffersPercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#temp_file_limit DatabasePostgresqlConfig#temp_file_limit}
    */
    readonly tempFileLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#timezone DatabasePostgresqlConfig#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#track_activity_query_size DatabasePostgresqlConfig#track_activity_query_size}
    */
    readonly trackActivityQuerySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#track_commit_timestamp DatabasePostgresqlConfig#track_commit_timestamp}
    */
    readonly trackCommitTimestamp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#track_functions DatabasePostgresqlConfig#track_functions}
    */
    readonly trackFunctions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#track_io_timing DatabasePostgresqlConfig#track_io_timing}
    */
    readonly trackIoTiming?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#wal_sender_timeout DatabasePostgresqlConfig#wal_sender_timeout}
    */
    readonly walSenderTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#wal_writer_delay DatabasePostgresqlConfig#wal_writer_delay}
    */
    readonly walWriterDelay?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#work_mem DatabasePostgresqlConfig#work_mem}
    */
    readonly workMem?: number;
    /**
    * pgbouncer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#pgbouncer DatabasePostgresqlConfig#pgbouncer}
    */
    readonly pgbouncer?: DatabasePostgresqlConfigPgbouncer[] | cdktn.IResolvable;
    /**
    * timescaledb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#timescaledb DatabasePostgresqlConfig#timescaledb}
    */
    readonly timescaledb?: DatabasePostgresqlConfigTimescaledb;
}
export interface DatabasePostgresqlConfigPgbouncer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autodb_idle_timeout DatabasePostgresqlConfig#autodb_idle_timeout}
    */
    readonly autodbIdleTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autodb_max_db_connections DatabasePostgresqlConfig#autodb_max_db_connections}
    */
    readonly autodbMaxDbConnections?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autodb_pool_mode DatabasePostgresqlConfig#autodb_pool_mode}
    */
    readonly autodbPoolMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#autodb_pool_size DatabasePostgresqlConfig#autodb_pool_size}
    */
    readonly autodbPoolSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#ignore_startup_parameters DatabasePostgresqlConfig#ignore_startup_parameters}
    */
    readonly ignoreStartupParameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#min_pool_size DatabasePostgresqlConfig#min_pool_size}
    */
    readonly minPoolSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#server_idle_timeout DatabasePostgresqlConfig#server_idle_timeout}
    */
    readonly serverIdleTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#server_lifetime DatabasePostgresqlConfig#server_lifetime}
    */
    readonly serverLifetime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#server_reset_query_always DatabasePostgresqlConfig#server_reset_query_always}
    */
    readonly serverResetQueryAlways?: boolean | cdktn.IResolvable;
}
export declare function databasePostgresqlConfigPgbouncerToTerraform(struct?: DatabasePostgresqlConfigPgbouncer | cdktn.IResolvable): any;
export declare function databasePostgresqlConfigPgbouncerToHclTerraform(struct?: DatabasePostgresqlConfigPgbouncer | cdktn.IResolvable): any;
export declare class DatabasePostgresqlConfigPgbouncerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabasePostgresqlConfigPgbouncer | cdktn.IResolvable | undefined;
    set internalValue(value: DatabasePostgresqlConfigPgbouncer | cdktn.IResolvable | undefined);
    private _autodbIdleTimeout?;
    get autodbIdleTimeout(): number;
    set autodbIdleTimeout(value: number);
    resetAutodbIdleTimeout(): void;
    get autodbIdleTimeoutInput(): number | undefined;
    private _autodbMaxDbConnections?;
    get autodbMaxDbConnections(): number;
    set autodbMaxDbConnections(value: number);
    resetAutodbMaxDbConnections(): void;
    get autodbMaxDbConnectionsInput(): number | undefined;
    private _autodbPoolMode?;
    get autodbPoolMode(): string;
    set autodbPoolMode(value: string);
    resetAutodbPoolMode(): void;
    get autodbPoolModeInput(): string | undefined;
    private _autodbPoolSize?;
    get autodbPoolSize(): number;
    set autodbPoolSize(value: number);
    resetAutodbPoolSize(): void;
    get autodbPoolSizeInput(): number | undefined;
    private _ignoreStartupParameters?;
    get ignoreStartupParameters(): string[];
    set ignoreStartupParameters(value: string[]);
    resetIgnoreStartupParameters(): void;
    get ignoreStartupParametersInput(): string[] | undefined;
    private _minPoolSize?;
    get minPoolSize(): number;
    set minPoolSize(value: number);
    resetMinPoolSize(): void;
    get minPoolSizeInput(): number | undefined;
    private _serverIdleTimeout?;
    get serverIdleTimeout(): number;
    set serverIdleTimeout(value: number);
    resetServerIdleTimeout(): void;
    get serverIdleTimeoutInput(): number | undefined;
    private _serverLifetime?;
    get serverLifetime(): number;
    set serverLifetime(value: number);
    resetServerLifetime(): void;
    get serverLifetimeInput(): number | undefined;
    private _serverResetQueryAlways?;
    get serverResetQueryAlways(): boolean | cdktn.IResolvable;
    set serverResetQueryAlways(value: boolean | cdktn.IResolvable);
    resetServerResetQueryAlways(): void;
    get serverResetQueryAlwaysInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DatabasePostgresqlConfigPgbouncerList extends cdktn.ComplexList {
    internalValue?: DatabasePostgresqlConfigPgbouncer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabasePostgresqlConfigPgbouncerOutputReference;
}
export interface DatabasePostgresqlConfigTimescaledb {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#max_background_workers DatabasePostgresqlConfig#max_background_workers}
    */
    readonly maxBackgroundWorkers?: number;
}
export declare function databasePostgresqlConfigTimescaledbToTerraform(struct?: DatabasePostgresqlConfigTimescaledbOutputReference | DatabasePostgresqlConfigTimescaledb): any;
export declare function databasePostgresqlConfigTimescaledbToHclTerraform(struct?: DatabasePostgresqlConfigTimescaledbOutputReference | DatabasePostgresqlConfigTimescaledb): any;
export declare class DatabasePostgresqlConfigTimescaledbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabasePostgresqlConfigTimescaledb | undefined;
    set internalValue(value: DatabasePostgresqlConfigTimescaledb | undefined);
    private _maxBackgroundWorkers?;
    get maxBackgroundWorkers(): number;
    set maxBackgroundWorkers(value: number);
    resetMaxBackgroundWorkers(): void;
    get maxBackgroundWorkersInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config digitalocean_database_postgresql_config}
*/
export declare class DatabasePostgresqlConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_postgresql_config";
    /**
    * Generates CDKTN code for importing a DatabasePostgresqlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabasePostgresqlConfig to import
    * @param importFromId The id of the existing DatabasePostgresqlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabasePostgresqlConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config digitalocean_database_postgresql_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabasePostgresqlConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabasePostgresqlConfigConfig);
    private _autovacuumAnalyzeScaleFactor?;
    get autovacuumAnalyzeScaleFactor(): number;
    set autovacuumAnalyzeScaleFactor(value: number);
    resetAutovacuumAnalyzeScaleFactor(): void;
    get autovacuumAnalyzeScaleFactorInput(): number | undefined;
    private _autovacuumAnalyzeThreshold?;
    get autovacuumAnalyzeThreshold(): number;
    set autovacuumAnalyzeThreshold(value: number);
    resetAutovacuumAnalyzeThreshold(): void;
    get autovacuumAnalyzeThresholdInput(): number | undefined;
    private _autovacuumFreezeMaxAge?;
    get autovacuumFreezeMaxAge(): number;
    set autovacuumFreezeMaxAge(value: number);
    resetAutovacuumFreezeMaxAge(): void;
    get autovacuumFreezeMaxAgeInput(): number | undefined;
    private _autovacuumMaxWorkers?;
    get autovacuumMaxWorkers(): number;
    set autovacuumMaxWorkers(value: number);
    resetAutovacuumMaxWorkers(): void;
    get autovacuumMaxWorkersInput(): number | undefined;
    private _autovacuumNaptime?;
    get autovacuumNaptime(): number;
    set autovacuumNaptime(value: number);
    resetAutovacuumNaptime(): void;
    get autovacuumNaptimeInput(): number | undefined;
    private _autovacuumVacuumCostDelay?;
    get autovacuumVacuumCostDelay(): number;
    set autovacuumVacuumCostDelay(value: number);
    resetAutovacuumVacuumCostDelay(): void;
    get autovacuumVacuumCostDelayInput(): number | undefined;
    private _autovacuumVacuumCostLimit?;
    get autovacuumVacuumCostLimit(): number;
    set autovacuumVacuumCostLimit(value: number);
    resetAutovacuumVacuumCostLimit(): void;
    get autovacuumVacuumCostLimitInput(): number | undefined;
    private _autovacuumVacuumScaleFactor?;
    get autovacuumVacuumScaleFactor(): number;
    set autovacuumVacuumScaleFactor(value: number);
    resetAutovacuumVacuumScaleFactor(): void;
    get autovacuumVacuumScaleFactorInput(): number | undefined;
    private _autovacuumVacuumThreshold?;
    get autovacuumVacuumThreshold(): number;
    set autovacuumVacuumThreshold(value: number);
    resetAutovacuumVacuumThreshold(): void;
    get autovacuumVacuumThresholdInput(): number | undefined;
    private _backupHour?;
    get backupHour(): number;
    set backupHour(value: number);
    resetBackupHour(): void;
    get backupHourInput(): number | undefined;
    private _backupMinute?;
    get backupMinute(): number;
    set backupMinute(value: number);
    resetBackupMinute(): void;
    get backupMinuteInput(): number | undefined;
    private _bgwriterDelay?;
    get bgwriterDelay(): number;
    set bgwriterDelay(value: number);
    resetBgwriterDelay(): void;
    get bgwriterDelayInput(): number | undefined;
    private _bgwriterFlushAfter?;
    get bgwriterFlushAfter(): number;
    set bgwriterFlushAfter(value: number);
    resetBgwriterFlushAfter(): void;
    get bgwriterFlushAfterInput(): number | undefined;
    private _bgwriterLruMaxpages?;
    get bgwriterLruMaxpages(): number;
    set bgwriterLruMaxpages(value: number);
    resetBgwriterLruMaxpages(): void;
    get bgwriterLruMaxpagesInput(): number | undefined;
    private _bgwriterLruMultiplier?;
    get bgwriterLruMultiplier(): number;
    set bgwriterLruMultiplier(value: number);
    resetBgwriterLruMultiplier(): void;
    get bgwriterLruMultiplierInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _deadlockTimeout?;
    get deadlockTimeout(): number;
    set deadlockTimeout(value: number);
    resetDeadlockTimeout(): void;
    get deadlockTimeoutInput(): number | undefined;
    private _defaultToastCompression?;
    get defaultToastCompression(): string;
    set defaultToastCompression(value: string);
    resetDefaultToastCompression(): void;
    get defaultToastCompressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleInTransactionSessionTimeout?;
    get idleInTransactionSessionTimeout(): number;
    set idleInTransactionSessionTimeout(value: number);
    resetIdleInTransactionSessionTimeout(): void;
    get idleInTransactionSessionTimeoutInput(): number | undefined;
    private _jit?;
    get jit(): boolean | cdktn.IResolvable;
    set jit(value: boolean | cdktn.IResolvable);
    resetJit(): void;
    get jitInput(): boolean | cdktn.IResolvable | undefined;
    private _logAutovacuumMinDuration?;
    get logAutovacuumMinDuration(): number;
    set logAutovacuumMinDuration(value: number);
    resetLogAutovacuumMinDuration(): void;
    get logAutovacuumMinDurationInput(): number | undefined;
    private _logErrorVerbosity?;
    get logErrorVerbosity(): string;
    set logErrorVerbosity(value: string);
    resetLogErrorVerbosity(): void;
    get logErrorVerbosityInput(): string | undefined;
    private _logLinePrefix?;
    get logLinePrefix(): string;
    set logLinePrefix(value: string);
    resetLogLinePrefix(): void;
    get logLinePrefixInput(): string | undefined;
    private _logMinDurationStatement?;
    get logMinDurationStatement(): number;
    set logMinDurationStatement(value: number);
    resetLogMinDurationStatement(): void;
    get logMinDurationStatementInput(): number | undefined;
    private _maxFilesPerProcess?;
    get maxFilesPerProcess(): number;
    set maxFilesPerProcess(value: number);
    resetMaxFilesPerProcess(): void;
    get maxFilesPerProcessInput(): number | undefined;
    private _maxLocksPerTransaction?;
    get maxLocksPerTransaction(): number;
    set maxLocksPerTransaction(value: number);
    resetMaxLocksPerTransaction(): void;
    get maxLocksPerTransactionInput(): number | undefined;
    private _maxLogicalReplicationWorkers?;
    get maxLogicalReplicationWorkers(): number;
    set maxLogicalReplicationWorkers(value: number);
    resetMaxLogicalReplicationWorkers(): void;
    get maxLogicalReplicationWorkersInput(): number | undefined;
    private _maxParallelWorkers?;
    get maxParallelWorkers(): number;
    set maxParallelWorkers(value: number);
    resetMaxParallelWorkers(): void;
    get maxParallelWorkersInput(): number | undefined;
    private _maxParallelWorkersPerGather?;
    get maxParallelWorkersPerGather(): number;
    set maxParallelWorkersPerGather(value: number);
    resetMaxParallelWorkersPerGather(): void;
    get maxParallelWorkersPerGatherInput(): number | undefined;
    private _maxPredLocksPerTransaction?;
    get maxPredLocksPerTransaction(): number;
    set maxPredLocksPerTransaction(value: number);
    resetMaxPredLocksPerTransaction(): void;
    get maxPredLocksPerTransactionInput(): number | undefined;
    private _maxPreparedTransactions?;
    get maxPreparedTransactions(): number;
    set maxPreparedTransactions(value: number);
    resetMaxPreparedTransactions(): void;
    get maxPreparedTransactionsInput(): number | undefined;
    private _maxReplicationSlots?;
    get maxReplicationSlots(): number;
    set maxReplicationSlots(value: number);
    resetMaxReplicationSlots(): void;
    get maxReplicationSlotsInput(): number | undefined;
    private _maxStackDepth?;
    get maxStackDepth(): number;
    set maxStackDepth(value: number);
    resetMaxStackDepth(): void;
    get maxStackDepthInput(): number | undefined;
    private _maxStandbyArchiveDelay?;
    get maxStandbyArchiveDelay(): number;
    set maxStandbyArchiveDelay(value: number);
    resetMaxStandbyArchiveDelay(): void;
    get maxStandbyArchiveDelayInput(): number | undefined;
    private _maxStandbyStreamingDelay?;
    get maxStandbyStreamingDelay(): number;
    set maxStandbyStreamingDelay(value: number);
    resetMaxStandbyStreamingDelay(): void;
    get maxStandbyStreamingDelayInput(): number | undefined;
    private _maxWalSenders?;
    get maxWalSenders(): number;
    set maxWalSenders(value: number);
    resetMaxWalSenders(): void;
    get maxWalSendersInput(): number | undefined;
    private _maxWorkerProcesses?;
    get maxWorkerProcesses(): number;
    set maxWorkerProcesses(value: number);
    resetMaxWorkerProcesses(): void;
    get maxWorkerProcessesInput(): number | undefined;
    private _pgPartmanBgwInterval?;
    get pgPartmanBgwInterval(): number;
    set pgPartmanBgwInterval(value: number);
    resetPgPartmanBgwInterval(): void;
    get pgPartmanBgwIntervalInput(): number | undefined;
    private _pgPartmanBgwRole?;
    get pgPartmanBgwRole(): string;
    set pgPartmanBgwRole(value: string);
    resetPgPartmanBgwRole(): void;
    get pgPartmanBgwRoleInput(): string | undefined;
    private _pgStatStatementsTrack?;
    get pgStatStatementsTrack(): string;
    set pgStatStatementsTrack(value: string);
    resetPgStatStatementsTrack(): void;
    get pgStatStatementsTrackInput(): string | undefined;
    private _sharedBuffersPercentage?;
    get sharedBuffersPercentage(): number;
    set sharedBuffersPercentage(value: number);
    resetSharedBuffersPercentage(): void;
    get sharedBuffersPercentageInput(): number | undefined;
    private _tempFileLimit?;
    get tempFileLimit(): number;
    set tempFileLimit(value: number);
    resetTempFileLimit(): void;
    get tempFileLimitInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _trackActivityQuerySize?;
    get trackActivityQuerySize(): number;
    set trackActivityQuerySize(value: number);
    resetTrackActivityQuerySize(): void;
    get trackActivityQuerySizeInput(): number | undefined;
    private _trackCommitTimestamp?;
    get trackCommitTimestamp(): string;
    set trackCommitTimestamp(value: string);
    resetTrackCommitTimestamp(): void;
    get trackCommitTimestampInput(): string | undefined;
    private _trackFunctions?;
    get trackFunctions(): string;
    set trackFunctions(value: string);
    resetTrackFunctions(): void;
    get trackFunctionsInput(): string | undefined;
    private _trackIoTiming?;
    get trackIoTiming(): string;
    set trackIoTiming(value: string);
    resetTrackIoTiming(): void;
    get trackIoTimingInput(): string | undefined;
    private _walSenderTimeout?;
    get walSenderTimeout(): number;
    set walSenderTimeout(value: number);
    resetWalSenderTimeout(): void;
    get walSenderTimeoutInput(): number | undefined;
    private _walWriterDelay?;
    get walWriterDelay(): number;
    set walWriterDelay(value: number);
    resetWalWriterDelay(): void;
    get walWriterDelayInput(): number | undefined;
    private _workMem?;
    get workMem(): number;
    set workMem(value: number);
    resetWorkMem(): void;
    get workMemInput(): number | undefined;
    private _pgbouncer;
    get pgbouncer(): DatabasePostgresqlConfigPgbouncerList;
    putPgbouncer(value: DatabasePostgresqlConfigPgbouncer[] | cdktn.IResolvable): void;
    resetPgbouncer(): void;
    get pgbouncerInput(): cdktn.IResolvable | DatabasePostgresqlConfigPgbouncer[] | undefined;
    private _timescaledb;
    get timescaledb(): DatabasePostgresqlConfigTimescaledbOutputReference;
    putTimescaledb(value: DatabasePostgresqlConfigTimescaledb): void;
    resetTimescaledb(): void;
    get timescaledbInput(): DatabasePostgresqlConfigTimescaledb | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
