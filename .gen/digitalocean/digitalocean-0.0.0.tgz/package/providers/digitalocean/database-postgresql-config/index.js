"use strict";
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabasePostgresqlConfig = exports.DatabasePostgresqlConfigTimescaledbOutputReference = exports.DatabasePostgresqlConfigPgbouncerList = exports.DatabasePostgresqlConfigPgbouncerOutputReference = void 0;
exports.databasePostgresqlConfigPgbouncerToTerraform = databasePostgresqlConfigPgbouncerToTerraform;
exports.databasePostgresqlConfigPgbouncerToHclTerraform = databasePostgresqlConfigPgbouncerToHclTerraform;
exports.databasePostgresqlConfigTimescaledbToTerraform = databasePostgresqlConfigTimescaledbToTerraform;
exports.databasePostgresqlConfigTimescaledbToHclTerraform = databasePostgresqlConfigTimescaledbToHclTerraform;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const cdktn = require("cdktn");
function databasePostgresqlConfigPgbouncerToTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    return {
        autodb_idle_timeout: cdktn.numberToTerraform(struct.autodbIdleTimeout),
        autodb_max_db_connections: cdktn.numberToTerraform(struct.autodbMaxDbConnections),
        autodb_pool_mode: cdktn.stringToTerraform(struct.autodbPoolMode),
        autodb_pool_size: cdktn.numberToTerraform(struct.autodbPoolSize),
        ignore_startup_parameters: cdktn.listMapper(cdktn.stringToTerraform, false)(struct.ignoreStartupParameters),
        min_pool_size: cdktn.numberToTerraform(struct.minPoolSize),
        server_idle_timeout: cdktn.numberToTerraform(struct.serverIdleTimeout),
        server_lifetime: cdktn.numberToTerraform(struct.serverLifetime),
        server_reset_query_always: cdktn.booleanToTerraform(struct.serverResetQueryAlways),
    };
}
function databasePostgresqlConfigPgbouncerToHclTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    const attrs = {
        autodb_idle_timeout: {
            value: cdktn.numberToHclTerraform(struct.autodbIdleTimeout),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        autodb_max_db_connections: {
            value: cdktn.numberToHclTerraform(struct.autodbMaxDbConnections),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        autodb_pool_mode: {
            value: cdktn.stringToHclTerraform(struct.autodbPoolMode),
            isBlock: false,
            type: "simple",
            storageClassType: "string",
        },
        autodb_pool_size: {
            value: cdktn.numberToHclTerraform(struct.autodbPoolSize),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        ignore_startup_parameters: {
            value: cdktn.listMapperHcl(cdktn.stringToHclTerraform, false)(struct.ignoreStartupParameters),
            isBlock: false,
            type: "set",
            storageClassType: "stringList",
        },
        min_pool_size: {
            value: cdktn.numberToHclTerraform(struct.minPoolSize),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        server_idle_timeout: {
            value: cdktn.numberToHclTerraform(struct.serverIdleTimeout),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        server_lifetime: {
            value: cdktn.numberToHclTerraform(struct.serverLifetime),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
        server_reset_query_always: {
            value: cdktn.booleanToHclTerraform(struct.serverResetQueryAlways),
            isBlock: false,
            type: "simple",
            storageClassType: "boolean",
        },
    };
    // remove undefined attributes
    return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
}
class DatabasePostgresqlConfigPgbouncerOutputReference extends cdktn.ComplexObject {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource, terraformAttribute, complexObjectIndex, complexObjectIsFromSet) {
        super(terraformResource, terraformAttribute, complexObjectIsFromSet, complexObjectIndex);
        this.isEmptyObject = false;
    }
    get internalValue() {
        if (this.resolvableValue) {
            return this.resolvableValue;
        }
        let hasAnyValues = this.isEmptyObject;
        const internalValueResult = {};
        if (this._autodbIdleTimeout !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbIdleTimeout = this._autodbIdleTimeout;
        }
        if (this._autodbMaxDbConnections !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbMaxDbConnections = this._autodbMaxDbConnections;
        }
        if (this._autodbPoolMode !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbPoolMode = this._autodbPoolMode;
        }
        if (this._autodbPoolSize !== undefined) {
            hasAnyValues = true;
            internalValueResult.autodbPoolSize = this._autodbPoolSize;
        }
        if (this._ignoreStartupParameters !== undefined) {
            hasAnyValues = true;
            internalValueResult.ignoreStartupParameters = this._ignoreStartupParameters;
        }
        if (this._minPoolSize !== undefined) {
            hasAnyValues = true;
            internalValueResult.minPoolSize = this._minPoolSize;
        }
        if (this._serverIdleTimeout !== undefined) {
            hasAnyValues = true;
            internalValueResult.serverIdleTimeout = this._serverIdleTimeout;
        }
        if (this._serverLifetime !== undefined) {
            hasAnyValues = true;
            internalValueResult.serverLifetime = this._serverLifetime;
        }
        if (this._serverResetQueryAlways !== undefined) {
            hasAnyValues = true;
            internalValueResult.serverResetQueryAlways = this._serverResetQueryAlways;
        }
        return hasAnyValues ? internalValueResult : undefined;
    }
    set internalValue(value) {
        if (value === undefined) {
            this.isEmptyObject = false;
            this.resolvableValue = undefined;
            this._autodbIdleTimeout = undefined;
            this._autodbMaxDbConnections = undefined;
            this._autodbPoolMode = undefined;
            this._autodbPoolSize = undefined;
            this._ignoreStartupParameters = undefined;
            this._minPoolSize = undefined;
            this._serverIdleTimeout = undefined;
            this._serverLifetime = undefined;
            this._serverResetQueryAlways = undefined;
        }
        else if (cdktn.Tokenization.isResolvable(value)) {
            this.isEmptyObject = false;
            this.resolvableValue = value;
        }
        else {
            this.isEmptyObject = Object.keys(value).length === 0;
            this.resolvableValue = undefined;
            this._autodbIdleTimeout = value.autodbIdleTimeout;
            this._autodbMaxDbConnections = value.autodbMaxDbConnections;
            this._autodbPoolMode = value.autodbPoolMode;
            this._autodbPoolSize = value.autodbPoolSize;
            this._ignoreStartupParameters = value.ignoreStartupParameters;
            this._minPoolSize = value.minPoolSize;
            this._serverIdleTimeout = value.serverIdleTimeout;
            this._serverLifetime = value.serverLifetime;
            this._serverResetQueryAlways = value.serverResetQueryAlways;
        }
    }
    get autodbIdleTimeout() {
        return this.getNumberAttribute('autodb_idle_timeout');
    }
    set autodbIdleTimeout(value) {
        this._autodbIdleTimeout = value;
    }
    resetAutodbIdleTimeout() {
        this._autodbIdleTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbIdleTimeoutInput() {
        return this._autodbIdleTimeout;
    }
    get autodbMaxDbConnections() {
        return this.getNumberAttribute('autodb_max_db_connections');
    }
    set autodbMaxDbConnections(value) {
        this._autodbMaxDbConnections = value;
    }
    resetAutodbMaxDbConnections() {
        this._autodbMaxDbConnections = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbMaxDbConnectionsInput() {
        return this._autodbMaxDbConnections;
    }
    get autodbPoolMode() {
        return this.getStringAttribute('autodb_pool_mode');
    }
    set autodbPoolMode(value) {
        this._autodbPoolMode = value;
    }
    resetAutodbPoolMode() {
        this._autodbPoolMode = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbPoolModeInput() {
        return this._autodbPoolMode;
    }
    get autodbPoolSize() {
        return this.getNumberAttribute('autodb_pool_size');
    }
    set autodbPoolSize(value) {
        this._autodbPoolSize = value;
    }
    resetAutodbPoolSize() {
        this._autodbPoolSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autodbPoolSizeInput() {
        return this._autodbPoolSize;
    }
    get ignoreStartupParameters() {
        return cdktn.Fn.tolist(this.getListAttribute('ignore_startup_parameters'));
    }
    set ignoreStartupParameters(value) {
        this._ignoreStartupParameters = value;
    }
    resetIgnoreStartupParameters() {
        this._ignoreStartupParameters = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ignoreStartupParametersInput() {
        return this._ignoreStartupParameters;
    }
    get minPoolSize() {
        return this.getNumberAttribute('min_pool_size');
    }
    set minPoolSize(value) {
        this._minPoolSize = value;
    }
    resetMinPoolSize() {
        this._minPoolSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get minPoolSizeInput() {
        return this._minPoolSize;
    }
    get serverIdleTimeout() {
        return this.getNumberAttribute('server_idle_timeout');
    }
    set serverIdleTimeout(value) {
        this._serverIdleTimeout = value;
    }
    resetServerIdleTimeout() {
        this._serverIdleTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get serverIdleTimeoutInput() {
        return this._serverIdleTimeout;
    }
    get serverLifetime() {
        return this.getNumberAttribute('server_lifetime');
    }
    set serverLifetime(value) {
        this._serverLifetime = value;
    }
    resetServerLifetime() {
        this._serverLifetime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get serverLifetimeInput() {
        return this._serverLifetime;
    }
    get serverResetQueryAlways() {
        return this.getBooleanAttribute('server_reset_query_always');
    }
    set serverResetQueryAlways(value) {
        this._serverResetQueryAlways = value;
    }
    resetServerResetQueryAlways() {
        this._serverResetQueryAlways = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get serverResetQueryAlwaysInput() {
        return this._serverResetQueryAlways;
    }
}
exports.DatabasePostgresqlConfigPgbouncerOutputReference = DatabasePostgresqlConfigPgbouncerOutputReference;
_a = JSII_RTTI_SYMBOL_1;
DatabasePostgresqlConfigPgbouncerOutputReference[_a] = { fqn: "digitalocean.databasePostgresqlConfig.DatabasePostgresqlConfigPgbouncerOutputReference", version: "0.0.0" };
class DatabasePostgresqlConfigPgbouncerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource, terraformAttribute, wrapsSet) {
        super(terraformResource, terraformAttribute, wrapsSet);
    }
    /**
    * @param index the index of the item to return
    */
    get(index) {
        return new DatabasePostgresqlConfigPgbouncerOutputReference(this.terraformResource, this.terraformAttribute, index, this.wrapsSet);
    }
}
exports.DatabasePostgresqlConfigPgbouncerList = DatabasePostgresqlConfigPgbouncerList;
_b = JSII_RTTI_SYMBOL_1;
DatabasePostgresqlConfigPgbouncerList[_b] = { fqn: "digitalocean.databasePostgresqlConfig.DatabasePostgresqlConfigPgbouncerList", version: "0.0.0" };
function databasePostgresqlConfigTimescaledbToTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    return {
        max_background_workers: cdktn.numberToTerraform(struct.maxBackgroundWorkers),
    };
}
function databasePostgresqlConfigTimescaledbToHclTerraform(struct) {
    if (!cdktn.canInspect(struct) || cdktn.Tokenization.isResolvable(struct)) {
        return struct;
    }
    if (cdktn.isComplexElement(struct)) {
        throw new Error("A complex element was used as configuration, this is not supported: https://cdk.tf/complex-object-as-configuration");
    }
    const attrs = {
        max_background_workers: {
            value: cdktn.numberToHclTerraform(struct.maxBackgroundWorkers),
            isBlock: false,
            type: "simple",
            storageClassType: "number",
        },
    };
    // remove undefined attributes
    return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
}
class DatabasePostgresqlConfigTimescaledbOutputReference extends cdktn.ComplexObject {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource, terraformAttribute) {
        super(terraformResource, terraformAttribute, false, 0);
        this.isEmptyObject = false;
    }
    get internalValue() {
        let hasAnyValues = this.isEmptyObject;
        const internalValueResult = {};
        if (this._maxBackgroundWorkers !== undefined) {
            hasAnyValues = true;
            internalValueResult.maxBackgroundWorkers = this._maxBackgroundWorkers;
        }
        return hasAnyValues ? internalValueResult : undefined;
    }
    set internalValue(value) {
        if (value === undefined) {
            this.isEmptyObject = false;
            this._maxBackgroundWorkers = undefined;
        }
        else {
            this.isEmptyObject = Object.keys(value).length === 0;
            this._maxBackgroundWorkers = value.maxBackgroundWorkers;
        }
    }
    get maxBackgroundWorkers() {
        return this.getNumberAttribute('max_background_workers');
    }
    set maxBackgroundWorkers(value) {
        this._maxBackgroundWorkers = value;
    }
    resetMaxBackgroundWorkers() {
        this._maxBackgroundWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxBackgroundWorkersInput() {
        return this._maxBackgroundWorkers;
    }
}
exports.DatabasePostgresqlConfigTimescaledbOutputReference = DatabasePostgresqlConfigTimescaledbOutputReference;
_c = JSII_RTTI_SYMBOL_1;
DatabasePostgresqlConfigTimescaledbOutputReference[_c] = { fqn: "digitalocean.databasePostgresqlConfig.DatabasePostgresqlConfigTimescaledbOutputReference", version: "0.0.0" };
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config digitalocean_database_postgresql_config}
*/
class DatabasePostgresqlConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabasePostgresqlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabasePostgresqlConfig to import
    * @param importFromId The id of the existing DatabasePostgresqlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabasePostgresqlConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_postgresql_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_postgresql_config digitalocean_database_postgresql_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabasePostgresqlConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_postgresql_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        // pgbouncer - computed: false, optional: true, required: false
        this._pgbouncer = new DatabasePostgresqlConfigPgbouncerList(this, "pgbouncer", false);
        // timescaledb - computed: false, optional: true, required: false
        this._timescaledb = new DatabasePostgresqlConfigTimescaledbOutputReference(this, "timescaledb");
        this._autovacuumAnalyzeScaleFactor = config.autovacuumAnalyzeScaleFactor;
        this._autovacuumAnalyzeThreshold = config.autovacuumAnalyzeThreshold;
        this._autovacuumFreezeMaxAge = config.autovacuumFreezeMaxAge;
        this._autovacuumMaxWorkers = config.autovacuumMaxWorkers;
        this._autovacuumNaptime = config.autovacuumNaptime;
        this._autovacuumVacuumCostDelay = config.autovacuumVacuumCostDelay;
        this._autovacuumVacuumCostLimit = config.autovacuumVacuumCostLimit;
        this._autovacuumVacuumScaleFactor = config.autovacuumVacuumScaleFactor;
        this._autovacuumVacuumThreshold = config.autovacuumVacuumThreshold;
        this._backupHour = config.backupHour;
        this._backupMinute = config.backupMinute;
        this._bgwriterDelay = config.bgwriterDelay;
        this._bgwriterFlushAfter = config.bgwriterFlushAfter;
        this._bgwriterLruMaxpages = config.bgwriterLruMaxpages;
        this._bgwriterLruMultiplier = config.bgwriterLruMultiplier;
        this._clusterId = config.clusterId;
        this._deadlockTimeout = config.deadlockTimeout;
        this._defaultToastCompression = config.defaultToastCompression;
        this._id = config.id;
        this._idleInTransactionSessionTimeout = config.idleInTransactionSessionTimeout;
        this._jit = config.jit;
        this._logAutovacuumMinDuration = config.logAutovacuumMinDuration;
        this._logErrorVerbosity = config.logErrorVerbosity;
        this._logLinePrefix = config.logLinePrefix;
        this._logMinDurationStatement = config.logMinDurationStatement;
        this._maxFilesPerProcess = config.maxFilesPerProcess;
        this._maxLocksPerTransaction = config.maxLocksPerTransaction;
        this._maxLogicalReplicationWorkers = config.maxLogicalReplicationWorkers;
        this._maxParallelWorkers = config.maxParallelWorkers;
        this._maxParallelWorkersPerGather = config.maxParallelWorkersPerGather;
        this._maxPredLocksPerTransaction = config.maxPredLocksPerTransaction;
        this._maxPreparedTransactions = config.maxPreparedTransactions;
        this._maxReplicationSlots = config.maxReplicationSlots;
        this._maxStackDepth = config.maxStackDepth;
        this._maxStandbyArchiveDelay = config.maxStandbyArchiveDelay;
        this._maxStandbyStreamingDelay = config.maxStandbyStreamingDelay;
        this._maxWalSenders = config.maxWalSenders;
        this._maxWorkerProcesses = config.maxWorkerProcesses;
        this._pgPartmanBgwInterval = config.pgPartmanBgwInterval;
        this._pgPartmanBgwRole = config.pgPartmanBgwRole;
        this._pgStatStatementsTrack = config.pgStatStatementsTrack;
        this._sharedBuffersPercentage = config.sharedBuffersPercentage;
        this._tempFileLimit = config.tempFileLimit;
        this._timezone = config.timezone;
        this._trackActivityQuerySize = config.trackActivityQuerySize;
        this._trackCommitTimestamp = config.trackCommitTimestamp;
        this._trackFunctions = config.trackFunctions;
        this._trackIoTiming = config.trackIoTiming;
        this._walSenderTimeout = config.walSenderTimeout;
        this._walWriterDelay = config.walWriterDelay;
        this._workMem = config.workMem;
        this._pgbouncer.internalValue = config.pgbouncer;
        this._timescaledb.internalValue = config.timescaledb;
    }
    get autovacuumAnalyzeScaleFactor() {
        return this.getNumberAttribute('autovacuum_analyze_scale_factor');
    }
    set autovacuumAnalyzeScaleFactor(value) {
        this._autovacuumAnalyzeScaleFactor = value;
    }
    resetAutovacuumAnalyzeScaleFactor() {
        this._autovacuumAnalyzeScaleFactor = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumAnalyzeScaleFactorInput() {
        return this._autovacuumAnalyzeScaleFactor;
    }
    get autovacuumAnalyzeThreshold() {
        return this.getNumberAttribute('autovacuum_analyze_threshold');
    }
    set autovacuumAnalyzeThreshold(value) {
        this._autovacuumAnalyzeThreshold = value;
    }
    resetAutovacuumAnalyzeThreshold() {
        this._autovacuumAnalyzeThreshold = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumAnalyzeThresholdInput() {
        return this._autovacuumAnalyzeThreshold;
    }
    get autovacuumFreezeMaxAge() {
        return this.getNumberAttribute('autovacuum_freeze_max_age');
    }
    set autovacuumFreezeMaxAge(value) {
        this._autovacuumFreezeMaxAge = value;
    }
    resetAutovacuumFreezeMaxAge() {
        this._autovacuumFreezeMaxAge = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumFreezeMaxAgeInput() {
        return this._autovacuumFreezeMaxAge;
    }
    get autovacuumMaxWorkers() {
        return this.getNumberAttribute('autovacuum_max_workers');
    }
    set autovacuumMaxWorkers(value) {
        this._autovacuumMaxWorkers = value;
    }
    resetAutovacuumMaxWorkers() {
        this._autovacuumMaxWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumMaxWorkersInput() {
        return this._autovacuumMaxWorkers;
    }
    get autovacuumNaptime() {
        return this.getNumberAttribute('autovacuum_naptime');
    }
    set autovacuumNaptime(value) {
        this._autovacuumNaptime = value;
    }
    resetAutovacuumNaptime() {
        this._autovacuumNaptime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumNaptimeInput() {
        return this._autovacuumNaptime;
    }
    get autovacuumVacuumCostDelay() {
        return this.getNumberAttribute('autovacuum_vacuum_cost_delay');
    }
    set autovacuumVacuumCostDelay(value) {
        this._autovacuumVacuumCostDelay = value;
    }
    resetAutovacuumVacuumCostDelay() {
        this._autovacuumVacuumCostDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumCostDelayInput() {
        return this._autovacuumVacuumCostDelay;
    }
    get autovacuumVacuumCostLimit() {
        return this.getNumberAttribute('autovacuum_vacuum_cost_limit');
    }
    set autovacuumVacuumCostLimit(value) {
        this._autovacuumVacuumCostLimit = value;
    }
    resetAutovacuumVacuumCostLimit() {
        this._autovacuumVacuumCostLimit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumCostLimitInput() {
        return this._autovacuumVacuumCostLimit;
    }
    get autovacuumVacuumScaleFactor() {
        return this.getNumberAttribute('autovacuum_vacuum_scale_factor');
    }
    set autovacuumVacuumScaleFactor(value) {
        this._autovacuumVacuumScaleFactor = value;
    }
    resetAutovacuumVacuumScaleFactor() {
        this._autovacuumVacuumScaleFactor = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumScaleFactorInput() {
        return this._autovacuumVacuumScaleFactor;
    }
    get autovacuumVacuumThreshold() {
        return this.getNumberAttribute('autovacuum_vacuum_threshold');
    }
    set autovacuumVacuumThreshold(value) {
        this._autovacuumVacuumThreshold = value;
    }
    resetAutovacuumVacuumThreshold() {
        this._autovacuumVacuumThreshold = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autovacuumVacuumThresholdInput() {
        return this._autovacuumVacuumThreshold;
    }
    get backupHour() {
        return this.getNumberAttribute('backup_hour');
    }
    set backupHour(value) {
        this._backupHour = value;
    }
    resetBackupHour() {
        this._backupHour = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupHourInput() {
        return this._backupHour;
    }
    get backupMinute() {
        return this.getNumberAttribute('backup_minute');
    }
    set backupMinute(value) {
        this._backupMinute = value;
    }
    resetBackupMinute() {
        this._backupMinute = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupMinuteInput() {
        return this._backupMinute;
    }
    get bgwriterDelay() {
        return this.getNumberAttribute('bgwriter_delay');
    }
    set bgwriterDelay(value) {
        this._bgwriterDelay = value;
    }
    resetBgwriterDelay() {
        this._bgwriterDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterDelayInput() {
        return this._bgwriterDelay;
    }
    get bgwriterFlushAfter() {
        return this.getNumberAttribute('bgwriter_flush_after');
    }
    set bgwriterFlushAfter(value) {
        this._bgwriterFlushAfter = value;
    }
    resetBgwriterFlushAfter() {
        this._bgwriterFlushAfter = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterFlushAfterInput() {
        return this._bgwriterFlushAfter;
    }
    get bgwriterLruMaxpages() {
        return this.getNumberAttribute('bgwriter_lru_maxpages');
    }
    set bgwriterLruMaxpages(value) {
        this._bgwriterLruMaxpages = value;
    }
    resetBgwriterLruMaxpages() {
        this._bgwriterLruMaxpages = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterLruMaxpagesInput() {
        return this._bgwriterLruMaxpages;
    }
    get bgwriterLruMultiplier() {
        return this.getNumberAttribute('bgwriter_lru_multiplier');
    }
    set bgwriterLruMultiplier(value) {
        this._bgwriterLruMultiplier = value;
    }
    resetBgwriterLruMultiplier() {
        this._bgwriterLruMultiplier = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get bgwriterLruMultiplierInput() {
        return this._bgwriterLruMultiplier;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get deadlockTimeout() {
        return this.getNumberAttribute('deadlock_timeout');
    }
    set deadlockTimeout(value) {
        this._deadlockTimeout = value;
    }
    resetDeadlockTimeout() {
        this._deadlockTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get deadlockTimeoutInput() {
        return this._deadlockTimeout;
    }
    get defaultToastCompression() {
        return this.getStringAttribute('default_toast_compression');
    }
    set defaultToastCompression(value) {
        this._defaultToastCompression = value;
    }
    resetDefaultToastCompression() {
        this._defaultToastCompression = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get defaultToastCompressionInput() {
        return this._defaultToastCompression;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get idleInTransactionSessionTimeout() {
        return this.getNumberAttribute('idle_in_transaction_session_timeout');
    }
    set idleInTransactionSessionTimeout(value) {
        this._idleInTransactionSessionTimeout = value;
    }
    resetIdleInTransactionSessionTimeout() {
        this._idleInTransactionSessionTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idleInTransactionSessionTimeoutInput() {
        return this._idleInTransactionSessionTimeout;
    }
    get jit() {
        return this.getBooleanAttribute('jit');
    }
    set jit(value) {
        this._jit = value;
    }
    resetJit() {
        this._jit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get jitInput() {
        return this._jit;
    }
    get logAutovacuumMinDuration() {
        return this.getNumberAttribute('log_autovacuum_min_duration');
    }
    set logAutovacuumMinDuration(value) {
        this._logAutovacuumMinDuration = value;
    }
    resetLogAutovacuumMinDuration() {
        this._logAutovacuumMinDuration = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logAutovacuumMinDurationInput() {
        return this._logAutovacuumMinDuration;
    }
    get logErrorVerbosity() {
        return this.getStringAttribute('log_error_verbosity');
    }
    set logErrorVerbosity(value) {
        this._logErrorVerbosity = value;
    }
    resetLogErrorVerbosity() {
        this._logErrorVerbosity = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logErrorVerbosityInput() {
        return this._logErrorVerbosity;
    }
    get logLinePrefix() {
        return this.getStringAttribute('log_line_prefix');
    }
    set logLinePrefix(value) {
        this._logLinePrefix = value;
    }
    resetLogLinePrefix() {
        this._logLinePrefix = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logLinePrefixInput() {
        return this._logLinePrefix;
    }
    get logMinDurationStatement() {
        return this.getNumberAttribute('log_min_duration_statement');
    }
    set logMinDurationStatement(value) {
        this._logMinDurationStatement = value;
    }
    resetLogMinDurationStatement() {
        this._logMinDurationStatement = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logMinDurationStatementInput() {
        return this._logMinDurationStatement;
    }
    get maxFilesPerProcess() {
        return this.getNumberAttribute('max_files_per_process');
    }
    set maxFilesPerProcess(value) {
        this._maxFilesPerProcess = value;
    }
    resetMaxFilesPerProcess() {
        this._maxFilesPerProcess = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxFilesPerProcessInput() {
        return this._maxFilesPerProcess;
    }
    get maxLocksPerTransaction() {
        return this.getNumberAttribute('max_locks_per_transaction');
    }
    set maxLocksPerTransaction(value) {
        this._maxLocksPerTransaction = value;
    }
    resetMaxLocksPerTransaction() {
        this._maxLocksPerTransaction = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxLocksPerTransactionInput() {
        return this._maxLocksPerTransaction;
    }
    get maxLogicalReplicationWorkers() {
        return this.getNumberAttribute('max_logical_replication_workers');
    }
    set maxLogicalReplicationWorkers(value) {
        this._maxLogicalReplicationWorkers = value;
    }
    resetMaxLogicalReplicationWorkers() {
        this._maxLogicalReplicationWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxLogicalReplicationWorkersInput() {
        return this._maxLogicalReplicationWorkers;
    }
    get maxParallelWorkers() {
        return this.getNumberAttribute('max_parallel_workers');
    }
    set maxParallelWorkers(value) {
        this._maxParallelWorkers = value;
    }
    resetMaxParallelWorkers() {
        this._maxParallelWorkers = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxParallelWorkersInput() {
        return this._maxParallelWorkers;
    }
    get maxParallelWorkersPerGather() {
        return this.getNumberAttribute('max_parallel_workers_per_gather');
    }
    set maxParallelWorkersPerGather(value) {
        this._maxParallelWorkersPerGather = value;
    }
    resetMaxParallelWorkersPerGather() {
        this._maxParallelWorkersPerGather = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxParallelWorkersPerGatherInput() {
        return this._maxParallelWorkersPerGather;
    }
    get maxPredLocksPerTransaction() {
        return this.getNumberAttribute('max_pred_locks_per_transaction');
    }
    set maxPredLocksPerTransaction(value) {
        this._maxPredLocksPerTransaction = value;
    }
    resetMaxPredLocksPerTransaction() {
        this._maxPredLocksPerTransaction = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxPredLocksPerTransactionInput() {
        return this._maxPredLocksPerTransaction;
    }
    get maxPreparedTransactions() {
        return this.getNumberAttribute('max_prepared_transactions');
    }
    set maxPreparedTransactions(value) {
        this._maxPreparedTransactions = value;
    }
    resetMaxPreparedTransactions() {
        this._maxPreparedTransactions = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxPreparedTransactionsInput() {
        return this._maxPreparedTransactions;
    }
    get maxReplicationSlots() {
        return this.getNumberAttribute('max_replication_slots');
    }
    set maxReplicationSlots(value) {
        this._maxReplicationSlots = value;
    }
    resetMaxReplicationSlots() {
        this._maxReplicationSlots = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxReplicationSlotsInput() {
        return this._maxReplicationSlots;
    }
    get maxStackDepth() {
        return this.getNumberAttribute('max_stack_depth');
    }
    set maxStackDepth(value) {
        this._maxStackDepth = value;
    }
    resetMaxStackDepth() {
        this._maxStackDepth = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxStackDepthInput() {
        return this._maxStackDepth;
    }
    get maxStandbyArchiveDelay() {
        return this.getNumberAttribute('max_standby_archive_delay');
    }
    set maxStandbyArchiveDelay(value) {
        this._maxStandbyArchiveDelay = value;
    }
    resetMaxStandbyArchiveDelay() {
        this._maxStandbyArchiveDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxStandbyArchiveDelayInput() {
        return this._maxStandbyArchiveDelay;
    }
    get maxStandbyStreamingDelay() {
        return this.getNumberAttribute('max_standby_streaming_delay');
    }
    set maxStandbyStreamingDelay(value) {
        this._maxStandbyStreamingDelay = value;
    }
    resetMaxStandbyStreamingDelay() {
        this._maxStandbyStreamingDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxStandbyStreamingDelayInput() {
        return this._maxStandbyStreamingDelay;
    }
    get maxWalSenders() {
        return this.getNumberAttribute('max_wal_senders');
    }
    set maxWalSenders(value) {
        this._maxWalSenders = value;
    }
    resetMaxWalSenders() {
        this._maxWalSenders = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxWalSendersInput() {
        return this._maxWalSenders;
    }
    get maxWorkerProcesses() {
        return this.getNumberAttribute('max_worker_processes');
    }
    set maxWorkerProcesses(value) {
        this._maxWorkerProcesses = value;
    }
    resetMaxWorkerProcesses() {
        this._maxWorkerProcesses = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxWorkerProcessesInput() {
        return this._maxWorkerProcesses;
    }
    get pgPartmanBgwInterval() {
        return this.getNumberAttribute('pg_partman_bgw_interval');
    }
    set pgPartmanBgwInterval(value) {
        this._pgPartmanBgwInterval = value;
    }
    resetPgPartmanBgwInterval() {
        this._pgPartmanBgwInterval = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgPartmanBgwIntervalInput() {
        return this._pgPartmanBgwInterval;
    }
    get pgPartmanBgwRole() {
        return this.getStringAttribute('pg_partman_bgw_role');
    }
    set pgPartmanBgwRole(value) {
        this._pgPartmanBgwRole = value;
    }
    resetPgPartmanBgwRole() {
        this._pgPartmanBgwRole = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgPartmanBgwRoleInput() {
        return this._pgPartmanBgwRole;
    }
    get pgStatStatementsTrack() {
        return this.getStringAttribute('pg_stat_statements_track');
    }
    set pgStatStatementsTrack(value) {
        this._pgStatStatementsTrack = value;
    }
    resetPgStatStatementsTrack() {
        this._pgStatStatementsTrack = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgStatStatementsTrackInput() {
        return this._pgStatStatementsTrack;
    }
    get sharedBuffersPercentage() {
        return this.getNumberAttribute('shared_buffers_percentage');
    }
    set sharedBuffersPercentage(value) {
        this._sharedBuffersPercentage = value;
    }
    resetSharedBuffersPercentage() {
        this._sharedBuffersPercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sharedBuffersPercentageInput() {
        return this._sharedBuffersPercentage;
    }
    get tempFileLimit() {
        return this.getNumberAttribute('temp_file_limit');
    }
    set tempFileLimit(value) {
        this._tempFileLimit = value;
    }
    resetTempFileLimit() {
        this._tempFileLimit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get tempFileLimitInput() {
        return this._tempFileLimit;
    }
    get timezone() {
        return this.getStringAttribute('timezone');
    }
    set timezone(value) {
        this._timezone = value;
    }
    resetTimezone() {
        this._timezone = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get timezoneInput() {
        return this._timezone;
    }
    get trackActivityQuerySize() {
        return this.getNumberAttribute('track_activity_query_size');
    }
    set trackActivityQuerySize(value) {
        this._trackActivityQuerySize = value;
    }
    resetTrackActivityQuerySize() {
        this._trackActivityQuerySize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackActivityQuerySizeInput() {
        return this._trackActivityQuerySize;
    }
    get trackCommitTimestamp() {
        return this.getStringAttribute('track_commit_timestamp');
    }
    set trackCommitTimestamp(value) {
        this._trackCommitTimestamp = value;
    }
    resetTrackCommitTimestamp() {
        this._trackCommitTimestamp = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackCommitTimestampInput() {
        return this._trackCommitTimestamp;
    }
    get trackFunctions() {
        return this.getStringAttribute('track_functions');
    }
    set trackFunctions(value) {
        this._trackFunctions = value;
    }
    resetTrackFunctions() {
        this._trackFunctions = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackFunctionsInput() {
        return this._trackFunctions;
    }
    get trackIoTiming() {
        return this.getStringAttribute('track_io_timing');
    }
    set trackIoTiming(value) {
        this._trackIoTiming = value;
    }
    resetTrackIoTiming() {
        this._trackIoTiming = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get trackIoTimingInput() {
        return this._trackIoTiming;
    }
    get walSenderTimeout() {
        return this.getNumberAttribute('wal_sender_timeout');
    }
    set walSenderTimeout(value) {
        this._walSenderTimeout = value;
    }
    resetWalSenderTimeout() {
        this._walSenderTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get walSenderTimeoutInput() {
        return this._walSenderTimeout;
    }
    get walWriterDelay() {
        return this.getNumberAttribute('wal_writer_delay');
    }
    set walWriterDelay(value) {
        this._walWriterDelay = value;
    }
    resetWalWriterDelay() {
        this._walWriterDelay = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get walWriterDelayInput() {
        return this._walWriterDelay;
    }
    get workMem() {
        return this.getNumberAttribute('work_mem');
    }
    set workMem(value) {
        this._workMem = value;
    }
    resetWorkMem() {
        this._workMem = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get workMemInput() {
        return this._workMem;
    }
    get pgbouncer() {
        return this._pgbouncer;
    }
    putPgbouncer(value) {
        this._pgbouncer.internalValue = value;
    }
    resetPgbouncer() {
        this._pgbouncer.internalValue = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pgbouncerInput() {
        return this._pgbouncer.internalValue;
    }
    get timescaledb() {
        return this._timescaledb;
    }
    putTimescaledb(value) {
        this._timescaledb.internalValue = value;
    }
    resetTimescaledb() {
        this._timescaledb.internalValue = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get timescaledbInput() {
        return this._timescaledb.internalValue;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            autovacuum_analyze_scale_factor: cdktn.numberToTerraform(this._autovacuumAnalyzeScaleFactor),
            autovacuum_analyze_threshold: cdktn.numberToTerraform(this._autovacuumAnalyzeThreshold),
            autovacuum_freeze_max_age: cdktn.numberToTerraform(this._autovacuumFreezeMaxAge),
            autovacuum_max_workers: cdktn.numberToTerraform(this._autovacuumMaxWorkers),
            autovacuum_naptime: cdktn.numberToTerraform(this._autovacuumNaptime),
            autovacuum_vacuum_cost_delay: cdktn.numberToTerraform(this._autovacuumVacuumCostDelay),
            autovacuum_vacuum_cost_limit: cdktn.numberToTerraform(this._autovacuumVacuumCostLimit),
            autovacuum_vacuum_scale_factor: cdktn.numberToTerraform(this._autovacuumVacuumScaleFactor),
            autovacuum_vacuum_threshold: cdktn.numberToTerraform(this._autovacuumVacuumThreshold),
            backup_hour: cdktn.numberToTerraform(this._backupHour),
            backup_minute: cdktn.numberToTerraform(this._backupMinute),
            bgwriter_delay: cdktn.numberToTerraform(this._bgwriterDelay),
            bgwriter_flush_after: cdktn.numberToTerraform(this._bgwriterFlushAfter),
            bgwriter_lru_maxpages: cdktn.numberToTerraform(this._bgwriterLruMaxpages),
            bgwriter_lru_multiplier: cdktn.numberToTerraform(this._bgwriterLruMultiplier),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            deadlock_timeout: cdktn.numberToTerraform(this._deadlockTimeout),
            default_toast_compression: cdktn.stringToTerraform(this._defaultToastCompression),
            id: cdktn.stringToTerraform(this._id),
            idle_in_transaction_session_timeout: cdktn.numberToTerraform(this._idleInTransactionSessionTimeout),
            jit: cdktn.booleanToTerraform(this._jit),
            log_autovacuum_min_duration: cdktn.numberToTerraform(this._logAutovacuumMinDuration),
            log_error_verbosity: cdktn.stringToTerraform(this._logErrorVerbosity),
            log_line_prefix: cdktn.stringToTerraform(this._logLinePrefix),
            log_min_duration_statement: cdktn.numberToTerraform(this._logMinDurationStatement),
            max_files_per_process: cdktn.numberToTerraform(this._maxFilesPerProcess),
            max_locks_per_transaction: cdktn.numberToTerraform(this._maxLocksPerTransaction),
            max_logical_replication_workers: cdktn.numberToTerraform(this._maxLogicalReplicationWorkers),
            max_parallel_workers: cdktn.numberToTerraform(this._maxParallelWorkers),
            max_parallel_workers_per_gather: cdktn.numberToTerraform(this._maxParallelWorkersPerGather),
            max_pred_locks_per_transaction: cdktn.numberToTerraform(this._maxPredLocksPerTransaction),
            max_prepared_transactions: cdktn.numberToTerraform(this._maxPreparedTransactions),
            max_replication_slots: cdktn.numberToTerraform(this._maxReplicationSlots),
            max_stack_depth: cdktn.numberToTerraform(this._maxStackDepth),
            max_standby_archive_delay: cdktn.numberToTerraform(this._maxStandbyArchiveDelay),
            max_standby_streaming_delay: cdktn.numberToTerraform(this._maxStandbyStreamingDelay),
            max_wal_senders: cdktn.numberToTerraform(this._maxWalSenders),
            max_worker_processes: cdktn.numberToTerraform(this._maxWorkerProcesses),
            pg_partman_bgw_interval: cdktn.numberToTerraform(this._pgPartmanBgwInterval),
            pg_partman_bgw_role: cdktn.stringToTerraform(this._pgPartmanBgwRole),
            pg_stat_statements_track: cdktn.stringToTerraform(this._pgStatStatementsTrack),
            shared_buffers_percentage: cdktn.numberToTerraform(this._sharedBuffersPercentage),
            temp_file_limit: cdktn.numberToTerraform(this._tempFileLimit),
            timezone: cdktn.stringToTerraform(this._timezone),
            track_activity_query_size: cdktn.numberToTerraform(this._trackActivityQuerySize),
            track_commit_timestamp: cdktn.stringToTerraform(this._trackCommitTimestamp),
            track_functions: cdktn.stringToTerraform(this._trackFunctions),
            track_io_timing: cdktn.stringToTerraform(this._trackIoTiming),
            wal_sender_timeout: cdktn.numberToTerraform(this._walSenderTimeout),
            wal_writer_delay: cdktn.numberToTerraform(this._walWriterDelay),
            work_mem: cdktn.numberToTerraform(this._workMem),
            pgbouncer: cdktn.listMapper(databasePostgresqlConfigPgbouncerToTerraform, true)(this._pgbouncer.internalValue),
            timescaledb: databasePostgresqlConfigTimescaledbToTerraform(this._timescaledb.internalValue),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            autovacuum_analyze_scale_factor: {
                value: cdktn.numberToHclTerraform(this._autovacuumAnalyzeScaleFactor),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_analyze_threshold: {
                value: cdktn.numberToHclTerraform(this._autovacuumAnalyzeThreshold),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_freeze_max_age: {
                value: cdktn.numberToHclTerraform(this._autovacuumFreezeMaxAge),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_max_workers: {
                value: cdktn.numberToHclTerraform(this._autovacuumMaxWorkers),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_naptime: {
                value: cdktn.numberToHclTerraform(this._autovacuumNaptime),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_cost_delay: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumCostDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_cost_limit: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumCostLimit),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_scale_factor: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumScaleFactor),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            autovacuum_vacuum_threshold: {
                value: cdktn.numberToHclTerraform(this._autovacuumVacuumThreshold),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            backup_hour: {
                value: cdktn.numberToHclTerraform(this._backupHour),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            backup_minute: {
                value: cdktn.numberToHclTerraform(this._backupMinute),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_delay: {
                value: cdktn.numberToHclTerraform(this._bgwriterDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_flush_after: {
                value: cdktn.numberToHclTerraform(this._bgwriterFlushAfter),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_lru_maxpages: {
                value: cdktn.numberToHclTerraform(this._bgwriterLruMaxpages),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            bgwriter_lru_multiplier: {
                value: cdktn.numberToHclTerraform(this._bgwriterLruMultiplier),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            deadlock_timeout: {
                value: cdktn.numberToHclTerraform(this._deadlockTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            default_toast_compression: {
                value: cdktn.stringToHclTerraform(this._defaultToastCompression),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            idle_in_transaction_session_timeout: {
                value: cdktn.numberToHclTerraform(this._idleInTransactionSessionTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            jit: {
                value: cdktn.booleanToHclTerraform(this._jit),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            log_autovacuum_min_duration: {
                value: cdktn.numberToHclTerraform(this._logAutovacuumMinDuration),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_error_verbosity: {
                value: cdktn.stringToHclTerraform(this._logErrorVerbosity),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_line_prefix: {
                value: cdktn.stringToHclTerraform(this._logLinePrefix),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_min_duration_statement: {
                value: cdktn.numberToHclTerraform(this._logMinDurationStatement),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_files_per_process: {
                value: cdktn.numberToHclTerraform(this._maxFilesPerProcess),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_locks_per_transaction: {
                value: cdktn.numberToHclTerraform(this._maxLocksPerTransaction),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_logical_replication_workers: {
                value: cdktn.numberToHclTerraform(this._maxLogicalReplicationWorkers),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_parallel_workers: {
                value: cdktn.numberToHclTerraform(this._maxParallelWorkers),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_parallel_workers_per_gather: {
                value: cdktn.numberToHclTerraform(this._maxParallelWorkersPerGather),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_pred_locks_per_transaction: {
                value: cdktn.numberToHclTerraform(this._maxPredLocksPerTransaction),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_prepared_transactions: {
                value: cdktn.numberToHclTerraform(this._maxPreparedTransactions),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_replication_slots: {
                value: cdktn.numberToHclTerraform(this._maxReplicationSlots),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_stack_depth: {
                value: cdktn.numberToHclTerraform(this._maxStackDepth),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_standby_archive_delay: {
                value: cdktn.numberToHclTerraform(this._maxStandbyArchiveDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_standby_streaming_delay: {
                value: cdktn.numberToHclTerraform(this._maxStandbyStreamingDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_wal_senders: {
                value: cdktn.numberToHclTerraform(this._maxWalSenders),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_worker_processes: {
                value: cdktn.numberToHclTerraform(this._maxWorkerProcesses),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            pg_partman_bgw_interval: {
                value: cdktn.numberToHclTerraform(this._pgPartmanBgwInterval),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            pg_partman_bgw_role: {
                value: cdktn.stringToHclTerraform(this._pgPartmanBgwRole),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            pg_stat_statements_track: {
                value: cdktn.stringToHclTerraform(this._pgStatStatementsTrack),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            shared_buffers_percentage: {
                value: cdktn.numberToHclTerraform(this._sharedBuffersPercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            temp_file_limit: {
                value: cdktn.numberToHclTerraform(this._tempFileLimit),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            timezone: {
                value: cdktn.stringToHclTerraform(this._timezone),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            track_activity_query_size: {
                value: cdktn.numberToHclTerraform(this._trackActivityQuerySize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            track_commit_timestamp: {
                value: cdktn.stringToHclTerraform(this._trackCommitTimestamp),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            track_functions: {
                value: cdktn.stringToHclTerraform(this._trackFunctions),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            track_io_timing: {
                value: cdktn.stringToHclTerraform(this._trackIoTiming),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            wal_sender_timeout: {
                value: cdktn.numberToHclTerraform(this._walSenderTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            wal_writer_delay: {
                value: cdktn.numberToHclTerraform(this._walWriterDelay),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            work_mem: {
                value: cdktn.numberToHclTerraform(this._workMem),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            pgbouncer: {
                value: cdktn.listMapperHcl(databasePostgresqlConfigPgbouncerToHclTerraform, true)(this._pgbouncer.internalValue),
                isBlock: true,
                type: "list",
                storageClassType: "DatabasePostgresqlConfigPgbouncerList",
            },
            timescaledb: {
                value: databasePostgresqlConfigTimescaledbToHclTerraform(this._timescaledb.internalValue),
                isBlock: true,
                type: "list",
                storageClassType: "DatabasePostgresqlConfigTimescaledbList",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabasePostgresqlConfig = DatabasePostgresqlConfig;
_d = JSII_RTTI_SYMBOL_1;
DatabasePostgresqlConfig[_d] = { fqn: "digitalocean.databasePostgresqlConfig.DatabasePostgresqlConfig", version: "0.0.0" };
// =================
// STATIC PROPERTIES
// =================
DatabasePostgresqlConfig.tfResourceType = "digitalocean_database_postgresql_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBNFFBLG9HQWdCQztBQUdELDBHQWdFQztBQXlRRCx3R0FRQztBQUdELDhHQWdCQzs7QUEvbkJELCtCQUErQjtBQXdRL0IsU0FBZ0IsNENBQTRDLENBQUMsTUFBOEQ7SUFDekgsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUFDLE9BQU8sTUFBTSxDQUFDO0lBQUMsQ0FBQztJQUM1RixJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ25DLE1BQU0sSUFBSSxLQUFLLENBQUMsb0hBQW9ILENBQUMsQ0FBQztJQUN4SSxDQUFDO0lBQ0QsT0FBTztRQUNMLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsaUJBQWlCLENBQUM7UUFDdkUseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLE1BQU8sQ0FBQyxzQkFBc0IsQ0FBQztRQUNsRixnQkFBZ0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsTUFBTyxDQUFDLGNBQWMsQ0FBQztRQUNqRSxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsTUFBTyxDQUFDLGNBQWMsQ0FBQztRQUNqRSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFPLENBQUMsdUJBQXVCLENBQUM7UUFDNUcsYUFBYSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsV0FBVyxDQUFDO1FBQzNELG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsaUJBQWlCLENBQUM7UUFDdkUsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUFPLENBQUMsY0FBYyxDQUFDO1FBQ2hFLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxNQUFPLENBQUMsc0JBQXNCLENBQUM7S0FDcEYsQ0FBQTtBQUNILENBQUM7QUFHRCxTQUFnQiwrQ0FBK0MsQ0FBQyxNQUE4RDtJQUM1SCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQUMsT0FBTyxNQUFNLENBQUM7SUFBQyxDQUFDO0lBQzVGLElBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDbkMsTUFBTSxJQUFJLEtBQUssQ0FBQyxvSEFBb0gsQ0FBQyxDQUFDO0lBQ3hJLENBQUM7SUFDRCxNQUFNLEtBQUssR0FBRztRQUNaLG1CQUFtQixFQUFFO1lBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsTUFBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzVELE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFLFFBQVE7WUFDZCxnQkFBZ0IsRUFBRSxRQUFRO1NBQzNCO1FBQ0QseUJBQXlCLEVBQUU7WUFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsc0JBQXNCLENBQUM7WUFDakUsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCxnQkFBZ0IsRUFBRTtZQUNoQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxjQUFjLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCxnQkFBZ0IsRUFBRTtZQUNoQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxjQUFjLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCx5QkFBeUIsRUFBRTtZQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTyxDQUFDLHVCQUF1QixDQUFDO1lBQzlGLE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFLEtBQUs7WUFDWCxnQkFBZ0IsRUFBRSxZQUFZO1NBQy9CO1FBQ0QsYUFBYSxFQUFFO1lBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsV0FBVyxDQUFDO1lBQ3RELE9BQU8sRUFBRSxLQUFLO1lBQ2QsSUFBSSxFQUFFLFFBQVE7WUFDZCxnQkFBZ0IsRUFBRSxRQUFRO1NBQzNCO1FBQ0QsbUJBQW1CLEVBQUU7WUFDbkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFPLENBQUMsaUJBQWlCLENBQUM7WUFDNUQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCxlQUFlLEVBQUU7WUFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxjQUFjLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLGdCQUFnQixFQUFFLFFBQVE7U0FDM0I7UUFDRCx5QkFBeUIsRUFBRTtZQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLHFCQUFxQixDQUFDLE1BQU8sQ0FBQyxzQkFBc0IsQ0FBQztZQUNsRSxPQUFPLEVBQUUsS0FBSztZQUNkLElBQUksRUFBRSxRQUFRO1lBQ2QsZ0JBQWdCLEVBQUUsU0FBUztTQUM1QjtLQUNGLENBQUM7SUFFRiw4QkFBOEI7SUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzVILENBQUM7QUFFRCxNQUFhLGdEQUFpRCxTQUFRLEtBQUssQ0FBQyxhQUFhO0lBSXZGOzs7OztNQUtFO0lBQ0YsWUFBbUIsaUJBQTZDLEVBQUUsa0JBQTBCLEVBQUUsa0JBQTBCLEVBQUUsc0JBQStCO1FBQ3ZKLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxrQkFBa0IsRUFBRSxzQkFBc0IsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBVm5GLGtCQUFhLEdBQUcsS0FBSyxDQUFDO0lBVzlCLENBQUM7SUFFRCxJQUFXLGFBQWE7UUFDdEIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzlCLENBQUM7UUFDRCxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3RDLE1BQU0sbUJBQW1CLEdBQVEsRUFBRSxDQUFDO1FBQ3BDLElBQUksSUFBSSxDQUFDLGtCQUFrQixLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2xFLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyx1QkFBdUIsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUMvQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUM1RSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsZUFBZSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3ZDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDNUQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN2QyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzVELENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyx3QkFBd0IsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNoRCxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztRQUM5RSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3BDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDdEQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGtCQUFrQixLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDcEIsbUJBQW1CLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2xFLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxlQUFlLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDdkMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNwQixtQkFBbUIsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUM1RCxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsdUJBQXVCLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDL0MsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNwQixtQkFBbUIsQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7UUFDNUUsQ0FBQztRQUNELE9BQU8sWUFBWSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBQ3hELENBQUM7SUFFRCxJQUFXLGFBQWEsQ0FBQyxLQUF3RTtRQUMvRixJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztZQUNqQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO1lBQ3BDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7WUFDekMsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7WUFDakMsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7WUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztZQUMxQyxJQUFJLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQztZQUM5QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO1lBQ2pDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7UUFDM0MsQ0FBQzthQUNJLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNoRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztRQUMvQixDQUFDO2FBQ0ksQ0FBQztZQUNKLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1lBQ3JELElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDbEQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztZQUM1RCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7WUFDNUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQzVDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUMsdUJBQXVCLENBQUM7WUFDOUQsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDbEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQzVDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsc0JBQXNCLENBQUM7UUFDOUQsQ0FBQztJQUNILENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFhO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUM7SUFDdkMsQ0FBQztJQUNNLDJCQUEyQjtRQUNoQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsU0FBUyxDQUFDO0lBQzNDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEMsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFlO1FBQ2hELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUNNLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0lBQzVDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw0QkFBNEI7UUFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUlELElBQVcsV0FBVztRQUNwQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQ0QsSUFBVyxXQUFXLENBQUMsS0FBYTtRQUNsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBQ00sZ0JBQWdCO1FBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDO0lBQ2hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQVcsY0FBYyxDQUFDLEtBQWE7UUFDckMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQUNNLG1CQUFtQjtRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztJQUNuQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsbUJBQW1CO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFrQztRQUNsRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7O0FBMU9ILDRHQTJPQzs7O0FBRUQsTUFBYSxxQ0FBc0MsU0FBUSxLQUFLLENBQUMsV0FBVztJQUcxRTs7OztNQUlFO0lBQ0YsWUFBWSxpQkFBNkMsRUFBRSxrQkFBMEIsRUFBRSxRQUFpQjtRQUN0RyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLENBQUE7SUFDeEQsQ0FBQztJQUVEOztNQUVFO0lBQ0ssR0FBRyxDQUFDLEtBQWE7UUFDdEIsT0FBTyxJQUFJLGdEQUFnRCxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNySSxDQUFDOztBQWpCSCxzRkFrQkM7OztBQVFELFNBQWdCLDhDQUE4QyxDQUFDLE1BQWlHO0lBQzlKLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFBQyxPQUFPLE1BQU0sQ0FBQztJQUFDLENBQUM7SUFDNUYsSUFBSSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNuQyxNQUFNLElBQUksS0FBSyxDQUFDLG9IQUFvSCxDQUFDLENBQUM7SUFDeEksQ0FBQztJQUNELE9BQU87UUFDTCxzQkFBc0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsTUFBTyxDQUFDLG9CQUFvQixDQUFDO0tBQzlFLENBQUE7QUFDSCxDQUFDO0FBR0QsU0FBZ0IsaURBQWlELENBQUMsTUFBaUc7SUFDakssSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUFDLE9BQU8sTUFBTSxDQUFDO0lBQUMsQ0FBQztJQUM1RixJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ25DLE1BQU0sSUFBSSxLQUFLLENBQUMsb0hBQW9ILENBQUMsQ0FBQztJQUN4SSxDQUFDO0lBQ0QsTUFBTSxLQUFLLEdBQUc7UUFDWixzQkFBc0IsRUFBRTtZQUN0QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU8sQ0FBQyxvQkFBb0IsQ0FBQztZQUMvRCxPQUFPLEVBQUUsS0FBSztZQUNkLElBQUksRUFBRSxRQUFRO1lBQ2QsZ0JBQWdCLEVBQUUsUUFBUTtTQUMzQjtLQUNGLENBQUM7SUFFRiw4QkFBOEI7SUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzVILENBQUM7QUFFRCxNQUFhLGtEQUFtRCxTQUFRLEtBQUssQ0FBQyxhQUFhO0lBR3pGOzs7TUFHRTtJQUNGLFlBQW1CLGlCQUE2QyxFQUFFLGtCQUEwQjtRQUMxRixLQUFLLENBQUMsaUJBQWlCLEVBQUUsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBUGpELGtCQUFhLEdBQUcsS0FBSyxDQUFDO0lBUTlCLENBQUM7SUFFRCxJQUFXLGFBQWE7UUFDdEIsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN0QyxNQUFNLG1CQUFtQixHQUFRLEVBQUUsQ0FBQztRQUNwQyxJQUFJLElBQUksQ0FBQyxxQkFBcUIsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUM3QyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLG1CQUFtQixDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztRQUN4RSxDQUFDO1FBQ0QsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7SUFDeEQsQ0FBQztJQUVELElBQVcsYUFBYSxDQUFDLEtBQXNEO1FBQzdFLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBQzNCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7UUFDekMsQ0FBQzthQUNJLENBQUM7WUFDSixJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLG9CQUFvQixDQUFDO1FBQzFELENBQUM7SUFDSCxDQUFDO0lBSUQsSUFBVyxvQkFBb0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0QsSUFBVyxvQkFBb0IsQ0FBQyxLQUFhO1FBQzNDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7SUFDckMsQ0FBQztJQUNNLHlCQUF5QjtRQUM5QixJQUFJLENBQUMscUJBQXFCLEdBQUcsU0FBUyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx5QkFBeUI7UUFDbEMsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUM7SUFDcEMsQ0FBQzs7QUE5Q0gsZ0hBK0NDOzs7QUFFRDs7RUFFRTtBQUNGLE1BQWEsd0JBQXlCLFNBQVEsS0FBSyxDQUFDLGlCQUFpQjtJQU9uRSxpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQjs7Ozs7O01BTUU7SUFDSyxNQUFNLENBQUMsdUJBQXVCLENBQUMsS0FBZ0IsRUFBRSxVQUFrQixFQUFFLFlBQW9CLEVBQUUsUUFBa0M7UUFDOUgsT0FBTyxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUscUJBQXFCLEVBQUUseUNBQXlDLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ2pLLENBQUM7SUFFTCxjQUFjO0lBQ2QsY0FBYztJQUNkLGNBQWM7SUFFZDs7Ozs7O01BTUU7SUFDRixZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxNQUFzQztRQUNyRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLHFCQUFxQixFQUFFLHlDQUF5QztZQUNoRSwwQkFBMEIsRUFBRTtnQkFDMUIsWUFBWSxFQUFFLGNBQWM7Z0JBQzVCLGVBQWUsRUFBRSxRQUFRO2dCQUN6Qix5QkFBeUIsRUFBRSxRQUFRO2FBQ3BDO1lBQ0QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO1lBQ3pCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO1lBQzNCLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtZQUNqQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7WUFDN0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1NBQ3hCLENBQUMsQ0FBQztRQXkyQkwsK0RBQStEO1FBQ3ZELGVBQVUsR0FBRyxJQUFJLHFDQUFxQyxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFlekYsaUVBQWlFO1FBQ3pELGlCQUFZLEdBQUcsSUFBSSxrREFBa0QsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7UUF6M0JqRyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQywyQkFBMkIsR0FBRyxNQUFNLENBQUMsMEJBQTBCLENBQUM7UUFDckUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMscUJBQXFCLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixDQUFDO1FBQ3pELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLDBCQUEwQixHQUFHLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztRQUNuRSxJQUFJLENBQUMsMEJBQTBCLEdBQUcsTUFBTSxDQUFDLHlCQUF5QixDQUFDO1FBQ25FLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxNQUFNLENBQUMsMkJBQTJCLENBQUM7UUFDdkUsSUFBSSxDQUFDLDBCQUEwQixHQUFHLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztRQUNuRSxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDckMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDO1FBQ3JELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxNQUFNLENBQUMsbUJBQW1CLENBQUM7UUFDdkQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFDbkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7UUFDL0MsSUFBSSxDQUFDLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztRQUMvRCxJQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGdDQUFnQyxHQUFHLE1BQU0sQ0FBQywrQkFBK0IsQ0FBQztRQUMvRSxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFDdkIsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQztRQUNqRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLHVCQUF1QixDQUFDO1FBQy9ELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDckQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDckQsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsMkJBQTJCLEdBQUcsTUFBTSxDQUFDLDBCQUEwQixDQUFDO1FBQ3JFLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLG9CQUFvQixHQUFHLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQztRQUN2RCxJQUFJLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDM0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMseUJBQXlCLEdBQUcsTUFBTSxDQUFDLHdCQUF3QixDQUFDO1FBQ2pFLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDO1FBQ3JELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQztRQUNqRCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzNELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQzNDLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNqQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDO1FBQzdELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1FBQzdDLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQ2pELElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUM3QyxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQ3ZELENBQUM7SUFRRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDRCxJQUFXLDRCQUE0QixDQUFDLEtBQWE7UUFDbkQsSUFBSSxDQUFDLDZCQUE2QixHQUFHLEtBQUssQ0FBQztJQUM3QyxDQUFDO0lBQ00saUNBQWlDO1FBQ3RDLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxTQUFTLENBQUM7SUFDakQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlDQUFpQztRQUMxQyxPQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztJQUM1QyxDQUFDO0lBSUQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ0QsSUFBVywwQkFBMEIsQ0FBQyxLQUFhO1FBQ2pELElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUM7SUFDM0MsQ0FBQztJQUNNLCtCQUErQjtRQUNwQyxJQUFJLENBQUMsMkJBQTJCLEdBQUcsU0FBUyxDQUFDO0lBQy9DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywrQkFBK0I7UUFDeEMsT0FBTyxJQUFJLENBQUMsMkJBQTJCLENBQUM7SUFDMUMsQ0FBQztJQUlELElBQVcsc0JBQXNCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcsc0JBQXNCLENBQUMsS0FBYTtRQUM3QyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFDRCxJQUFXLHlCQUF5QixDQUFDLEtBQWE7UUFDaEQsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQztJQUMxQyxDQUFDO0lBQ00sOEJBQThCO1FBQ25DLElBQUksQ0FBQywwQkFBMEIsR0FBRyxTQUFTLENBQUM7SUFDOUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDhCQUE4QjtRQUN2QyxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQztJQUN6QyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDZCQUE2QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLFVBQVU7UUFDbkIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUNELElBQVcsVUFBVSxDQUFDLEtBQWE7UUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7SUFDM0IsQ0FBQztJQUNNLGVBQWU7UUFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7SUFDL0IsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFJRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUNELElBQVcsWUFBWSxDQUFDLEtBQWE7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUNNLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUJBQWlCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBSUQsSUFBVyxhQUFhO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQVcsYUFBYSxDQUFDLEtBQWE7UUFDcEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNNLGtCQUFrQjtRQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztJQUNsQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsa0JBQWtCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM3QixDQUFDO0lBSUQsSUFBVyxrQkFBa0I7UUFDM0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxrQkFBa0IsQ0FBQyxLQUFhO1FBQ3pDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUM7SUFDbkMsQ0FBQztJQUNNLHVCQUF1QjtRQUM1QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsU0FBUyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDbEMsQ0FBQztJQUlELElBQVcsbUJBQW1CO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUNELElBQVcsbUJBQW1CLENBQUMsS0FBYTtRQUMxQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsS0FBSyxDQUFDO0lBQ3BDLENBQUM7SUFDTSx3QkFBd0I7UUFDN0IsSUFBSSxDQUFDLG9CQUFvQixHQUFHLFNBQVMsQ0FBQztJQUN4QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsd0JBQXdCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDO0lBQ25DLENBQUM7SUFJRCxJQUFXLHFCQUFxQjtRQUM5QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFDRCxJQUFXLHFCQUFxQixDQUFDLEtBQWE7UUFDNUMsSUFBSSxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQztJQUN0QyxDQUFDO0lBQ00sMEJBQTBCO1FBQy9CLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxTQUFTLENBQUM7SUFDMUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDBCQUEwQjtRQUNuQyxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztJQUNyQyxDQUFDO0lBSUQsSUFBVyxTQUFTO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFXLFNBQVMsQ0FBQyxLQUFhO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN6QixDQUFDO0lBSUQsSUFBVyxlQUFlO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDckQsQ0FBQztJQUNELElBQVcsZUFBZSxDQUFDLEtBQWE7UUFDdEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztJQUNoQyxDQUFDO0lBQ00sb0JBQW9CO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxTQUFTLENBQUM7SUFDcEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUMvQixDQUFDO0lBSUQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFhO1FBQzlDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUNNLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0lBQzVDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw0QkFBNEI7UUFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUlELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFXLEVBQUUsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFDTSxPQUFPO1FBQ1osSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2xCLENBQUM7SUFJRCxJQUFXLCtCQUErQjtRQUN4QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFDRCxJQUFXLCtCQUErQixDQUFDLEtBQWE7UUFDdEQsSUFBSSxDQUFDLGdDQUFnQyxHQUFHLEtBQUssQ0FBQztJQUNoRCxDQUFDO0lBQ00sb0NBQW9DO1FBQ3pDLElBQUksQ0FBQyxnQ0FBZ0MsR0FBRyxTQUFTLENBQUM7SUFDcEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG9DQUFvQztRQUM3QyxPQUFPLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQztJQUMvQyxDQUFDO0lBSUQsSUFBVyxHQUFHO1FBQ1osT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQVcsR0FBRyxDQUFDLEtBQWtDO1FBQy9DLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLENBQUM7SUFDTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7SUFDeEIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25CLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBYTtRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFhO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUM7SUFDdkMsQ0FBQztJQUNNLDJCQUEyQjtRQUNoQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsU0FBUyxDQUFDO0lBQzNDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEMsQ0FBQztJQUlELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlDQUFpQyxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUNELElBQVcsNEJBQTRCLENBQUMsS0FBYTtRQUNuRCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFDTSxpQ0FBaUM7UUFDdEMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLFNBQVMsQ0FBQztJQUNqRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDO0lBQzVDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdDQUFnQyxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUNELElBQVcsMEJBQTBCLENBQUMsS0FBYTtRQUNqRCxJQUFJLENBQUMsMkJBQTJCLEdBQUcsS0FBSyxDQUFDO0lBQzNDLENBQUM7SUFDTSwrQkFBK0I7UUFDcEMsSUFBSSxDQUFDLDJCQUEyQixHQUFHLFNBQVMsQ0FBQztJQUMvQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsK0JBQStCO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLDJCQUEyQixDQUFDO0lBQzFDLENBQUM7SUFJRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFDRCxJQUFXLHVCQUF1QixDQUFDLEtBQWE7UUFDOUMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQztJQUN4QyxDQUFDO0lBQ00sNEJBQTRCO1FBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxTQUFTLENBQUM7SUFDNUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztJQUN2QyxDQUFDO0lBSUQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBQ0QsSUFBVyxtQkFBbUIsQ0FBQyxLQUFhO1FBQzFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUNNLHdCQUF3QjtRQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFDbkMsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsc0JBQXNCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcsc0JBQXNCLENBQUMsS0FBYTtRQUM3QyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxhQUFhO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQVcsYUFBYSxDQUFDLEtBQWE7UUFDcEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNNLGtCQUFrQjtRQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztJQUNsQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsa0JBQWtCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM3QixDQUFDO0lBSUQsSUFBVyxrQkFBa0I7UUFDM0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxrQkFBa0IsQ0FBQyxLQUFhO1FBQ3pDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUM7SUFDbkMsQ0FBQztJQUNNLHVCQUF1QjtRQUM1QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsU0FBUyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDbEMsQ0FBQztJQUlELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUNELElBQVcsb0JBQW9CLENBQUMsS0FBYTtRQUMzQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDO0lBQ3JDLENBQUM7SUFDTSx5QkFBeUI7UUFDOUIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLFNBQVMsQ0FBQztJQUN6QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDO0lBQ3BDLENBQUM7SUFJRCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGdCQUFnQixDQUFDLEtBQWE7UUFDdkMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBQ00scUJBQXFCO1FBQzFCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxTQUFTLENBQUM7SUFDckMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHFCQUFxQjtRQUM5QixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztJQUNoQyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBYTtRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGFBQWE7UUFDdEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBVyxhQUFhLENBQUMsS0FBYTtRQUNwQyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUM5QixDQUFDO0lBQ00sa0JBQWtCO1FBQ3ZCLElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO0lBQ2xDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxrQkFBa0I7UUFDM0IsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO0lBQzdCLENBQUM7SUFJRCxJQUFXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQVcsUUFBUSxDQUFDLEtBQWE7UUFDL0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDekIsQ0FBQztJQUNNLGFBQWE7UUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7SUFDN0IsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGFBQWE7UUFDdEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3hCLENBQUM7SUFJRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWE7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyxvQkFBb0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0QsSUFBVyxvQkFBb0IsQ0FBQyxLQUFhO1FBQzNDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7SUFDckMsQ0FBQztJQUNNLHlCQUF5QjtRQUM5QixJQUFJLENBQUMscUJBQXFCLEdBQUcsU0FBUyxDQUFDO0lBQ3pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx5QkFBeUI7UUFDbEMsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUM7SUFDcEMsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFJRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBQ0QsSUFBVyxjQUFjLENBQUMsS0FBYTtRQUNyQyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBQ00sbUJBQW1CO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO0lBQ25DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFJRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUNELElBQVcsT0FBTyxDQUFDLEtBQWE7UUFDOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDeEIsQ0FBQztJQUNNLFlBQVk7UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7SUFDNUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFDTSxZQUFZLENBQUMsS0FBOEQ7UUFDaEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSxjQUFjO1FBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLFdBQVc7UUFDcEIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFDTSxjQUFjLENBQUMsS0FBMEM7UUFDOUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSxnQkFBZ0I7UUFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztJQUN6QyxDQUFDO0lBRUQsWUFBWTtJQUNaLFlBQVk7SUFDWixZQUFZO0lBRUYsb0JBQW9CO1FBQzVCLE9BQU87WUFDTCwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO1lBQzVGLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7WUFDdkYseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUNoRixzQkFBc0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO1lBQzNFLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFDcEUsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztZQUN0Riw0QkFBNEIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDO1lBQ3RGLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7WUFDMUYsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztZQUNyRixXQUFXLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDdEQsYUFBYSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQzFELGNBQWMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUM1RCxvQkFBb0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1lBQ3ZFLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDekUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztZQUM3RSxVQUFVLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDcEQsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNoRSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ2pGLEVBQUUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNyQyxtQ0FBbUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxDQUFDO1lBQ25HLEdBQUcsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN4QywyQkFBMkIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1lBQ3BGLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFDckUsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzdELDBCQUEwQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7WUFDbEYscUJBQXFCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN4RSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1lBQ2hGLCtCQUErQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7WUFDNUYsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN2RSwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO1lBQzNGLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7WUFDekYseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNqRixxQkFBcUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBQ3pFLGVBQWUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUM3RCx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1lBQ2hGLDJCQUEyQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7WUFDcEYsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzdELG9CQUFvQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7WUFDdkUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUM1RSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ3BFLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7WUFDOUUseUJBQXlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNqRixlQUFlLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7WUFDN0QsUUFBUSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2pELHlCQUF5QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDaEYsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUMzRSxlQUFlLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDOUQsZUFBZSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzdELGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDbkUsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsUUFBUSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ2hELFNBQVMsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLDRDQUE0QyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBQzlHLFdBQVcsRUFBRSw4Q0FBOEMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztTQUM3RixDQUFDO0lBQ0osQ0FBQztJQUVTLHVCQUF1QjtRQUMvQixNQUFNLEtBQUssR0FBRztZQUNaLCtCQUErQixFQUFFO2dCQUMvQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztnQkFDckUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQztnQkFDbkUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHlCQUF5QixFQUFFO2dCQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztnQkFDL0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHNCQUFzQixFQUFFO2dCQUN0QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDMUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDhCQUE4QixFQUFFO2dCQUM5QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztnQkFDcEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFdBQVcsRUFBRTtnQkFDWCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7Z0JBQ25ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsY0FBYyxFQUFFO2dCQUNkLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG9CQUFvQixFQUFFO2dCQUNwQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztnQkFDM0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHFCQUFxQixFQUFFO2dCQUNyQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztnQkFDNUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHVCQUF1QixFQUFFO2dCQUN2QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztnQkFDOUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFVBQVUsRUFBRTtnQkFDVixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7Z0JBQ2xELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxFQUFFLEVBQUU7Z0JBQ0YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUMzQyxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsbUNBQW1DLEVBQUU7Z0JBQ25DLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxDQUFDO2dCQUN4RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsR0FBRyxFQUFFO2dCQUNILEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDN0MsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDakUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDMUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwwQkFBMEIsRUFBRTtnQkFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7Z0JBQ3JFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7Z0JBQ3BFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw4QkFBOEIsRUFBRTtnQkFDOUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ25FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7Z0JBQzVELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxlQUFlLEVBQUU7Z0JBQ2YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO2dCQUN0RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUMvRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsMkJBQTJCLEVBQUU7Z0JBQzNCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO2dCQUNqRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG9CQUFvQixFQUFFO2dCQUNwQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztnQkFDM0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHVCQUF1QixFQUFFO2dCQUN2QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztnQkFDN0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDekQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHdCQUF3QixFQUFFO2dCQUN4QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztnQkFDOUQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHlCQUF5QixFQUFFO2dCQUN6QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztnQkFDaEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxRQUFRLEVBQUU7Z0JBQ1IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNqRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUMvRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsc0JBQXNCLEVBQUU7Z0JBQ3RCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDdkQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxrQkFBa0IsRUFBRTtnQkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7Z0JBQ3pELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUN2RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsUUFBUSxFQUFFO2dCQUNSLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDaEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFNBQVMsRUFBRTtnQkFDVCxLQUFLLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQywrQ0FBK0MsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztnQkFDaEgsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osZ0JBQWdCLEVBQUUsdUNBQXVDO2FBQzFEO1lBQ0QsV0FBVyxFQUFFO2dCQUNYLEtBQUssRUFBRSxpREFBaUQsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztnQkFDekYsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osZ0JBQWdCLEVBQUUseUNBQXlDO2FBQzVEO1NBQ0YsQ0FBQztRQUVGLDhCQUE4QjtRQUM5QixPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsS0FBSyxLQUFLLFNBQVMsQ0FBRSxDQUFDLENBQUE7SUFDNUgsQ0FBQzs7QUExekNILDREQTJ6Q0M7OztBQXp6Q0Msb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNwQixvQkFBb0I7QUFDRyx1Q0FBYyxHQUFHLHlDQUF5QyxBQUE1QyxDQUE2QyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZ1xuLy8gZ2VuZXJhdGVkIGZyb20gdGVycmFmb3JtIHJlc291cmNlIHNjaGVtYVxuXG5pbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCAqIGFzIGNka3RuIGZyb20gJ2Nka3RuJztcblxuLy8gQ29uZmlndXJhdGlvblxuXG5leHBvcnQgaW50ZXJmYWNlIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ0NvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybU1ldGFBcmd1bWVudHMge1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNhdXRvdmFjdXVtX2FuYWx5emVfc2NhbGVfZmFjdG9yIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvdmFjdXVtX2FuYWx5emVfc2NhbGVfZmFjdG9yfVxuICAqL1xuICByZWFkb25seSBhdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNhdXRvdmFjdXVtX2FuYWx5emVfdGhyZXNob2xkIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvdmFjdXVtX2FuYWx5emVfdGhyZXNob2xkfVxuICAqL1xuICByZWFkb25seSBhdXRvdmFjdXVtQW5hbHl6ZVRocmVzaG9sZD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV9mcmVlemVfbWF4X2FnZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV9mcmVlemVfbWF4X2FnZX1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV9tYXhfd29ya2VycyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV9tYXhfd29ya2Vyc31cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bU1heFdvcmtlcnM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG92YWN1dW1fbmFwdGltZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV9uYXB0aW1lfVxuICAqL1xuICByZWFkb25seSBhdXRvdmFjdXVtTmFwdGltZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9kZWxheSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9kZWxheX1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9saW1pdCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9saW1pdH1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fc2NhbGVfZmFjdG9yIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvdmFjdXVtX3ZhY3V1bV9zY2FsZV9mYWN0b3J9XG4gICovXG4gIHJlYWRvbmx5IGF1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3Rvcj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b3ZhY3V1bV92YWN1dW1fdGhyZXNob2xkIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvdmFjdXVtX3ZhY3V1bV90aHJlc2hvbGR9XG4gICovXG4gIHJlYWRvbmx5IGF1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2JhY2t1cF9ob3VyIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNiYWNrdXBfaG91cn1cbiAgKi9cbiAgcmVhZG9ubHkgYmFja3VwSG91cj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYmFja3VwX21pbnV0ZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYmFja3VwX21pbnV0ZX1cbiAgKi9cbiAgcmVhZG9ubHkgYmFja3VwTWludXRlPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNiZ3dyaXRlcl9kZWxheSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYmd3cml0ZXJfZGVsYXl9XG4gICovXG4gIHJlYWRvbmx5IGJnd3JpdGVyRGVsYXk/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2Jnd3JpdGVyX2ZsdXNoX2FmdGVyIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNiZ3dyaXRlcl9mbHVzaF9hZnRlcn1cbiAgKi9cbiAgcmVhZG9ubHkgYmd3cml0ZXJGbHVzaEFmdGVyPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNiZ3dyaXRlcl9scnVfbWF4cGFnZXMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2Jnd3JpdGVyX2xydV9tYXhwYWdlc31cbiAgKi9cbiAgcmVhZG9ubHkgYmd3cml0ZXJMcnVNYXhwYWdlcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYmd3cml0ZXJfbHJ1X211bHRpcGxpZXIgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2Jnd3JpdGVyX2xydV9tdWx0aXBsaWVyfVxuICAqL1xuICByZWFkb25seSBiZ3dyaXRlckxydU11bHRpcGxpZXI/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2NsdXN0ZXJfaWQgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2NsdXN0ZXJfaWR9XG4gICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJJZDogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNkZWFkbG9ja190aW1lb3V0IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNkZWFkbG9ja190aW1lb3V0fVxuICAqL1xuICByZWFkb25seSBkZWFkbG9ja1RpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2RlZmF1bHRfdG9hc3RfY29tcHJlc3Npb24gRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2RlZmF1bHRfdG9hc3RfY29tcHJlc3Npb259XG4gICovXG4gIHJlYWRvbmx5IGRlZmF1bHRUb2FzdENvbXByZXNzaW9uPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNpZCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjaWR9XG4gICpcbiAgKiBQbGVhc2UgYmUgYXdhcmUgdGhhdCB0aGUgaWQgZmllbGQgaXMgYXV0b21hdGljYWxseSBhZGRlZCB0byBhbGwgcmVzb3VyY2VzIGluIFRlcnJhZm9ybSBwcm92aWRlcnMgdXNpbmcgYSBUZXJyYWZvcm0gcHJvdmlkZXIgU0RLIHZlcnNpb24gYmVsb3cgMi5cbiAgKiBJZiB5b3UgZXhwZXJpZW5jZSBwcm9ibGVtcyBzZXR0aW5nIHRoaXMgdmFsdWUgaXQgbWlnaHQgbm90IGJlIHNldHRhYmxlLiBQbGVhc2UgdGFrZSBhIGxvb2sgYXQgdGhlIHByb3ZpZGVyIGRvY3VtZW50YXRpb24gdG8gZW5zdXJlIGl0IHNob3VsZCBiZSBzZXR0YWJsZS5cbiAgKi9cbiAgcmVhZG9ubHkgaWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2lkbGVfaW5fdHJhbnNhY3Rpb25fc2Vzc2lvbl90aW1lb3V0IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNpZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgaWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjaml0IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNqaXR9XG4gICovXG4gIHJlYWRvbmx5IGppdD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbG9nX2F1dG92YWN1dW1fbWluX2R1cmF0aW9uIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNsb2dfYXV0b3ZhY3V1bV9taW5fZHVyYXRpb259XG4gICovXG4gIHJlYWRvbmx5IGxvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbG9nX2Vycm9yX3ZlcmJvc2l0eSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbG9nX2Vycm9yX3ZlcmJvc2l0eX1cbiAgKi9cbiAgcmVhZG9ubHkgbG9nRXJyb3JWZXJib3NpdHk/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2xvZ19saW5lX3ByZWZpeCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbG9nX2xpbmVfcHJlZml4fVxuICAqL1xuICByZWFkb25seSBsb2dMaW5lUHJlZml4Pzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNsb2dfbWluX2R1cmF0aW9uX3N0YXRlbWVudCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbG9nX21pbl9kdXJhdGlvbl9zdGF0ZW1lbnR9XG4gICovXG4gIHJlYWRvbmx5IGxvZ01pbkR1cmF0aW9uU3RhdGVtZW50PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfZmlsZXNfcGVyX3Byb2Nlc3MgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9maWxlc19wZXJfcHJvY2Vzc31cbiAgKi9cbiAgcmVhZG9ubHkgbWF4RmlsZXNQZXJQcm9jZXNzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfbG9ja3NfcGVyX3RyYW5zYWN0aW9uIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfbG9ja3NfcGVyX3RyYW5zYWN0aW9ufVxuICAqL1xuICByZWFkb25seSBtYXhMb2Nrc1BlclRyYW5zYWN0aW9uPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfbG9naWNhbF9yZXBsaWNhdGlvbl93b3JrZXJzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfbG9naWNhbF9yZXBsaWNhdGlvbl93b3JrZXJzfVxuICAqL1xuICByZWFkb25seSBtYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfcGFyYWxsZWxfd29ya2VycyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X3BhcmFsbGVsX3dvcmtlcnN9XG4gICovXG4gIHJlYWRvbmx5IG1heFBhcmFsbGVsV29ya2Vycz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X3BhcmFsbGVsX3dvcmtlcnNfcGVyX2dhdGhlciBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X3BhcmFsbGVsX3dvcmtlcnNfcGVyX2dhdGhlcn1cbiAgKi9cbiAgcmVhZG9ubHkgbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfcHJlZF9sb2Nrc19wZXJfdHJhbnNhY3Rpb24gRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9wcmVkX2xvY2tzX3Blcl90cmFuc2FjdGlvbn1cbiAgKi9cbiAgcmVhZG9ubHkgbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21heF9wcmVwYXJlZF90cmFuc2FjdGlvbnMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9wcmVwYXJlZF90cmFuc2FjdGlvbnN9XG4gICovXG4gIHJlYWRvbmx5IG1heFByZXBhcmVkVHJhbnNhY3Rpb25zPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfcmVwbGljYXRpb25fc2xvdHMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9yZXBsaWNhdGlvbl9zbG90c31cbiAgKi9cbiAgcmVhZG9ubHkgbWF4UmVwbGljYXRpb25TbG90cz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjbWF4X3N0YWNrX2RlcHRoIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfc3RhY2tfZGVwdGh9XG4gICovXG4gIHJlYWRvbmx5IG1heFN0YWNrRGVwdGg/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21heF9zdGFuZGJ5X2FyY2hpdmVfZGVsYXkgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21heF9zdGFuZGJ5X2FyY2hpdmVfZGVsYXl9XG4gICovXG4gIHJlYWRvbmx5IG1heFN0YW5kYnlBcmNoaXZlRGVsYXk/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21heF9zdGFuZGJ5X3N0cmVhbWluZ19kZWxheSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X3N0YW5kYnlfc3RyZWFtaW5nX2RlbGF5fVxuICAqL1xuICByZWFkb25seSBtYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXk/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21heF93YWxfc2VuZGVycyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X3dhbF9zZW5kZXJzfVxuICAqL1xuICByZWFkb25seSBtYXhXYWxTZW5kZXJzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfd29ya2VyX3Byb2Nlc3NlcyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjbWF4X3dvcmtlcl9wcm9jZXNzZXN9XG4gICovXG4gIHJlYWRvbmx5IG1heFdvcmtlclByb2Nlc3Nlcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjcGdfcGFydG1hbl9iZ3dfaW50ZXJ2YWwgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3BnX3BhcnRtYW5fYmd3X2ludGVydmFsfVxuICAqL1xuICByZWFkb25seSBwZ1BhcnRtYW5CZ3dJbnRlcnZhbD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjcGdfcGFydG1hbl9iZ3dfcm9sZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjcGdfcGFydG1hbl9iZ3dfcm9sZX1cbiAgKi9cbiAgcmVhZG9ubHkgcGdQYXJ0bWFuQmd3Um9sZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjcGdfc3RhdF9zdGF0ZW1lbnRzX3RyYWNrIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNwZ19zdGF0X3N0YXRlbWVudHNfdHJhY2t9XG4gICovXG4gIHJlYWRvbmx5IHBnU3RhdFN0YXRlbWVudHNUcmFjaz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjc2hhcmVkX2J1ZmZlcnNfcGVyY2VudGFnZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjc2hhcmVkX2J1ZmZlcnNfcGVyY2VudGFnZX1cbiAgKi9cbiAgcmVhZG9ubHkgc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2U/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3RlbXBfZmlsZV9saW1pdCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjdGVtcF9maWxlX2xpbWl0fVxuICAqL1xuICByZWFkb25seSB0ZW1wRmlsZUxpbWl0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN0aW1lem9uZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjdGltZXpvbmV9XG4gICovXG4gIHJlYWRvbmx5IHRpbWV6b25lPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN0cmFja19hY3Rpdml0eV9xdWVyeV9zaXplIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyN0cmFja19hY3Rpdml0eV9xdWVyeV9zaXplfVxuICAqL1xuICByZWFkb25seSB0cmFja0FjdGl2aXR5UXVlcnlTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN0cmFja19jb21taXRfdGltZXN0YW1wIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyN0cmFja19jb21taXRfdGltZXN0YW1wfVxuICAqL1xuICByZWFkb25seSB0cmFja0NvbW1pdFRpbWVzdGFtcD86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjdHJhY2tfZnVuY3Rpb25zIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyN0cmFja19mdW5jdGlvbnN9XG4gICovXG4gIHJlYWRvbmx5IHRyYWNrRnVuY3Rpb25zPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN0cmFja19pb190aW1pbmcgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3RyYWNrX2lvX3RpbWluZ31cbiAgKi9cbiAgcmVhZG9ubHkgdHJhY2tJb1RpbWluZz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjd2FsX3NlbmRlcl90aW1lb3V0IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyN3YWxfc2VuZGVyX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IHdhbFNlbmRlclRpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI3dhbF93cml0ZXJfZGVsYXkgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI3dhbF93cml0ZXJfZGVsYXl9XG4gICovXG4gIHJlYWRvbmx5IHdhbFdyaXRlckRlbGF5PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN3b3JrX21lbSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjd29ya19tZW19XG4gICovXG4gIHJlYWRvbmx5IHdvcmtNZW0/OiBudW1iZXI7XG4gIC8qKlxuICAqIHBnYm91bmNlciBibG9ja1xuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjcGdib3VuY2VyIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNwZ2JvdW5jZXJ9XG4gICovXG4gIHJlYWRvbmx5IHBnYm91bmNlcj86IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlcltdIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIHRpbWVzY2FsZWRiIGJsb2NrXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyN0aW1lc2NhbGVkYiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjdGltZXNjYWxlZGJ9XG4gICovXG4gIHJlYWRvbmx5IHRpbWVzY2FsZWRiPzogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGI7XG59XG5leHBvcnQgaW50ZXJmYWNlIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlciB7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2F1dG9kYl9pZGxlX3RpbWVvdXQgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2F1dG9kYl9pZGxlX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IGF1dG9kYklkbGVUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNhdXRvZGJfbWF4X2RiX2Nvbm5lY3Rpb25zIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvZGJfbWF4X2RiX2Nvbm5lY3Rpb25zfVxuICAqL1xuICByZWFkb25seSBhdXRvZGJNYXhEYkNvbm5lY3Rpb25zPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNhdXRvZGJfcG9vbF9tb2RlIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNhdXRvZGJfcG9vbF9tb2RlfVxuICAqL1xuICByZWFkb25seSBhdXRvZGJQb29sTW9kZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjYXV0b2RiX3Bvb2xfc2l6ZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcjYXV0b2RiX3Bvb2xfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b2RiUG9vbFNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2lnbm9yZV9zdGFydHVwX3BhcmFtZXRlcnMgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI2lnbm9yZV9zdGFydHVwX3BhcmFtZXRlcnN9XG4gICovXG4gIHJlYWRvbmx5IGlnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzPzogc3RyaW5nW107XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI21pbl9wb29sX3NpemUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnI21pbl9wb29sX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IG1pblBvb2xTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNzZXJ2ZXJfaWRsZV90aW1lb3V0IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNzZXJ2ZXJfaWRsZV90aW1lb3V0fVxuICAqL1xuICByZWFkb25seSBzZXJ2ZXJJZGxlVGltZW91dD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcjc2VydmVyX2xpZmV0aW1lIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNzZXJ2ZXJfbGlmZXRpbWV9XG4gICovXG4gIHJlYWRvbmx5IHNlcnZlckxpZmV0aW1lPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNzZXJ2ZXJfcmVzZXRfcXVlcnlfYWx3YXlzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNzZXJ2ZXJfcmVzZXRfcXVlcnlfYWx3YXlzfVxuICAqL1xuICByZWFkb25seSBzZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyVG9UZXJyYWZvcm0oc3RydWN0PzogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyIHwgY2RrdG4uSVJlc29sdmFibGUpOiBhbnkge1xuICBpZiAoIWNka3RuLmNhbkluc3BlY3Qoc3RydWN0KSB8fCBjZGt0bi5Ub2tlbml6YXRpb24uaXNSZXNvbHZhYmxlKHN0cnVjdCkpIHsgcmV0dXJuIHN0cnVjdDsgfVxuICBpZiAoY2RrdG4uaXNDb21wbGV4RWxlbWVudChzdHJ1Y3QpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQSBjb21wbGV4IGVsZW1lbnQgd2FzIHVzZWQgYXMgY29uZmlndXJhdGlvbiwgdGhpcyBpcyBub3Qgc3VwcG9ydGVkOiBodHRwczovL2Nkay50Zi9jb21wbGV4LW9iamVjdC1hcy1jb25maWd1cmF0aW9uXCIpO1xuICB9XG4gIHJldHVybiB7XG4gICAgYXV0b2RiX2lkbGVfdGltZW91dDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJJZGxlVGltZW91dCksXG4gICAgYXV0b2RiX21heF9kYl9jb25uZWN0aW9uczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJNYXhEYkNvbm5lY3Rpb25zKSxcbiAgICBhdXRvZGJfcG9vbF9tb2RlOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybShzdHJ1Y3QhLmF1dG9kYlBvb2xNb2RlKSxcbiAgICBhdXRvZGJfcG9vbF9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybShzdHJ1Y3QhLmF1dG9kYlBvb2xTaXplKSxcbiAgICBpZ25vcmVfc3RhcnR1cF9wYXJhbWV0ZXJzOiBjZGt0bi5saXN0TWFwcGVyKGNka3RuLnN0cmluZ1RvVGVycmFmb3JtLCBmYWxzZSkoc3RydWN0IS5pZ25vcmVTdGFydHVwUGFyYW1ldGVycyksXG4gICAgbWluX3Bvb2xfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5taW5Qb29sU2l6ZSksXG4gICAgc2VydmVyX2lkbGVfdGltZW91dDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0oc3RydWN0IS5zZXJ2ZXJJZGxlVGltZW91dCksXG4gICAgc2VydmVyX2xpZmV0aW1lOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybShzdHJ1Y3QhLnNlcnZlckxpZmV0aW1lKSxcbiAgICBzZXJ2ZXJfcmVzZXRfcXVlcnlfYWx3YXlzOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0oc3RydWN0IS5zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzKSxcbiAgfVxufVxuXG5cbmV4cG9ydCBmdW5jdGlvbiBkYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3Q/OiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXIgfCBjZGt0bi5JUmVzb2x2YWJsZSk6IGFueSB7XG4gIGlmICghY2RrdG4uY2FuSW5zcGVjdChzdHJ1Y3QpIHx8IGNka3RuLlRva2VuaXphdGlvbi5pc1Jlc29sdmFibGUoc3RydWN0KSkgeyByZXR1cm4gc3RydWN0OyB9XG4gIGlmIChjZGt0bi5pc0NvbXBsZXhFbGVtZW50KHN0cnVjdCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJBIGNvbXBsZXggZWxlbWVudCB3YXMgdXNlZCBhcyBjb25maWd1cmF0aW9uLCB0aGlzIGlzIG5vdCBzdXBwb3J0ZWQ6IGh0dHBzOi8vY2RrLnRmL2NvbXBsZXgtb2JqZWN0LWFzLWNvbmZpZ3VyYXRpb25cIik7XG4gIH1cbiAgY29uc3QgYXR0cnMgPSB7XG4gICAgYXV0b2RiX2lkbGVfdGltZW91dDoge1xuICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHN0cnVjdCEuYXV0b2RiSWRsZVRpbWVvdXQpLFxuICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICB9LFxuICAgIGF1dG9kYl9tYXhfZGJfY29ubmVjdGlvbnM6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLmF1dG9kYk1heERiQ29ubmVjdGlvbnMpLFxuICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICB9LFxuICAgIGF1dG9kYl9wb29sX21vZGU6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLmF1dG9kYlBvb2xNb2RlKSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgfSxcbiAgICBhdXRvZGJfcG9vbF9zaXplOiB7XG4gICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0oc3RydWN0IS5hdXRvZGJQb29sU2l6ZSksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgIH0sXG4gICAgaWdub3JlX3N0YXJ0dXBfcGFyYW1ldGVyczoge1xuICAgICAgdmFsdWU6IGNka3RuLmxpc3RNYXBwZXJIY2woY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0sIGZhbHNlKShzdHJ1Y3QhLmlnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzKSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzZXRcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nTGlzdFwiLFxuICAgIH0sXG4gICAgbWluX3Bvb2xfc2l6ZToge1xuICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHN0cnVjdCEubWluUG9vbFNpemUpLFxuICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICB9LFxuICAgIHNlcnZlcl9pZGxlX3RpbWVvdXQ6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLnNlcnZlcklkbGVUaW1lb3V0KSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgfSxcbiAgICBzZXJ2ZXJfbGlmZXRpbWU6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLnNlcnZlckxpZmV0aW1lKSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgfSxcbiAgICBzZXJ2ZXJfcmVzZXRfcXVlcnlfYWx3YXlzOiB7XG4gICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHN0cnVjdCEuc2VydmVyUmVzZXRRdWVyeUFsd2F5cyksXG4gICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICB9LFxuICB9O1xuXG4gIC8vIHJlbW92ZSB1bmRlZmluZWQgYXR0cmlidXRlc1xuICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGF0dHJzKS5maWx0ZXIoKFtfLCB2YWx1ZV0pID0+IHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUudmFsdWUgIT09IHVuZGVmaW5lZCkpO1xufVxuXG5leHBvcnQgY2xhc3MgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyT3V0cHV0UmVmZXJlbmNlIGV4dGVuZHMgY2RrdG4uQ29tcGxleE9iamVjdCB7XG4gIHByaXZhdGUgaXNFbXB0eU9iamVjdCA9IGZhbHNlO1xuICBwcml2YXRlIHJlc29sdmFibGVWYWx1ZT86IGNka3RuLklSZXNvbHZhYmxlO1xuXG4gIC8qKlxuICAqIEBwYXJhbSB0ZXJyYWZvcm1SZXNvdXJjZSBUaGUgcGFyZW50IHJlc291cmNlXG4gICogQHBhcmFtIHRlcnJhZm9ybUF0dHJpYnV0ZSBUaGUgYXR0cmlidXRlIG9uIHRoZSBwYXJlbnQgcmVzb3VyY2UgdGhpcyBjbGFzcyBpcyByZWZlcmVuY2luZ1xuICAqIEBwYXJhbSBjb21wbGV4T2JqZWN0SW5kZXggdGhlIGluZGV4IG9mIHRoaXMgaXRlbSBpbiB0aGUgbGlzdFxuICAqIEBwYXJhbSBjb21wbGV4T2JqZWN0SXNGcm9tU2V0IHdoZXRoZXIgdGhlIGxpc3QgaXMgd3JhcHBpbmcgYSBzZXQgKHdpbGwgYWRkIHRvbGlzdCgpIHRvIGJlIGFibGUgdG8gYWNjZXNzIGFuIGl0ZW0gdmlhIGFuIGluZGV4KVxuICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3IodGVycmFmb3JtUmVzb3VyY2U6IGNka3RuLklJbnRlcnBvbGF0aW5nUGFyZW50LCB0ZXJyYWZvcm1BdHRyaWJ1dGU6IHN0cmluZywgY29tcGxleE9iamVjdEluZGV4OiBudW1iZXIsIGNvbXBsZXhPYmplY3RJc0Zyb21TZXQ6IGJvb2xlYW4pIHtcbiAgICBzdXBlcih0ZXJyYWZvcm1SZXNvdXJjZSwgdGVycmFmb3JtQXR0cmlidXRlLCBjb21wbGV4T2JqZWN0SXNGcm9tU2V0LCBjb21wbGV4T2JqZWN0SW5kZXgpO1xuICB9XG5cbiAgcHVibGljIGdldCBpbnRlcm5hbFZhbHVlKCk6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlciB8IGNka3RuLklSZXNvbHZhYmxlIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAodGhpcy5yZXNvbHZhYmxlVmFsdWUpIHtcbiAgICAgIHJldHVybiB0aGlzLnJlc29sdmFibGVWYWx1ZTtcbiAgICB9XG4gICAgbGV0IGhhc0FueVZhbHVlcyA9IHRoaXMuaXNFbXB0eU9iamVjdDtcbiAgICBjb25zdCBpbnRlcm5hbFZhbHVlUmVzdWx0OiBhbnkgPSB7fTtcbiAgICBpZiAodGhpcy5fYXV0b2RiSWRsZVRpbWVvdXQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQuYXV0b2RiSWRsZVRpbWVvdXQgPSB0aGlzLl9hdXRvZGJJZGxlVGltZW91dDtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2F1dG9kYk1heERiQ29ubmVjdGlvbnMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQuYXV0b2RiTWF4RGJDb25uZWN0aW9ucyA9IHRoaXMuX2F1dG9kYk1heERiQ29ubmVjdGlvbnM7XG4gICAgfVxuICAgIGlmICh0aGlzLl9hdXRvZGJQb29sTW9kZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBoYXNBbnlWYWx1ZXMgPSB0cnVlO1xuICAgICAgaW50ZXJuYWxWYWx1ZVJlc3VsdC5hdXRvZGJQb29sTW9kZSA9IHRoaXMuX2F1dG9kYlBvb2xNb2RlO1xuICAgIH1cbiAgICBpZiAodGhpcy5fYXV0b2RiUG9vbFNpemUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQuYXV0b2RiUG9vbFNpemUgPSB0aGlzLl9hdXRvZGJQb29sU2l6ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2lnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0Lmlnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzID0gdGhpcy5faWdub3JlU3RhcnR1cFBhcmFtZXRlcnM7XG4gICAgfVxuICAgIGlmICh0aGlzLl9taW5Qb29sU2l6ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBoYXNBbnlWYWx1ZXMgPSB0cnVlO1xuICAgICAgaW50ZXJuYWxWYWx1ZVJlc3VsdC5taW5Qb29sU2l6ZSA9IHRoaXMuX21pblBvb2xTaXplO1xuICAgIH1cbiAgICBpZiAodGhpcy5fc2VydmVySWRsZVRpbWVvdXQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQuc2VydmVySWRsZVRpbWVvdXQgPSB0aGlzLl9zZXJ2ZXJJZGxlVGltZW91dDtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3NlcnZlckxpZmV0aW1lICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0LnNlcnZlckxpZmV0aW1lID0gdGhpcy5fc2VydmVyTGlmZXRpbWU7XG4gICAgfVxuICAgIGlmICh0aGlzLl9zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGhhc0FueVZhbHVlcyA9IHRydWU7XG4gICAgICBpbnRlcm5hbFZhbHVlUmVzdWx0LnNlcnZlclJlc2V0UXVlcnlBbHdheXMgPSB0aGlzLl9zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzO1xuICAgIH1cbiAgICByZXR1cm4gaGFzQW55VmFsdWVzID8gaW50ZXJuYWxWYWx1ZVJlc3VsdCA6IHVuZGVmaW5lZDtcbiAgfVxuXG4gIHB1YmxpYyBzZXQgaW50ZXJuYWxWYWx1ZSh2YWx1ZTogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyIHwgY2RrdG4uSVJlc29sdmFibGUgfCB1bmRlZmluZWQpIHtcbiAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5pc0VtcHR5T2JqZWN0ID0gZmFsc2U7XG4gICAgICB0aGlzLnJlc29sdmFibGVWYWx1ZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX2F1dG9kYklkbGVUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fYXV0b2RiTWF4RGJDb25uZWN0aW9ucyA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX2F1dG9kYlBvb2xNb2RlID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fYXV0b2RiUG9vbFNpemUgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9pZ25vcmVTdGFydHVwUGFyYW1ldGVycyA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX21pblBvb2xTaXplID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fc2VydmVySWRsZVRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLl9zZXJ2ZXJMaWZldGltZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuX3NlcnZlclJlc2V0UXVlcnlBbHdheXMgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGVsc2UgaWYgKGNka3RuLlRva2VuaXphdGlvbi5pc1Jlc29sdmFibGUodmFsdWUpKSB7XG4gICAgICB0aGlzLmlzRW1wdHlPYmplY3QgPSBmYWxzZTtcbiAgICAgIHRoaXMucmVzb2x2YWJsZVZhbHVlID0gdmFsdWU7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5pc0VtcHR5T2JqZWN0ID0gT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aCA9PT0gMDtcbiAgICAgIHRoaXMucmVzb2x2YWJsZVZhbHVlID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fYXV0b2RiSWRsZVRpbWVvdXQgPSB2YWx1ZS5hdXRvZGJJZGxlVGltZW91dDtcbiAgICAgIHRoaXMuX2F1dG9kYk1heERiQ29ubmVjdGlvbnMgPSB2YWx1ZS5hdXRvZGJNYXhEYkNvbm5lY3Rpb25zO1xuICAgICAgdGhpcy5fYXV0b2RiUG9vbE1vZGUgPSB2YWx1ZS5hdXRvZGJQb29sTW9kZTtcbiAgICAgIHRoaXMuX2F1dG9kYlBvb2xTaXplID0gdmFsdWUuYXV0b2RiUG9vbFNpemU7XG4gICAgICB0aGlzLl9pZ25vcmVTdGFydHVwUGFyYW1ldGVycyA9IHZhbHVlLmlnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzO1xuICAgICAgdGhpcy5fbWluUG9vbFNpemUgPSB2YWx1ZS5taW5Qb29sU2l6ZTtcbiAgICAgIHRoaXMuX3NlcnZlcklkbGVUaW1lb3V0ID0gdmFsdWUuc2VydmVySWRsZVRpbWVvdXQ7XG4gICAgICB0aGlzLl9zZXJ2ZXJMaWZldGltZSA9IHZhbHVlLnNlcnZlckxpZmV0aW1lO1xuICAgICAgdGhpcy5fc2VydmVyUmVzZXRRdWVyeUFsd2F5cyA9IHZhbHVlLnNlcnZlclJlc2V0UXVlcnlBbHdheXM7XG4gICAgfVxuICB9XG5cbiAgLy8gYXV0b2RiX2lkbGVfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2F1dG9kYklkbGVUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBhdXRvZGJJZGxlVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG9kYl9pZGxlX3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG9kYklkbGVUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9hdXRvZGJJZGxlVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG9kYklkbGVUaW1lb3V0KCkge1xuICAgIHRoaXMuX2F1dG9kYklkbGVUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvZGJJZGxlVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvZGJJZGxlVGltZW91dDtcbiAgfVxuXG4gIC8vIGF1dG9kYl9tYXhfZGJfY29ubmVjdGlvbnMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvZGJNYXhEYkNvbm5lY3Rpb25zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBhdXRvZGJNYXhEYkNvbm5lY3Rpb25zKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b2RiX21heF9kYl9jb25uZWN0aW9ucycpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b2RiTWF4RGJDb25uZWN0aW9ucyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b2RiTWF4RGJDb25uZWN0aW9ucyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG9kYk1heERiQ29ubmVjdGlvbnMoKSB7XG4gICAgdGhpcy5fYXV0b2RiTWF4RGJDb25uZWN0aW9ucyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b2RiTWF4RGJDb25uZWN0aW9uc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvZGJNYXhEYkNvbm5lY3Rpb25zO1xuICB9XG5cbiAgLy8gYXV0b2RiX3Bvb2xfbW9kZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2F1dG9kYlBvb2xNb2RlPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBhdXRvZGJQb29sTW9kZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2F1dG9kYl9wb29sX21vZGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG9kYlBvb2xNb2RlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9hdXRvZGJQb29sTW9kZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG9kYlBvb2xNb2RlKCkge1xuICAgIHRoaXMuX2F1dG9kYlBvb2xNb2RlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvZGJQb29sTW9kZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvZGJQb29sTW9kZTtcbiAgfVxuXG4gIC8vIGF1dG9kYl9wb29sX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvZGJQb29sU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b2RiUG9vbFNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvZGJfcG9vbF9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvZGJQb29sU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b2RiUG9vbFNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvZGJQb29sU2l6ZSgpIHtcbiAgICB0aGlzLl9hdXRvZGJQb29sU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b2RiUG9vbFNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b2RiUG9vbFNpemU7XG4gIH1cblxuICAvLyBpZ25vcmVfc3RhcnR1cF9wYXJhbWV0ZXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaWdub3JlU3RhcnR1cFBhcmFtZXRlcnM/OiBzdHJpbmdbXTsgXG4gIHB1YmxpYyBnZXQgaWdub3JlU3RhcnR1cFBhcmFtZXRlcnMoKSB7XG4gICAgcmV0dXJuIGNka3RuLkZuLnRvbGlzdCh0aGlzLmdldExpc3RBdHRyaWJ1dGUoJ2lnbm9yZV9zdGFydHVwX3BhcmFtZXRlcnMnKSk7XG4gIH1cbiAgcHVibGljIHNldCBpZ25vcmVTdGFydHVwUGFyYW1ldGVycyh2YWx1ZTogc3RyaW5nW10pIHtcbiAgICB0aGlzLl9pZ25vcmVTdGFydHVwUGFyYW1ldGVycyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzKCkge1xuICAgIHRoaXMuX2lnbm9yZVN0YXJ0dXBQYXJhbWV0ZXJzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpZ25vcmVTdGFydHVwUGFyYW1ldGVyc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pZ25vcmVTdGFydHVwUGFyYW1ldGVycztcbiAgfVxuXG4gIC8vIG1pbl9wb29sX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9taW5Qb29sU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWluUG9vbFNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtaW5fcG9vbF9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCBtaW5Qb29sU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWluUG9vbFNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNaW5Qb29sU2l6ZSgpIHtcbiAgICB0aGlzLl9taW5Qb29sU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWluUG9vbFNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWluUG9vbFNpemU7XG4gIH1cblxuICAvLyBzZXJ2ZXJfaWRsZV90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc2VydmVySWRsZVRpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHNlcnZlcklkbGVUaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnc2VydmVyX2lkbGVfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgc2VydmVySWRsZVRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3NlcnZlcklkbGVUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U2VydmVySWRsZVRpbWVvdXQoKSB7XG4gICAgdGhpcy5fc2VydmVySWRsZVRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNlcnZlcklkbGVUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NlcnZlcklkbGVUaW1lb3V0O1xuICB9XG5cbiAgLy8gc2VydmVyX2xpZmV0aW1lIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc2VydmVyTGlmZXRpbWU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHNlcnZlckxpZmV0aW1lKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnc2VydmVyX2xpZmV0aW1lJyk7XG4gIH1cbiAgcHVibGljIHNldCBzZXJ2ZXJMaWZldGltZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fc2VydmVyTGlmZXRpbWUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTZXJ2ZXJMaWZldGltZSgpIHtcbiAgICB0aGlzLl9zZXJ2ZXJMaWZldGltZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgc2VydmVyTGlmZXRpbWVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc2VydmVyTGlmZXRpbWU7XG4gIH1cblxuICAvLyBzZXJ2ZXJfcmVzZXRfcXVlcnlfYWx3YXlzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc2VydmVyUmVzZXRRdWVyeUFsd2F5cz86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgc2VydmVyUmVzZXRRdWVyeUFsd2F5cygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdzZXJ2ZXJfcmVzZXRfcXVlcnlfYWx3YXlzJyk7XG4gIH1cbiAgcHVibGljIHNldCBzZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U2VydmVyUmVzZXRRdWVyeUFsd2F5cygpIHtcbiAgICB0aGlzLl9zZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzZXJ2ZXJSZXNldFF1ZXJ5QWx3YXlzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NlcnZlclJlc2V0UXVlcnlBbHdheXM7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlckxpc3QgZXh0ZW5kcyBjZGt0bi5Db21wbGV4TGlzdCB7XG4gIHB1YmxpYyBpbnRlcm5hbFZhbHVlPyA6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlcltdIHwgY2RrdG4uSVJlc29sdmFibGVcblxuICAvKipcbiAgKiBAcGFyYW0gdGVycmFmb3JtUmVzb3VyY2UgVGhlIHBhcmVudCByZXNvdXJjZVxuICAqIEBwYXJhbSB0ZXJyYWZvcm1BdHRyaWJ1dGUgVGhlIGF0dHJpYnV0ZSBvbiB0aGUgcGFyZW50IHJlc291cmNlIHRoaXMgY2xhc3MgaXMgcmVmZXJlbmNpbmdcbiAgKiBAcGFyYW0gd3JhcHNTZXQgd2hldGhlciB0aGUgbGlzdCBpcyB3cmFwcGluZyBhIHNldCAod2lsbCBhZGQgdG9saXN0KCkgdG8gYmUgYWJsZSB0byBhY2Nlc3MgYW4gaXRlbSB2aWEgYW4gaW5kZXgpXG4gICovXG4gIGNvbnN0cnVjdG9yKHRlcnJhZm9ybVJlc291cmNlOiBjZGt0bi5JSW50ZXJwb2xhdGluZ1BhcmVudCwgdGVycmFmb3JtQXR0cmlidXRlOiBzdHJpbmcsIHdyYXBzU2V0OiBib29sZWFuKSB7XG4gICAgc3VwZXIodGVycmFmb3JtUmVzb3VyY2UsIHRlcnJhZm9ybUF0dHJpYnV0ZSwgd3JhcHNTZXQpXG4gIH1cblxuICAvKipcbiAgKiBAcGFyYW0gaW5kZXggdGhlIGluZGV4IG9mIHRoZSBpdGVtIHRvIHJldHVyblxuICAqL1xuICBwdWJsaWMgZ2V0KGluZGV4OiBudW1iZXIpOiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJPdXRwdXRSZWZlcmVuY2Uge1xuICAgIHJldHVybiBuZXcgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyT3V0cHV0UmVmZXJlbmNlKHRoaXMudGVycmFmb3JtUmVzb3VyY2UsIHRoaXMudGVycmFmb3JtQXR0cmlidXRlLCBpbmRleCwgdGhpcy53cmFwc1NldCk7XG4gIH1cbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGIge1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZyNtYXhfYmFja2dyb3VuZF93b3JrZXJzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZyNtYXhfYmFja2dyb3VuZF93b3JrZXJzfVxuICAqL1xuICByZWFkb25seSBtYXhCYWNrZ3JvdW5kV29ya2Vycz86IG51bWJlcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiVG9UZXJyYWZvcm0oc3RydWN0PzogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGJPdXRwdXRSZWZlcmVuY2UgfCBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYik6IGFueSB7XG4gIGlmICghY2RrdG4uY2FuSW5zcGVjdChzdHJ1Y3QpIHx8IGNka3RuLlRva2VuaXphdGlvbi5pc1Jlc29sdmFibGUoc3RydWN0KSkgeyByZXR1cm4gc3RydWN0OyB9XG4gIGlmIChjZGt0bi5pc0NvbXBsZXhFbGVtZW50KHN0cnVjdCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJBIGNvbXBsZXggZWxlbWVudCB3YXMgdXNlZCBhcyBjb25maWd1cmF0aW9uLCB0aGlzIGlzIG5vdCBzdXBwb3J0ZWQ6IGh0dHBzOi8vY2RrLnRmL2NvbXBsZXgtb2JqZWN0LWFzLWNvbmZpZ3VyYXRpb25cIik7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBtYXhfYmFja2dyb3VuZF93b3JrZXJzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybShzdHJ1Y3QhLm1heEJhY2tncm91bmRXb3JrZXJzKSxcbiAgfVxufVxuXG5cbmV4cG9ydCBmdW5jdGlvbiBkYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYlRvSGNsVGVycmFmb3JtKHN0cnVjdD86IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiT3V0cHV0UmVmZXJlbmNlIHwgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGIpOiBhbnkge1xuICBpZiAoIWNka3RuLmNhbkluc3BlY3Qoc3RydWN0KSB8fCBjZGt0bi5Ub2tlbml6YXRpb24uaXNSZXNvbHZhYmxlKHN0cnVjdCkpIHsgcmV0dXJuIHN0cnVjdDsgfVxuICBpZiAoY2RrdG4uaXNDb21wbGV4RWxlbWVudChzdHJ1Y3QpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQSBjb21wbGV4IGVsZW1lbnQgd2FzIHVzZWQgYXMgY29uZmlndXJhdGlvbiwgdGhpcyBpcyBub3Qgc3VwcG9ydGVkOiBodHRwczovL2Nkay50Zi9jb21wbGV4LW9iamVjdC1hcy1jb25maWd1cmF0aW9uXCIpO1xuICB9XG4gIGNvbnN0IGF0dHJzID0ge1xuICAgIG1heF9iYWNrZ3JvdW5kX3dvcmtlcnM6IHtcbiAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybShzdHJ1Y3QhLm1heEJhY2tncm91bmRXb3JrZXJzKSxcbiAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgfSxcbiAgfTtcblxuICAvLyByZW1vdmUgdW5kZWZpbmVkIGF0dHJpYnV0ZXNcbiAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhhdHRycykuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnZhbHVlICE9PSB1bmRlZmluZWQpKTtcbn1cblxuZXhwb3J0IGNsYXNzIERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiT3V0cHV0UmVmZXJlbmNlIGV4dGVuZHMgY2RrdG4uQ29tcGxleE9iamVjdCB7XG4gIHByaXZhdGUgaXNFbXB0eU9iamVjdCA9IGZhbHNlO1xuXG4gIC8qKlxuICAqIEBwYXJhbSB0ZXJyYWZvcm1SZXNvdXJjZSBUaGUgcGFyZW50IHJlc291cmNlXG4gICogQHBhcmFtIHRlcnJhZm9ybUF0dHJpYnV0ZSBUaGUgYXR0cmlidXRlIG9uIHRoZSBwYXJlbnQgcmVzb3VyY2UgdGhpcyBjbGFzcyBpcyByZWZlcmVuY2luZ1xuICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3IodGVycmFmb3JtUmVzb3VyY2U6IGNka3RuLklJbnRlcnBvbGF0aW5nUGFyZW50LCB0ZXJyYWZvcm1BdHRyaWJ1dGU6IHN0cmluZykge1xuICAgIHN1cGVyKHRlcnJhZm9ybVJlc291cmNlLCB0ZXJyYWZvcm1BdHRyaWJ1dGUsIGZhbHNlLCAwKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgaW50ZXJuYWxWYWx1ZSgpOiBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYiB8IHVuZGVmaW5lZCB7XG4gICAgbGV0IGhhc0FueVZhbHVlcyA9IHRoaXMuaXNFbXB0eU9iamVjdDtcbiAgICBjb25zdCBpbnRlcm5hbFZhbHVlUmVzdWx0OiBhbnkgPSB7fTtcbiAgICBpZiAodGhpcy5fbWF4QmFja2dyb3VuZFdvcmtlcnMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaGFzQW55VmFsdWVzID0gdHJ1ZTtcbiAgICAgIGludGVybmFsVmFsdWVSZXN1bHQubWF4QmFja2dyb3VuZFdvcmtlcnMgPSB0aGlzLl9tYXhCYWNrZ3JvdW5kV29ya2VycztcbiAgICB9XG4gICAgcmV0dXJuIGhhc0FueVZhbHVlcyA/IGludGVybmFsVmFsdWVSZXN1bHQgOiB1bmRlZmluZWQ7XG4gIH1cblxuICBwdWJsaWMgc2V0IGludGVybmFsVmFsdWUodmFsdWU6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiIHwgdW5kZWZpbmVkKSB7XG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuaXNFbXB0eU9iamVjdCA9IGZhbHNlO1xuICAgICAgdGhpcy5fbWF4QmFja2dyb3VuZFdvcmtlcnMgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5pc0VtcHR5T2JqZWN0ID0gT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aCA9PT0gMDtcbiAgICAgIHRoaXMuX21heEJhY2tncm91bmRXb3JrZXJzID0gdmFsdWUubWF4QmFja2dyb3VuZFdvcmtlcnM7XG4gICAgfVxuICB9XG5cbiAgLy8gbWF4X2JhY2tncm91bmRfd29ya2VycyAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhCYWNrZ3JvdW5kV29ya2Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4QmFja2dyb3VuZFdvcmtlcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfYmFja2dyb3VuZF93b3JrZXJzJyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhCYWNrZ3JvdW5kV29ya2Vycyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4QmFja2dyb3VuZFdvcmtlcnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhCYWNrZ3JvdW5kV29ya2VycygpIHtcbiAgICB0aGlzLl9tYXhCYWNrZ3JvdW5kV29ya2VycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4QmFja2dyb3VuZFdvcmtlcnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4QmFja2dyb3VuZFdvcmtlcnM7XG4gIH1cbn1cblxuLyoqXG4qIFJlcHJlc2VudHMgYSB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnIGRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZ31cbiovXG5leHBvcnQgY2xhc3MgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtUmVzb3VyY2Uge1xuXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIC8vIFNUQVRJQyBQUk9QRVJUSUVTXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgdGZSZXNvdXJjZVR5cGUgPSBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9wb3N0Z3Jlc3FsX2NvbmZpZ1wiO1xuXG4gIC8vID09PT09PT09PT09PT09XG4gIC8vIFNUQVRJQyBNZXRob2RzXG4gIC8vID09PT09PT09PT09PT09XG4gIC8qKlxuICAqIEdlbmVyYXRlcyBDREtUTiBjb2RlIGZvciBpbXBvcnRpbmcgYSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcgcmVzb3VyY2UgdXBvbiBydW5uaW5nIFwiY2RrdG4gcGxhbiA8c3RhY2stbmFtZT5cIlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGltcG9ydFRvSWQgVGhlIGNvbnN0cnVjdCBpZCB1c2VkIGluIHRoZSBnZW5lcmF0ZWQgY29uZmlnIGZvciB0aGUgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnIHRvIGltcG9ydFxuICAqIEBwYXJhbSBpbXBvcnRGcm9tSWQgVGhlIGlkIG9mIHRoZSBleGlzdGluZyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcgdGhhdCBzaG91bGQgYmUgaW1wb3J0ZWQuIFJlZmVyIHRvIHRoZSB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnI2ltcG9ydCBpbXBvcnQgc2VjdGlvbn0gaW4gdGhlIGRvY3VtZW50YXRpb24gb2YgdGhpcyByZXNvdXJjZSBmb3IgdGhlIGlkIHRvIHVzZVxuICAqIEBwYXJhbSBwcm92aWRlcj8gT3B0aW9uYWwgaW5zdGFuY2Ugb2YgdGhlIHByb3ZpZGVyIHdoZXJlIHRoZSBEYXRhYmFzZVBvc3RncmVzcWxDb25maWcgdG8gaW1wb3J0IGlzIGZvdW5kXG4gICovXG4gIHB1YmxpYyBzdGF0aWMgZ2VuZXJhdGVDb25maWdGb3JJbXBvcnQoc2NvcGU6IENvbnN0cnVjdCwgaW1wb3J0VG9JZDogc3RyaW5nLCBpbXBvcnRGcm9tSWQ6IHN0cmluZywgcHJvdmlkZXI/OiBjZGt0bi5UZXJyYWZvcm1Qcm92aWRlcikge1xuICAgICAgICByZXR1cm4gbmV3IGNka3RuLkltcG9ydGFibGVSZXNvdXJjZShzY29wZSwgaW1wb3J0VG9JZCwgeyB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6IFwiZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnXCIsIGltcG9ydElkOiBpbXBvcnRGcm9tSWQsIHByb3ZpZGVyIH0pO1xuICAgICAgfVxuXG4gIC8vID09PT09PT09PT09XG4gIC8vIElOSVRJQUxJWkVSXG4gIC8vID09PT09PT09PT09XG5cbiAgLyoqXG4gICogQ3JlYXRlIGEgbmV3IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3Bvc3RncmVzcWxfY29uZmlnfSBSZXNvdXJjZVxuICAqXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaWQgVGhlIHNjb3BlZCBjb25zdHJ1Y3QgSUQuIE11c3QgYmUgdW5pcXVlIGFtb25nc3Qgc2libGluZ3MgaW4gdGhlIHNhbWUgc2NvcGVcbiAgKiBAcGFyYW0gb3B0aW9ucyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdDb25maWdcbiAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIGNvbmZpZzogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnQ29uZmlnKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6ICdkaWdpdGFsb2NlYW5fZGF0YWJhc2VfcG9zdGdyZXNxbF9jb25maWcnLFxuICAgICAgdGVycmFmb3JtR2VuZXJhdG9yTWV0YWRhdGE6IHtcbiAgICAgICAgcHJvdmlkZXJOYW1lOiAnZGlnaXRhbG9jZWFuJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uOiAnMi44Ny4wJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uQ29uc3RyYWludDogJzIuODcuMCdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcjogY29uZmlnLnByb3ZpZGVyLFxuICAgICAgZGVwZW5kc09uOiBjb25maWcuZGVwZW5kc09uLFxuICAgICAgY291bnQ6IGNvbmZpZy5jb3VudCxcbiAgICAgIGxpZmVjeWNsZTogY29uZmlnLmxpZmVjeWNsZSxcbiAgICAgIHByb3Zpc2lvbmVyczogY29uZmlnLnByb3Zpc2lvbmVycyxcbiAgICAgIGNvbm5lY3Rpb246IGNvbmZpZy5jb25uZWN0aW9uLFxuICAgICAgZm9yRWFjaDogY29uZmlnLmZvckVhY2hcbiAgICB9KTtcbiAgICB0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yID0gY29uZmlnLmF1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3I7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQgPSBjb25maWcuYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQ7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZSA9IGNvbmZpZy5hdXRvdmFjdXVtRnJlZXplTWF4QWdlO1xuICAgIHRoaXMuX2F1dG92YWN1dW1NYXhXb3JrZXJzID0gY29uZmlnLmF1dG92YWN1dW1NYXhXb3JrZXJzO1xuICAgIHRoaXMuX2F1dG92YWN1dW1OYXB0aW1lID0gY29uZmlnLmF1dG92YWN1dW1OYXB0aW1lO1xuICAgIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXkgPSBjb25maWcuYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheTtcbiAgICB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0ID0gY29uZmlnLmF1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQ7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yID0gY29uZmlnLmF1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvcjtcbiAgICB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkID0gY29uZmlnLmF1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQ7XG4gICAgdGhpcy5fYmFja3VwSG91ciA9IGNvbmZpZy5iYWNrdXBIb3VyO1xuICAgIHRoaXMuX2JhY2t1cE1pbnV0ZSA9IGNvbmZpZy5iYWNrdXBNaW51dGU7XG4gICAgdGhpcy5fYmd3cml0ZXJEZWxheSA9IGNvbmZpZy5iZ3dyaXRlckRlbGF5O1xuICAgIHRoaXMuX2Jnd3JpdGVyRmx1c2hBZnRlciA9IGNvbmZpZy5iZ3dyaXRlckZsdXNoQWZ0ZXI7XG4gICAgdGhpcy5fYmd3cml0ZXJMcnVNYXhwYWdlcyA9IGNvbmZpZy5iZ3dyaXRlckxydU1heHBhZ2VzO1xuICAgIHRoaXMuX2Jnd3JpdGVyTHJ1TXVsdGlwbGllciA9IGNvbmZpZy5iZ3dyaXRlckxydU11bHRpcGxpZXI7XG4gICAgdGhpcy5fY2x1c3RlcklkID0gY29uZmlnLmNsdXN0ZXJJZDtcbiAgICB0aGlzLl9kZWFkbG9ja1RpbWVvdXQgPSBjb25maWcuZGVhZGxvY2tUaW1lb3V0O1xuICAgIHRoaXMuX2RlZmF1bHRUb2FzdENvbXByZXNzaW9uID0gY29uZmlnLmRlZmF1bHRUb2FzdENvbXByZXNzaW9uO1xuICAgIHRoaXMuX2lkID0gY29uZmlnLmlkO1xuICAgIHRoaXMuX2lkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQgPSBjb25maWcuaWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dDtcbiAgICB0aGlzLl9qaXQgPSBjb25maWcuaml0O1xuICAgIHRoaXMuX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbiA9IGNvbmZpZy5sb2dBdXRvdmFjdXVtTWluRHVyYXRpb247XG4gICAgdGhpcy5fbG9nRXJyb3JWZXJib3NpdHkgPSBjb25maWcubG9nRXJyb3JWZXJib3NpdHk7XG4gICAgdGhpcy5fbG9nTGluZVByZWZpeCA9IGNvbmZpZy5sb2dMaW5lUHJlZml4O1xuICAgIHRoaXMuX2xvZ01pbkR1cmF0aW9uU3RhdGVtZW50ID0gY29uZmlnLmxvZ01pbkR1cmF0aW9uU3RhdGVtZW50O1xuICAgIHRoaXMuX21heEZpbGVzUGVyUHJvY2VzcyA9IGNvbmZpZy5tYXhGaWxlc1BlclByb2Nlc3M7XG4gICAgdGhpcy5fbWF4TG9ja3NQZXJUcmFuc2FjdGlvbiA9IGNvbmZpZy5tYXhMb2Nrc1BlclRyYW5zYWN0aW9uO1xuICAgIHRoaXMuX21heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnMgPSBjb25maWcubWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2VycztcbiAgICB0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnMgPSBjb25maWcubWF4UGFyYWxsZWxXb3JrZXJzO1xuICAgIHRoaXMuX21heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlciA9IGNvbmZpZy5tYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXI7XG4gICAgdGhpcy5fbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24gPSBjb25maWcubWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb247XG4gICAgdGhpcy5fbWF4UHJlcGFyZWRUcmFuc2FjdGlvbnMgPSBjb25maWcubWF4UHJlcGFyZWRUcmFuc2FjdGlvbnM7XG4gICAgdGhpcy5fbWF4UmVwbGljYXRpb25TbG90cyA9IGNvbmZpZy5tYXhSZXBsaWNhdGlvblNsb3RzO1xuICAgIHRoaXMuX21heFN0YWNrRGVwdGggPSBjb25maWcubWF4U3RhY2tEZXB0aDtcbiAgICB0aGlzLl9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5ID0gY29uZmlnLm1heFN0YW5kYnlBcmNoaXZlRGVsYXk7XG4gICAgdGhpcy5fbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5ID0gY29uZmlnLm1heFN0YW5kYnlTdHJlYW1pbmdEZWxheTtcbiAgICB0aGlzLl9tYXhXYWxTZW5kZXJzID0gY29uZmlnLm1heFdhbFNlbmRlcnM7XG4gICAgdGhpcy5fbWF4V29ya2VyUHJvY2Vzc2VzID0gY29uZmlnLm1heFdvcmtlclByb2Nlc3NlcztcbiAgICB0aGlzLl9wZ1BhcnRtYW5CZ3dJbnRlcnZhbCA9IGNvbmZpZy5wZ1BhcnRtYW5CZ3dJbnRlcnZhbDtcbiAgICB0aGlzLl9wZ1BhcnRtYW5CZ3dSb2xlID0gY29uZmlnLnBnUGFydG1hbkJnd1JvbGU7XG4gICAgdGhpcy5fcGdTdGF0U3RhdGVtZW50c1RyYWNrID0gY29uZmlnLnBnU3RhdFN0YXRlbWVudHNUcmFjaztcbiAgICB0aGlzLl9zaGFyZWRCdWZmZXJzUGVyY2VudGFnZSA9IGNvbmZpZy5zaGFyZWRCdWZmZXJzUGVyY2VudGFnZTtcbiAgICB0aGlzLl90ZW1wRmlsZUxpbWl0ID0gY29uZmlnLnRlbXBGaWxlTGltaXQ7XG4gICAgdGhpcy5fdGltZXpvbmUgPSBjb25maWcudGltZXpvbmU7XG4gICAgdGhpcy5fdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSA9IGNvbmZpZy50cmFja0FjdGl2aXR5UXVlcnlTaXplO1xuICAgIHRoaXMuX3RyYWNrQ29tbWl0VGltZXN0YW1wID0gY29uZmlnLnRyYWNrQ29tbWl0VGltZXN0YW1wO1xuICAgIHRoaXMuX3RyYWNrRnVuY3Rpb25zID0gY29uZmlnLnRyYWNrRnVuY3Rpb25zO1xuICAgIHRoaXMuX3RyYWNrSW9UaW1pbmcgPSBjb25maWcudHJhY2tJb1RpbWluZztcbiAgICB0aGlzLl93YWxTZW5kZXJUaW1lb3V0ID0gY29uZmlnLndhbFNlbmRlclRpbWVvdXQ7XG4gICAgdGhpcy5fd2FsV3JpdGVyRGVsYXkgPSBjb25maWcud2FsV3JpdGVyRGVsYXk7XG4gICAgdGhpcy5fd29ya01lbSA9IGNvbmZpZy53b3JrTWVtO1xuICAgIHRoaXMuX3BnYm91bmNlci5pbnRlcm5hbFZhbHVlID0gY29uZmlnLnBnYm91bmNlcjtcbiAgICB0aGlzLl90aW1lc2NhbGVkYi5pbnRlcm5hbFZhbHVlID0gY29uZmlnLnRpbWVzY2FsZWRiO1xuICB9XG5cbiAgLy8gPT09PT09PT09PVxuICAvLyBBVFRSSUJVVEVTXG4gIC8vID09PT09PT09PT1cblxuICAvLyBhdXRvdmFjdXVtX2FuYWx5emVfc2NhbGVfZmFjdG9yIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bUFuYWx5emVTY2FsZUZhY3Rvcj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bUFuYWx5emVTY2FsZUZhY3RvcigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG92YWN1dW1fYW5hbHl6ZV9zY2FsZV9mYWN0b3InKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3IodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3IgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtQW5hbHl6ZVNjYWxlRmFjdG9yKCkge1xuICAgIHRoaXMuX2F1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3IgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3JJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVTY2FsZUZhY3RvcjtcbiAgfVxuXG4gIC8vIGF1dG92YWN1dW1fYW5hbHl6ZV90aHJlc2hvbGQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvdmFjdXVtQW5hbHl6ZVRocmVzaG9sZD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX2FuYWx5emVfdGhyZXNob2xkJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvdmFjdXVtQW5hbHl6ZVRocmVzaG9sZCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtQW5hbHl6ZVRocmVzaG9sZCgpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVRocmVzaG9sZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQ7XG4gIH1cblxuICAvLyBhdXRvdmFjdXVtX2ZyZWV6ZV9tYXhfYWdlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG92YWN1dW1fZnJlZXplX21heF9hZ2UnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG92YWN1dW1GcmVlemVNYXhBZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2F1dG92YWN1dW1GcmVlemVNYXhBZ2UgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtRnJlZXplTWF4QWdlKCkge1xuICAgIHRoaXMuX2F1dG92YWN1dW1GcmVlemVNYXhBZ2UgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1GcmVlemVNYXhBZ2VJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZTtcbiAgfVxuXG4gIC8vIGF1dG92YWN1dW1fbWF4X3dvcmtlcnMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvdmFjdXVtTWF4V29ya2Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bU1heFdvcmtlcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX21heF93b3JrZXJzJyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvdmFjdXVtTWF4V29ya2Vycyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bU1heFdvcmtlcnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtTWF4V29ya2VycygpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtTWF4V29ya2VycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bU1heFdvcmtlcnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bU1heFdvcmtlcnM7XG4gIH1cblxuICAvLyBhdXRvdmFjdXVtX25hcHRpbWUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvdmFjdXVtTmFwdGltZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bU5hcHRpbWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX25hcHRpbWUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG92YWN1dW1OYXB0aW1lKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtTmFwdGltZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG92YWN1dW1OYXB0aW1lKCkge1xuICAgIHRoaXMuX2F1dG92YWN1dW1OYXB0aW1lID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvdmFjdXVtTmFwdGltZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvdmFjdXVtTmFwdGltZTtcbiAgfVxuXG4gIC8vIGF1dG92YWN1dW1fdmFjdXVtX2Nvc3RfZGVsYXkgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBhdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9kZWxheScpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXkoKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bVZhY3V1bUNvc3REZWxheUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5O1xuICB9XG5cbiAgLy8gYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9saW1pdCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2F1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdhdXRvdmFjdXVtX3ZhY3V1bV9jb3N0X2xpbWl0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBhdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCgpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvdmFjdXVtVmFjdXVtQ29zdExpbWl0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0TGltaXQ7XG4gIH1cblxuICAvLyBhdXRvdmFjdXVtX3ZhY3V1bV9zY2FsZV9mYWN0b3IgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3I/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGF1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvcigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG92YWN1dW1fdmFjdXVtX3NjYWxlX2ZhY3RvcicpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3IgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3IoKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhdXRvdmFjdXVtVmFjdXVtU2NhbGVGYWN0b3JJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yO1xuICB9XG5cbiAgLy8gYXV0b3ZhY3V1bV92YWN1dW1fdGhyZXNob2xkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2F1dG92YWN1dW1fdmFjdXVtX3RocmVzaG9sZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEF1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQoKSB7XG4gICAgdGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYXV0b3ZhY3V1bVZhY3V1bVRocmVzaG9sZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkO1xuICB9XG5cbiAgLy8gYmFja3VwX2hvdXIgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9iYWNrdXBIb3VyPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBiYWNrdXBIb3VyKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYmFja3VwX2hvdXInKTtcbiAgfVxuICBwdWJsaWMgc2V0IGJhY2t1cEhvdXIodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2JhY2t1cEhvdXIgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRCYWNrdXBIb3VyKCkge1xuICAgIHRoaXMuX2JhY2t1cEhvdXIgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGJhY2t1cEhvdXJJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYmFja3VwSG91cjtcbiAgfVxuXG4gIC8vIGJhY2t1cF9taW51dGUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9iYWNrdXBNaW51dGU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGJhY2t1cE1pbnV0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2JhY2t1cF9taW51dGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGJhY2t1cE1pbnV0ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYmFja3VwTWludXRlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QmFja3VwTWludXRlKCkge1xuICAgIHRoaXMuX2JhY2t1cE1pbnV0ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYmFja3VwTWludXRlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2JhY2t1cE1pbnV0ZTtcbiAgfVxuXG4gIC8vIGJnd3JpdGVyX2RlbGF5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYmd3cml0ZXJEZWxheT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmd3cml0ZXJEZWxheSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2Jnd3JpdGVyX2RlbGF5Jyk7XG4gIH1cbiAgcHVibGljIHNldCBiZ3dyaXRlckRlbGF5KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9iZ3dyaXRlckRlbGF5ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Qmd3cml0ZXJEZWxheSgpIHtcbiAgICB0aGlzLl9iZ3dyaXRlckRlbGF5ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBiZ3dyaXRlckRlbGF5SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Jnd3JpdGVyRGVsYXk7XG4gIH1cblxuICAvLyBiZ3dyaXRlcl9mbHVzaF9hZnRlciAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2Jnd3JpdGVyRmx1c2hBZnRlcj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmd3cml0ZXJGbHVzaEFmdGVyKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYmd3cml0ZXJfZmx1c2hfYWZ0ZXInKTtcbiAgfVxuICBwdWJsaWMgc2V0IGJnd3JpdGVyRmx1c2hBZnRlcih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYmd3cml0ZXJGbHVzaEFmdGVyID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0Qmd3cml0ZXJGbHVzaEFmdGVyKCkge1xuICAgIHRoaXMuX2Jnd3JpdGVyRmx1c2hBZnRlciA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYmd3cml0ZXJGbHVzaEFmdGVySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Jnd3JpdGVyRmx1c2hBZnRlcjtcbiAgfVxuXG4gIC8vIGJnd3JpdGVyX2xydV9tYXhwYWdlcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2Jnd3JpdGVyTHJ1TWF4cGFnZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGJnd3JpdGVyTHJ1TWF4cGFnZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdiZ3dyaXRlcl9scnVfbWF4cGFnZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGJnd3JpdGVyTHJ1TWF4cGFnZXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2Jnd3JpdGVyTHJ1TWF4cGFnZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRCZ3dyaXRlckxydU1heHBhZ2VzKCkge1xuICAgIHRoaXMuX2Jnd3JpdGVyTHJ1TWF4cGFnZXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGJnd3JpdGVyTHJ1TWF4cGFnZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYmd3cml0ZXJMcnVNYXhwYWdlcztcbiAgfVxuXG4gIC8vIGJnd3JpdGVyX2xydV9tdWx0aXBsaWVyIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYmd3cml0ZXJMcnVNdWx0aXBsaWVyPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBiZ3dyaXRlckxydU11bHRpcGxpZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdiZ3dyaXRlcl9scnVfbXVsdGlwbGllcicpO1xuICB9XG4gIHB1YmxpYyBzZXQgYmd3cml0ZXJMcnVNdWx0aXBsaWVyKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9iZ3dyaXRlckxydU11bHRpcGxpZXIgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRCZ3dyaXRlckxydU11bHRpcGxpZXIoKSB7XG4gICAgdGhpcy5fYmd3cml0ZXJMcnVNdWx0aXBsaWVyID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBiZ3dyaXRlckxydU11bHRpcGxpZXJJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYmd3cml0ZXJMcnVNdWx0aXBsaWVyO1xuICB9XG5cbiAgLy8gY2x1c3Rlcl9pZCAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IGZhbHNlLCByZXF1aXJlZDogdHJ1ZVxuICBwcml2YXRlIF9jbHVzdGVySWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJJZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2NsdXN0ZXJfaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGNsdXN0ZXJJZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fY2x1c3RlcklkID0gdmFsdWU7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJJZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9jbHVzdGVySWQ7XG4gIH1cblxuICAvLyBkZWFkbG9ja190aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZGVhZGxvY2tUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBkZWFkbG9ja1RpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdkZWFkbG9ja190aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBkZWFkbG9ja1RpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2RlYWRsb2NrVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldERlYWRsb2NrVGltZW91dCgpIHtcbiAgICB0aGlzLl9kZWFkbG9ja1RpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGRlYWRsb2NrVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9kZWFkbG9ja1RpbWVvdXQ7XG4gIH1cblxuICAvLyBkZWZhdWx0X3RvYXN0X2NvbXByZXNzaW9uIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZGVmYXVsdFRvYXN0Q29tcHJlc3Npb24/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGRlZmF1bHRUb2FzdENvbXByZXNzaW9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnZGVmYXVsdF90b2FzdF9jb21wcmVzc2lvbicpO1xuICB9XG4gIHB1YmxpYyBzZXQgZGVmYXVsdFRvYXN0Q29tcHJlc3Npb24odmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2RlZmF1bHRUb2FzdENvbXByZXNzaW9uID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0RGVmYXVsdFRvYXN0Q29tcHJlc3Npb24oKSB7XG4gICAgdGhpcy5fZGVmYXVsdFRvYXN0Q29tcHJlc3Npb24gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGRlZmF1bHRUb2FzdENvbXByZXNzaW9uSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RlZmF1bHRUb2FzdENvbXByZXNzaW9uO1xuICB9XG5cbiAgLy8gaWQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pZD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdpZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2lkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SWQoKSB7XG4gICAgdGhpcy5faWQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lkO1xuICB9XG5cbiAgLy8gaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2lkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJZGxlSW5UcmFuc2FjdGlvblNlc3Npb25UaW1lb3V0KCkge1xuICAgIHRoaXMuX2lkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dDtcbiAgfVxuXG4gIC8vIGppdCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2ppdD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgaml0KCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2ppdCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaml0KHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9qaXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRKaXQoKSB7XG4gICAgdGhpcy5faml0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBqaXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faml0O1xuICB9XG5cbiAgLy8gbG9nX2F1dG92YWN1dW1fbWluX2R1cmF0aW9uIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsb2dBdXRvdmFjdXVtTWluRHVyYXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsb2dfYXV0b3ZhY3V1bV9taW5fZHVyYXRpb24nKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uKCkge1xuICAgIHRoaXMuX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbjtcbiAgfVxuXG4gIC8vIGxvZ19lcnJvcl92ZXJib3NpdHkgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dFcnJvclZlcmJvc2l0eT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgbG9nRXJyb3JWZXJib3NpdHkoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdsb2dfZXJyb3JfdmVyYm9zaXR5Jyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dFcnJvclZlcmJvc2l0eSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fbG9nRXJyb3JWZXJib3NpdHkgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dFcnJvclZlcmJvc2l0eSgpIHtcbiAgICB0aGlzLl9sb2dFcnJvclZlcmJvc2l0eSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nRXJyb3JWZXJib3NpdHlJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nRXJyb3JWZXJib3NpdHk7XG4gIH1cblxuICAvLyBsb2dfbGluZV9wcmVmaXggLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dMaW5lUHJlZml4Pzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBsb2dMaW5lUHJlZml4KCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX2xpbmVfcHJlZml4Jyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dMaW5lUHJlZml4KHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9sb2dMaW5lUHJlZml4ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nTGluZVByZWZpeCgpIHtcbiAgICB0aGlzLl9sb2dMaW5lUHJlZml4ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dMaW5lUHJlZml4SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ0xpbmVQcmVmaXg7XG4gIH1cblxuICAvLyBsb2dfbWluX2R1cmF0aW9uX3N0YXRlbWVudCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ01pbkR1cmF0aW9uU3RhdGVtZW50PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsb2dNaW5EdXJhdGlvblN0YXRlbWVudCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xvZ19taW5fZHVyYXRpb25fc3RhdGVtZW50Jyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dNaW5EdXJhdGlvblN0YXRlbWVudCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9nTWluRHVyYXRpb25TdGF0ZW1lbnQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dNaW5EdXJhdGlvblN0YXRlbWVudCgpIHtcbiAgICB0aGlzLl9sb2dNaW5EdXJhdGlvblN0YXRlbWVudCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nTWluRHVyYXRpb25TdGF0ZW1lbnRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nTWluRHVyYXRpb25TdGF0ZW1lbnQ7XG4gIH1cblxuICAvLyBtYXhfZmlsZXNfcGVyX3Byb2Nlc3MgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhGaWxlc1BlclByb2Nlc3M/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heEZpbGVzUGVyUHJvY2VzcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9maWxlc19wZXJfcHJvY2VzcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4RmlsZXNQZXJQcm9jZXNzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhGaWxlc1BlclByb2Nlc3MgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhGaWxlc1BlclByb2Nlc3MoKSB7XG4gICAgdGhpcy5fbWF4RmlsZXNQZXJQcm9jZXNzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhGaWxlc1BlclByb2Nlc3NJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4RmlsZXNQZXJQcm9jZXNzO1xuICB9XG5cbiAgLy8gbWF4X2xvY2tzX3Blcl90cmFuc2FjdGlvbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heExvY2tzUGVyVHJhbnNhY3Rpb24/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heExvY2tzUGVyVHJhbnNhY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfbG9ja3NfcGVyX3RyYW5zYWN0aW9uJyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhMb2Nrc1BlclRyYW5zYWN0aW9uKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhMb2Nrc1BlclRyYW5zYWN0aW9uID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4TG9ja3NQZXJUcmFuc2FjdGlvbigpIHtcbiAgICB0aGlzLl9tYXhMb2Nrc1BlclRyYW5zYWN0aW9uID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhMb2Nrc1BlclRyYW5zYWN0aW9uSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heExvY2tzUGVyVHJhbnNhY3Rpb247XG4gIH1cblxuICAvLyBtYXhfbG9naWNhbF9yZXBsaWNhdGlvbl93b3JrZXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2Vycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2VycygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9sb2dpY2FsX3JlcGxpY2F0aW9uX3dvcmtlcnMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzKCkge1xuICAgIHRoaXMuX21heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heExvZ2ljYWxSZXBsaWNhdGlvbldvcmtlcnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2VycztcbiAgfVxuXG4gIC8vIG1heF9wYXJhbGxlbF93b3JrZXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4UGFyYWxsZWxXb3JrZXJzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBtYXhQYXJhbGxlbFdvcmtlcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfcGFyYWxsZWxfd29ya2VycycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4UGFyYWxsZWxXb3JrZXJzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhQYXJhbGxlbFdvcmtlcnMoKSB7XG4gICAgdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhQYXJhbGxlbFdvcmtlcnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzO1xuICB9XG5cbiAgLy8gbWF4X3BhcmFsbGVsX3dvcmtlcnNfcGVyX2dhdGhlciAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFBhcmFsbGVsV29ya2Vyc1BlckdhdGhlcj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X3BhcmFsbGVsX3dvcmtlcnNfcGVyX2dhdGhlcicpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXIgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXIoKSB7XG4gICAgdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXJJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyO1xuICB9XG5cbiAgLy8gbWF4X3ByZWRfbG9ja3NfcGVyX3RyYW5zYWN0aW9uIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X3ByZWRfbG9ja3NfcGVyX3RyYW5zYWN0aW9uJyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhQcmVkTG9ja3NQZXJUcmFuc2FjdGlvbih2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24gPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhQcmVkTG9ja3NQZXJUcmFuc2FjdGlvbigpIHtcbiAgICB0aGlzLl9tYXhQcmVkTG9ja3NQZXJUcmFuc2FjdGlvbiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb25JbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb247XG4gIH1cblxuICAvLyBtYXhfcHJlcGFyZWRfdHJhbnNhY3Rpb25zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4UHJlcGFyZWRUcmFuc2FjdGlvbnM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFByZXBhcmVkVHJhbnNhY3Rpb25zKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWF4X3ByZXBhcmVkX3RyYW5zYWN0aW9ucycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4UHJlcGFyZWRUcmFuc2FjdGlvbnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heFByZXBhcmVkVHJhbnNhY3Rpb25zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4UHJlcGFyZWRUcmFuc2FjdGlvbnMoKSB7XG4gICAgdGhpcy5fbWF4UHJlcGFyZWRUcmFuc2FjdGlvbnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heFByZXBhcmVkVHJhbnNhY3Rpb25zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heFByZXBhcmVkVHJhbnNhY3Rpb25zO1xuICB9XG5cbiAgLy8gbWF4X3JlcGxpY2F0aW9uX3Nsb3RzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4UmVwbGljYXRpb25TbG90cz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4UmVwbGljYXRpb25TbG90cygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9yZXBsaWNhdGlvbl9zbG90cycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4UmVwbGljYXRpb25TbG90cyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4UmVwbGljYXRpb25TbG90cyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heFJlcGxpY2F0aW9uU2xvdHMoKSB7XG4gICAgdGhpcy5fbWF4UmVwbGljYXRpb25TbG90cyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4UmVwbGljYXRpb25TbG90c0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhSZXBsaWNhdGlvblNsb3RzO1xuICB9XG5cbiAgLy8gbWF4X3N0YWNrX2RlcHRoIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4U3RhY2tEZXB0aD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4U3RhY2tEZXB0aCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9zdGFja19kZXB0aCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4U3RhY2tEZXB0aCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4U3RhY2tEZXB0aCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heFN0YWNrRGVwdGgoKSB7XG4gICAgdGhpcy5fbWF4U3RhY2tEZXB0aCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4U3RhY2tEZXB0aElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhTdGFja0RlcHRoO1xuICB9XG5cbiAgLy8gbWF4X3N0YW5kYnlfYXJjaGl2ZV9kZWxheSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heFN0YW5kYnlBcmNoaXZlRGVsYXk/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFN0YW5kYnlBcmNoaXZlRGVsYXkoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfc3RhbmRieV9hcmNoaXZlX2RlbGF5Jyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhTdGFuZGJ5QXJjaGl2ZURlbGF5KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4U3RhbmRieUFyY2hpdmVEZWxheSgpIHtcbiAgICB0aGlzLl9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhTdGFuZGJ5QXJjaGl2ZURlbGF5SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heFN0YW5kYnlBcmNoaXZlRGVsYXk7XG4gIH1cblxuICAvLyBtYXhfc3RhbmRieV9zdHJlYW1pbmdfZGVsYXkgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXk/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFN0YW5kYnlTdHJlYW1pbmdEZWxheSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9zdGFuZGJ5X3N0cmVhbWluZ19kZWxheScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXkgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRNYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXkoKSB7XG4gICAgdGhpcy5fbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXlJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5O1xuICB9XG5cbiAgLy8gbWF4X3dhbF9zZW5kZXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4V2FsU2VuZGVycz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4V2FsU2VuZGVycygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF93YWxfc2VuZGVycycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4V2FsU2VuZGVycyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4V2FsU2VuZGVycyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heFdhbFNlbmRlcnMoKSB7XG4gICAgdGhpcy5fbWF4V2FsU2VuZGVycyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4V2FsU2VuZGVyc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhXYWxTZW5kZXJzO1xuICB9XG5cbiAgLy8gbWF4X3dvcmtlcl9wcm9jZXNzZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9tYXhXb3JrZXJQcm9jZXNzZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heFdvcmtlclByb2Nlc3NlcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF93b3JrZXJfcHJvY2Vzc2VzJyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhXb3JrZXJQcm9jZXNzZXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX21heFdvcmtlclByb2Nlc3NlcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heFdvcmtlclByb2Nlc3NlcygpIHtcbiAgICB0aGlzLl9tYXhXb3JrZXJQcm9jZXNzZXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG1heFdvcmtlclByb2Nlc3Nlc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhXb3JrZXJQcm9jZXNzZXM7XG4gIH1cblxuICAvLyBwZ19wYXJ0bWFuX2Jnd19pbnRlcnZhbCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3BnUGFydG1hbkJnd0ludGVydmFsPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBwZ1BhcnRtYW5CZ3dJbnRlcnZhbCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3BnX3BhcnRtYW5fYmd3X2ludGVydmFsJyk7XG4gIH1cbiAgcHVibGljIHNldCBwZ1BhcnRtYW5CZ3dJbnRlcnZhbCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fcGdQYXJ0bWFuQmd3SW50ZXJ2YWwgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQZ1BhcnRtYW5CZ3dJbnRlcnZhbCgpIHtcbiAgICB0aGlzLl9wZ1BhcnRtYW5CZ3dJbnRlcnZhbCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcGdQYXJ0bWFuQmd3SW50ZXJ2YWxJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGdQYXJ0bWFuQmd3SW50ZXJ2YWw7XG4gIH1cblxuICAvLyBwZ19wYXJ0bWFuX2Jnd19yb2xlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfcGdQYXJ0bWFuQmd3Um9sZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgcGdQYXJ0bWFuQmd3Um9sZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3BnX3BhcnRtYW5fYmd3X3JvbGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHBnUGFydG1hbkJnd1JvbGUodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3BnUGFydG1hbkJnd1JvbGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQZ1BhcnRtYW5CZ3dSb2xlKCkge1xuICAgIHRoaXMuX3BnUGFydG1hbkJnd1JvbGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHBnUGFydG1hbkJnd1JvbGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGdQYXJ0bWFuQmd3Um9sZTtcbiAgfVxuXG4gIC8vIHBnX3N0YXRfc3RhdGVtZW50c190cmFjayAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3BnU3RhdFN0YXRlbWVudHNUcmFjaz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgcGdTdGF0U3RhdGVtZW50c1RyYWNrKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgncGdfc3RhdF9zdGF0ZW1lbnRzX3RyYWNrJyk7XG4gIH1cbiAgcHVibGljIHNldCBwZ1N0YXRTdGF0ZW1lbnRzVHJhY2sodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3BnU3RhdFN0YXRlbWVudHNUcmFjayA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFBnU3RhdFN0YXRlbWVudHNUcmFjaygpIHtcbiAgICB0aGlzLl9wZ1N0YXRTdGF0ZW1lbnRzVHJhY2sgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHBnU3RhdFN0YXRlbWVudHNUcmFja0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9wZ1N0YXRTdGF0ZW1lbnRzVHJhY2s7XG4gIH1cblxuICAvLyBzaGFyZWRfYnVmZmVyc19wZXJjZW50YWdlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2U/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHNoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnc2hhcmVkX2J1ZmZlcnNfcGVyY2VudGFnZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3NoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2UoKSB7XG4gICAgdGhpcy5fc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2UgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlO1xuICB9XG5cbiAgLy8gdGVtcF9maWxlX2xpbWl0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGVtcEZpbGVMaW1pdD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGVtcEZpbGVMaW1pdCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RlbXBfZmlsZV9saW1pdCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGVtcEZpbGVMaW1pdCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGVtcEZpbGVMaW1pdCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRlbXBGaWxlTGltaXQoKSB7XG4gICAgdGhpcy5fdGVtcEZpbGVMaW1pdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGVtcEZpbGVMaW1pdElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90ZW1wRmlsZUxpbWl0O1xuICB9XG5cbiAgLy8gdGltZXpvbmUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aW1lem9uZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgdGltZXpvbmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCd0aW1lem9uZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGltZXpvbmUodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3RpbWV6b25lID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGltZXpvbmUoKSB7XG4gICAgdGhpcy5fdGltZXpvbmUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRpbWV6b25lSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RpbWV6b25lO1xuICB9XG5cbiAgLy8gdHJhY2tfYWN0aXZpdHlfcXVlcnlfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RyYWNrQWN0aXZpdHlRdWVyeVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRyYWNrQWN0aXZpdHlRdWVyeVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0cmFja19hY3Rpdml0eV9xdWVyeV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0cmFja0FjdGl2aXR5UXVlcnlTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90cmFja0FjdGl2aXR5UXVlcnlTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSgpIHtcbiAgICB0aGlzLl90cmFja0FjdGl2aXR5UXVlcnlTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0cmFja0FjdGl2aXR5UXVlcnlTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RyYWNrQWN0aXZpdHlRdWVyeVNpemU7XG4gIH1cblxuICAvLyB0cmFja19jb21taXRfdGltZXN0YW1wIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdHJhY2tDb21taXRUaW1lc3RhbXA/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHRyYWNrQ29tbWl0VGltZXN0YW1wKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgndHJhY2tfY29tbWl0X3RpbWVzdGFtcCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgdHJhY2tDb21taXRUaW1lc3RhbXAodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3RyYWNrQ29tbWl0VGltZXN0YW1wID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VHJhY2tDb21taXRUaW1lc3RhbXAoKSB7XG4gICAgdGhpcy5fdHJhY2tDb21taXRUaW1lc3RhbXAgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRyYWNrQ29tbWl0VGltZXN0YW1wSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RyYWNrQ29tbWl0VGltZXN0YW1wO1xuICB9XG5cbiAgLy8gdHJhY2tfZnVuY3Rpb25zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdHJhY2tGdW5jdGlvbnM/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHRyYWNrRnVuY3Rpb25zKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgndHJhY2tfZnVuY3Rpb25zJyk7XG4gIH1cbiAgcHVibGljIHNldCB0cmFja0Z1bmN0aW9ucyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fdHJhY2tGdW5jdGlvbnMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUcmFja0Z1bmN0aW9ucygpIHtcbiAgICB0aGlzLl90cmFja0Z1bmN0aW9ucyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdHJhY2tGdW5jdGlvbnNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdHJhY2tGdW5jdGlvbnM7XG4gIH1cblxuICAvLyB0cmFja19pb190aW1pbmcgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90cmFja0lvVGltaW5nPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCB0cmFja0lvVGltaW5nKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgndHJhY2tfaW9fdGltaW5nJyk7XG4gIH1cbiAgcHVibGljIHNldCB0cmFja0lvVGltaW5nKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl90cmFja0lvVGltaW5nID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VHJhY2tJb1RpbWluZygpIHtcbiAgICB0aGlzLl90cmFja0lvVGltaW5nID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0cmFja0lvVGltaW5nSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RyYWNrSW9UaW1pbmc7XG4gIH1cblxuICAvLyB3YWxfc2VuZGVyX3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF93YWxTZW5kZXJUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB3YWxTZW5kZXJUaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnd2FsX3NlbmRlcl90aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCB3YWxTZW5kZXJUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl93YWxTZW5kZXJUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0V2FsU2VuZGVyVGltZW91dCgpIHtcbiAgICB0aGlzLl93YWxTZW5kZXJUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB3YWxTZW5kZXJUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dhbFNlbmRlclRpbWVvdXQ7XG4gIH1cblxuICAvLyB3YWxfd3JpdGVyX2RlbGF5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfd2FsV3JpdGVyRGVsYXk/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHdhbFdyaXRlckRlbGF5KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnd2FsX3dyaXRlcl9kZWxheScpO1xuICB9XG4gIHB1YmxpYyBzZXQgd2FsV3JpdGVyRGVsYXkodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3dhbFdyaXRlckRlbGF5ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0V2FsV3JpdGVyRGVsYXkoKSB7XG4gICAgdGhpcy5fd2FsV3JpdGVyRGVsYXkgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHdhbFdyaXRlckRlbGF5SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dhbFdyaXRlckRlbGF5O1xuICB9XG5cbiAgLy8gd29ya19tZW0gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF93b3JrTWVtPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB3b3JrTWVtKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnd29ya19tZW0nKTtcbiAgfVxuICBwdWJsaWMgc2V0IHdvcmtNZW0odmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3dvcmtNZW0gPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRXb3JrTWVtKCkge1xuICAgIHRoaXMuX3dvcmtNZW0gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHdvcmtNZW1JbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fd29ya01lbTtcbiAgfVxuXG4gIC8vIHBnYm91bmNlciAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9wZ2JvdW5jZXIgPSBuZXcgRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyTGlzdCh0aGlzLCBcInBnYm91bmNlclwiLCBmYWxzZSk7XG4gIHB1YmxpYyBnZXQgcGdib3VuY2VyKCkge1xuICAgIHJldHVybiB0aGlzLl9wZ2JvdW5jZXI7XG4gIH1cbiAgcHVibGljIHB1dFBnYm91bmNlcih2YWx1ZTogRGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnUGdib3VuY2VyW10gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX3BnYm91bmNlci5pbnRlcm5hbFZhbHVlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0UGdib3VuY2VyKCkge1xuICAgIHRoaXMuX3BnYm91bmNlci5pbnRlcm5hbFZhbHVlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBwZ2JvdW5jZXJJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGdib3VuY2VyLmludGVybmFsVmFsdWU7XG4gIH1cblxuICAvLyB0aW1lc2NhbGVkYiAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aW1lc2NhbGVkYiA9IG5ldyBEYXRhYmFzZVBvc3RncmVzcWxDb25maWdUaW1lc2NhbGVkYk91dHB1dFJlZmVyZW5jZSh0aGlzLCBcInRpbWVzY2FsZWRiXCIpO1xuICBwdWJsaWMgZ2V0IHRpbWVzY2FsZWRiKCkge1xuICAgIHJldHVybiB0aGlzLl90aW1lc2NhbGVkYjtcbiAgfVxuICBwdWJsaWMgcHV0VGltZXNjYWxlZGIodmFsdWU6IERhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiKSB7XG4gICAgdGhpcy5fdGltZXNjYWxlZGIuaW50ZXJuYWxWYWx1ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRpbWVzY2FsZWRiKCkge1xuICAgIHRoaXMuX3RpbWVzY2FsZWRiLmludGVybmFsVmFsdWUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRpbWVzY2FsZWRiSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RpbWVzY2FsZWRiLmludGVybmFsVmFsdWU7XG4gIH1cblxuICAvLyA9PT09PT09PT1cbiAgLy8gU1lOVEhFU0lTXG4gIC8vID09PT09PT09PVxuXG4gIHByb3RlY3RlZCBzeW50aGVzaXplQXR0cmlidXRlcygpOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGF1dG92YWN1dW1fYW5hbHl6ZV9zY2FsZV9mYWN0b3I6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3IpLFxuICAgICAgYXV0b3ZhY3V1bV9hbmFseXplX3RocmVzaG9sZDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bUFuYWx5emVUaHJlc2hvbGQpLFxuICAgICAgYXV0b3ZhY3V1bV9mcmVlemVfbWF4X2FnZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bUZyZWV6ZU1heEFnZSksXG4gICAgICBhdXRvdmFjdXVtX21heF93b3JrZXJzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtTWF4V29ya2VycyksXG4gICAgICBhdXRvdmFjdXVtX25hcHRpbWU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1OYXB0aW1lKSxcbiAgICAgIGF1dG92YWN1dW1fdmFjdXVtX2Nvc3RfZGVsYXk6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1WYWN1dW1Db3N0RGVsYXkpLFxuICAgICAgYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9saW1pdDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCksXG4gICAgICBhdXRvdmFjdXVtX3ZhY3V1bV9zY2FsZV9mYWN0b3I6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1WYWN1dW1TY2FsZUZhY3RvciksXG4gICAgICBhdXRvdmFjdXVtX3ZhY3V1bV90aHJlc2hvbGQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1WYWN1dW1UaHJlc2hvbGQpLFxuICAgICAgYmFja3VwX2hvdXI6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2JhY2t1cEhvdXIpLFxuICAgICAgYmFja3VwX21pbnV0ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmFja3VwTWludXRlKSxcbiAgICAgIGJnd3JpdGVyX2RlbGF5OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iZ3dyaXRlckRlbGF5KSxcbiAgICAgIGJnd3JpdGVyX2ZsdXNoX2FmdGVyOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iZ3dyaXRlckZsdXNoQWZ0ZXIpLFxuICAgICAgYmd3cml0ZXJfbHJ1X21heHBhZ2VzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iZ3dyaXRlckxydU1heHBhZ2VzKSxcbiAgICAgIGJnd3JpdGVyX2xydV9tdWx0aXBsaWVyOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iZ3dyaXRlckxydU11bHRpcGxpZXIpLFxuICAgICAgY2x1c3Rlcl9pZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgIGRlYWRsb2NrX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2RlYWRsb2NrVGltZW91dCksXG4gICAgICBkZWZhdWx0X3RvYXN0X2NvbXByZXNzaW9uOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9kZWZhdWx0VG9hc3RDb21wcmVzc2lvbiksXG4gICAgICBpZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgaWRsZV9pbl90cmFuc2FjdGlvbl9zZXNzaW9uX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2lkbGVJblRyYW5zYWN0aW9uU2Vzc2lvblRpbWVvdXQpLFxuICAgICAgaml0OiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5faml0KSxcbiAgICAgIGxvZ19hdXRvdmFjdXVtX21pbl9kdXJhdGlvbjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbG9nQXV0b3ZhY3V1bU1pbkR1cmF0aW9uKSxcbiAgICAgIGxvZ19lcnJvcl92ZXJib3NpdHk6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2xvZ0Vycm9yVmVyYm9zaXR5KSxcbiAgICAgIGxvZ19saW5lX3ByZWZpeDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fbG9nTGluZVByZWZpeCksXG4gICAgICBsb2dfbWluX2R1cmF0aW9uX3N0YXRlbWVudDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbG9nTWluRHVyYXRpb25TdGF0ZW1lbnQpLFxuICAgICAgbWF4X2ZpbGVzX3Blcl9wcm9jZXNzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tYXhGaWxlc1BlclByb2Nlc3MpLFxuICAgICAgbWF4X2xvY2tzX3Blcl90cmFuc2FjdGlvbjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4TG9ja3NQZXJUcmFuc2FjdGlvbiksXG4gICAgICBtYXhfbG9naWNhbF9yZXBsaWNhdGlvbl93b3JrZXJzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tYXhMb2dpY2FsUmVwbGljYXRpb25Xb3JrZXJzKSxcbiAgICAgIG1heF9wYXJhbGxlbF93b3JrZXJzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnMpLFxuICAgICAgbWF4X3BhcmFsbGVsX3dvcmtlcnNfcGVyX2dhdGhlcjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4UGFyYWxsZWxXb3JrZXJzUGVyR2F0aGVyKSxcbiAgICAgIG1heF9wcmVkX2xvY2tzX3Blcl90cmFuc2FjdGlvbjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4UHJlZExvY2tzUGVyVHJhbnNhY3Rpb24pLFxuICAgICAgbWF4X3ByZXBhcmVkX3RyYW5zYWN0aW9uczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4UHJlcGFyZWRUcmFuc2FjdGlvbnMpLFxuICAgICAgbWF4X3JlcGxpY2F0aW9uX3Nsb3RzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tYXhSZXBsaWNhdGlvblNsb3RzKSxcbiAgICAgIG1heF9zdGFja19kZXB0aDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4U3RhY2tEZXB0aCksXG4gICAgICBtYXhfc3RhbmRieV9hcmNoaXZlX2RlbGF5OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5KSxcbiAgICAgIG1heF9zdGFuZGJ5X3N0cmVhbWluZ19kZWxheTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4U3RhbmRieVN0cmVhbWluZ0RlbGF5KSxcbiAgICAgIG1heF93YWxfc2VuZGVyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4V2FsU2VuZGVycyksXG4gICAgICBtYXhfd29ya2VyX3Byb2Nlc3NlczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4V29ya2VyUHJvY2Vzc2VzKSxcbiAgICAgIHBnX3BhcnRtYW5fYmd3X2ludGVydmFsOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9wZ1BhcnRtYW5CZ3dJbnRlcnZhbCksXG4gICAgICBwZ19wYXJ0bWFuX2Jnd19yb2xlOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9wZ1BhcnRtYW5CZ3dSb2xlKSxcbiAgICAgIHBnX3N0YXRfc3RhdGVtZW50c190cmFjazogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fcGdTdGF0U3RhdGVtZW50c1RyYWNrKSxcbiAgICAgIHNoYXJlZF9idWZmZXJzX3BlcmNlbnRhZ2U6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3NoYXJlZEJ1ZmZlcnNQZXJjZW50YWdlKSxcbiAgICAgIHRlbXBfZmlsZV9saW1pdDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGVtcEZpbGVMaW1pdCksXG4gICAgICB0aW1lem9uZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fdGltZXpvbmUpLFxuICAgICAgdHJhY2tfYWN0aXZpdHlfcXVlcnlfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdHJhY2tBY3Rpdml0eVF1ZXJ5U2l6ZSksXG4gICAgICB0cmFja19jb21taXRfdGltZXN0YW1wOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl90cmFja0NvbW1pdFRpbWVzdGFtcCksXG4gICAgICB0cmFja19mdW5jdGlvbnM6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX3RyYWNrRnVuY3Rpb25zKSxcbiAgICAgIHRyYWNrX2lvX3RpbWluZzogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fdHJhY2tJb1RpbWluZyksXG4gICAgICB3YWxfc2VuZGVyX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3dhbFNlbmRlclRpbWVvdXQpLFxuICAgICAgd2FsX3dyaXRlcl9kZWxheTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fd2FsV3JpdGVyRGVsYXkpLFxuICAgICAgd29ya19tZW06IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3dvcmtNZW0pLFxuICAgICAgcGdib3VuY2VyOiBjZGt0bi5saXN0TWFwcGVyKGRhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1BnYm91bmNlclRvVGVycmFmb3JtLCB0cnVlKSh0aGlzLl9wZ2JvdW5jZXIuaW50ZXJuYWxWYWx1ZSksXG4gICAgICB0aW1lc2NhbGVkYjogZGF0YWJhc2VQb3N0Z3Jlc3FsQ29uZmlnVGltZXNjYWxlZGJUb1RlcnJhZm9ybSh0aGlzLl90aW1lc2NhbGVkYi5pbnRlcm5hbFZhbHVlKSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVIY2xBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICBjb25zdCBhdHRycyA9IHtcbiAgICAgIGF1dG92YWN1dW1fYW5hbHl6ZV9zY2FsZV9mYWN0b3I6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1BbmFseXplU2NhbGVGYWN0b3IpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBhdXRvdmFjdXVtX2FuYWx5emVfdGhyZXNob2xkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtQW5hbHl6ZVRocmVzaG9sZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGF1dG92YWN1dW1fZnJlZXplX21heF9hZ2U6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2F1dG92YWN1dW1GcmVlemVNYXhBZ2UpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBhdXRvdmFjdXVtX21heF93b3JrZXJzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtTWF4V29ya2VycyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGF1dG92YWN1dW1fbmFwdGltZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bU5hcHRpbWUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBhdXRvdmFjdXVtX3ZhY3V1bV9jb3N0X2RlbGF5OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtVmFjdXVtQ29zdERlbGF5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYXV0b3ZhY3V1bV92YWN1dW1fY29zdF9saW1pdDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bVZhY3V1bUNvc3RMaW1pdCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGF1dG92YWN1dW1fdmFjdXVtX3NjYWxlX2ZhY3Rvcjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYXV0b3ZhY3V1bVZhY3V1bVNjYWxlRmFjdG9yKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYXV0b3ZhY3V1bV92YWN1dW1fdGhyZXNob2xkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9hdXRvdmFjdXVtVmFjdXVtVGhyZXNob2xkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgYmFja3VwX2hvdXI6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2JhY2t1cEhvdXIpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiYWNrdXBfbWludXRlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9iYWNrdXBNaW51dGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiZ3dyaXRlcl9kZWxheToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJEZWxheSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGJnd3JpdGVyX2ZsdXNoX2FmdGVyOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9iZ3dyaXRlckZsdXNoQWZ0ZXIpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiZ3dyaXRlcl9scnVfbWF4cGFnZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2Jnd3JpdGVyTHJ1TWF4cGFnZXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiZ3dyaXRlcl9scnVfbXVsdGlwbGllcjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYmd3cml0ZXJMcnVNdWx0aXBsaWVyKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgY2x1c3Rlcl9pZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgZGVhZGxvY2tfdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fZGVhZGxvY2tUaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgZGVmYXVsdF90b2FzdF9jb21wcmVzc2lvbjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fZGVmYXVsdFRvYXN0Q29tcHJlc3Npb24pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBpZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBpZGxlX2luX3RyYW5zYWN0aW9uX3Nlc3Npb25fdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faWRsZUluVHJhbnNhY3Rpb25TZXNzaW9uVGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGppdDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2ppdCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBsb2dfYXV0b3ZhY3V1bV9taW5fZHVyYXRpb246IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ0F1dG92YWN1dW1NaW5EdXJhdGlvbiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGxvZ19lcnJvcl92ZXJib3NpdHk6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ0Vycm9yVmVyYm9zaXR5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9nX2xpbmVfcHJlZml4OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dMaW5lUHJlZml4KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9nX21pbl9kdXJhdGlvbl9zdGF0ZW1lbnQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ01pbkR1cmF0aW9uU3RhdGVtZW50KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X2ZpbGVzX3Blcl9wcm9jZXNzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhGaWxlc1BlclByb2Nlc3MpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfbG9ja3NfcGVyX3RyYW5zYWN0aW9uOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhMb2Nrc1BlclRyYW5zYWN0aW9uKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X2xvZ2ljYWxfcmVwbGljYXRpb25fd29ya2Vyczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4TG9naWNhbFJlcGxpY2F0aW9uV29ya2VycyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1heF9wYXJhbGxlbF93b3JrZXJzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfcGFyYWxsZWxfd29ya2Vyc19wZXJfZ2F0aGVyOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhQYXJhbGxlbFdvcmtlcnNQZXJHYXRoZXIpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfcHJlZF9sb2Nrc19wZXJfdHJhbnNhY3Rpb246IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heFByZWRMb2Nrc1BlclRyYW5zYWN0aW9uKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3ByZXBhcmVkX3RyYW5zYWN0aW9uczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4UHJlcGFyZWRUcmFuc2FjdGlvbnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfcmVwbGljYXRpb25fc2xvdHM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heFJlcGxpY2F0aW9uU2xvdHMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfc3RhY2tfZGVwdGg6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heFN0YWNrRGVwdGgpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfc3RhbmRieV9hcmNoaXZlX2RlbGF5OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhTdGFuZGJ5QXJjaGl2ZURlbGF5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X3N0YW5kYnlfc3RyZWFtaW5nX2RlbGF5OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhTdGFuZGJ5U3RyZWFtaW5nRGVsYXkpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfd2FsX3NlbmRlcnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX21heFdhbFNlbmRlcnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBtYXhfd29ya2VyX3Byb2Nlc3Nlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4V29ya2VyUHJvY2Vzc2VzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgcGdfcGFydG1hbl9iZ3dfaW50ZXJ2YWw6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3BnUGFydG1hbkJnd0ludGVydmFsKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgcGdfcGFydG1hbl9iZ3dfcm9sZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fcGdQYXJ0bWFuQmd3Um9sZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIHBnX3N0YXRfc3RhdGVtZW50c190cmFjazoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fcGdTdGF0U3RhdGVtZW50c1RyYWNrKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgc2hhcmVkX2J1ZmZlcnNfcGVyY2VudGFnZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fc2hhcmVkQnVmZmVyc1BlcmNlbnRhZ2UpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0ZW1wX2ZpbGVfbGltaXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RlbXBGaWxlTGltaXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aW1lem9uZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fdGltZXpvbmUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICB0cmFja19hY3Rpdml0eV9xdWVyeV9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90cmFja0FjdGl2aXR5UXVlcnlTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdHJhY2tfY29tbWl0X3RpbWVzdGFtcDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fdHJhY2tDb21taXRUaW1lc3RhbXApLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICB0cmFja19mdW5jdGlvbnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3RyYWNrRnVuY3Rpb25zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgdHJhY2tfaW9fdGltaW5nOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl90cmFja0lvVGltaW5nKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgd2FsX3NlbmRlcl90aW1lb3V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl93YWxTZW5kZXJUaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgd2FsX3dyaXRlcl9kZWxheToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fd2FsV3JpdGVyRGVsYXkpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB3b3JrX21lbToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fd29ya01lbSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHBnYm91bmNlcjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubGlzdE1hcHBlckhjbChkYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJUb0hjbFRlcnJhZm9ybSwgdHJ1ZSkodGhpcy5fcGdib3VuY2VyLmludGVybmFsVmFsdWUpLFxuICAgICAgICBpc0Jsb2NrOiB0cnVlLFxuICAgICAgICB0eXBlOiBcImxpc3RcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJEYXRhYmFzZVBvc3RncmVzcWxDb25maWdQZ2JvdW5jZXJMaXN0XCIsXG4gICAgICB9LFxuICAgICAgdGltZXNjYWxlZGI6IHtcbiAgICAgICAgdmFsdWU6IGRhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiVG9IY2xUZXJyYWZvcm0odGhpcy5fdGltZXNjYWxlZGIuaW50ZXJuYWxWYWx1ZSksXG4gICAgICAgIGlzQmxvY2s6IHRydWUsXG4gICAgICAgIHR5cGU6IFwibGlzdFwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIkRhdGFiYXNlUG9zdGdyZXNxbENvbmZpZ1RpbWVzY2FsZWRiTGlzdFwiLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgLy8gcmVtb3ZlIHVuZGVmaW5lZCBhdHRyaWJ1dGVzXG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhhdHRycykuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnZhbHVlICE9PSB1bmRlZmluZWQgKSlcbiAgfVxufVxuIl19