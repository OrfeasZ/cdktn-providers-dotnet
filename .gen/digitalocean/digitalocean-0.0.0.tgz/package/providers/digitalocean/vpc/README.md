# `digitalocean_vpc`

Refer to the Terraform Registry for docs: [`digitalocean_vpc`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc).
