# `data_digitalocean_dedicated_inference_tokens`

Refer to the Terraform Registry for docs: [`data_digitalocean_dedicated_inference_tokens`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference_tokens).
