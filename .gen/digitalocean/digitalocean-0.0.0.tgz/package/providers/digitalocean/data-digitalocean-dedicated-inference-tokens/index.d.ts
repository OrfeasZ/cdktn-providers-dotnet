import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDedicatedInferenceTokensConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the dedicated inference endpoint to list tokens for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#dedicated_inference_id DataDigitaloceanDedicatedInferenceTokens#dedicated_inference_id}
    */
    readonly dedicatedInferenceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#id DataDigitaloceanDedicatedInferenceTokens#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#filter DataDigitaloceanDedicatedInferenceTokens#filter}
    */
    readonly filter?: DataDigitaloceanDedicatedInferenceTokensFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#sort DataDigitaloceanDedicatedInferenceTokens#sort}
    */
    readonly sort?: DataDigitaloceanDedicatedInferenceTokensSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanDedicatedInferenceTokensTokens {
}
export declare function dataDigitaloceanDedicatedInferenceTokensTokensToTerraform(struct?: DataDigitaloceanDedicatedInferenceTokensTokens): any;
export declare function dataDigitaloceanDedicatedInferenceTokensTokensToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceTokensTokens): any;
export declare class DataDigitaloceanDedicatedInferenceTokensTokensOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceTokensTokens | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceTokensTokens | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
}
export declare class DataDigitaloceanDedicatedInferenceTokensTokensList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceTokensTokensOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceTokensFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#all DataDigitaloceanDedicatedInferenceTokens#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#key DataDigitaloceanDedicatedInferenceTokens#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#match_by DataDigitaloceanDedicatedInferenceTokens#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#values DataDigitaloceanDedicatedInferenceTokens#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanDedicatedInferenceTokensFilterToTerraform(struct?: DataDigitaloceanDedicatedInferenceTokensFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanDedicatedInferenceTokensFilterToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceTokensFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanDedicatedInferenceTokensFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceTokensFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceTokensFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanDedicatedInferenceTokensFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDedicatedInferenceTokensFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceTokensFilterOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceTokensSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#direction DataDigitaloceanDedicatedInferenceTokens#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#key DataDigitaloceanDedicatedInferenceTokens#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanDedicatedInferenceTokensSortToTerraform(struct?: DataDigitaloceanDedicatedInferenceTokensSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanDedicatedInferenceTokensSortToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceTokensSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanDedicatedInferenceTokensSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceTokensSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceTokensSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanDedicatedInferenceTokensSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDedicatedInferenceTokensSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceTokensSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens digitalocean_dedicated_inference_tokens}
*/
export declare class DataDigitaloceanDedicatedInferenceTokens extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_dedicated_inference_tokens";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDedicatedInferenceTokens resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDedicatedInferenceTokens to import
    * @param importFromId The id of the existing DataDigitaloceanDedicatedInferenceTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDedicatedInferenceTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_tokens digitalocean_dedicated_inference_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDedicatedInferenceTokensConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanDedicatedInferenceTokensConfig);
    private _dedicatedInferenceId?;
    get dedicatedInferenceId(): string;
    set dedicatedInferenceId(value: string);
    get dedicatedInferenceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tokens;
    get tokens(): DataDigitaloceanDedicatedInferenceTokensTokensList;
    private _filter;
    get filter(): DataDigitaloceanDedicatedInferenceTokensFilterList;
    putFilter(value: DataDigitaloceanDedicatedInferenceTokensFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanDedicatedInferenceTokensFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanDedicatedInferenceTokensSortList;
    putSort(value: DataDigitaloceanDedicatedInferenceTokensSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanDedicatedInferenceTokensSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
