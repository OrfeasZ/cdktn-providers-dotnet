"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseValkeyConfig = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config digitalocean_database_valkey_config}
*/
class DatabaseValkeyConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseValkeyConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseValkeyConfig to import
    * @param importFromId The id of the existing DatabaseValkeyConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseValkeyConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_valkey_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_valkey_config digitalocean_database_valkey_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseValkeyConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_valkey_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._aclChannelsDefault = config.aclChannelsDefault;
        this._clusterId = config.clusterId;
        this._frequentSnapshots = config.frequentSnapshots;
        this._id = config.id;
        this._ioThreads = config.ioThreads;
        this._lfuDecayTime = config.lfuDecayTime;
        this._lfuLogFactor = config.lfuLogFactor;
        this._notifyKeyspaceEvents = config.notifyKeyspaceEvents;
        this._numberOfDatabases = config.numberOfDatabases;
        this._persistence = config.persistence;
        this._pubsubClientOutputBufferLimit = config.pubsubClientOutputBufferLimit;
        this._ssl = config.ssl;
        this._timeout = config.timeout;
        this._valkeyActiveExpireEffort = config.valkeyActiveExpireEffort;
        this._valkeyMaxmemoryPolicy = config.valkeyMaxmemoryPolicy;
    }
    get aclChannelsDefault() {
        return this.getStringAttribute('acl_channels_default');
    }
    set aclChannelsDefault(value) {
        this._aclChannelsDefault = value;
    }
    resetAclChannelsDefault() {
        this._aclChannelsDefault = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get aclChannelsDefaultInput() {
        return this._aclChannelsDefault;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get frequentSnapshots() {
        return this.getBooleanAttribute('frequent_snapshots');
    }
    set frequentSnapshots(value) {
        this._frequentSnapshots = value;
    }
    resetFrequentSnapshots() {
        this._frequentSnapshots = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get frequentSnapshotsInput() {
        return this._frequentSnapshots;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get ioThreads() {
        return this.getNumberAttribute('io_threads');
    }
    set ioThreads(value) {
        this._ioThreads = value;
    }
    resetIoThreads() {
        this._ioThreads = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ioThreadsInput() {
        return this._ioThreads;
    }
    get lfuDecayTime() {
        return this.getNumberAttribute('lfu_decay_time');
    }
    set lfuDecayTime(value) {
        this._lfuDecayTime = value;
    }
    resetLfuDecayTime() {
        this._lfuDecayTime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get lfuDecayTimeInput() {
        return this._lfuDecayTime;
    }
    get lfuLogFactor() {
        return this.getNumberAttribute('lfu_log_factor');
    }
    set lfuLogFactor(value) {
        this._lfuLogFactor = value;
    }
    resetLfuLogFactor() {
        this._lfuLogFactor = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get lfuLogFactorInput() {
        return this._lfuLogFactor;
    }
    get notifyKeyspaceEvents() {
        return this.getStringAttribute('notify_keyspace_events');
    }
    set notifyKeyspaceEvents(value) {
        this._notifyKeyspaceEvents = value;
    }
    resetNotifyKeyspaceEvents() {
        this._notifyKeyspaceEvents = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get notifyKeyspaceEventsInput() {
        return this._notifyKeyspaceEvents;
    }
    get numberOfDatabases() {
        return this.getNumberAttribute('number_of_databases');
    }
    set numberOfDatabases(value) {
        this._numberOfDatabases = value;
    }
    resetNumberOfDatabases() {
        this._numberOfDatabases = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get numberOfDatabasesInput() {
        return this._numberOfDatabases;
    }
    get persistence() {
        return this.getStringAttribute('persistence');
    }
    set persistence(value) {
        this._persistence = value;
    }
    resetPersistence() {
        this._persistence = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get persistenceInput() {
        return this._persistence;
    }
    get pubsubClientOutputBufferLimit() {
        return this.getNumberAttribute('pubsub_client_output_buffer_limit');
    }
    set pubsubClientOutputBufferLimit(value) {
        this._pubsubClientOutputBufferLimit = value;
    }
    resetPubsubClientOutputBufferLimit() {
        this._pubsubClientOutputBufferLimit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pubsubClientOutputBufferLimitInput() {
        return this._pubsubClientOutputBufferLimit;
    }
    get ssl() {
        return this.getBooleanAttribute('ssl');
    }
    set ssl(value) {
        this._ssl = value;
    }
    resetSsl() {
        this._ssl = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sslInput() {
        return this._ssl;
    }
    get timeout() {
        return this.getNumberAttribute('timeout');
    }
    set timeout(value) {
        this._timeout = value;
    }
    resetTimeout() {
        this._timeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get timeoutInput() {
        return this._timeout;
    }
    get valkeyActiveExpireEffort() {
        return this.getNumberAttribute('valkey_active_expire_effort');
    }
    set valkeyActiveExpireEffort(value) {
        this._valkeyActiveExpireEffort = value;
    }
    resetValkeyActiveExpireEffort() {
        this._valkeyActiveExpireEffort = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get valkeyActiveExpireEffortInput() {
        return this._valkeyActiveExpireEffort;
    }
    get valkeyMaxmemoryPolicy() {
        return this.getStringAttribute('valkey_maxmemory_policy');
    }
    set valkeyMaxmemoryPolicy(value) {
        this._valkeyMaxmemoryPolicy = value;
    }
    resetValkeyMaxmemoryPolicy() {
        this._valkeyMaxmemoryPolicy = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get valkeyMaxmemoryPolicyInput() {
        return this._valkeyMaxmemoryPolicy;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            acl_channels_default: cdktn.stringToTerraform(this._aclChannelsDefault),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            frequent_snapshots: cdktn.booleanToTerraform(this._frequentSnapshots),
            id: cdktn.stringToTerraform(this._id),
            io_threads: cdktn.numberToTerraform(this._ioThreads),
            lfu_decay_time: cdktn.numberToTerraform(this._lfuDecayTime),
            lfu_log_factor: cdktn.numberToTerraform(this._lfuLogFactor),
            notify_keyspace_events: cdktn.stringToTerraform(this._notifyKeyspaceEvents),
            number_of_databases: cdktn.numberToTerraform(this._numberOfDatabases),
            persistence: cdktn.stringToTerraform(this._persistence),
            pubsub_client_output_buffer_limit: cdktn.numberToTerraform(this._pubsubClientOutputBufferLimit),
            ssl: cdktn.booleanToTerraform(this._ssl),
            timeout: cdktn.numberToTerraform(this._timeout),
            valkey_active_expire_effort: cdktn.numberToTerraform(this._valkeyActiveExpireEffort),
            valkey_maxmemory_policy: cdktn.stringToTerraform(this._valkeyMaxmemoryPolicy),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            acl_channels_default: {
                value: cdktn.stringToHclTerraform(this._aclChannelsDefault),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            frequent_snapshots: {
                value: cdktn.booleanToHclTerraform(this._frequentSnapshots),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            io_threads: {
                value: cdktn.numberToHclTerraform(this._ioThreads),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            lfu_decay_time: {
                value: cdktn.numberToHclTerraform(this._lfuDecayTime),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            lfu_log_factor: {
                value: cdktn.numberToHclTerraform(this._lfuLogFactor),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            notify_keyspace_events: {
                value: cdktn.stringToHclTerraform(this._notifyKeyspaceEvents),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            number_of_databases: {
                value: cdktn.numberToHclTerraform(this._numberOfDatabases),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            persistence: {
                value: cdktn.stringToHclTerraform(this._persistence),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            pubsub_client_output_buffer_limit: {
                value: cdktn.numberToHclTerraform(this._pubsubClientOutputBufferLimit),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ssl: {
                value: cdktn.booleanToHclTerraform(this._ssl),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            timeout: {
                value: cdktn.numberToHclTerraform(this._timeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            valkey_active_expire_effort: {
                value: cdktn.numberToHclTerraform(this._valkeyActiveExpireEffort),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            valkey_maxmemory_policy: {
                value: cdktn.stringToHclTerraform(this._valkeyMaxmemoryPolicy),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseValkeyConfig = DatabaseValkeyConfig;
_a = JSII_RTTI_SYMBOL_1;
DatabaseValkeyConfig[_a] = { fqn: "digitalocean.databaseValkeyConfig.DatabaseValkeyConfig", version: "0.0.0" };
// =================
// STATIC PROPERTIES
// =================
DatabaseValkeyConfig.tfResourceType = "digitalocean_database_valkey_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUlBLCtCQUErQjtBQWtIL0I7O0VBRUU7QUFDRixNQUFhLG9CQUFxQixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPL0QsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLHFDQUFxQyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM3SixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBa0M7UUFDakYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSxxQ0FBcUM7WUFDNUQsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDO1FBQ3JELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUN6QyxJQUFJLENBQUMscUJBQXFCLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixDQUFDO1FBQ3pELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsNkJBQTZCLENBQUM7UUFDM0UsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUMvQixJQUFJLENBQUMseUJBQXlCLEdBQUcsTUFBTSxDQUFDLHdCQUF3QixDQUFDO1FBQ2pFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7SUFDN0QsQ0FBQztJQVFELElBQVcsa0JBQWtCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNELElBQVcsa0JBQWtCLENBQUMsS0FBYTtRQUN6QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO0lBQ25DLENBQUM7SUFDTSx1QkFBdUI7UUFDNUIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLFNBQVMsQ0FBQztJQUN2QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDO0lBQ2xDLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWtDO1FBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFXLEVBQUUsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFDTSxPQUFPO1FBQ1osSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2xCLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNNLGNBQWM7UUFDbkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUM7SUFDOUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBQ0QsSUFBVyxZQUFZLENBQUMsS0FBYTtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBQ00saUJBQWlCO1FBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzVCLENBQUM7SUFJRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBQ0QsSUFBVyxZQUFZLENBQUMsS0FBYTtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM3QixDQUFDO0lBQ00saUJBQWlCO1FBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsU0FBUyxDQUFDO0lBQ2pDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzVCLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsV0FBVztRQUNwQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBQ0QsSUFBVyxXQUFXLENBQUMsS0FBYTtRQUNsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBQ00sZ0JBQWdCO1FBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsU0FBUyxDQUFDO0lBQ2hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFJRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFDRCxJQUFXLDZCQUE2QixDQUFDLEtBQWE7UUFDcEQsSUFBSSxDQUFDLDhCQUE4QixHQUFHLEtBQUssQ0FBQztJQUM5QyxDQUFDO0lBQ00sa0NBQWtDO1FBQ3ZDLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxTQUFTLENBQUM7SUFDbEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtDQUFrQztRQUMzQyxPQUFPLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztJQUM3QyxDQUFDO0lBSUQsSUFBVyxHQUFHO1FBQ1osT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNELElBQVcsR0FBRyxDQUFDLEtBQWtDO1FBQy9DLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLENBQUM7SUFDTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7SUFDeEIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25CLENBQUM7SUFJRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQVcsT0FBTyxDQUFDLEtBQWE7UUFDOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDeEIsQ0FBQztJQUNNLFlBQVk7UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7SUFDNUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUJBQXlCLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN2RSxVQUFVLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDcEQsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNyRSxFQUFFLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDckMsVUFBVSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3BELGNBQWMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUMzRCxjQUFjLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDM0Qsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUMzRSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3JFLFdBQVcsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUN2RCxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO1lBQy9GLEdBQUcsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN4QyxPQUFPLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDL0MsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUNwRix1QkFBdUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1NBQzlFLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCO1FBQy9CLE1BQU0sS0FBSyxHQUFHO1lBQ1osb0JBQW9CLEVBQUU7Z0JBQ3BCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDM0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELEVBQUUsRUFBRTtnQkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxVQUFVLEVBQUU7Z0JBQ1YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dCQUNsRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsY0FBYyxFQUFFO2dCQUNkLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztnQkFDckQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGNBQWMsRUFBRTtnQkFDZCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQ3JELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxzQkFBc0IsRUFBRTtnQkFDdEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzdELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxtQkFBbUIsRUFBRTtnQkFDbkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxXQUFXLEVBQUU7Z0JBQ1gsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNwRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsaUNBQWlDLEVBQUU7Z0JBQ2pDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO2dCQUN0RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsR0FBRyxFQUFFO2dCQUNILEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDN0MsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELE9BQU8sRUFBRTtnQkFDUCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ2hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwyQkFBMkIsRUFBRTtnQkFDM0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7U0FDRixDQUFDO1FBRUYsOEJBQThCO1FBQzlCLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFFLENBQUMsQ0FBQTtJQUM1SCxDQUFDOztBQTFhSCxvREEyYUM7OztBQXphQyxvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNHLG1DQUFjLEdBQUcscUNBQXFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZ1xuLy8gZ2VuZXJhdGVkIGZyb20gdGVycmFmb3JtIHJlc291cmNlIHNjaGVtYVxuXG5pbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCAqIGFzIGNka3RuIGZyb20gJ2Nka3RuJztcblxuLy8gQ29uZmlndXJhdGlvblxuXG5leHBvcnQgaW50ZXJmYWNlIERhdGFiYXNlVmFsa2V5Q29uZmlnQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtTWV0YUFyZ3VtZW50cyB7XG4gIC8qKlxuICAqIERldGVybWluZXMgZGVmYXVsdCBwdWIvc3ViIGNoYW5uZWxzJyBBQ0wgZm9yIG5ldyB1c2VycyBpZiBBQ0wgaXMgbm90IHN1cHBsaWVkLiBXaGVuIHRoaXMgb3B0aW9uIGlzIG5vdCBkZWZpbmVkLCBhbGxfY2hhbm5lbHMgaXMgYXNzdW1lZCB0byBrZWVwIGJhY2t3YXJkIGNvbXBhdGliaWxpdHkuIFRoaXMgb3B0aW9uIGRvZXNuJ3QgYWZmZWN0IFZhbGtleSBjb25maWd1cmF0aW9uIGFjbC1wdWJzdWItZGVmYXVsdC5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjYWNsX2NoYW5uZWxzX2RlZmF1bHQgRGF0YWJhc2VWYWxrZXlDb25maWcjYWNsX2NoYW5uZWxzX2RlZmF1bHR9XG4gICovXG4gIHJlYWRvbmx5IGFjbENoYW5uZWxzRGVmYXVsdD86IHN0cmluZztcbiAgLyoqXG4gICogQSB1bmlxdWUgaWRlbnRpZmllciBmb3IgdGhlIGRhdGFiYXNlIGNsdXN0ZXIuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2NsdXN0ZXJfaWQgRGF0YWJhc2VWYWxrZXlDb25maWcjY2x1c3Rlcl9pZH1cbiAgKi9cbiAgcmVhZG9ubHkgY2x1c3RlcklkOiBzdHJpbmc7XG4gIC8qKlxuICAqIEZyZXF1ZW50IFJEQiBzbmFwc2hvdHMuIFdoZW4gZW5hYmxlZCwgVmFsa2V5IHdpbGwgY3JlYXRlIGZyZXF1ZW50IGxvY2FsIFJEQiBzbmFwc2hvdHMuIFdoZW4gZGlzYWJsZWQsIFZhbGtleSB3aWxsIG9ubHkgdGFrZSBSREIgc25hcHNob3RzIHdoZW4gYSBiYWNrdXAgaXMgY3JlYXRlZCwgYmFzZWQgb24gdGhlIGJhY2t1cCBzY2hlZHVsZS4gVGhpcyBzZXR0aW5nIGlzIGlnbm9yZWQgd2hlbiB2YWxrZXlfcGVyc2lzdGVuY2UgaXMgc2V0IHRvIG9mZi5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjZnJlcXVlbnRfc25hcHNob3RzIERhdGFiYXNlVmFsa2V5Q29uZmlnI2ZyZXF1ZW50X3NuYXBzaG90c31cbiAgKi9cbiAgcmVhZG9ubHkgZnJlcXVlbnRTbmFwc2hvdHM/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjaWQgRGF0YWJhc2VWYWxrZXlDb25maWcjaWR9XG4gICpcbiAgKiBQbGVhc2UgYmUgYXdhcmUgdGhhdCB0aGUgaWQgZmllbGQgaXMgYXV0b21hdGljYWxseSBhZGRlZCB0byBhbGwgcmVzb3VyY2VzIGluIFRlcnJhZm9ybSBwcm92aWRlcnMgdXNpbmcgYSBUZXJyYWZvcm0gcHJvdmlkZXIgU0RLIHZlcnNpb24gYmVsb3cgMi5cbiAgKiBJZiB5b3UgZXhwZXJpZW5jZSBwcm9ibGVtcyBzZXR0aW5nIHRoaXMgdmFsdWUgaXQgbWlnaHQgbm90IGJlIHNldHRhYmxlLiBQbGVhc2UgdGFrZSBhIGxvb2sgYXQgdGhlIHByb3ZpZGVyIGRvY3VtZW50YXRpb24gdG8gZW5zdXJlIGl0IHNob3VsZCBiZSBzZXR0YWJsZS5cbiAgKi9cbiAgcmVhZG9ubHkgaWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAqIFRoZSBudW1iZXIgb2YgSU8gdGhyZWFkcyB1c2VkIGJ5IFZhbGtleS4gTXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDMyLlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNpb190aHJlYWRzIERhdGFiYXNlVmFsa2V5Q29uZmlnI2lvX3RocmVhZHN9XG4gICovXG4gIHJlYWRvbmx5IGlvVGhyZWFkcz86IG51bWJlcjtcbiAgLyoqXG4gICogVGhlIGRlY2F5IHRpbWUgZm9yIFZhbGtleSdzIExGVSBjYWNoZSBldmljdGlvbi4gTXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDEyMC5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjbGZ1X2RlY2F5X3RpbWUgRGF0YWJhc2VWYWxrZXlDb25maWcjbGZ1X2RlY2F5X3RpbWV9XG4gICovXG4gIHJlYWRvbmx5IGxmdURlY2F5VGltZT86IG51bWJlcjtcbiAgLyoqXG4gICogVGhlIGxvZyBmYWN0b3IgZm9yIFZhbGtleSdzIExGVSAoTGVhc3QgRnJlcXVlbnRseSBVc2VkKSBjYWNoZSBldmljdGlvbi4gTXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDEwMC5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjbGZ1X2xvZ19mYWN0b3IgRGF0YWJhc2VWYWxrZXlDb25maWcjbGZ1X2xvZ19mYWN0b3J9XG4gICovXG4gIHJlYWRvbmx5IGxmdUxvZ0ZhY3Rvcj86IG51bWJlcjtcbiAgLyoqXG4gICogU2V0IG5vdGlmeS1rZXlzcGFjZS1ldmVudHMgb3B0aW9uLiBSZXF1aXJlcyBhdCBsZWFzdCBLIG9yIEUgYW5kIGFjY2VwdHMgYW55IGNvbWJpbmF0aW9uIG9mIHRoZSBmb2xsb3dpbmcgb3B0aW9ucy4gU2V0dGluZyB0aGUgcGFyYW1ldGVyIHRvIFwiXCIgZGlzYWJsZXMgbm90aWZpY2F0aW9ucy5cbiAgKiBcbiAgKiBLIOKAlCBLZXlzcGFjZSBldmVudHNcbiAgKiBFIOKAlCBLZXlldmVudCBldmVudHNcbiAgKiBnIOKAlCBHZW5lcmljIGNvbW1hbmRzIChlLmcuIERFTCwgRVhQSVJFLCBSRU5BTUUsIC4uLilcbiAgKiAkIOKAlCBTdHJpbmcgY29tbWFuZHNcbiAgKiBsIOKAlCBMaXN0IGNvbW1hbmRzXG4gICogcyDigJQgU2V0IGNvbW1hbmRzXG4gICogaCDigJQgSGFzaCBjb21tYW5kc1xuICAqIHog4oCUIFNvcnRlZCBzZXQgY29tbWFuZHNcbiAgKiB0IOKAlCBTdHJlYW0gY29tbWFuZHNcbiAgKiBkIOKAlCBNb2R1bGUga2V5IHR5cGUgZXZlbnRzXG4gICogeCDigJQgRXhwaXJlZCBldmVudHNcbiAgKiBlIOKAlCBFdmljdGVkIGV2ZW50c1xuICAqIG0g4oCUIEtleSBtaXNzIGV2ZW50c1xuICAqIG4g4oCUIE5ldyBrZXkgZXZlbnRzXG4gICogQSDigJQgQWxpYXMgZm9yIFwiZyRsc2h6dHhlZFwiXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI25vdGlmeV9rZXlzcGFjZV9ldmVudHMgRGF0YWJhc2VWYWxrZXlDb25maWcjbm90aWZ5X2tleXNwYWNlX2V2ZW50c31cbiAgKi9cbiAgcmVhZG9ubHkgbm90aWZ5S2V5c3BhY2VFdmVudHM/OiBzdHJpbmc7XG4gIC8qKlxuICAqIFRoZSBudW1iZXIgb2YgbG9naWNhbCBkYXRhYmFzZXMgaW4gdGhlIFZhbGtleSBjbHVzdGVyLiBNdXN0IGJlIGJldHdlZW4gMSBhbmQgMTI4LlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyNudW1iZXJfb2ZfZGF0YWJhc2VzIERhdGFiYXNlVmFsa2V5Q29uZmlnI251bWJlcl9vZl9kYXRhYmFzZXN9XG4gICovXG4gIHJlYWRvbmx5IG51bWJlck9mRGF0YWJhc2VzPzogbnVtYmVyO1xuICAvKipcbiAgKiBXaGVuIHBlcnNpc3RlbmNlIGlzICdyZGInLCBWYWxrZXkgZG9lcyBSREIgZHVtcHMgZWFjaCAxMCBtaW51dGVzIGlmIGFueSBrZXkgaXMgY2hhbmdlZC4gQWxzbyBSREIgZHVtcHMgYXJlIGRvbmUgYWNjb3JkaW5nIHRvIGJhY2t1cCBzY2hlZHVsZSBmb3IgYmFja3VwIHB1cnBvc2VzLiBXaGVuIHBlcnNpc3RlbmNlIGlzICdvZmYnLCBubyBSREIgZHVtcHMgYW5kIGJhY2t1cHMgYXJlIGRvbmUsIHNvIGRhdGEgY2FuIGJlIGxvc3QgYXQgYW55IG1vbWVudCBpZiBzZXJ2aWNlIGlzIHJlc3RhcnRlZCBmb3IgYW55IHJlYXNvbiwgb3IgaWYgc2VydmljZSBpcyBwb3dlcmVkIG9mZi4gQWxzbyBzZXJ2aWNlIGNhbid0IGJlIGZvcmtlZC5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjcGVyc2lzdGVuY2UgRGF0YWJhc2VWYWxrZXlDb25maWcjcGVyc2lzdGVuY2V9XG4gICovXG4gIHJlYWRvbmx5IHBlcnNpc3RlbmNlPzogc3RyaW5nO1xuICAvKipcbiAgKiBTZXQgb3V0cHV0IGJ1ZmZlciBsaW1pdCBmb3IgcHViIC8gc3ViIGNsaWVudHMgaW4gTUIuIFRoZSB2YWx1ZSBpcyB0aGUgaGFyZCBsaW1pdCwgdGhlIHNvZnQgbGltaXQgaXMgMS80IG9mIHRoZSBoYXJkIGxpbWl0LiBXaGVuIHNldHRpbmcgdGhlIGxpbWl0LCBiZSBtaW5kZnVsIG9mIHRoZSBhdmFpbGFibGUgbWVtb3J5IGluIHRoZSBzZWxlY3RlZCBzZXJ2aWNlIHBsYW4uXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI3B1YnN1Yl9jbGllbnRfb3V0cHV0X2J1ZmZlcl9saW1pdCBEYXRhYmFzZVZhbGtleUNvbmZpZyNwdWJzdWJfY2xpZW50X291dHB1dF9idWZmZXJfbGltaXR9XG4gICovXG4gIHJlYWRvbmx5IHB1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0PzogbnVtYmVyO1xuICAvKipcbiAgKiBXaGV0aGVyIHRvIGVuYWJsZSBTU0wvVExTIGZvciBjb25uZWN0aW9ucyB0byB0aGUgVmFsa2V5IGNsdXN0ZXIuXG4gICpcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI3NzbCBEYXRhYmFzZVZhbGtleUNvbmZpZyNzc2x9XG4gICovXG4gIHJlYWRvbmx5IHNzbD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogVGhlIHRpbWVvdXQgKGluIHNlY29uZHMpIGZvciBWYWxrZXkgY2xpZW50IGNvbm5lY3Rpb25zLlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyN0aW1lb3V0IERhdGFiYXNlVmFsa2V5Q29uZmlnI3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IHRpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIEFjdGl2ZSBleHBpcmUgZWZmb3J0LiBWYWxrZXkgcmVjbGFpbXMgZXhwaXJlZCBrZXlzIGJvdGggd2hlbiBhY2Nlc3NlZCBhbmQgaW4gdGhlIGJhY2tncm91bmQuIFRoZSBiYWNrZ3JvdW5kIHByb2Nlc3Mgc2NhbnMgZm9yIGV4cGlyZWQga2V5cyB0byBmcmVlIG1lbW9yeS4gSW5jcmVhc2luZyB0aGUgYWN0aXZlLWV4cGlyZS1lZmZvcnQgc2V0dGluZyAoZGVmYXVsdCAxLCBtYXggMTApIHVzZXMgbW9yZSBDUFUgdG8gcmVjbGFpbSBleHBpcmVkIGtleXMgZmFzdGVyLCByZWR1Y2luZyBtZW1vcnkgdXNhZ2UgYnV0IHBvdGVudGlhbGx5IGluY3JlYXNpbmcgbGF0ZW5jeS5cbiAgKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcjdmFsa2V5X2FjdGl2ZV9leHBpcmVfZWZmb3J0IERhdGFiYXNlVmFsa2V5Q29uZmlnI3ZhbGtleV9hY3RpdmVfZXhwaXJlX2VmZm9ydH1cbiAgKi9cbiAgcmVhZG9ubHkgdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0PzogbnVtYmVyO1xuICAvKipcbiAgKiBBIHN0cmluZyBzcGVjaWZ5aW5nIHRoZSBkZXNpcmVkIGV2aWN0aW9uIHBvbGljeSBmb3IgYSBDYWNoaW5nIG9yIFZhbGtleSBjbHVzdGVyLlxuICAqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyN2YWxrZXlfbWF4bWVtb3J5X3BvbGljeSBEYXRhYmFzZVZhbGtleUNvbmZpZyN2YWxrZXlfbWF4bWVtb3J5X3BvbGljeX1cbiAgKi9cbiAgcmVhZG9ubHkgdmFsa2V5TWF4bWVtb3J5UG9saWN5Pzogc3RyaW5nO1xufVxuXG4vKipcbiogUmVwcmVzZW50cyBhIHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfdmFsa2V5X2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2VfdmFsa2V5X2NvbmZpZ31cbiovXG5leHBvcnQgY2xhc3MgRGF0YWJhc2VWYWxrZXlDb25maWcgZXh0ZW5kcyBjZGt0bi5UZXJyYWZvcm1SZXNvdXJjZSB7XG5cbiAgLy8gPT09PT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIFBST1BFUlRJRVNcbiAgLy8gPT09PT09PT09PT09PT09PT1cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSB0ZlJlc291cmNlVHlwZSA9IFwiZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3ZhbGtleV9jb25maWdcIjtcblxuICAvLyA9PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgTWV0aG9kc1xuICAvLyA9PT09PT09PT09PT09PVxuICAvKipcbiAgKiBHZW5lcmF0ZXMgQ0RLVE4gY29kZSBmb3IgaW1wb3J0aW5nIGEgRGF0YWJhc2VWYWxrZXlDb25maWcgcmVzb3VyY2UgdXBvbiBydW5uaW5nIFwiY2RrdG4gcGxhbiA8c3RhY2stbmFtZT5cIlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGltcG9ydFRvSWQgVGhlIGNvbnN0cnVjdCBpZCB1c2VkIGluIHRoZSBnZW5lcmF0ZWQgY29uZmlnIGZvciB0aGUgRGF0YWJhc2VWYWxrZXlDb25maWcgdG8gaW1wb3J0XG4gICogQHBhcmFtIGltcG9ydEZyb21JZCBUaGUgaWQgb2YgdGhlIGV4aXN0aW5nIERhdGFiYXNlVmFsa2V5Q29uZmlnIHRoYXQgc2hvdWxkIGJlIGltcG9ydGVkLiBSZWZlciB0byB0aGUge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV92YWxrZXlfY29uZmlnI2ltcG9ydCBpbXBvcnQgc2VjdGlvbn0gaW4gdGhlIGRvY3VtZW50YXRpb24gb2YgdGhpcyByZXNvdXJjZSBmb3IgdGhlIGlkIHRvIHVzZVxuICAqIEBwYXJhbSBwcm92aWRlcj8gT3B0aW9uYWwgaW5zdGFuY2Ugb2YgdGhlIHByb3ZpZGVyIHdoZXJlIHRoZSBEYXRhYmFzZVZhbGtleUNvbmZpZyB0byBpbXBvcnQgaXMgZm91bmRcbiAgKi9cbiAgcHVibGljIHN0YXRpYyBnZW5lcmF0ZUNvbmZpZ0ZvckltcG9ydChzY29wZTogQ29uc3RydWN0LCBpbXBvcnRUb0lkOiBzdHJpbmcsIGltcG9ydEZyb21JZDogc3RyaW5nLCBwcm92aWRlcj86IGNka3RuLlRlcnJhZm9ybVByb3ZpZGVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgY2RrdG4uSW1wb3J0YWJsZVJlc291cmNlKHNjb3BlLCBpbXBvcnRUb0lkLCB7IHRlcnJhZm9ybVJlc291cmNlVHlwZTogXCJkaWdpdGFsb2NlYW5fZGF0YWJhc2VfdmFsa2V5X2NvbmZpZ1wiLCBpbXBvcnRJZDogaW1wb3J0RnJvbUlkLCBwcm92aWRlciB9KTtcbiAgICAgIH1cblxuICAvLyA9PT09PT09PT09PVxuICAvLyBJTklUSUFMSVpFUlxuICAvLyA9PT09PT09PT09PVxuXG4gIC8qKlxuICAqIENyZWF0ZSBhIG5ldyB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX3ZhbGtleV9jb25maWcgZGlnaXRhbG9jZWFuX2RhdGFiYXNlX3ZhbGtleV9jb25maWd9IFJlc291cmNlXG4gICpcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpZCBUaGUgc2NvcGVkIGNvbnN0cnVjdCBJRC4gTXVzdCBiZSB1bmlxdWUgYW1vbmdzdCBzaWJsaW5ncyBpbiB0aGUgc2FtZSBzY29wZVxuICAqIEBwYXJhbSBvcHRpb25zIERhdGFiYXNlVmFsa2V5Q29uZmlnQ29uZmlnXG4gICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBjb25maWc6IERhdGFiYXNlVmFsa2V5Q29uZmlnQ29uZmlnKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6ICdkaWdpdGFsb2NlYW5fZGF0YWJhc2VfdmFsa2V5X2NvbmZpZycsXG4gICAgICB0ZXJyYWZvcm1HZW5lcmF0b3JNZXRhZGF0YToge1xuICAgICAgICBwcm92aWRlck5hbWU6ICdkaWdpdGFsb2NlYW4nLFxuICAgICAgICBwcm92aWRlclZlcnNpb246ICcyLjg3LjAnLFxuICAgICAgICBwcm92aWRlclZlcnNpb25Db25zdHJhaW50OiAnMi44Ny4wJ1xuICAgICAgfSxcbiAgICAgIHByb3ZpZGVyOiBjb25maWcucHJvdmlkZXIsXG4gICAgICBkZXBlbmRzT246IGNvbmZpZy5kZXBlbmRzT24sXG4gICAgICBjb3VudDogY29uZmlnLmNvdW50LFxuICAgICAgbGlmZWN5Y2xlOiBjb25maWcubGlmZWN5Y2xlLFxuICAgICAgcHJvdmlzaW9uZXJzOiBjb25maWcucHJvdmlzaW9uZXJzLFxuICAgICAgY29ubmVjdGlvbjogY29uZmlnLmNvbm5lY3Rpb24sXG4gICAgICBmb3JFYWNoOiBjb25maWcuZm9yRWFjaFxuICAgIH0pO1xuICAgIHRoaXMuX2FjbENoYW5uZWxzRGVmYXVsdCA9IGNvbmZpZy5hY2xDaGFubmVsc0RlZmF1bHQ7XG4gICAgdGhpcy5fY2x1c3RlcklkID0gY29uZmlnLmNsdXN0ZXJJZDtcbiAgICB0aGlzLl9mcmVxdWVudFNuYXBzaG90cyA9IGNvbmZpZy5mcmVxdWVudFNuYXBzaG90cztcbiAgICB0aGlzLl9pZCA9IGNvbmZpZy5pZDtcbiAgICB0aGlzLl9pb1RocmVhZHMgPSBjb25maWcuaW9UaHJlYWRzO1xuICAgIHRoaXMuX2xmdURlY2F5VGltZSA9IGNvbmZpZy5sZnVEZWNheVRpbWU7XG4gICAgdGhpcy5fbGZ1TG9nRmFjdG9yID0gY29uZmlnLmxmdUxvZ0ZhY3RvcjtcbiAgICB0aGlzLl9ub3RpZnlLZXlzcGFjZUV2ZW50cyA9IGNvbmZpZy5ub3RpZnlLZXlzcGFjZUV2ZW50cztcbiAgICB0aGlzLl9udW1iZXJPZkRhdGFiYXNlcyA9IGNvbmZpZy5udW1iZXJPZkRhdGFiYXNlcztcbiAgICB0aGlzLl9wZXJzaXN0ZW5jZSA9IGNvbmZpZy5wZXJzaXN0ZW5jZTtcbiAgICB0aGlzLl9wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdCA9IGNvbmZpZy5wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdDtcbiAgICB0aGlzLl9zc2wgPSBjb25maWcuc3NsO1xuICAgIHRoaXMuX3RpbWVvdXQgPSBjb25maWcudGltZW91dDtcbiAgICB0aGlzLl92YWxrZXlBY3RpdmVFeHBpcmVFZmZvcnQgPSBjb25maWcudmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0O1xuICAgIHRoaXMuX3ZhbGtleU1heG1lbW9yeVBvbGljeSA9IGNvbmZpZy52YWxrZXlNYXhtZW1vcnlQb2xpY3k7XG4gIH1cblxuICAvLyA9PT09PT09PT09XG4gIC8vIEFUVFJJQlVURVNcbiAgLy8gPT09PT09PT09PVxuXG4gIC8vIGFjbF9jaGFubmVsc19kZWZhdWx0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYWNsQ2hhbm5lbHNEZWZhdWx0Pzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBhY2xDaGFubmVsc0RlZmF1bHQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdhY2xfY2hhbm5lbHNfZGVmYXVsdCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgYWNsQ2hhbm5lbHNEZWZhdWx0KHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9hY2xDaGFubmVsc0RlZmF1bHQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBY2xDaGFubmVsc0RlZmF1bHQoKSB7XG4gICAgdGhpcy5fYWNsQ2hhbm5lbHNEZWZhdWx0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhY2xDaGFubmVsc0RlZmF1bHRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYWNsQ2hhbm5lbHNEZWZhdWx0O1xuICB9XG5cbiAgLy8gY2x1c3Rlcl9pZCAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IGZhbHNlLCByZXF1aXJlZDogdHJ1ZVxuICBwcml2YXRlIF9jbHVzdGVySWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJJZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2NsdXN0ZXJfaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGNsdXN0ZXJJZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fY2x1c3RlcklkID0gdmFsdWU7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJJZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9jbHVzdGVySWQ7XG4gIH1cblxuICAvLyBmcmVxdWVudF9zbmFwc2hvdHMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9mcmVxdWVudFNuYXBzaG90cz86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgZnJlcXVlbnRTbmFwc2hvdHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnZnJlcXVlbnRfc25hcHNob3RzJyk7XG4gIH1cbiAgcHVibGljIHNldCBmcmVxdWVudFNuYXBzaG90cyh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fZnJlcXVlbnRTbmFwc2hvdHMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRGcmVxdWVudFNuYXBzaG90cygpIHtcbiAgICB0aGlzLl9mcmVxdWVudFNuYXBzaG90cyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgZnJlcXVlbnRTbmFwc2hvdHNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZnJlcXVlbnRTbmFwc2hvdHM7XG4gIH1cblxuICAvLyBpZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBpZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5faWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJZCgpIHtcbiAgICB0aGlzLl9pZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faWQ7XG4gIH1cblxuICAvLyBpb190aHJlYWRzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW9UaHJlYWRzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpb1RocmVhZHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpb190aHJlYWRzJyk7XG4gIH1cbiAgcHVibGljIHNldCBpb1RocmVhZHModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2lvVGhyZWFkcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElvVGhyZWFkcygpIHtcbiAgICB0aGlzLl9pb1RocmVhZHMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlvVGhyZWFkc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pb1RocmVhZHM7XG4gIH1cblxuICAvLyBsZnVfZGVjYXlfdGltZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xmdURlY2F5VGltZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbGZ1RGVjYXlUaW1lKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbGZ1X2RlY2F5X3RpbWUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxmdURlY2F5VGltZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbGZ1RGVjYXlUaW1lID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TGZ1RGVjYXlUaW1lKCkge1xuICAgIHRoaXMuX2xmdURlY2F5VGltZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbGZ1RGVjYXlUaW1lSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xmdURlY2F5VGltZTtcbiAgfVxuXG4gIC8vIGxmdV9sb2dfZmFjdG9yIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbGZ1TG9nRmFjdG9yPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsZnVMb2dGYWN0b3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdsZnVfbG9nX2ZhY3RvcicpO1xuICB9XG4gIHB1YmxpYyBzZXQgbGZ1TG9nRmFjdG9yKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9sZnVMb2dGYWN0b3IgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMZnVMb2dGYWN0b3IoKSB7XG4gICAgdGhpcy5fbGZ1TG9nRmFjdG9yID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsZnVMb2dGYWN0b3JJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbGZ1TG9nRmFjdG9yO1xuICB9XG5cbiAgLy8gbm90aWZ5X2tleXNwYWNlX2V2ZW50cyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX25vdGlmeUtleXNwYWNlRXZlbnRzPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBub3RpZnlLZXlzcGFjZUV2ZW50cygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ25vdGlmeV9rZXlzcGFjZV9ldmVudHMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG5vdGlmeUtleXNwYWNlRXZlbnRzKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9ub3RpZnlLZXlzcGFjZUV2ZW50cyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE5vdGlmeUtleXNwYWNlRXZlbnRzKCkge1xuICAgIHRoaXMuX25vdGlmeUtleXNwYWNlRXZlbnRzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBub3RpZnlLZXlzcGFjZUV2ZW50c0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9ub3RpZnlLZXlzcGFjZUV2ZW50cztcbiAgfVxuXG4gIC8vIG51bWJlcl9vZl9kYXRhYmFzZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9udW1iZXJPZkRhdGFiYXNlcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbnVtYmVyT2ZEYXRhYmFzZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdudW1iZXJfb2ZfZGF0YWJhc2VzJyk7XG4gIH1cbiAgcHVibGljIHNldCBudW1iZXJPZkRhdGFiYXNlcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbnVtYmVyT2ZEYXRhYmFzZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXROdW1iZXJPZkRhdGFiYXNlcygpIHtcbiAgICB0aGlzLl9udW1iZXJPZkRhdGFiYXNlcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbnVtYmVyT2ZEYXRhYmFzZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbnVtYmVyT2ZEYXRhYmFzZXM7XG4gIH1cblxuICAvLyBwZXJzaXN0ZW5jZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3BlcnNpc3RlbmNlPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBwZXJzaXN0ZW5jZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3BlcnNpc3RlbmNlJyk7XG4gIH1cbiAgcHVibGljIHNldCBwZXJzaXN0ZW5jZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fcGVyc2lzdGVuY2UgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQZXJzaXN0ZW5jZSgpIHtcbiAgICB0aGlzLl9wZXJzaXN0ZW5jZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcGVyc2lzdGVuY2VJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGVyc2lzdGVuY2U7XG4gIH1cblxuICAvLyBwdWJzdWJfY2xpZW50X291dHB1dF9idWZmZXJfbGltaXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdwdWJzdWJfY2xpZW50X291dHB1dF9idWZmZXJfbGltaXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHB1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFB1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0KCkge1xuICAgIHRoaXMuX3B1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBwdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9wdWJzdWJDbGllbnRPdXRwdXRCdWZmZXJMaW1pdDtcbiAgfVxuXG4gIC8vIHNzbCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NzbD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgc3NsKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ3NzbCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgc3NsKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9zc2wgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTc2woKSB7XG4gICAgdGhpcy5fc3NsID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBzc2xJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc3NsO1xuICB9XG5cbiAgLy8gdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRpbWVvdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCB0aW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90aW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGltZW91dCgpIHtcbiAgICB0aGlzLl90aW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RpbWVvdXQ7XG4gIH1cblxuICAvLyB2YWxrZXlfYWN0aXZlX2V4cGlyZV9lZmZvcnQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF92YWxrZXlBY3RpdmVFeHBpcmVFZmZvcnQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHZhbGtleUFjdGl2ZUV4cGlyZUVmZm9ydCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3ZhbGtleV9hY3RpdmVfZXhwaXJlX2VmZm9ydCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl92YWxrZXlBY3RpdmVFeHBpcmVFZmZvcnQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRWYWxrZXlBY3RpdmVFeHBpcmVFZmZvcnQoKSB7XG4gICAgdGhpcy5fdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB2YWxrZXlBY3RpdmVFeHBpcmVFZmZvcnRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0O1xuICB9XG5cbiAgLy8gdmFsa2V5X21heG1lbW9yeV9wb2xpY3kgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF92YWxrZXlNYXhtZW1vcnlQb2xpY3k/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IHZhbGtleU1heG1lbW9yeVBvbGljeSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3ZhbGtleV9tYXhtZW1vcnlfcG9saWN5Jyk7XG4gIH1cbiAgcHVibGljIHNldCB2YWxrZXlNYXhtZW1vcnlQb2xpY3kodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3ZhbGtleU1heG1lbW9yeVBvbGljeSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFZhbGtleU1heG1lbW9yeVBvbGljeSgpIHtcbiAgICB0aGlzLl92YWxrZXlNYXhtZW1vcnlQb2xpY3kgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHZhbGtleU1heG1lbW9yeVBvbGljeUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl92YWxrZXlNYXhtZW1vcnlQb2xpY3k7XG4gIH1cblxuICAvLyA9PT09PT09PT1cbiAgLy8gU1lOVEhFU0lTXG4gIC8vID09PT09PT09PVxuXG4gIHByb3RlY3RlZCBzeW50aGVzaXplQXR0cmlidXRlcygpOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFjbF9jaGFubmVsc19kZWZhdWx0OiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9hY2xDaGFubmVsc0RlZmF1bHQpLFxuICAgICAgY2x1c3Rlcl9pZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgIGZyZXF1ZW50X3NuYXBzaG90czogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2ZyZXF1ZW50U25hcHNob3RzKSxcbiAgICAgIGlkOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9pZCksXG4gICAgICBpb190aHJlYWRzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pb1RocmVhZHMpLFxuICAgICAgbGZ1X2RlY2F5X3RpbWU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2xmdURlY2F5VGltZSksXG4gICAgICBsZnVfbG9nX2ZhY3RvcjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbGZ1TG9nRmFjdG9yKSxcbiAgICAgIG5vdGlmeV9rZXlzcGFjZV9ldmVudHM6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX25vdGlmeUtleXNwYWNlRXZlbnRzKSxcbiAgICAgIG51bWJlcl9vZl9kYXRhYmFzZXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX251bWJlck9mRGF0YWJhc2VzKSxcbiAgICAgIHBlcnNpc3RlbmNlOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9wZXJzaXN0ZW5jZSksXG4gICAgICBwdWJzdWJfY2xpZW50X291dHB1dF9idWZmZXJfbGltaXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3B1YnN1YkNsaWVudE91dHB1dEJ1ZmZlckxpbWl0KSxcbiAgICAgIHNzbDogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX3NzbCksXG4gICAgICB0aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aW1lb3V0KSxcbiAgICAgIHZhbGtleV9hY3RpdmVfZXhwaXJlX2VmZm9ydDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0KSxcbiAgICAgIHZhbGtleV9tYXhtZW1vcnlfcG9saWN5OiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl92YWxrZXlNYXhtZW1vcnlQb2xpY3kpLFxuICAgIH07XG4gIH1cblxuICBwcm90ZWN0ZWQgc3ludGhlc2l6ZUhjbEF0dHJpYnV0ZXMoKTogeyBbbmFtZTogc3RyaW5nXTogYW55IH0ge1xuICAgIGNvbnN0IGF0dHJzID0ge1xuICAgICAgYWNsX2NoYW5uZWxzX2RlZmF1bHQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2FjbENoYW5uZWxzRGVmYXVsdCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGNsdXN0ZXJfaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGZyZXF1ZW50X3NuYXBzaG90czoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2ZyZXF1ZW50U25hcHNob3RzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGlkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9pZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGlvX3RocmVhZHM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lvVGhyZWFkcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGxmdV9kZWNheV90aW1lOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9sZnVEZWNheVRpbWUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBsZnVfbG9nX2ZhY3Rvcjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbGZ1TG9nRmFjdG9yKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbm90aWZ5X2tleXNwYWNlX2V2ZW50czoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fbm90aWZ5S2V5c3BhY2VFdmVudHMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBudW1iZXJfb2ZfZGF0YWJhc2VzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9udW1iZXJPZkRhdGFiYXNlcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHBlcnNpc3RlbmNlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9wZXJzaXN0ZW5jZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIHB1YnN1Yl9jbGllbnRfb3V0cHV0X2J1ZmZlcl9saW1pdDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fcHVic3ViQ2xpZW50T3V0cHV0QnVmZmVyTGltaXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBzc2w6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9zc2wpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHZhbGtleV9hY3RpdmVfZXhwaXJlX2VmZm9ydDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdmFsa2V5QWN0aXZlRXhwaXJlRWZmb3J0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdmFsa2V5X21heG1lbW9yeV9wb2xpY3k6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3ZhbGtleU1heG1lbW9yeVBvbGljeSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgLy8gcmVtb3ZlIHVuZGVmaW5lZCBhdHRyaWJ1dGVzXG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhhdHRycykuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnZhbHVlICE9PSB1bmRlZmluZWQgKSlcbiAgfVxufVxuIl19