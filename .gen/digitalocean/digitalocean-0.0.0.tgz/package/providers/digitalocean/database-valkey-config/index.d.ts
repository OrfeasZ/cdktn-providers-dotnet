import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseValkeyConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Determines default pub/sub channels' ACL for new users if ACL is not supplied. When this option is not defined, all_channels is assumed to keep backward compatibility. This option doesn't affect Valkey configuration acl-pubsub-default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#acl_channels_default DatabaseValkeyConfig#acl_channels_default}
    */
    readonly aclChannelsDefault?: string;
    /**
    * A unique identifier for the database cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#cluster_id DatabaseValkeyConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Frequent RDB snapshots. When enabled, Valkey will create frequent local RDB snapshots. When disabled, Valkey will only take RDB snapshots when a backup is created, based on the backup schedule. This setting is ignored when valkey_persistence is set to off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#frequent_snapshots DatabaseValkeyConfig#frequent_snapshots}
    */
    readonly frequentSnapshots?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#id DatabaseValkeyConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The number of IO threads used by Valkey. Must be between 1 and 32.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#io_threads DatabaseValkeyConfig#io_threads}
    */
    readonly ioThreads?: number;
    /**
    * The decay time for Valkey's LFU cache eviction. Must be between 1 and 120.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#lfu_decay_time DatabaseValkeyConfig#lfu_decay_time}
    */
    readonly lfuDecayTime?: number;
    /**
    * The log factor for Valkey's LFU (Least Frequently Used) cache eviction. Must be between 1 and 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#lfu_log_factor DatabaseValkeyConfig#lfu_log_factor}
    */
    readonly lfuLogFactor?: number;
    /**
    * Set notify-keyspace-events option. Requires at least K or E and accepts any combination of the following options. Setting the parameter to "" disables notifications.
    *
    * K — Keyspace events
    * E — Keyevent events
    * g — Generic commands (e.g. DEL, EXPIRE, RENAME, ...)
    * $ — String commands
    * l — List commands
    * s — Set commands
    * h — Hash commands
    * z — Sorted set commands
    * t — Stream commands
    * d — Module key type events
    * x — Expired events
    * e — Evicted events
    * m — Key miss events
    * n — New key events
    * A — Alias for "g$lshztxed"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#notify_keyspace_events DatabaseValkeyConfig#notify_keyspace_events}
    */
    readonly notifyKeyspaceEvents?: string;
    /**
    * The number of logical databases in the Valkey cluster. Must be between 1 and 128.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#number_of_databases DatabaseValkeyConfig#number_of_databases}
    */
    readonly numberOfDatabases?: number;
    /**
    * When persistence is 'rdb', Valkey does RDB dumps each 10 minutes if any key is changed. Also RDB dumps are done according to backup schedule for backup purposes. When persistence is 'off', no RDB dumps and backups are done, so data can be lost at any moment if service is restarted for any reason, or if service is powered off. Also service can't be forked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#persistence DatabaseValkeyConfig#persistence}
    */
    readonly persistence?: string;
    /**
    * Set output buffer limit for pub / sub clients in MB. The value is the hard limit, the soft limit is 1/4 of the hard limit. When setting the limit, be mindful of the available memory in the selected service plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#pubsub_client_output_buffer_limit DatabaseValkeyConfig#pubsub_client_output_buffer_limit}
    */
    readonly pubsubClientOutputBufferLimit?: number;
    /**
    * Whether to enable SSL/TLS for connections to the Valkey cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#ssl DatabaseValkeyConfig#ssl}
    */
    readonly ssl?: boolean | cdktn.IResolvable;
    /**
    * The timeout (in seconds) for Valkey client connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#timeout DatabaseValkeyConfig#timeout}
    */
    readonly timeout?: number;
    /**
    * Active expire effort. Valkey reclaims expired keys both when accessed and in the background. The background process scans for expired keys to free memory. Increasing the active-expire-effort setting (default 1, max 10) uses more CPU to reclaim expired keys faster, reducing memory usage but potentially increasing latency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#valkey_active_expire_effort DatabaseValkeyConfig#valkey_active_expire_effort}
    */
    readonly valkeyActiveExpireEffort?: number;
    /**
    * A string specifying the desired eviction policy for a Caching or Valkey cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#valkey_maxmemory_policy DatabaseValkeyConfig#valkey_maxmemory_policy}
    */
    readonly valkeyMaxmemoryPolicy?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config digitalocean_database_valkey_config}
*/
export declare class DatabaseValkeyConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_valkey_config";
    /**
    * Generates CDKTN code for importing a DatabaseValkeyConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseValkeyConfig to import
    * @param importFromId The id of the existing DatabaseValkeyConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseValkeyConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_valkey_config digitalocean_database_valkey_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseValkeyConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseValkeyConfigConfig);
    private _aclChannelsDefault?;
    get aclChannelsDefault(): string;
    set aclChannelsDefault(value: string);
    resetAclChannelsDefault(): void;
    get aclChannelsDefaultInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _frequentSnapshots?;
    get frequentSnapshots(): boolean | cdktn.IResolvable;
    set frequentSnapshots(value: boolean | cdktn.IResolvable);
    resetFrequentSnapshots(): void;
    get frequentSnapshotsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ioThreads?;
    get ioThreads(): number;
    set ioThreads(value: number);
    resetIoThreads(): void;
    get ioThreadsInput(): number | undefined;
    private _lfuDecayTime?;
    get lfuDecayTime(): number;
    set lfuDecayTime(value: number);
    resetLfuDecayTime(): void;
    get lfuDecayTimeInput(): number | undefined;
    private _lfuLogFactor?;
    get lfuLogFactor(): number;
    set lfuLogFactor(value: number);
    resetLfuLogFactor(): void;
    get lfuLogFactorInput(): number | undefined;
    private _notifyKeyspaceEvents?;
    get notifyKeyspaceEvents(): string;
    set notifyKeyspaceEvents(value: string);
    resetNotifyKeyspaceEvents(): void;
    get notifyKeyspaceEventsInput(): string | undefined;
    private _numberOfDatabases?;
    get numberOfDatabases(): number;
    set numberOfDatabases(value: number);
    resetNumberOfDatabases(): void;
    get numberOfDatabasesInput(): number | undefined;
    private _persistence?;
    get persistence(): string;
    set persistence(value: string);
    resetPersistence(): void;
    get persistenceInput(): string | undefined;
    private _pubsubClientOutputBufferLimit?;
    get pubsubClientOutputBufferLimit(): number;
    set pubsubClientOutputBufferLimit(value: number);
    resetPubsubClientOutputBufferLimit(): void;
    get pubsubClientOutputBufferLimitInput(): number | undefined;
    private _ssl?;
    get ssl(): boolean | cdktn.IResolvable;
    set ssl(value: boolean | cdktn.IResolvable);
    resetSsl(): void;
    get sslInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _valkeyActiveExpireEffort?;
    get valkeyActiveExpireEffort(): number;
    set valkeyActiveExpireEffort(value: number);
    resetValkeyActiveExpireEffort(): void;
    get valkeyActiveExpireEffortInput(): number | undefined;
    private _valkeyMaxmemoryPolicy?;
    get valkeyMaxmemoryPolicy(): string;
    set valkeyMaxmemoryPolicy(value: string);
    resetValkeyMaxmemoryPolicy(): void;
    get valkeyMaxmemoryPolicyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
