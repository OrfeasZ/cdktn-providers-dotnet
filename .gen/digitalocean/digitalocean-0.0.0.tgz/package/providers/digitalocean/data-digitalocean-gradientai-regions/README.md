# `data_digitalocean_gradientai_regions`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_regions`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_regions).
