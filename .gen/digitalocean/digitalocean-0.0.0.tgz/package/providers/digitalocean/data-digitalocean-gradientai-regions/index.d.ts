import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiRegionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#id DataDigitaloceanGradientaiRegions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#filter DataDigitaloceanGradientaiRegions#filter}
    */
    readonly filter?: DataDigitaloceanGradientaiRegionsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#sort DataDigitaloceanGradientaiRegions#sort}
    */
    readonly sort?: DataDigitaloceanGradientaiRegionsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiRegionsRegions {
}
export declare function dataDigitaloceanGradientaiRegionsRegionsToTerraform(struct?: DataDigitaloceanGradientaiRegionsRegions): any;
export declare function dataDigitaloceanGradientaiRegionsRegionsToHclTerraform(struct?: DataDigitaloceanGradientaiRegionsRegions): any;
export declare class DataDigitaloceanGradientaiRegionsRegionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiRegionsRegions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiRegionsRegions | undefined);
    get inferenceUrl(): string;
    get region(): string;
    get servesBatch(): cdktn.IResolvable;
    get servesInference(): cdktn.IResolvable;
    get streamInferenceUrl(): string;
}
export declare class DataDigitaloceanGradientaiRegionsRegionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiRegionsRegionsOutputReference;
}
export interface DataDigitaloceanGradientaiRegionsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#all DataDigitaloceanGradientaiRegions#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#key DataDigitaloceanGradientaiRegions#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#match_by DataDigitaloceanGradientaiRegions#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#values DataDigitaloceanGradientaiRegions#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGradientaiRegionsFilterToTerraform(struct?: DataDigitaloceanGradientaiRegionsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiRegionsFilterToHclTerraform(struct?: DataDigitaloceanGradientaiRegionsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiRegionsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiRegionsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiRegionsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGradientaiRegionsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiRegionsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiRegionsFilterOutputReference;
}
export interface DataDigitaloceanGradientaiRegionsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#direction DataDigitaloceanGradientaiRegions#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#key DataDigitaloceanGradientaiRegions#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGradientaiRegionsSortToTerraform(struct?: DataDigitaloceanGradientaiRegionsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiRegionsSortToHclTerraform(struct?: DataDigitaloceanGradientaiRegionsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiRegionsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiRegionsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiRegionsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiRegionsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiRegionsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiRegionsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions digitalocean_gradientai_regions}
*/
export declare class DataDigitaloceanGradientaiRegions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_regions";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiRegions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiRegions to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiRegions that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiRegions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_regions digitalocean_gradientai_regions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiRegionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGradientaiRegionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _regions;
    get regions(): DataDigitaloceanGradientaiRegionsRegionsList;
    private _filter;
    get filter(): DataDigitaloceanGradientaiRegionsFilterList;
    putFilter(value: DataDigitaloceanGradientaiRegionsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanGradientaiRegionsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGradientaiRegionsSortList;
    putSort(value: DataDigitaloceanGradientaiRegionsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanGradientaiRegionsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
