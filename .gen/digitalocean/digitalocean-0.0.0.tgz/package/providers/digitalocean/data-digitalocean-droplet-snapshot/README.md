# `data_digitalocean_droplet_snapshot`

Refer to the Terraform Registry for docs: [`data_digitalocean_droplet_snapshot`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet_snapshot).
