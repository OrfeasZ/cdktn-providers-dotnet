# `digitalocean_dedicated_inference`

Refer to the Terraform Registry for docs: [`digitalocean_dedicated_inference`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/dedicated_inference).
