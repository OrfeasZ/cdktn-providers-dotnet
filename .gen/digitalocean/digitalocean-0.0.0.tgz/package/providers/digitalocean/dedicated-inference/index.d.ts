import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DedicatedInferenceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to enable a public HTTPS endpoint for the dedicated inference endpoint. This field is immutable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#enable_public_endpoint DedicatedInference#enable_public_endpoint}
    */
    readonly enablePublicEndpoint?: boolean | cdktn.IResolvable;
    /**
    * A HuggingFace token for accessing gated models.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#hugging_face_token DedicatedInference#hugging_face_token}
    */
    readonly huggingFaceToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#id DedicatedInference#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A human-readable name for the dedicated inference endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#name DedicatedInference#name}
    */
    readonly name: string;
    /**
    * The region slug where the dedicated inference endpoint will be deployed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#region DedicatedInference#region}
    */
    readonly region: string;
    /**
    * The UUID of the VPC to deploy the dedicated inference endpoint into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#vpc_uuid DedicatedInference#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * model_deployments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#model_deployments DedicatedInference#model_deployments}
    */
    readonly modelDeployments: DedicatedInferenceModelDeployments[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#timeouts DedicatedInference#timeouts}
    */
    readonly timeouts?: DedicatedInferenceTimeouts;
}
export interface DedicatedInferenceModelDeploymentsAccelerators {
    /**
    * The slug identifier for the GPU accelerator type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#accelerator_slug DedicatedInference#accelerator_slug}
    */
    readonly acceleratorSlug: string;
    /**
    * The number of accelerator units to allocate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#scale DedicatedInference#scale}
    */
    readonly scale: number;
    /**
    * The accelerator type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#type DedicatedInference#type}
    */
    readonly type: string;
}
export declare function dedicatedInferenceModelDeploymentsAcceleratorsToTerraform(struct?: DedicatedInferenceModelDeploymentsAccelerators | cdktn.IResolvable): any;
export declare function dedicatedInferenceModelDeploymentsAcceleratorsToHclTerraform(struct?: DedicatedInferenceModelDeploymentsAccelerators | cdktn.IResolvable): any;
export declare class DedicatedInferenceModelDeploymentsAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DedicatedInferenceModelDeploymentsAccelerators | cdktn.IResolvable | undefined;
    set internalValue(value: DedicatedInferenceModelDeploymentsAccelerators | cdktn.IResolvable | undefined);
    private _acceleratorSlug?;
    get acceleratorSlug(): string;
    set acceleratorSlug(value: string);
    get acceleratorSlugInput(): string | undefined;
    private _scale?;
    get scale(): number;
    set scale(value: number);
    get scaleInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class DedicatedInferenceModelDeploymentsAcceleratorsList extends cdktn.ComplexList {
    internalValue?: DedicatedInferenceModelDeploymentsAccelerators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DedicatedInferenceModelDeploymentsAcceleratorsOutputReference;
}
export interface DedicatedInferenceModelDeployments {
    /**
    * The unique ID of the model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#model_id DedicatedInference#model_id}
    */
    readonly modelId?: string;
    /**
    * The provider of the model (e.g. 'modelcatalog', 'hugging_face').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#model_provider DedicatedInference#model_provider}
    */
    readonly modelProvider: string;
    /**
    * The slug identifier for the model to deploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#model_slug DedicatedInference#model_slug}
    */
    readonly modelSlug: string;
    /**
    * The provider-specific model ID. Required when model_provider is 'hugging_face', optional for 'modelcatalog'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#provider_model_id DedicatedInference#provider_model_id}
    */
    readonly providerModelId?: string;
    /**
    * accelerators block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#accelerators DedicatedInference#accelerators}
    */
    readonly accelerators: DedicatedInferenceModelDeploymentsAccelerators[] | cdktn.IResolvable;
}
export declare function dedicatedInferenceModelDeploymentsToTerraform(struct?: DedicatedInferenceModelDeployments | cdktn.IResolvable): any;
export declare function dedicatedInferenceModelDeploymentsToHclTerraform(struct?: DedicatedInferenceModelDeployments | cdktn.IResolvable): any;
export declare class DedicatedInferenceModelDeploymentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DedicatedInferenceModelDeployments | cdktn.IResolvable | undefined;
    set internalValue(value: DedicatedInferenceModelDeployments | cdktn.IResolvable | undefined);
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _modelProvider?;
    get modelProvider(): string;
    set modelProvider(value: string);
    get modelProviderInput(): string | undefined;
    private _modelSlug?;
    get modelSlug(): string;
    set modelSlug(value: string);
    get modelSlugInput(): string | undefined;
    private _providerModelId?;
    get providerModelId(): string;
    set providerModelId(value: string);
    resetProviderModelId(): void;
    get providerModelIdInput(): string | undefined;
    private _accelerators;
    get accelerators(): DedicatedInferenceModelDeploymentsAcceleratorsList;
    putAccelerators(value: DedicatedInferenceModelDeploymentsAccelerators[] | cdktn.IResolvable): void;
    get acceleratorsInput(): cdktn.IResolvable | DedicatedInferenceModelDeploymentsAccelerators[] | undefined;
}
export declare class DedicatedInferenceModelDeploymentsList extends cdktn.ComplexList {
    internalValue?: DedicatedInferenceModelDeployments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DedicatedInferenceModelDeploymentsOutputReference;
}
export interface DedicatedInferenceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#create DedicatedInference#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#delete DedicatedInference#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#update DedicatedInference#update}
    */
    readonly update?: string;
}
export declare function dedicatedInferenceTimeoutsToTerraform(struct?: DedicatedInferenceTimeouts | cdktn.IResolvable): any;
export declare function dedicatedInferenceTimeoutsToHclTerraform(struct?: DedicatedInferenceTimeouts | cdktn.IResolvable): any;
export declare class DedicatedInferenceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DedicatedInferenceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DedicatedInferenceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference digitalocean_dedicated_inference}
*/
export declare class DedicatedInference extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_dedicated_inference";
    /**
    * Generates CDKTN code for importing a DedicatedInference resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DedicatedInference to import
    * @param importFromId The id of the existing DedicatedInference that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DedicatedInference to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/dedicated_inference digitalocean_dedicated_inference} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DedicatedInferenceConfig
    */
    constructor(scope: Construct, id: string, config: DedicatedInferenceConfig);
    get createdAt(): string;
    private _enablePublicEndpoint?;
    get enablePublicEndpoint(): boolean | cdktn.IResolvable;
    set enablePublicEndpoint(value: boolean | cdktn.IResolvable);
    resetEnablePublicEndpoint(): void;
    get enablePublicEndpointInput(): boolean | cdktn.IResolvable | undefined;
    private _huggingFaceToken?;
    get huggingFaceToken(): string;
    set huggingFaceToken(value: string);
    resetHuggingFaceToken(): void;
    get huggingFaceTokenInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get privateEndpointFqdn(): string;
    get publicEndpointFqdn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _modelDeployments;
    get modelDeployments(): DedicatedInferenceModelDeploymentsList;
    putModelDeployments(value: DedicatedInferenceModelDeployments[] | cdktn.IResolvable): void;
    get modelDeploymentsInput(): cdktn.IResolvable | DedicatedInferenceModelDeployments[] | undefined;
    private _timeouts;
    get timeouts(): DedicatedInferenceTimeoutsOutputReference;
    putTimeouts(value: DedicatedInferenceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DedicatedInferenceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
