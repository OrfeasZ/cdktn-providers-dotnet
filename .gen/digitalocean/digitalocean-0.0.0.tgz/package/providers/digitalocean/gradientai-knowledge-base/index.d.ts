import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiKnowledgeBaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * The time when the knowledge base was added to the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#added_to_agent_at GradientaiKnowledgeBase#added_to_agent_at}
    */
    readonly addedToAgentAt?: string;
    /**
    * The unique identifier of the DigitalOcean OpenSearch database this knowledge base will use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#database_id GradientaiKnowledgeBase#database_id}
    */
    readonly databaseId?: string;
    /**
    * The unique identifier of the embedding model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#embedding_model_uuid GradientaiKnowledgeBase#embedding_model_uuid}
    */
    readonly embeddingModelUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#id GradientaiKnowledgeBase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Indicates whether the knowledge base is public or private.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#is_public GradientaiKnowledgeBase#is_public}
    */
    readonly isPublic?: boolean | cdktn.IResolvable;
    /**
    * The name of the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#name GradientaiKnowledgeBase#name}
    */
    readonly name: string;
    /**
    * The unique identifier of the project to which the knowledge base belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#project_id GradientaiKnowledgeBase#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#region GradientaiKnowledgeBase#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#tags GradientaiKnowledgeBase#tags}
    */
    readonly tags?: string[];
    /**
    * The unique identifier of the VPC to which the knowledge base belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#vpc_uuid GradientaiKnowledgeBase#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * datasources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#datasources GradientaiKnowledgeBase#datasources}
    */
    readonly datasources: GradientaiKnowledgeBaseDatasources[] | cdktn.IResolvable;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#last_indexing_job GradientaiKnowledgeBase#last_indexing_job}
    */
    readonly lastIndexingJob?: GradientaiKnowledgeBaseLastIndexingJob[] | cdktn.IResolvable;
}
export interface GradientaiKnowledgeBaseDatasourcesFileUploadDataSource {
    /**
    * The original name of the uploaded file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#original_file_name GradientaiKnowledgeBase#original_file_name}
    */
    readonly originalFileName?: string;
    /**
    * The size of the file in bytes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#size_in_bytes GradientaiKnowledgeBase#size_in_bytes}
    */
    readonly sizeInBytes?: string;
    /**
    * The stored object key for the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#stored_object_key GradientaiKnowledgeBase#stored_object_key}
    */
    readonly storedObjectKey?: string;
}
export declare function gradientaiKnowledgeBaseDatasourcesFileUploadDataSourceToTerraform(struct?: GradientaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktn.IResolvable): any;
export declare function gradientaiKnowledgeBaseDatasourcesFileUploadDataSourceToHclTerraform(struct?: GradientaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktn.IResolvable): any;
export declare class GradientaiKnowledgeBaseDatasourcesFileUploadDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktn.IResolvable | undefined);
    private _originalFileName?;
    get originalFileName(): string;
    set originalFileName(value: string);
    resetOriginalFileName(): void;
    get originalFileNameInput(): string | undefined;
    private _sizeInBytes?;
    get sizeInBytes(): string;
    set sizeInBytes(value: string);
    resetSizeInBytes(): void;
    get sizeInBytesInput(): string | undefined;
    private _storedObjectKey?;
    get storedObjectKey(): string;
    set storedObjectKey(value: string);
    resetStoredObjectKey(): void;
    get storedObjectKeyInput(): string | undefined;
}
export declare class GradientaiKnowledgeBaseDatasourcesFileUploadDataSourceList extends cdktn.ComplexList {
    internalValue?: GradientaiKnowledgeBaseDatasourcesFileUploadDataSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiKnowledgeBaseDatasourcesFileUploadDataSourceOutputReference;
}
export interface GradientaiKnowledgeBaseDatasourcesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#completed_datasources GradientaiKnowledgeBase#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#data_source_uuids GradientaiKnowledgeBase#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#phase GradientaiKnowledgeBase#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#tokens GradientaiKnowledgeBase#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#total_datasources GradientaiKnowledgeBase#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#uuid GradientaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiKnowledgeBaseDatasourcesLastIndexingJobToTerraform(struct?: GradientaiKnowledgeBaseDatasourcesLastIndexingJob | cdktn.IResolvable): any;
export declare function gradientaiKnowledgeBaseDatasourcesLastIndexingJobToHclTerraform(struct?: GradientaiKnowledgeBaseDatasourcesLastIndexingJob | cdktn.IResolvable): any;
export declare class GradientaiKnowledgeBaseDatasourcesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiKnowledgeBaseDatasourcesLastIndexingJob | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDatasourcesLastIndexingJob | cdktn.IResolvable | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiKnowledgeBaseDatasourcesLastIndexingJobList extends cdktn.ComplexList {
    internalValue?: GradientaiKnowledgeBaseDatasourcesLastIndexingJob[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiKnowledgeBaseDatasourcesLastIndexingJobOutputReference;
}
export interface GradientaiKnowledgeBaseDatasourcesSpacesDataSource {
    /**
    * The name of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#bucket_name GradientaiKnowledgeBase#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The path to the item in the bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#item_path GradientaiKnowledgeBase#item_path}
    */
    readonly itemPath?: string;
    /**
    * The region of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#region GradientaiKnowledgeBase#region}
    */
    readonly region?: string;
}
export declare function gradientaiKnowledgeBaseDatasourcesSpacesDataSourceToTerraform(struct?: GradientaiKnowledgeBaseDatasourcesSpacesDataSource | cdktn.IResolvable): any;
export declare function gradientaiKnowledgeBaseDatasourcesSpacesDataSourceToHclTerraform(struct?: GradientaiKnowledgeBaseDatasourcesSpacesDataSource | cdktn.IResolvable): any;
export declare class GradientaiKnowledgeBaseDatasourcesSpacesDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiKnowledgeBaseDatasourcesSpacesDataSource | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDatasourcesSpacesDataSource | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _itemPath?;
    get itemPath(): string;
    set itemPath(value: string);
    resetItemPath(): void;
    get itemPathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class GradientaiKnowledgeBaseDatasourcesSpacesDataSourceList extends cdktn.ComplexList {
    internalValue?: GradientaiKnowledgeBaseDatasourcesSpacesDataSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiKnowledgeBaseDatasourcesSpacesDataSourceOutputReference;
}
export interface GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource {
    /**
    * The base URL to crawl
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#base_url GradientaiKnowledgeBase#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Options for specifying how URLs found on pages should be handled.
    * - UNKNOWN: Default unknown value
    * - SCOPED: Only include the base URL.
    * - PATH: Crawl the base URL and linked pages within the URL path.
    * - DOMAIN: Crawl the base URL and linked pages within the same domain.
    * - SUBDOMAINS: Crawl the base URL and linked pages for any subdomain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#crawling_option GradientaiKnowledgeBase#crawling_option}
    */
    readonly crawlingOption?: string;
    /**
    * Whether to embed media content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#embed_media GradientaiKnowledgeBase#embed_media}
    */
    readonly embedMedia?: boolean | cdktn.IResolvable;
}
export declare function gradientaiKnowledgeBaseDatasourcesWebCrawlerDataSourceToTerraform(struct?: GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktn.IResolvable): any;
export declare function gradientaiKnowledgeBaseDatasourcesWebCrawlerDataSourceToHclTerraform(struct?: GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktn.IResolvable): any;
export declare class GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktn.IResolvable | undefined);
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _crawlingOption?;
    get crawlingOption(): string;
    set crawlingOption(value: string);
    resetCrawlingOption(): void;
    get crawlingOptionInput(): string | undefined;
    private _embedMedia?;
    get embedMedia(): boolean | cdktn.IResolvable;
    set embedMedia(value: boolean | cdktn.IResolvable);
    resetEmbedMedia(): void;
    get embedMediaInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSourceList extends cdktn.ComplexList {
    internalValue?: GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSourceOutputReference;
}
export interface GradientaiKnowledgeBaseDatasources {
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#uuid GradientaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
    /**
    * file_upload_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#file_upload_data_source GradientaiKnowledgeBase#file_upload_data_source}
    */
    readonly fileUploadDataSource?: GradientaiKnowledgeBaseDatasourcesFileUploadDataSource[] | cdktn.IResolvable;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#last_indexing_job GradientaiKnowledgeBase#last_indexing_job}
    */
    readonly lastIndexingJob?: GradientaiKnowledgeBaseDatasourcesLastIndexingJob[] | cdktn.IResolvable;
    /**
    * spaces_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#spaces_data_source GradientaiKnowledgeBase#spaces_data_source}
    */
    readonly spacesDataSource?: GradientaiKnowledgeBaseDatasourcesSpacesDataSource[] | cdktn.IResolvable;
    /**
    * web_crawler_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#web_crawler_data_source GradientaiKnowledgeBase#web_crawler_data_source}
    */
    readonly webCrawlerDataSource?: GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | cdktn.IResolvable;
}
export declare function gradientaiKnowledgeBaseDatasourcesToTerraform(struct?: GradientaiKnowledgeBaseDatasources | cdktn.IResolvable): any;
export declare function gradientaiKnowledgeBaseDatasourcesToHclTerraform(struct?: GradientaiKnowledgeBaseDatasources | cdktn.IResolvable): any;
export declare class GradientaiKnowledgeBaseDatasourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiKnowledgeBaseDatasources | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDatasources | cdktn.IResolvable | undefined);
    get createdAt(): string;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _fileUploadDataSource;
    get fileUploadDataSource(): GradientaiKnowledgeBaseDatasourcesFileUploadDataSourceList;
    putFileUploadDataSource(value: GradientaiKnowledgeBaseDatasourcesFileUploadDataSource[] | cdktn.IResolvable): void;
    resetFileUploadDataSource(): void;
    get fileUploadDataSourceInput(): cdktn.IResolvable | GradientaiKnowledgeBaseDatasourcesFileUploadDataSource[] | undefined;
    private _lastIndexingJob;
    get lastIndexingJob(): GradientaiKnowledgeBaseDatasourcesLastIndexingJobList;
    putLastIndexingJob(value: GradientaiKnowledgeBaseDatasourcesLastIndexingJob[] | cdktn.IResolvable): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): cdktn.IResolvable | GradientaiKnowledgeBaseDatasourcesLastIndexingJob[] | undefined;
    private _spacesDataSource;
    get spacesDataSource(): GradientaiKnowledgeBaseDatasourcesSpacesDataSourceList;
    putSpacesDataSource(value: GradientaiKnowledgeBaseDatasourcesSpacesDataSource[] | cdktn.IResolvable): void;
    resetSpacesDataSource(): void;
    get spacesDataSourceInput(): cdktn.IResolvable | GradientaiKnowledgeBaseDatasourcesSpacesDataSource[] | undefined;
    private _webCrawlerDataSource;
    get webCrawlerDataSource(): GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSourceList;
    putWebCrawlerDataSource(value: GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | cdktn.IResolvable): void;
    resetWebCrawlerDataSource(): void;
    get webCrawlerDataSourceInput(): cdktn.IResolvable | GradientaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | undefined;
}
export declare class GradientaiKnowledgeBaseDatasourcesList extends cdktn.ComplexList {
    internalValue?: GradientaiKnowledgeBaseDatasources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiKnowledgeBaseDatasourcesOutputReference;
}
export interface GradientaiKnowledgeBaseLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#completed_datasources GradientaiKnowledgeBase#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#data_source_uuids GradientaiKnowledgeBase#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#phase GradientaiKnowledgeBase#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#tokens GradientaiKnowledgeBase#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#total_datasources GradientaiKnowledgeBase#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#uuid GradientaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiKnowledgeBaseLastIndexingJobToTerraform(struct?: GradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable): any;
export declare function gradientaiKnowledgeBaseLastIndexingJobToHclTerraform(struct?: GradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable): any;
export declare class GradientaiKnowledgeBaseLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiKnowledgeBaseLastIndexingJobList extends cdktn.ComplexList {
    internalValue?: GradientaiKnowledgeBaseLastIndexingJob[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiKnowledgeBaseLastIndexingJobOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base digitalocean_gradientai_knowledge_base}
*/
export declare class GradientaiKnowledgeBase extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_knowledge_base";
    /**
    * Generates CDKTN code for importing a GradientaiKnowledgeBase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiKnowledgeBase to import
    * @param importFromId The id of the existing GradientaiKnowledgeBase that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiKnowledgeBase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_knowledge_base digitalocean_gradientai_knowledge_base} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiKnowledgeBaseConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiKnowledgeBaseConfig);
    private _addedToAgentAt?;
    get addedToAgentAt(): string;
    set addedToAgentAt(value: string);
    resetAddedToAgentAt(): void;
    get addedToAgentAtInput(): string | undefined;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    get embeddingModelUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktn.IResolvable;
    set isPublic(value: boolean | cdktn.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _datasources;
    get datasources(): GradientaiKnowledgeBaseDatasourcesList;
    putDatasources(value: GradientaiKnowledgeBaseDatasources[] | cdktn.IResolvable): void;
    get datasourcesInput(): cdktn.IResolvable | GradientaiKnowledgeBaseDatasources[] | undefined;
    private _lastIndexingJob;
    get lastIndexingJob(): GradientaiKnowledgeBaseLastIndexingJobList;
    putLastIndexingJob(value: GradientaiKnowledgeBaseLastIndexingJob[] | cdktn.IResolvable): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): cdktn.IResolvable | GradientaiKnowledgeBaseLastIndexingJob[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
