# `data_digitalocean_account`

Refer to the Terraform Registry for docs: [`data_digitalocean_account`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/account).
