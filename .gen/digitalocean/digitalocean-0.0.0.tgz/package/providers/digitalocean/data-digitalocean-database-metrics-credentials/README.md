# `data_digitalocean_database_metrics_credentials`

Refer to the Terraform Registry for docs: [`data_digitalocean_database_metrics_credentials`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/database_metrics_credentials).
