import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDatabaseMetricsCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_metrics_credentials#id DataDigitaloceanDatabaseMetricsCredentials#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_metrics_credentials digitalocean_database_metrics_credentials}
*/
export declare class DataDigitaloceanDatabaseMetricsCredentials extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_database_metrics_credentials";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDatabaseMetricsCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDatabaseMetricsCredentials to import
    * @param importFromId The id of the existing DataDigitaloceanDatabaseMetricsCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_metrics_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDatabaseMetricsCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_metrics_credentials digitalocean_database_metrics_credentials} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDatabaseMetricsCredentialsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDatabaseMetricsCredentialsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get password(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
