import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DropletAutoscaleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the Droplet autoscale pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#name DropletAutoscale#name}
    */
    readonly name: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#config DropletAutoscale#config}
    */
    readonly config: DropletAutoscaleConfigA;
    /**
    * droplet_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#droplet_template DropletAutoscale#droplet_template}
    */
    readonly dropletTemplate: DropletAutoscaleDropletTemplate;
}
export interface DropletAutoscaleCurrentUtilization {
}
export declare function dropletAutoscaleCurrentUtilizationToTerraform(struct?: DropletAutoscaleCurrentUtilization): any;
export declare function dropletAutoscaleCurrentUtilizationToHclTerraform(struct?: DropletAutoscaleCurrentUtilization): any;
export declare class DropletAutoscaleCurrentUtilizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DropletAutoscaleCurrentUtilization | undefined;
    set internalValue(value: DropletAutoscaleCurrentUtilization | undefined);
    get cpu(): number;
    get memory(): number;
}
export declare class DropletAutoscaleCurrentUtilizationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DropletAutoscaleCurrentUtilizationOutputReference;
}
export interface DropletAutoscaleConfigA {
    /**
    * Cooldown duration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#cooldown_minutes DropletAutoscale#cooldown_minutes}
    */
    readonly cooldownMinutes?: number;
    /**
    * Max number of members
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#max_instances DropletAutoscale#max_instances}
    */
    readonly maxInstances?: number;
    /**
    * Min number of members
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#min_instances DropletAutoscale#min_instances}
    */
    readonly minInstances?: number;
    /**
    * CPU target threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#target_cpu_utilization DropletAutoscale#target_cpu_utilization}
    */
    readonly targetCpuUtilization?: number;
    /**
    * Memory target threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#target_memory_utilization DropletAutoscale#target_memory_utilization}
    */
    readonly targetMemoryUtilization?: number;
    /**
    * Target number of members
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#target_number_instances DropletAutoscale#target_number_instances}
    */
    readonly targetNumberInstances?: number;
}
export declare function dropletAutoscaleConfigAToTerraform(struct?: DropletAutoscaleConfigAOutputReference | DropletAutoscaleConfigA): any;
export declare function dropletAutoscaleConfigAToHclTerraform(struct?: DropletAutoscaleConfigAOutputReference | DropletAutoscaleConfigA): any;
export declare class DropletAutoscaleConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DropletAutoscaleConfigA | undefined;
    set internalValue(value: DropletAutoscaleConfigA | undefined);
    private _cooldownMinutes?;
    get cooldownMinutes(): number;
    set cooldownMinutes(value: number);
    resetCooldownMinutes(): void;
    get cooldownMinutesInput(): number | undefined;
    private _maxInstances?;
    get maxInstances(): number;
    set maxInstances(value: number);
    resetMaxInstances(): void;
    get maxInstancesInput(): number | undefined;
    private _minInstances?;
    get minInstances(): number;
    set minInstances(value: number);
    resetMinInstances(): void;
    get minInstancesInput(): number | undefined;
    private _targetCpuUtilization?;
    get targetCpuUtilization(): number;
    set targetCpuUtilization(value: number);
    resetTargetCpuUtilization(): void;
    get targetCpuUtilizationInput(): number | undefined;
    private _targetMemoryUtilization?;
    get targetMemoryUtilization(): number;
    set targetMemoryUtilization(value: number);
    resetTargetMemoryUtilization(): void;
    get targetMemoryUtilizationInput(): number | undefined;
    private _targetNumberInstances?;
    get targetNumberInstances(): number;
    set targetNumberInstances(value: number);
    resetTargetNumberInstances(): void;
    get targetNumberInstancesInput(): number | undefined;
}
export interface DropletAutoscaleDropletTemplate {
    /**
    * Droplet image
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#image DropletAutoscale#image}
    */
    readonly image: string;
    /**
    * Enable droplet IPv6
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#ipv6 DropletAutoscale#ipv6}
    */
    readonly ipv6?: boolean | cdktn.IResolvable;
    /**
    * Droplet project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#project_id DropletAutoscale#project_id}
    */
    readonly projectId?: string;
    /**
    * Enables public networking for the Droplet. By default, this is always enabled on new Droplets, but by explicitly setting it to false, you can create a Droplet with public networking entirely disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#public_networking DropletAutoscale#public_networking}
    */
    readonly publicNetworking?: boolean | cdktn.IResolvable;
    /**
    * Droplet region
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#region DropletAutoscale#region}
    */
    readonly region: string;
    /**
    * Droplet size
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#size DropletAutoscale#size}
    */
    readonly size: string;
    /**
    * Droplet SSH keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#ssh_keys DropletAutoscale#ssh_keys}
    */
    readonly sshKeys: string[];
    /**
    * Droplet tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#tags DropletAutoscale#tags}
    */
    readonly tags?: string[];
    /**
    * Droplet user data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#user_data DropletAutoscale#user_data}
    */
    readonly userData?: string;
    /**
    * Droplet VPC UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#vpc_uuid DropletAutoscale#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * Enable droplet agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#with_droplet_agent DropletAutoscale#with_droplet_agent}
    */
    readonly withDropletAgent?: boolean | cdktn.IResolvable;
}
export declare function dropletAutoscaleDropletTemplateToTerraform(struct?: DropletAutoscaleDropletTemplateOutputReference | DropletAutoscaleDropletTemplate): any;
export declare function dropletAutoscaleDropletTemplateToHclTerraform(struct?: DropletAutoscaleDropletTemplateOutputReference | DropletAutoscaleDropletTemplate): any;
export declare class DropletAutoscaleDropletTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DropletAutoscaleDropletTemplate | undefined;
    set internalValue(value: DropletAutoscaleDropletTemplate | undefined);
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _ipv6?;
    get ipv6(): boolean | cdktn.IResolvable;
    set ipv6(value: boolean | cdktn.IResolvable);
    resetIpv6(): void;
    get ipv6Input(): boolean | cdktn.IResolvable | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _publicNetworking?;
    get publicNetworking(): boolean | cdktn.IResolvable;
    set publicNetworking(value: boolean | cdktn.IResolvable);
    resetPublicNetworking(): void;
    get publicNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
    private _sshKeys?;
    get sshKeys(): string[];
    set sshKeys(value: string[]);
    get sshKeysInput(): string[] | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _withDropletAgent?;
    get withDropletAgent(): boolean | cdktn.IResolvable;
    set withDropletAgent(value: boolean | cdktn.IResolvable);
    resetWithDropletAgent(): void;
    get withDropletAgentInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale digitalocean_droplet_autoscale}
*/
export declare class DropletAutoscale extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_droplet_autoscale";
    /**
    * Generates CDKTN code for importing a DropletAutoscale resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DropletAutoscale to import
    * @param importFromId The id of the existing DropletAutoscale that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DropletAutoscale to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet_autoscale digitalocean_droplet_autoscale} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DropletAutoscaleConfig
    */
    constructor(scope: Construct, id: string, config: DropletAutoscaleConfig);
    get createdAt(): string;
    private _currentUtilization;
    get currentUtilization(): DropletAutoscaleCurrentUtilizationList;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    private _config;
    get config(): DropletAutoscaleConfigAOutputReference;
    putConfig(value: DropletAutoscaleConfigA): void;
    get configInput(): DropletAutoscaleConfigA | undefined;
    private _dropletTemplate;
    get dropletTemplate(): DropletAutoscaleDropletTemplateOutputReference;
    putDropletTemplate(value: DropletAutoscaleDropletTemplate): void;
    get dropletTemplateInput(): DropletAutoscaleDropletTemplate | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
