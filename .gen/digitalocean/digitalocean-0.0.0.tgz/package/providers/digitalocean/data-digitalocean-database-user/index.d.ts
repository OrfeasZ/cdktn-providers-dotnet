import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDatabaseUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_user#cluster_id DataDigitaloceanDatabaseUser#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_user#id DataDigitaloceanDatabaseUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_user#name DataDigitaloceanDatabaseUser#name}
    */
    readonly name: string;
}
export interface DataDigitaloceanDatabaseUserSettingsAcl {
}
export declare function dataDigitaloceanDatabaseUserSettingsAclToTerraform(struct?: DataDigitaloceanDatabaseUserSettingsAcl): any;
export declare function dataDigitaloceanDatabaseUserSettingsAclToHclTerraform(struct?: DataDigitaloceanDatabaseUserSettingsAcl): any;
export declare class DataDigitaloceanDatabaseUserSettingsAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDatabaseUserSettingsAcl | undefined;
    set internalValue(value: DataDigitaloceanDatabaseUserSettingsAcl | undefined);
    get id(): string;
    get permission(): string;
    get topic(): string;
}
export declare class DataDigitaloceanDatabaseUserSettingsAclList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDatabaseUserSettingsAclOutputReference;
}
export interface DataDigitaloceanDatabaseUserSettingsOpensearchAcl {
}
export declare function dataDigitaloceanDatabaseUserSettingsOpensearchAclToTerraform(struct?: DataDigitaloceanDatabaseUserSettingsOpensearchAcl): any;
export declare function dataDigitaloceanDatabaseUserSettingsOpensearchAclToHclTerraform(struct?: DataDigitaloceanDatabaseUserSettingsOpensearchAcl): any;
export declare class DataDigitaloceanDatabaseUserSettingsOpensearchAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDatabaseUserSettingsOpensearchAcl | undefined;
    set internalValue(value: DataDigitaloceanDatabaseUserSettingsOpensearchAcl | undefined);
    get index(): string;
    get permission(): string;
}
export declare class DataDigitaloceanDatabaseUserSettingsOpensearchAclList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDatabaseUserSettingsOpensearchAclOutputReference;
}
export interface DataDigitaloceanDatabaseUserSettings {
}
export declare function dataDigitaloceanDatabaseUserSettingsToTerraform(struct?: DataDigitaloceanDatabaseUserSettings): any;
export declare function dataDigitaloceanDatabaseUserSettingsToHclTerraform(struct?: DataDigitaloceanDatabaseUserSettings): any;
export declare class DataDigitaloceanDatabaseUserSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDatabaseUserSettings | undefined;
    set internalValue(value: DataDigitaloceanDatabaseUserSettings | undefined);
    private _acl;
    get acl(): DataDigitaloceanDatabaseUserSettingsAclList;
    private _opensearchAcl;
    get opensearchAcl(): DataDigitaloceanDatabaseUserSettingsOpensearchAclList;
}
export declare class DataDigitaloceanDatabaseUserSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDatabaseUserSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_user digitalocean_database_user}
*/
export declare class DataDigitaloceanDatabaseUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_database_user";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDatabaseUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDatabaseUser to import
    * @param importFromId The id of the existing DataDigitaloceanDatabaseUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDatabaseUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_user digitalocean_database_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDatabaseUserConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanDatabaseUserConfig);
    get accessCert(): string;
    get accessKey(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get mysqlAuthPlugin(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get password(): string;
    get role(): string;
    private _settings;
    get settings(): DataDigitaloceanDatabaseUserSettingsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
