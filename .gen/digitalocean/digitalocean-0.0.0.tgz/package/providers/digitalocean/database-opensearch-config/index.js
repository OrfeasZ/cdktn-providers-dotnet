"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseOpensearchConfig = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config digitalocean_database_opensearch_config}
*/
class DatabaseOpensearchConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseOpensearchConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseOpensearchConfig to import
    * @param importFromId The id of the existing DatabaseOpensearchConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseOpensearchConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_opensearch_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_opensearch_config digitalocean_database_opensearch_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseOpensearchConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_opensearch_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._actionAutoCreateIndexEnabled = config.actionAutoCreateIndexEnabled;
        this._actionDestructiveRequiresName = config.actionDestructiveRequiresName;
        this._clusterId = config.clusterId;
        this._clusterMaxShardsPerNode = config.clusterMaxShardsPerNode;
        this._clusterRoutingAllocationNodeConcurrentRecoveries = config.clusterRoutingAllocationNodeConcurrentRecoveries;
        this._enableSecurityAudit = config.enableSecurityAudit;
        this._httpMaxContentLengthBytes = config.httpMaxContentLengthBytes;
        this._httpMaxHeaderSizeBytes = config.httpMaxHeaderSizeBytes;
        this._httpMaxInitialLineLengthBytes = config.httpMaxInitialLineLengthBytes;
        this._id = config.id;
        this._indicesFielddataCacheSizePercentage = config.indicesFielddataCacheSizePercentage;
        this._indicesMemoryIndexBufferSizePercentage = config.indicesMemoryIndexBufferSizePercentage;
        this._indicesMemoryMaxIndexBufferSizeMb = config.indicesMemoryMaxIndexBufferSizeMb;
        this._indicesMemoryMinIndexBufferSizeMb = config.indicesMemoryMinIndexBufferSizeMb;
        this._indicesQueriesCacheSizePercentage = config.indicesQueriesCacheSizePercentage;
        this._indicesQueryBoolMaxClauseCount = config.indicesQueryBoolMaxClauseCount;
        this._indicesRecoveryMaxConcurrentFileChunks = config.indicesRecoveryMaxConcurrentFileChunks;
        this._indicesRecoveryMaxMbPerSec = config.indicesRecoveryMaxMbPerSec;
        this._ismEnabled = config.ismEnabled;
        this._ismHistoryEnabled = config.ismHistoryEnabled;
        this._ismHistoryMaxAgeHours = config.ismHistoryMaxAgeHours;
        this._ismHistoryMaxDocs = config.ismHistoryMaxDocs;
        this._ismHistoryRolloverCheckPeriodHours = config.ismHistoryRolloverCheckPeriodHours;
        this._ismHistoryRolloverRetentionPeriodDays = config.ismHistoryRolloverRetentionPeriodDays;
        this._overrideMainResponseVersion = config.overrideMainResponseVersion;
        this._pluginsAlertingFilterByBackendRolesEnabled = config.pluginsAlertingFilterByBackendRolesEnabled;
        this._reindexRemoteWhitelist = config.reindexRemoteWhitelist;
        this._scriptMaxCompilationsRate = config.scriptMaxCompilationsRate;
        this._searchMaxBuckets = config.searchMaxBuckets;
        this._threadPoolAnalyzeQueueSize = config.threadPoolAnalyzeQueueSize;
        this._threadPoolAnalyzeSize = config.threadPoolAnalyzeSize;
        this._threadPoolForceMergeSize = config.threadPoolForceMergeSize;
        this._threadPoolGetQueueSize = config.threadPoolGetQueueSize;
        this._threadPoolGetSize = config.threadPoolGetSize;
        this._threadPoolSearchQueueSize = config.threadPoolSearchQueueSize;
        this._threadPoolSearchSize = config.threadPoolSearchSize;
        this._threadPoolSearchThrottledQueueSize = config.threadPoolSearchThrottledQueueSize;
        this._threadPoolSearchThrottledSize = config.threadPoolSearchThrottledSize;
        this._threadPoolWriteQueueSize = config.threadPoolWriteQueueSize;
        this._threadPoolWriteSize = config.threadPoolWriteSize;
    }
    get actionAutoCreateIndexEnabled() {
        return this.getBooleanAttribute('action_auto_create_index_enabled');
    }
    set actionAutoCreateIndexEnabled(value) {
        this._actionAutoCreateIndexEnabled = value;
    }
    resetActionAutoCreateIndexEnabled() {
        this._actionAutoCreateIndexEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get actionAutoCreateIndexEnabledInput() {
        return this._actionAutoCreateIndexEnabled;
    }
    get actionDestructiveRequiresName() {
        return this.getBooleanAttribute('action_destructive_requires_name');
    }
    set actionDestructiveRequiresName(value) {
        this._actionDestructiveRequiresName = value;
    }
    resetActionDestructiveRequiresName() {
        this._actionDestructiveRequiresName = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get actionDestructiveRequiresNameInput() {
        return this._actionDestructiveRequiresName;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get clusterMaxShardsPerNode() {
        return this.getNumberAttribute('cluster_max_shards_per_node');
    }
    set clusterMaxShardsPerNode(value) {
        this._clusterMaxShardsPerNode = value;
    }
    resetClusterMaxShardsPerNode() {
        this._clusterMaxShardsPerNode = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get clusterMaxShardsPerNodeInput() {
        return this._clusterMaxShardsPerNode;
    }
    get clusterRoutingAllocationNodeConcurrentRecoveries() {
        return this.getNumberAttribute('cluster_routing_allocation_node_concurrent_recoveries');
    }
    set clusterRoutingAllocationNodeConcurrentRecoveries(value) {
        this._clusterRoutingAllocationNodeConcurrentRecoveries = value;
    }
    resetClusterRoutingAllocationNodeConcurrentRecoveries() {
        this._clusterRoutingAllocationNodeConcurrentRecoveries = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get clusterRoutingAllocationNodeConcurrentRecoveriesInput() {
        return this._clusterRoutingAllocationNodeConcurrentRecoveries;
    }
    get enableSecurityAudit() {
        return this.getBooleanAttribute('enable_security_audit');
    }
    set enableSecurityAudit(value) {
        this._enableSecurityAudit = value;
    }
    resetEnableSecurityAudit() {
        this._enableSecurityAudit = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get enableSecurityAuditInput() {
        return this._enableSecurityAudit;
    }
    get httpMaxContentLengthBytes() {
        return this.getNumberAttribute('http_max_content_length_bytes');
    }
    set httpMaxContentLengthBytes(value) {
        this._httpMaxContentLengthBytes = value;
    }
    resetHttpMaxContentLengthBytes() {
        this._httpMaxContentLengthBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpMaxContentLengthBytesInput() {
        return this._httpMaxContentLengthBytes;
    }
    get httpMaxHeaderSizeBytes() {
        return this.getNumberAttribute('http_max_header_size_bytes');
    }
    set httpMaxHeaderSizeBytes(value) {
        this._httpMaxHeaderSizeBytes = value;
    }
    resetHttpMaxHeaderSizeBytes() {
        this._httpMaxHeaderSizeBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpMaxHeaderSizeBytesInput() {
        return this._httpMaxHeaderSizeBytes;
    }
    get httpMaxInitialLineLengthBytes() {
        return this.getNumberAttribute('http_max_initial_line_length_bytes');
    }
    set httpMaxInitialLineLengthBytes(value) {
        this._httpMaxInitialLineLengthBytes = value;
    }
    resetHttpMaxInitialLineLengthBytes() {
        this._httpMaxInitialLineLengthBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpMaxInitialLineLengthBytesInput() {
        return this._httpMaxInitialLineLengthBytes;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get indicesFielddataCacheSizePercentage() {
        return this.getNumberAttribute('indices_fielddata_cache_size_percentage');
    }
    set indicesFielddataCacheSizePercentage(value) {
        this._indicesFielddataCacheSizePercentage = value;
    }
    resetIndicesFielddataCacheSizePercentage() {
        this._indicesFielddataCacheSizePercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesFielddataCacheSizePercentageInput() {
        return this._indicesFielddataCacheSizePercentage;
    }
    get indicesMemoryIndexBufferSizePercentage() {
        return this.getNumberAttribute('indices_memory_index_buffer_size_percentage');
    }
    set indicesMemoryIndexBufferSizePercentage(value) {
        this._indicesMemoryIndexBufferSizePercentage = value;
    }
    resetIndicesMemoryIndexBufferSizePercentage() {
        this._indicesMemoryIndexBufferSizePercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesMemoryIndexBufferSizePercentageInput() {
        return this._indicesMemoryIndexBufferSizePercentage;
    }
    get indicesMemoryMaxIndexBufferSizeMb() {
        return this.getNumberAttribute('indices_memory_max_index_buffer_size_mb');
    }
    set indicesMemoryMaxIndexBufferSizeMb(value) {
        this._indicesMemoryMaxIndexBufferSizeMb = value;
    }
    resetIndicesMemoryMaxIndexBufferSizeMb() {
        this._indicesMemoryMaxIndexBufferSizeMb = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesMemoryMaxIndexBufferSizeMbInput() {
        return this._indicesMemoryMaxIndexBufferSizeMb;
    }
    get indicesMemoryMinIndexBufferSizeMb() {
        return this.getNumberAttribute('indices_memory_min_index_buffer_size_mb');
    }
    set indicesMemoryMinIndexBufferSizeMb(value) {
        this._indicesMemoryMinIndexBufferSizeMb = value;
    }
    resetIndicesMemoryMinIndexBufferSizeMb() {
        this._indicesMemoryMinIndexBufferSizeMb = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesMemoryMinIndexBufferSizeMbInput() {
        return this._indicesMemoryMinIndexBufferSizeMb;
    }
    get indicesQueriesCacheSizePercentage() {
        return this.getNumberAttribute('indices_queries_cache_size_percentage');
    }
    set indicesQueriesCacheSizePercentage(value) {
        this._indicesQueriesCacheSizePercentage = value;
    }
    resetIndicesQueriesCacheSizePercentage() {
        this._indicesQueriesCacheSizePercentage = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesQueriesCacheSizePercentageInput() {
        return this._indicesQueriesCacheSizePercentage;
    }
    get indicesQueryBoolMaxClauseCount() {
        return this.getNumberAttribute('indices_query_bool_max_clause_count');
    }
    set indicesQueryBoolMaxClauseCount(value) {
        this._indicesQueryBoolMaxClauseCount = value;
    }
    resetIndicesQueryBoolMaxClauseCount() {
        this._indicesQueryBoolMaxClauseCount = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesQueryBoolMaxClauseCountInput() {
        return this._indicesQueryBoolMaxClauseCount;
    }
    get indicesRecoveryMaxConcurrentFileChunks() {
        return this.getNumberAttribute('indices_recovery_max_concurrent_file_chunks');
    }
    set indicesRecoveryMaxConcurrentFileChunks(value) {
        this._indicesRecoveryMaxConcurrentFileChunks = value;
    }
    resetIndicesRecoveryMaxConcurrentFileChunks() {
        this._indicesRecoveryMaxConcurrentFileChunks = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesRecoveryMaxConcurrentFileChunksInput() {
        return this._indicesRecoveryMaxConcurrentFileChunks;
    }
    get indicesRecoveryMaxMbPerSec() {
        return this.getNumberAttribute('indices_recovery_max_mb_per_sec');
    }
    set indicesRecoveryMaxMbPerSec(value) {
        this._indicesRecoveryMaxMbPerSec = value;
    }
    resetIndicesRecoveryMaxMbPerSec() {
        this._indicesRecoveryMaxMbPerSec = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get indicesRecoveryMaxMbPerSecInput() {
        return this._indicesRecoveryMaxMbPerSec;
    }
    get ismEnabled() {
        return this.getBooleanAttribute('ism_enabled');
    }
    set ismEnabled(value) {
        this._ismEnabled = value;
    }
    resetIsmEnabled() {
        this._ismEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismEnabledInput() {
        return this._ismEnabled;
    }
    get ismHistoryEnabled() {
        return this.getBooleanAttribute('ism_history_enabled');
    }
    set ismHistoryEnabled(value) {
        this._ismHistoryEnabled = value;
    }
    resetIsmHistoryEnabled() {
        this._ismHistoryEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryEnabledInput() {
        return this._ismHistoryEnabled;
    }
    get ismHistoryMaxAgeHours() {
        return this.getNumberAttribute('ism_history_max_age_hours');
    }
    set ismHistoryMaxAgeHours(value) {
        this._ismHistoryMaxAgeHours = value;
    }
    resetIsmHistoryMaxAgeHours() {
        this._ismHistoryMaxAgeHours = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryMaxAgeHoursInput() {
        return this._ismHistoryMaxAgeHours;
    }
    get ismHistoryMaxDocs() {
        return this.getNumberAttribute('ism_history_max_docs');
    }
    set ismHistoryMaxDocs(value) {
        this._ismHistoryMaxDocs = value;
    }
    resetIsmHistoryMaxDocs() {
        this._ismHistoryMaxDocs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryMaxDocsInput() {
        return this._ismHistoryMaxDocs;
    }
    get ismHistoryRolloverCheckPeriodHours() {
        return this.getNumberAttribute('ism_history_rollover_check_period_hours');
    }
    set ismHistoryRolloverCheckPeriodHours(value) {
        this._ismHistoryRolloverCheckPeriodHours = value;
    }
    resetIsmHistoryRolloverCheckPeriodHours() {
        this._ismHistoryRolloverCheckPeriodHours = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryRolloverCheckPeriodHoursInput() {
        return this._ismHistoryRolloverCheckPeriodHours;
    }
    get ismHistoryRolloverRetentionPeriodDays() {
        return this.getNumberAttribute('ism_history_rollover_retention_period_days');
    }
    set ismHistoryRolloverRetentionPeriodDays(value) {
        this._ismHistoryRolloverRetentionPeriodDays = value;
    }
    resetIsmHistoryRolloverRetentionPeriodDays() {
        this._ismHistoryRolloverRetentionPeriodDays = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get ismHistoryRolloverRetentionPeriodDaysInput() {
        return this._ismHistoryRolloverRetentionPeriodDays;
    }
    get overrideMainResponseVersion() {
        return this.getBooleanAttribute('override_main_response_version');
    }
    set overrideMainResponseVersion(value) {
        this._overrideMainResponseVersion = value;
    }
    resetOverrideMainResponseVersion() {
        this._overrideMainResponseVersion = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get overrideMainResponseVersionInput() {
        return this._overrideMainResponseVersion;
    }
    get pluginsAlertingFilterByBackendRolesEnabled() {
        return this.getBooleanAttribute('plugins_alerting_filter_by_backend_roles_enabled');
    }
    set pluginsAlertingFilterByBackendRolesEnabled(value) {
        this._pluginsAlertingFilterByBackendRolesEnabled = value;
    }
    resetPluginsAlertingFilterByBackendRolesEnabled() {
        this._pluginsAlertingFilterByBackendRolesEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get pluginsAlertingFilterByBackendRolesEnabledInput() {
        return this._pluginsAlertingFilterByBackendRolesEnabled;
    }
    get reindexRemoteWhitelist() {
        return cdktn.Fn.tolist(this.getListAttribute('reindex_remote_whitelist'));
    }
    set reindexRemoteWhitelist(value) {
        this._reindexRemoteWhitelist = value;
    }
    resetReindexRemoteWhitelist() {
        this._reindexRemoteWhitelist = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get reindexRemoteWhitelistInput() {
        return this._reindexRemoteWhitelist;
    }
    get scriptMaxCompilationsRate() {
        return this.getStringAttribute('script_max_compilations_rate');
    }
    set scriptMaxCompilationsRate(value) {
        this._scriptMaxCompilationsRate = value;
    }
    resetScriptMaxCompilationsRate() {
        this._scriptMaxCompilationsRate = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get scriptMaxCompilationsRateInput() {
        return this._scriptMaxCompilationsRate;
    }
    get searchMaxBuckets() {
        return this.getNumberAttribute('search_max_buckets');
    }
    set searchMaxBuckets(value) {
        this._searchMaxBuckets = value;
    }
    resetSearchMaxBuckets() {
        this._searchMaxBuckets = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get searchMaxBucketsInput() {
        return this._searchMaxBuckets;
    }
    get threadPoolAnalyzeQueueSize() {
        return this.getNumberAttribute('thread_pool_analyze_queue_size');
    }
    set threadPoolAnalyzeQueueSize(value) {
        this._threadPoolAnalyzeQueueSize = value;
    }
    resetThreadPoolAnalyzeQueueSize() {
        this._threadPoolAnalyzeQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolAnalyzeQueueSizeInput() {
        return this._threadPoolAnalyzeQueueSize;
    }
    get threadPoolAnalyzeSize() {
        return this.getNumberAttribute('thread_pool_analyze_size');
    }
    set threadPoolAnalyzeSize(value) {
        this._threadPoolAnalyzeSize = value;
    }
    resetThreadPoolAnalyzeSize() {
        this._threadPoolAnalyzeSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolAnalyzeSizeInput() {
        return this._threadPoolAnalyzeSize;
    }
    get threadPoolForceMergeSize() {
        return this.getNumberAttribute('thread_pool_force_merge_size');
    }
    set threadPoolForceMergeSize(value) {
        this._threadPoolForceMergeSize = value;
    }
    resetThreadPoolForceMergeSize() {
        this._threadPoolForceMergeSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolForceMergeSizeInput() {
        return this._threadPoolForceMergeSize;
    }
    get threadPoolGetQueueSize() {
        return this.getNumberAttribute('thread_pool_get_queue_size');
    }
    set threadPoolGetQueueSize(value) {
        this._threadPoolGetQueueSize = value;
    }
    resetThreadPoolGetQueueSize() {
        this._threadPoolGetQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolGetQueueSizeInput() {
        return this._threadPoolGetQueueSize;
    }
    get threadPoolGetSize() {
        return this.getNumberAttribute('thread_pool_get_size');
    }
    set threadPoolGetSize(value) {
        this._threadPoolGetSize = value;
    }
    resetThreadPoolGetSize() {
        this._threadPoolGetSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolGetSizeInput() {
        return this._threadPoolGetSize;
    }
    get threadPoolSearchQueueSize() {
        return this.getNumberAttribute('thread_pool_search_queue_size');
    }
    set threadPoolSearchQueueSize(value) {
        this._threadPoolSearchQueueSize = value;
    }
    resetThreadPoolSearchQueueSize() {
        this._threadPoolSearchQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchQueueSizeInput() {
        return this._threadPoolSearchQueueSize;
    }
    get threadPoolSearchSize() {
        return this.getNumberAttribute('thread_pool_search_size');
    }
    set threadPoolSearchSize(value) {
        this._threadPoolSearchSize = value;
    }
    resetThreadPoolSearchSize() {
        this._threadPoolSearchSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchSizeInput() {
        return this._threadPoolSearchSize;
    }
    get threadPoolSearchThrottledQueueSize() {
        return this.getNumberAttribute('thread_pool_search_throttled_queue_size');
    }
    set threadPoolSearchThrottledQueueSize(value) {
        this._threadPoolSearchThrottledQueueSize = value;
    }
    resetThreadPoolSearchThrottledQueueSize() {
        this._threadPoolSearchThrottledQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchThrottledQueueSizeInput() {
        return this._threadPoolSearchThrottledQueueSize;
    }
    get threadPoolSearchThrottledSize() {
        return this.getNumberAttribute('thread_pool_search_throttled_size');
    }
    set threadPoolSearchThrottledSize(value) {
        this._threadPoolSearchThrottledSize = value;
    }
    resetThreadPoolSearchThrottledSize() {
        this._threadPoolSearchThrottledSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolSearchThrottledSizeInput() {
        return this._threadPoolSearchThrottledSize;
    }
    get threadPoolWriteQueueSize() {
        return this.getNumberAttribute('thread_pool_write_queue_size');
    }
    set threadPoolWriteQueueSize(value) {
        this._threadPoolWriteQueueSize = value;
    }
    resetThreadPoolWriteQueueSize() {
        this._threadPoolWriteQueueSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolWriteQueueSizeInput() {
        return this._threadPoolWriteQueueSize;
    }
    get threadPoolWriteSize() {
        return this.getNumberAttribute('thread_pool_write_size');
    }
    set threadPoolWriteSize(value) {
        this._threadPoolWriteSize = value;
    }
    resetThreadPoolWriteSize() {
        this._threadPoolWriteSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get threadPoolWriteSizeInput() {
        return this._threadPoolWriteSize;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            action_auto_create_index_enabled: cdktn.booleanToTerraform(this._actionAutoCreateIndexEnabled),
            action_destructive_requires_name: cdktn.booleanToTerraform(this._actionDestructiveRequiresName),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            cluster_max_shards_per_node: cdktn.numberToTerraform(this._clusterMaxShardsPerNode),
            cluster_routing_allocation_node_concurrent_recoveries: cdktn.numberToTerraform(this._clusterRoutingAllocationNodeConcurrentRecoveries),
            enable_security_audit: cdktn.booleanToTerraform(this._enableSecurityAudit),
            http_max_content_length_bytes: cdktn.numberToTerraform(this._httpMaxContentLengthBytes),
            http_max_header_size_bytes: cdktn.numberToTerraform(this._httpMaxHeaderSizeBytes),
            http_max_initial_line_length_bytes: cdktn.numberToTerraform(this._httpMaxInitialLineLengthBytes),
            id: cdktn.stringToTerraform(this._id),
            indices_fielddata_cache_size_percentage: cdktn.numberToTerraform(this._indicesFielddataCacheSizePercentage),
            indices_memory_index_buffer_size_percentage: cdktn.numberToTerraform(this._indicesMemoryIndexBufferSizePercentage),
            indices_memory_max_index_buffer_size_mb: cdktn.numberToTerraform(this._indicesMemoryMaxIndexBufferSizeMb),
            indices_memory_min_index_buffer_size_mb: cdktn.numberToTerraform(this._indicesMemoryMinIndexBufferSizeMb),
            indices_queries_cache_size_percentage: cdktn.numberToTerraform(this._indicesQueriesCacheSizePercentage),
            indices_query_bool_max_clause_count: cdktn.numberToTerraform(this._indicesQueryBoolMaxClauseCount),
            indices_recovery_max_concurrent_file_chunks: cdktn.numberToTerraform(this._indicesRecoveryMaxConcurrentFileChunks),
            indices_recovery_max_mb_per_sec: cdktn.numberToTerraform(this._indicesRecoveryMaxMbPerSec),
            ism_enabled: cdktn.booleanToTerraform(this._ismEnabled),
            ism_history_enabled: cdktn.booleanToTerraform(this._ismHistoryEnabled),
            ism_history_max_age_hours: cdktn.numberToTerraform(this._ismHistoryMaxAgeHours),
            ism_history_max_docs: cdktn.numberToTerraform(this._ismHistoryMaxDocs),
            ism_history_rollover_check_period_hours: cdktn.numberToTerraform(this._ismHistoryRolloverCheckPeriodHours),
            ism_history_rollover_retention_period_days: cdktn.numberToTerraform(this._ismHistoryRolloverRetentionPeriodDays),
            override_main_response_version: cdktn.booleanToTerraform(this._overrideMainResponseVersion),
            plugins_alerting_filter_by_backend_roles_enabled: cdktn.booleanToTerraform(this._pluginsAlertingFilterByBackendRolesEnabled),
            reindex_remote_whitelist: cdktn.listMapper(cdktn.stringToTerraform, false)(this._reindexRemoteWhitelist),
            script_max_compilations_rate: cdktn.stringToTerraform(this._scriptMaxCompilationsRate),
            search_max_buckets: cdktn.numberToTerraform(this._searchMaxBuckets),
            thread_pool_analyze_queue_size: cdktn.numberToTerraform(this._threadPoolAnalyzeQueueSize),
            thread_pool_analyze_size: cdktn.numberToTerraform(this._threadPoolAnalyzeSize),
            thread_pool_force_merge_size: cdktn.numberToTerraform(this._threadPoolForceMergeSize),
            thread_pool_get_queue_size: cdktn.numberToTerraform(this._threadPoolGetQueueSize),
            thread_pool_get_size: cdktn.numberToTerraform(this._threadPoolGetSize),
            thread_pool_search_queue_size: cdktn.numberToTerraform(this._threadPoolSearchQueueSize),
            thread_pool_search_size: cdktn.numberToTerraform(this._threadPoolSearchSize),
            thread_pool_search_throttled_queue_size: cdktn.numberToTerraform(this._threadPoolSearchThrottledQueueSize),
            thread_pool_search_throttled_size: cdktn.numberToTerraform(this._threadPoolSearchThrottledSize),
            thread_pool_write_queue_size: cdktn.numberToTerraform(this._threadPoolWriteQueueSize),
            thread_pool_write_size: cdktn.numberToTerraform(this._threadPoolWriteSize),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            action_auto_create_index_enabled: {
                value: cdktn.booleanToHclTerraform(this._actionAutoCreateIndexEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            action_destructive_requires_name: {
                value: cdktn.booleanToHclTerraform(this._actionDestructiveRequiresName),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            cluster_max_shards_per_node: {
                value: cdktn.numberToHclTerraform(this._clusterMaxShardsPerNode),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            cluster_routing_allocation_node_concurrent_recoveries: {
                value: cdktn.numberToHclTerraform(this._clusterRoutingAllocationNodeConcurrentRecoveries),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            enable_security_audit: {
                value: cdktn.booleanToHclTerraform(this._enableSecurityAudit),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            http_max_content_length_bytes: {
                value: cdktn.numberToHclTerraform(this._httpMaxContentLengthBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            http_max_header_size_bytes: {
                value: cdktn.numberToHclTerraform(this._httpMaxHeaderSizeBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            http_max_initial_line_length_bytes: {
                value: cdktn.numberToHclTerraform(this._httpMaxInitialLineLengthBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            indices_fielddata_cache_size_percentage: {
                value: cdktn.numberToHclTerraform(this._indicesFielddataCacheSizePercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_memory_index_buffer_size_percentage: {
                value: cdktn.numberToHclTerraform(this._indicesMemoryIndexBufferSizePercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_memory_max_index_buffer_size_mb: {
                value: cdktn.numberToHclTerraform(this._indicesMemoryMaxIndexBufferSizeMb),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_memory_min_index_buffer_size_mb: {
                value: cdktn.numberToHclTerraform(this._indicesMemoryMinIndexBufferSizeMb),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_queries_cache_size_percentage: {
                value: cdktn.numberToHclTerraform(this._indicesQueriesCacheSizePercentage),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_query_bool_max_clause_count: {
                value: cdktn.numberToHclTerraform(this._indicesQueryBoolMaxClauseCount),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_recovery_max_concurrent_file_chunks: {
                value: cdktn.numberToHclTerraform(this._indicesRecoveryMaxConcurrentFileChunks),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            indices_recovery_max_mb_per_sec: {
                value: cdktn.numberToHclTerraform(this._indicesRecoveryMaxMbPerSec),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_enabled: {
                value: cdktn.booleanToHclTerraform(this._ismEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            ism_history_enabled: {
                value: cdktn.booleanToHclTerraform(this._ismHistoryEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            ism_history_max_age_hours: {
                value: cdktn.numberToHclTerraform(this._ismHistoryMaxAgeHours),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_history_max_docs: {
                value: cdktn.numberToHclTerraform(this._ismHistoryMaxDocs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_history_rollover_check_period_hours: {
                value: cdktn.numberToHclTerraform(this._ismHistoryRolloverCheckPeriodHours),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            ism_history_rollover_retention_period_days: {
                value: cdktn.numberToHclTerraform(this._ismHistoryRolloverRetentionPeriodDays),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            override_main_response_version: {
                value: cdktn.booleanToHclTerraform(this._overrideMainResponseVersion),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            plugins_alerting_filter_by_backend_roles_enabled: {
                value: cdktn.booleanToHclTerraform(this._pluginsAlertingFilterByBackendRolesEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            reindex_remote_whitelist: {
                value: cdktn.listMapperHcl(cdktn.stringToHclTerraform, false)(this._reindexRemoteWhitelist),
                isBlock: false,
                type: "set",
                storageClassType: "stringList",
            },
            script_max_compilations_rate: {
                value: cdktn.stringToHclTerraform(this._scriptMaxCompilationsRate),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            search_max_buckets: {
                value: cdktn.numberToHclTerraform(this._searchMaxBuckets),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_analyze_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolAnalyzeQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_analyze_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolAnalyzeSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_force_merge_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolForceMergeSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_get_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolGetQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_get_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolGetSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_throttled_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchThrottledQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_search_throttled_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolSearchThrottledSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_write_queue_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolWriteQueueSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            thread_pool_write_size: {
                value: cdktn.numberToHclTerraform(this._threadPoolWriteSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseOpensearchConfig = DatabaseOpensearchConfig;
_a = JSII_RTTI_SYMBOL_1;
DatabaseOpensearchConfig[_a] = { fqn: "digitalocean.databaseOpensearchConfig.DatabaseOpensearchConfig", version: "0.0.0" };
// =================
// STATIC PROPERTIES
// =================
DatabaseOpensearchConfig.tfResourceType = "digitalocean_database_opensearch_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUlBLCtCQUErQjtBQTBLL0I7O0VBRUU7QUFDRixNQUFhLHdCQUF5QixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPbkUsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLHlDQUF5QyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUNqSyxDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBc0M7UUFDckYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSx5Q0FBeUM7WUFDaEUsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsNkJBQTZCLENBQUM7UUFDM0UsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ25DLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLGlEQUFpRCxHQUFHLE1BQU0sQ0FBQyxnREFBZ0QsQ0FBQztRQUNqSCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDLG1CQUFtQixDQUFDO1FBQ3ZELElBQUksQ0FBQywwQkFBMEIsR0FBRyxNQUFNLENBQUMseUJBQXlCLENBQUM7UUFDbkUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsOEJBQThCLEdBQUcsTUFBTSxDQUFDLDZCQUE2QixDQUFDO1FBQzNFLElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsb0NBQW9DLEdBQUcsTUFBTSxDQUFDLG1DQUFtQyxDQUFDO1FBQ3ZGLElBQUksQ0FBQyx1Q0FBdUMsR0FBRyxNQUFNLENBQUMsc0NBQXNDLENBQUM7UUFDN0YsSUFBSSxDQUFDLGtDQUFrQyxHQUFHLE1BQU0sQ0FBQyxpQ0FBaUMsQ0FBQztRQUNuRixJQUFJLENBQUMsa0NBQWtDLEdBQUcsTUFBTSxDQUFDLGlDQUFpQyxDQUFDO1FBQ25GLElBQUksQ0FBQyxrQ0FBa0MsR0FBRyxNQUFNLENBQUMsaUNBQWlDLENBQUM7UUFDbkYsSUFBSSxDQUFDLCtCQUErQixHQUFHLE1BQU0sQ0FBQyw4QkFBOEIsQ0FBQztRQUM3RSxJQUFJLENBQUMsdUNBQXVDLEdBQUcsTUFBTSxDQUFDLHNDQUFzQyxDQUFDO1FBQzdGLElBQUksQ0FBQywyQkFBMkIsR0FBRyxNQUFNLENBQUMsMEJBQTBCLENBQUM7UUFDckUsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxNQUFNLENBQUMsa0NBQWtDLENBQUM7UUFDckYsSUFBSSxDQUFDLHNDQUFzQyxHQUFHLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQztRQUMzRixJQUFJLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDO1FBQ3ZFLElBQUksQ0FBQywyQ0FBMkMsR0FBRyxNQUFNLENBQUMsMENBQTBDLENBQUM7UUFDckcsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsTUFBTSxDQUFDLHlCQUF5QixDQUFDO1FBQ25FLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUM7UUFDakQsSUFBSSxDQUFDLDJCQUEyQixHQUFHLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQztRQUNyRSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzNELElBQUksQ0FBQyx5QkFBeUIsR0FBRyxNQUFNLENBQUMsd0JBQXdCLENBQUM7UUFDakUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQywwQkFBMEIsR0FBRyxNQUFNLENBQUMseUJBQXlCLENBQUM7UUFDbkUsSUFBSSxDQUFDLHFCQUFxQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztRQUN6RCxJQUFJLENBQUMsbUNBQW1DLEdBQUcsTUFBTSxDQUFDLGtDQUFrQyxDQUFDO1FBQ3JGLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsNkJBQTZCLENBQUM7UUFDM0UsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQztRQUNqRSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDLG1CQUFtQixDQUFDO0lBQ3pELENBQUM7SUFRRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFDRCxJQUFXLDRCQUE0QixDQUFDLEtBQWtDO1FBQ3hFLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxLQUFLLENBQUM7SUFDN0MsQ0FBQztJQUNNLGlDQUFpQztRQUN0QyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsU0FBUyxDQUFDO0lBQ2pELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxpQ0FBaUM7UUFDMUMsT0FBTyxJQUFJLENBQUMsNkJBQTZCLENBQUM7SUFDNUMsQ0FBQztJQUlELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGtDQUFrQyxDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUNELElBQVcsNkJBQTZCLENBQUMsS0FBa0M7UUFDekUsSUFBSSxDQUFDLDhCQUE4QixHQUFHLEtBQUssQ0FBQztJQUM5QyxDQUFDO0lBQ00sa0NBQWtDO1FBQ3ZDLElBQUksQ0FBQyw4QkFBOEIsR0FBRyxTQUFTLENBQUM7SUFDbEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtDQUFrQztRQUMzQyxPQUFPLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztJQUM3QyxDQUFDO0lBSUQsSUFBVyxTQUFTO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFDRCxJQUFXLFNBQVMsQ0FBQyxLQUFhO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN6QixDQUFDO0lBSUQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsNkJBQTZCLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFhO1FBQzlDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUNNLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0lBQzVDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw0QkFBNEI7UUFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUlELElBQVcsZ0RBQWdEO1FBQ3pELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHVEQUF1RCxDQUFDLENBQUM7SUFDMUYsQ0FBQztJQUNELElBQVcsZ0RBQWdELENBQUMsS0FBYTtRQUN2RSxJQUFJLENBQUMsaURBQWlELEdBQUcsS0FBSyxDQUFDO0lBQ2pFLENBQUM7SUFDTSxxREFBcUQ7UUFDMUQsSUFBSSxDQUFDLGlEQUFpRCxHQUFHLFNBQVMsQ0FBQztJQUNyRSxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscURBQXFEO1FBQzlELE9BQU8sSUFBSSxDQUFDLGlEQUFpRCxDQUFDO0lBQ2hFLENBQUM7SUFJRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG1CQUFtQixDQUFDLEtBQWtDO1FBQy9ELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUNNLHdCQUF3QjtRQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFDbkMsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLCtCQUErQixDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWE7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyw2QkFBNkI7UUFDdEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsb0NBQW9DLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBQ0QsSUFBVyw2QkFBNkIsQ0FBQyxLQUFhO1FBQ3BELElBQUksQ0FBQyw4QkFBOEIsR0FBRyxLQUFLLENBQUM7SUFDOUMsQ0FBQztJQUNNLGtDQUFrQztRQUN2QyxJQUFJLENBQUMsOEJBQThCLEdBQUcsU0FBUyxDQUFDO0lBQ2xELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsOEJBQThCLENBQUM7SUFDN0MsQ0FBQztJQUlELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFDRCxJQUFXLEVBQUUsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFDTSxPQUFPO1FBQ1osSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLE9BQU87UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2xCLENBQUM7SUFJRCxJQUFXLG1DQUFtQztRQUM1QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDRCxJQUFXLG1DQUFtQyxDQUFDLEtBQWE7UUFDMUQsSUFBSSxDQUFDLG9DQUFvQyxHQUFHLEtBQUssQ0FBQztJQUNwRCxDQUFDO0lBQ00sd0NBQXdDO1FBQzdDLElBQUksQ0FBQyxvQ0FBb0MsR0FBRyxTQUFTLENBQUM7SUFDeEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHdDQUF3QztRQUNqRCxPQUFPLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQztJQUNuRCxDQUFDO0lBSUQsSUFBVyxzQ0FBc0M7UUFDL0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsNkNBQTZDLENBQUMsQ0FBQztJQUNoRixDQUFDO0lBQ0QsSUFBVyxzQ0FBc0MsQ0FBQyxLQUFhO1FBQzdELElBQUksQ0FBQyx1Q0FBdUMsR0FBRyxLQUFLLENBQUM7SUFDdkQsQ0FBQztJQUNNLDJDQUEyQztRQUNoRCxJQUFJLENBQUMsdUNBQXVDLEdBQUcsU0FBUyxDQUFDO0lBQzNELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQ0FBMkM7UUFDcEQsT0FBTyxJQUFJLENBQUMsdUNBQXVDLENBQUM7SUFDdEQsQ0FBQztJQUlELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHlDQUF5QyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUNELElBQVcsaUNBQWlDLENBQUMsS0FBYTtRQUN4RCxJQUFJLENBQUMsa0NBQWtDLEdBQUcsS0FBSyxDQUFDO0lBQ2xELENBQUM7SUFDTSxzQ0FBc0M7UUFDM0MsSUFBSSxDQUFDLGtDQUFrQyxHQUFHLFNBQVMsQ0FBQztJQUN0RCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsc0NBQXNDO1FBQy9DLE9BQU8sSUFBSSxDQUFDLGtDQUFrQyxDQUFDO0lBQ2pELENBQUM7SUFJRCxJQUFXLGlDQUFpQztRQUMxQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDRCxJQUFXLGlDQUFpQyxDQUFDLEtBQWE7UUFDeEQsSUFBSSxDQUFDLGtDQUFrQyxHQUFHLEtBQUssQ0FBQztJQUNsRCxDQUFDO0lBQ00sc0NBQXNDO1FBQzNDLElBQUksQ0FBQyxrQ0FBa0MsR0FBRyxTQUFTLENBQUM7SUFDdEQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNDQUFzQztRQUMvQyxPQUFPLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQztJQUNqRCxDQUFDO0lBSUQsSUFBVyxpQ0FBaUM7UUFDMUMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsdUNBQXVDLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBQ0QsSUFBVyxpQ0FBaUMsQ0FBQyxLQUFhO1FBQ3hELElBQUksQ0FBQyxrQ0FBa0MsR0FBRyxLQUFLLENBQUM7SUFDbEQsQ0FBQztJQUNNLHNDQUFzQztRQUMzQyxJQUFJLENBQUMsa0NBQWtDLEdBQUcsU0FBUyxDQUFDO0lBQ3RELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQ0FBc0M7UUFDL0MsT0FBTyxJQUFJLENBQUMsa0NBQWtDLENBQUM7SUFDakQsQ0FBQztJQUlELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUNELElBQVcsOEJBQThCLENBQUMsS0FBYTtRQUNyRCxJQUFJLENBQUMsK0JBQStCLEdBQUcsS0FBSyxDQUFDO0lBQy9DLENBQUM7SUFDTSxtQ0FBbUM7UUFDeEMsSUFBSSxDQUFDLCtCQUErQixHQUFHLFNBQVMsQ0FBQztJQUNuRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsbUNBQW1DO1FBQzVDLE9BQU8sSUFBSSxDQUFDLCtCQUErQixDQUFDO0lBQzlDLENBQUM7SUFJRCxJQUFXLHNDQUFzQztRQUMvQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO0lBQ2hGLENBQUM7SUFDRCxJQUFXLHNDQUFzQyxDQUFDLEtBQWE7UUFDN0QsSUFBSSxDQUFDLHVDQUF1QyxHQUFHLEtBQUssQ0FBQztJQUN2RCxDQUFDO0lBQ00sMkNBQTJDO1FBQ2hELElBQUksQ0FBQyx1Q0FBdUMsR0FBRyxTQUFTLENBQUM7SUFDM0QsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJDQUEyQztRQUNwRCxPQUFPLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQztJQUN0RCxDQUFDO0lBSUQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywwQkFBMEIsQ0FBQyxLQUFhO1FBQ2pELElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUM7SUFDM0MsQ0FBQztJQUNNLCtCQUErQjtRQUNwQyxJQUFJLENBQUMsMkJBQTJCLEdBQUcsU0FBUyxDQUFDO0lBQy9DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywrQkFBK0I7UUFDeEMsT0FBTyxJQUFJLENBQUMsMkJBQTJCLENBQUM7SUFDMUMsQ0FBQztJQUlELElBQVcsVUFBVTtRQUNuQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBQ0QsSUFBVyxVQUFVLENBQUMsS0FBa0M7UUFDdEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7SUFDM0IsQ0FBQztJQUNNLGVBQWU7UUFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7SUFDL0IsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWtDO1FBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUNELElBQVcscUJBQXFCLENBQUMsS0FBYTtRQUM1QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7SUFDTSwwQkFBMEI7UUFDL0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsQ0FBQztJQUMxQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JDLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBQ0QsSUFBVyxrQ0FBa0MsQ0FBQyxLQUFhO1FBQ3pELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUM7SUFDbkQsQ0FBQztJQUNNLHVDQUF1QztRQUM1QyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsU0FBUyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1Q0FBdUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsbUNBQW1DLENBQUM7SUFDbEQsQ0FBQztJQUlELElBQVcscUNBQXFDO1FBQzlDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUNELElBQVcscUNBQXFDLENBQUMsS0FBYTtRQUM1RCxJQUFJLENBQUMsc0NBQXNDLEdBQUcsS0FBSyxDQUFDO0lBQ3RELENBQUM7SUFDTSwwQ0FBMEM7UUFDL0MsSUFBSSxDQUFDLHNDQUFzQyxHQUFHLFNBQVMsQ0FBQztJQUMxRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMENBQTBDO1FBQ25ELE9BQU8sSUFBSSxDQUFDLHNDQUFzQyxDQUFDO0lBQ3JELENBQUM7SUFJRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDRCxJQUFXLDJCQUEyQixDQUFDLEtBQWtDO1FBQ3ZFLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsMENBQTBDO1FBQ25ELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGtEQUFrRCxDQUFDLENBQUM7SUFDdEYsQ0FBQztJQUNELElBQVcsMENBQTBDLENBQUMsS0FBa0M7UUFDdEYsSUFBSSxDQUFDLDJDQUEyQyxHQUFHLEtBQUssQ0FBQztJQUMzRCxDQUFDO0lBQ00sK0NBQStDO1FBQ3BELElBQUksQ0FBQywyQ0FBMkMsR0FBRyxTQUFTLENBQUM7SUFDL0QsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLCtDQUErQztRQUN4RCxPQUFPLElBQUksQ0FBQywyQ0FBMkMsQ0FBQztJQUMxRCxDQUFDO0lBSUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWU7UUFDL0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyx5QkFBeUI7UUFDbEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ0QsSUFBVyx5QkFBeUIsQ0FBQyxLQUFhO1FBQ2hELElBQUksQ0FBQywwQkFBMEIsR0FBRyxLQUFLLENBQUM7SUFDMUMsQ0FBQztJQUNNLDhCQUE4QjtRQUNuQyxJQUFJLENBQUMsMEJBQTBCLEdBQUcsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw4QkFBOEI7UUFDdkMsT0FBTyxJQUFJLENBQUMsMEJBQTBCLENBQUM7SUFDekMsQ0FBQztJQUlELElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFJRCxJQUFXLDBCQUEwQjtRQUNuQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFDRCxJQUFXLDBCQUEwQixDQUFDLEtBQWE7UUFDakQsSUFBSSxDQUFDLDJCQUEyQixHQUFHLEtBQUssQ0FBQztJQUMzQyxDQUFDO0lBQ00sK0JBQStCO1FBQ3BDLElBQUksQ0FBQywyQkFBMkIsR0FBRyxTQUFTLENBQUM7SUFDL0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLCtCQUErQjtRQUN4QyxPQUFPLElBQUksQ0FBQywyQkFBMkIsQ0FBQztJQUMxQyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUlELElBQVcsd0JBQXdCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNELElBQVcsd0JBQXdCLENBQUMsS0FBYTtRQUMvQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO0lBQ3pDLENBQUM7SUFDTSw2QkFBNkI7UUFDbEMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLFNBQVMsQ0FBQztJQUM3QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixDQUFDO0lBQ3hDLENBQUM7SUFJRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFDRCxJQUFXLHNCQUFzQixDQUFDLEtBQWE7UUFDN0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBQ00sMkJBQTJCO1FBQ2hDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxTQUFTLENBQUM7SUFDM0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0QyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLCtCQUErQixDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUNELElBQVcseUJBQXlCLENBQUMsS0FBYTtRQUNoRCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0lBQzFDLENBQUM7SUFDTSw4QkFBOEI7UUFDbkMsSUFBSSxDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDO0lBQ3pDLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBQ0QsSUFBVyxrQ0FBa0MsQ0FBQyxLQUFhO1FBQ3pELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUM7SUFDbkQsQ0FBQztJQUNNLHVDQUF1QztRQUM1QyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsU0FBUyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1Q0FBdUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsbUNBQW1DLENBQUM7SUFDbEQsQ0FBQztJQUlELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUNELElBQVcsNkJBQTZCLENBQUMsS0FBYTtRQUNwRCxJQUFJLENBQUMsOEJBQThCLEdBQUcsS0FBSyxDQUFDO0lBQzlDLENBQUM7SUFDTSxrQ0FBa0M7UUFDdkMsSUFBSSxDQUFDLDhCQUE4QixHQUFHLFNBQVMsQ0FBQztJQUNsRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsa0NBQWtDO1FBQzNDLE9BQU8sSUFBSSxDQUFDLDhCQUE4QixDQUFDO0lBQzdDLENBQUM7SUFJRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFDRCxJQUFXLHdCQUF3QixDQUFDLEtBQWE7UUFDL0MsSUFBSSxDQUFDLHlCQUF5QixHQUFHLEtBQUssQ0FBQztJQUN6QyxDQUFDO0lBQ00sNkJBQTZCO1FBQ2xDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxTQUFTLENBQUM7SUFDN0MsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDZCQUE2QjtRQUN0QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztJQUN4QyxDQUFDO0lBSUQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBQ0QsSUFBVyxtQkFBbUIsQ0FBQyxLQUFhO1FBQzFDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUNNLHdCQUF3QjtRQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDO0lBQ3hDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFDbkMsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztZQUM5RixnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO1lBQy9GLFVBQVUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUNwRCwyQkFBMkIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ25GLHFEQUFxRCxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaURBQWlELENBQUM7WUFDdEkscUJBQXFCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztZQUMxRSw2QkFBNkIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDO1lBQ3ZGLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDakYsa0NBQWtDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztZQUNoRyxFQUFFLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDckMsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQztZQUMzRywyQ0FBMkMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVDQUF1QyxDQUFDO1lBQ2xILHVDQUF1QyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7WUFDekcsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQztZQUN6RyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxDQUFDO1lBQ3ZHLG1DQUFtQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7WUFDbEcsMkNBQTJDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQztZQUNsSCwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDO1lBQzFGLFdBQVcsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUN2RCxtQkFBbUIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3RFLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7WUFDL0Usb0JBQW9CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUN0RSx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDO1lBQzFHLDBDQUEwQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0NBQXNDLENBQUM7WUFDaEgsOEJBQThCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUMzRixnREFBZ0QsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLDJDQUEyQyxDQUFDO1lBQzVILHdCQUF3QixFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN4Ryw0QkFBNEIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDO1lBQ3RGLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDbkUsOEJBQThCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQztZQUN6Rix3QkFBd0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzlFLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7WUFDckYsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUNqRixvQkFBb0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3RFLDZCQUE2QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUM7WUFDdkYsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUM1RSx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDO1lBQzFHLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUM7WUFDL0YsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUNyRixzQkFBc0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1NBQzNFLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCO1FBQy9CLE1BQU0sS0FBSyxHQUFHO1lBQ1osZ0NBQWdDLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO2dCQUN0RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsZ0NBQWdDLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDO2dCQUN2RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztnQkFDaEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHFEQUFxRCxFQUFFO2dCQUNyRCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpREFBaUQsQ0FBQztnQkFDekYsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELHFCQUFxQixFQUFFO2dCQUNyQixLQUFLLEVBQUUsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztnQkFDN0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsU0FBUzthQUM1QjtZQUNELDZCQUE2QixFQUFFO2dCQUM3QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQztnQkFDbEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDBCQUEwQixFQUFFO2dCQUMxQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztnQkFDL0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtDQUFrQyxFQUFFO2dCQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQztnQkFDdEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELEVBQUUsRUFBRTtnQkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0NBQW9DLENBQUM7Z0JBQzVFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwyQ0FBMkMsRUFBRTtnQkFDM0MsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUNBQXVDLENBQUM7Z0JBQy9FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQ0FBcUMsRUFBRTtnQkFDckMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUM7Z0JBQzFFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxtQ0FBbUMsRUFBRTtnQkFDbkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7Z0JBQ3ZFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwyQ0FBMkMsRUFBRTtnQkFDM0MsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUNBQXVDLENBQUM7Z0JBQy9FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ25FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxXQUFXLEVBQUU7Z0JBQ1gsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUNwRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsb0JBQW9CLEVBQUU7Z0JBQ3BCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsdUNBQXVDLEVBQUU7Z0JBQ3ZDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDO2dCQUMzRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsMENBQTBDLEVBQUU7Z0JBQzFDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNDQUFzQyxDQUFDO2dCQUM5RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsOEJBQThCLEVBQUU7Z0JBQzlCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNyRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsZ0RBQWdELEVBQUU7Z0JBQ2hELEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDJDQUEyQyxDQUFDO2dCQUNwRixPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0Qsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQzNGLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxLQUFLO2dCQUNYLGdCQUFnQixFQUFFLFlBQVk7YUFDL0I7WUFDRCw0QkFBNEIsRUFBRTtnQkFDNUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUM7Z0JBQ2xFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxrQkFBa0IsRUFBRTtnQkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7Z0JBQ3pELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw4QkFBOEIsRUFBRTtnQkFDOUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUM7Z0JBQ25FLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx3QkFBd0IsRUFBRTtnQkFDeEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw0QkFBNEIsRUFBRTtnQkFDNUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwwQkFBMEIsRUFBRTtnQkFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw2QkFBNkIsRUFBRTtnQkFDN0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUM7Z0JBQ2xFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzdELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUNBQW1DLENBQUM7Z0JBQzNFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQ0FBaUMsRUFBRTtnQkFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUM7Z0JBQ3RFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCw0QkFBNEIsRUFBRTtnQkFDNUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxzQkFBc0IsRUFBRTtnQkFDdEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7Z0JBQzVELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7U0FDRixDQUFDO1FBRUYsOEJBQThCO1FBQzlCLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFFLENBQUMsQ0FBQTtJQUM1SCxDQUFDOztBQWxnQ0gsNERBbWdDQzs7O0FBamdDQyxvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ3BCLG9CQUFvQjtBQUNHLHVDQUFjLEdBQUcseUNBQXlDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWdcbi8vIGdlbmVyYXRlZCBmcm9tIHRlcnJhZm9ybSByZXNvdXJjZSBzY2hlbWFcblxuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBjZGt0biBmcm9tICdjZGt0bic7XG5cbi8vIENvbmZpZ3VyYXRpb25cblxuZXhwb3J0IGludGVyZmFjZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWdDb25maWcgZXh0ZW5kcyBjZGt0bi5UZXJyYWZvcm1NZXRhQXJndW1lbnRzIHtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjYWN0aW9uX2F1dG9fY3JlYXRlX2luZGV4X2VuYWJsZWQgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2FjdGlvbl9hdXRvX2NyZWF0ZV9pbmRleF9lbmFibGVkfVxuICAqL1xuICByZWFkb25seSBhY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNhY3Rpb25fZGVzdHJ1Y3RpdmVfcmVxdWlyZXNfbmFtZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjYWN0aW9uX2Rlc3RydWN0aXZlX3JlcXVpcmVzX25hbWV9XG4gICovXG4gIHJlYWRvbmx5IGFjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNjbHVzdGVyX2lkIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNjbHVzdGVyX2lkfVxuICAqL1xuICByZWFkb25seSBjbHVzdGVySWQ6IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjY2x1c3Rlcl9tYXhfc2hhcmRzX3Blcl9ub2RlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNjbHVzdGVyX21heF9zaGFyZHNfcGVyX25vZGV9XG4gICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNjbHVzdGVyX3JvdXRpbmdfYWxsb2NhdGlvbl9ub2RlX2NvbmN1cnJlbnRfcmVjb3ZlcmllcyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjY2x1c3Rlcl9yb3V0aW5nX2FsbG9jYXRpb25fbm9kZV9jb25jdXJyZW50X3JlY292ZXJpZXN9XG4gICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3Zlcmllcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjZW5hYmxlX3NlY3VyaXR5X2F1ZGl0IERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNlbmFibGVfc2VjdXJpdHlfYXVkaXR9XG4gICovXG4gIHJlYWRvbmx5IGVuYWJsZVNlY3VyaXR5QXVkaXQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2h0dHBfbWF4X2NvbnRlbnRfbGVuZ3RoX2J5dGVzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNodHRwX21heF9jb250ZW50X2xlbmd0aF9ieXRlc31cbiAgKi9cbiAgcmVhZG9ubHkgaHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaHR0cF9tYXhfaGVhZGVyX3NpemVfYnl0ZXMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2h0dHBfbWF4X2hlYWRlcl9zaXplX2J5dGVzfVxuICAqL1xuICByZWFkb25seSBodHRwTWF4SGVhZGVyU2l6ZUJ5dGVzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNodHRwX21heF9pbml0aWFsX2xpbmVfbGVuZ3RoX2J5dGVzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNodHRwX21heF9pbml0aWFsX2xpbmVfbGVuZ3RoX2J5dGVzfVxuICAqL1xuICByZWFkb25seSBodHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaWQgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2lkfVxuICAqXG4gICogUGxlYXNlIGJlIGF3YXJlIHRoYXQgdGhlIGlkIGZpZWxkIGlzIGF1dG9tYXRpY2FsbHkgYWRkZWQgdG8gYWxsIHJlc291cmNlcyBpbiBUZXJyYWZvcm0gcHJvdmlkZXJzIHVzaW5nIGEgVGVycmFmb3JtIHByb3ZpZGVyIFNESyB2ZXJzaW9uIGJlbG93IDIuXG4gICogSWYgeW91IGV4cGVyaWVuY2UgcHJvYmxlbXMgc2V0dGluZyB0aGlzIHZhbHVlIGl0IG1pZ2h0IG5vdCBiZSBzZXR0YWJsZS4gUGxlYXNlIHRha2UgYSBsb29rIGF0IHRoZSBwcm92aWRlciBkb2N1bWVudGF0aW9uIHRvIGVuc3VyZSBpdCBzaG91bGQgYmUgc2V0dGFibGUuXG4gICovXG4gIHJlYWRvbmx5IGlkPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX2ZpZWxkZGF0YV9jYWNoZV9zaXplX3BlcmNlbnRhZ2UgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2luZGljZXNfZmllbGRkYXRhX2NhY2hlX3NpemVfcGVyY2VudGFnZX1cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2U/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2luZGljZXNfbWVtb3J5X2luZGV4X2J1ZmZlcl9zaXplX3BlcmNlbnRhZ2UgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2luZGljZXNfbWVtb3J5X2luZGV4X2J1ZmZlcl9zaXplX3BlcmNlbnRhZ2V9XG4gICovXG4gIHJlYWRvbmx5IGluZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX21lbW9yeV9tYXhfaW5kZXhfYnVmZmVyX3NpemVfbWIgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2luZGljZXNfbWVtb3J5X21heF9pbmRleF9idWZmZXJfc2l6ZV9tYn1cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX21lbW9yeV9taW5faW5kZXhfYnVmZmVyX3NpemVfbWIgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2luZGljZXNfbWVtb3J5X21pbl9pbmRleF9idWZmZXJfc2l6ZV9tYn1cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX3F1ZXJpZXNfY2FjaGVfc2l6ZV9wZXJjZW50YWdlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX3F1ZXJpZXNfY2FjaGVfc2l6ZV9wZXJjZW50YWdlfVxuICAqL1xuICByZWFkb25seSBpbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2U/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2luZGljZXNfcXVlcnlfYm9vbF9tYXhfY2xhdXNlX2NvdW50IERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX3F1ZXJ5X2Jvb2xfbWF4X2NsYXVzZV9jb3VudH1cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbmRpY2VzX3JlY292ZXJ5X21heF9jb25jdXJyZW50X2ZpbGVfY2h1bmtzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpbmRpY2VzX3JlY292ZXJ5X21heF9jb25jdXJyZW50X2ZpbGVfY2h1bmtzfVxuICAqL1xuICByZWFkb25seSBpbmRpY2VzUmVjb3ZlcnlNYXhDb25jdXJyZW50RmlsZUNodW5rcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaW5kaWNlc19yZWNvdmVyeV9tYXhfbWJfcGVyX3NlYyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaW5kaWNlc19yZWNvdmVyeV9tYXhfbWJfcGVyX3NlY31cbiAgKi9cbiAgcmVhZG9ubHkgaW5kaWNlc1JlY292ZXJ5TWF4TWJQZXJTZWM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lzbV9lbmFibGVkIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpc21fZW5hYmxlZH1cbiAgKi9cbiAgcmVhZG9ubHkgaXNtRW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaXNtX2hpc3RvcnlfZW5hYmxlZCBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaXNtX2hpc3RvcnlfZW5hYmxlZH1cbiAgKi9cbiAgcmVhZG9ubHkgaXNtSGlzdG9yeUVuYWJsZWQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lzbV9oaXN0b3J5X21heF9hZ2VfaG91cnMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2lzbV9oaXN0b3J5X21heF9hZ2VfaG91cnN9XG4gICovXG4gIHJlYWRvbmx5IGlzbUhpc3RvcnlNYXhBZ2VIb3Vycz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaXNtX2hpc3RvcnlfbWF4X2RvY3MgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI2lzbV9oaXN0b3J5X21heF9kb2NzfVxuICAqL1xuICByZWFkb25seSBpc21IaXN0b3J5TWF4RG9jcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjaXNtX2hpc3Rvcnlfcm9sbG92ZXJfY2hlY2tfcGVyaW9kX2hvdXJzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNpc21faGlzdG9yeV9yb2xsb3Zlcl9jaGVja19wZXJpb2RfaG91cnN9XG4gICovXG4gIHJlYWRvbmx5IGlzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI2lzbV9oaXN0b3J5X3JvbGxvdmVyX3JldGVudGlvbl9wZXJpb2RfZGF5cyBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjaXNtX2hpc3Rvcnlfcm9sbG92ZXJfcmV0ZW50aW9uX3BlcmlvZF9kYXlzfVxuICAqL1xuICByZWFkb25seSBpc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNvdmVycmlkZV9tYWluX3Jlc3BvbnNlX3ZlcnNpb24gRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI292ZXJyaWRlX21haW5fcmVzcG9uc2VfdmVyc2lvbn1cbiAgKi9cbiAgcmVhZG9ubHkgb3ZlcnJpZGVNYWluUmVzcG9uc2VWZXJzaW9uPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNwbHVnaW5zX2FsZXJ0aW5nX2ZpbHRlcl9ieV9iYWNrZW5kX3JvbGVzX2VuYWJsZWQgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3BsdWdpbnNfYWxlcnRpbmdfZmlsdGVyX2J5X2JhY2tlbmRfcm9sZXNfZW5hYmxlZH1cbiAgKi9cbiAgcmVhZG9ubHkgcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNyZWluZGV4X3JlbW90ZV93aGl0ZWxpc3QgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3JlaW5kZXhfcmVtb3RlX3doaXRlbGlzdH1cbiAgKi9cbiAgcmVhZG9ubHkgcmVpbmRleFJlbW90ZVdoaXRlbGlzdD86IHN0cmluZ1tdO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNzY3JpcHRfbWF4X2NvbXBpbGF0aW9uc19yYXRlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyNzY3JpcHRfbWF4X2NvbXBpbGF0aW9uc19yYXRlfVxuICAqL1xuICByZWFkb25seSBzY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNzZWFyY2hfbWF4X2J1Y2tldHMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3NlYXJjaF9tYXhfYnVja2V0c31cbiAgKi9cbiAgcmVhZG9ubHkgc2VhcmNoTWF4QnVja2V0cz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfYW5hbHl6ZV9xdWV1ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9hbmFseXplX3F1ZXVlX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xBbmFseXplUXVldWVTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF9hbmFseXplX3NpemUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3RocmVhZF9wb29sX2FuYWx5emVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbEFuYWx5emVTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF9mb3JjZV9tZXJnZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9mb3JjZV9tZXJnZV9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sRm9yY2VNZXJnZVNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI3RocmVhZF9wb29sX2dldF9xdWV1ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9nZXRfcXVldWVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfZ2V0X3NpemUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3RocmVhZF9wb29sX2dldF9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sR2V0U2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfc2VhcmNoX3F1ZXVlX3NpemUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3RocmVhZF9wb29sX3NlYXJjaF9xdWV1ZV9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sU2VhcmNoUXVldWVTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF9zZWFyY2hfc2l6ZSBEYXRhYmFzZU9wZW5zZWFyY2hDb25maWcjdGhyZWFkX3Bvb2xfc2VhcmNoX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xTZWFyY2hTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3F1ZXVlX3NpemUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3RocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfcXVldWVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWcjdGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyN0aHJlYWRfcG9vbF93cml0ZV9xdWV1ZV9zaXplIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyN0aHJlYWRfcG9vbF93cml0ZV9xdWV1ZV9zaXplfVxuICAqL1xuICByZWFkb25seSB0aHJlYWRQb29sV3JpdGVRdWV1ZVNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnI3RocmVhZF9wb29sX3dyaXRlX3NpemUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnI3RocmVhZF9wb29sX3dyaXRlX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHRocmVhZFBvb2xXcml0ZVNpemU/OiBudW1iZXI7XG59XG5cbi8qKlxuKiBSZXByZXNlbnRzIGEge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWd9XG4qL1xuZXhwb3J0IGNsYXNzIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyBleHRlbmRzIGNka3RuLlRlcnJhZm9ybVJlc291cmNlIHtcblxuICAvLyA9PT09PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgUFJPUEVSVElFU1xuICAvLyA9PT09PT09PT09PT09PT09PVxuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IHRmUmVzb3VyY2VUeXBlID0gXCJkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfb3BlbnNlYXJjaF9jb25maWdcIjtcblxuICAvLyA9PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgTWV0aG9kc1xuICAvLyA9PT09PT09PT09PT09PVxuICAvKipcbiAgKiBHZW5lcmF0ZXMgQ0RLVE4gY29kZSBmb3IgaW1wb3J0aW5nIGEgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnIHJlc291cmNlIHVwb24gcnVubmluZyBcImNka3RuIHBsYW4gPHN0YWNrLW5hbWU+XCJcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpbXBvcnRUb0lkIFRoZSBjb25zdHJ1Y3QgaWQgdXNlZCBpbiB0aGUgZ2VuZXJhdGVkIGNvbmZpZyBmb3IgdGhlIERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZyB0byBpbXBvcnRcbiAgKiBAcGFyYW0gaW1wb3J0RnJvbUlkIFRoZSBpZCBvZiB0aGUgZXhpc3RpbmcgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnIHRoYXQgc2hvdWxkIGJlIGltcG9ydGVkLiBSZWZlciB0byB0aGUge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZyNpbXBvcnQgaW1wb3J0IHNlY3Rpb259IGluIHRoZSBkb2N1bWVudGF0aW9uIG9mIHRoaXMgcmVzb3VyY2UgZm9yIHRoZSBpZCB0byB1c2VcbiAgKiBAcGFyYW0gcHJvdmlkZXI/IE9wdGlvbmFsIGluc3RhbmNlIG9mIHRoZSBwcm92aWRlciB3aGVyZSB0aGUgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnIHRvIGltcG9ydCBpcyBmb3VuZFxuICAqL1xuICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQ29uZmlnRm9ySW1wb3J0KHNjb3BlOiBDb25zdHJ1Y3QsIGltcG9ydFRvSWQ6IHN0cmluZywgaW1wb3J0RnJvbUlkOiBzdHJpbmcsIHByb3ZpZGVyPzogY2RrdG4uVGVycmFmb3JtUHJvdmlkZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBjZGt0bi5JbXBvcnRhYmxlUmVzb3VyY2Uoc2NvcGUsIGltcG9ydFRvSWQsIHsgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZ1wiLCBpbXBvcnRJZDogaW1wb3J0RnJvbUlkLCBwcm92aWRlciB9KTtcbiAgICAgIH1cblxuICAvLyA9PT09PT09PT09PVxuICAvLyBJTklUSUFMSVpFUlxuICAvLyA9PT09PT09PT09PVxuXG4gIC8qKlxuICAqIENyZWF0ZSBhIG5ldyB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnIGRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9vcGVuc2VhcmNoX2NvbmZpZ30gUmVzb3VyY2VcbiAgKlxuICAqIEBwYXJhbSBzY29wZSBUaGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgY29uc3RydWN0XG4gICogQHBhcmFtIGlkIFRoZSBzY29wZWQgY29uc3RydWN0IElELiBNdXN0IGJlIHVuaXF1ZSBhbW9uZ3N0IHNpYmxpbmdzIGluIHRoZSBzYW1lIHNjb3BlXG4gICogQHBhcmFtIG9wdGlvbnMgRGF0YWJhc2VPcGVuc2VhcmNoQ29uZmlnQ29uZmlnXG4gICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBjb25maWc6IERhdGFiYXNlT3BlbnNlYXJjaENvbmZpZ0NvbmZpZykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiAnZGlnaXRhbG9jZWFuX2RhdGFiYXNlX29wZW5zZWFyY2hfY29uZmlnJyxcbiAgICAgIHRlcnJhZm9ybUdlbmVyYXRvck1ldGFkYXRhOiB7XG4gICAgICAgIHByb3ZpZGVyTmFtZTogJ2RpZ2l0YWxvY2VhbicsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbjogJzIuODcuMCcsXG4gICAgICAgIHByb3ZpZGVyVmVyc2lvbkNvbnN0cmFpbnQ6ICcyLjg3LjAnXG4gICAgICB9LFxuICAgICAgcHJvdmlkZXI6IGNvbmZpZy5wcm92aWRlcixcbiAgICAgIGRlcGVuZHNPbjogY29uZmlnLmRlcGVuZHNPbixcbiAgICAgIGNvdW50OiBjb25maWcuY291bnQsXG4gICAgICBsaWZlY3ljbGU6IGNvbmZpZy5saWZlY3ljbGUsXG4gICAgICBwcm92aXNpb25lcnM6IGNvbmZpZy5wcm92aXNpb25lcnMsXG4gICAgICBjb25uZWN0aW9uOiBjb25maWcuY29ubmVjdGlvbixcbiAgICAgIGZvckVhY2g6IGNvbmZpZy5mb3JFYWNoXG4gICAgfSk7XG4gICAgdGhpcy5fYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCA9IGNvbmZpZy5hY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkO1xuICAgIHRoaXMuX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lID0gY29uZmlnLmFjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lO1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IGNvbmZpZy5jbHVzdGVySWQ7XG4gICAgdGhpcy5fY2x1c3Rlck1heFNoYXJkc1Blck5vZGUgPSBjb25maWcuY2x1c3Rlck1heFNoYXJkc1Blck5vZGU7XG4gICAgdGhpcy5fY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzID0gY29uZmlnLmNsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3ZlcmllcztcbiAgICB0aGlzLl9lbmFibGVTZWN1cml0eUF1ZGl0ID0gY29uZmlnLmVuYWJsZVNlY3VyaXR5QXVkaXQ7XG4gICAgdGhpcy5faHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcyA9IGNvbmZpZy5odHRwTWF4Q29udGVudExlbmd0aEJ5dGVzO1xuICAgIHRoaXMuX2h0dHBNYXhIZWFkZXJTaXplQnl0ZXMgPSBjb25maWcuaHR0cE1heEhlYWRlclNpemVCeXRlcztcbiAgICB0aGlzLl9odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcyA9IGNvbmZpZy5odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcztcbiAgICB0aGlzLl9pZCA9IGNvbmZpZy5pZDtcbiAgICB0aGlzLl9pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZSA9IGNvbmZpZy5pbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZTtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSA9IGNvbmZpZy5pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZTtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWIgPSBjb25maWcuaW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iO1xuICAgIHRoaXMuX2luZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYiA9IGNvbmZpZy5pbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWI7XG4gICAgdGhpcy5faW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlID0gY29uZmlnLmluZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZTtcbiAgICB0aGlzLl9pbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQgPSBjb25maWcuaW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50O1xuICAgIHRoaXMuX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzID0gY29uZmlnLmluZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzO1xuICAgIHRoaXMuX2luZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjID0gY29uZmlnLmluZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjO1xuICAgIHRoaXMuX2lzbUVuYWJsZWQgPSBjb25maWcuaXNtRW5hYmxlZDtcbiAgICB0aGlzLl9pc21IaXN0b3J5RW5hYmxlZCA9IGNvbmZpZy5pc21IaXN0b3J5RW5hYmxlZDtcbiAgICB0aGlzLl9pc21IaXN0b3J5TWF4QWdlSG91cnMgPSBjb25maWcuaXNtSGlzdG9yeU1heEFnZUhvdXJzO1xuICAgIHRoaXMuX2lzbUhpc3RvcnlNYXhEb2NzID0gY29uZmlnLmlzbUhpc3RvcnlNYXhEb2NzO1xuICAgIHRoaXMuX2lzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnMgPSBjb25maWcuaXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3VycztcbiAgICB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzID0gY29uZmlnLmlzbUhpc3RvcnlSb2xsb3ZlclJldGVudGlvblBlcmlvZERheXM7XG4gICAgdGhpcy5fb3ZlcnJpZGVNYWluUmVzcG9uc2VWZXJzaW9uID0gY29uZmlnLm92ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbjtcbiAgICB0aGlzLl9wbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWQgPSBjb25maWcucGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkO1xuICAgIHRoaXMuX3JlaW5kZXhSZW1vdGVXaGl0ZWxpc3QgPSBjb25maWcucmVpbmRleFJlbW90ZVdoaXRlbGlzdDtcbiAgICB0aGlzLl9zY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlID0gY29uZmlnLnNjcmlwdE1heENvbXBpbGF0aW9uc1JhdGU7XG4gICAgdGhpcy5fc2VhcmNoTWF4QnVja2V0cyA9IGNvbmZpZy5zZWFyY2hNYXhCdWNrZXRzO1xuICAgIHRoaXMuX3RocmVhZFBvb2xBbmFseXplUXVldWVTaXplID0gY29uZmlnLnRocmVhZFBvb2xBbmFseXplUXVldWVTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xBbmFseXplU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sQW5hbHl6ZVNpemU7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplID0gY29uZmlnLnRocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sR2V0UXVldWVTaXplID0gY29uZmlnLnRocmVhZFBvb2xHZXRRdWV1ZVNpemU7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEdldFNpemUgPSBjb25maWcudGhyZWFkUG9vbEdldFNpemU7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sU2VhcmNoUXVldWVTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hTaXplID0gY29uZmlnLnRocmVhZFBvb2xTZWFyY2hTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUgPSBjb25maWcudGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZSA9IGNvbmZpZy50aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZTtcbiAgICB0aGlzLl90aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUgPSBjb25maWcudGhyZWFkUG9vbFdyaXRlUXVldWVTaXplO1xuICAgIHRoaXMuX3RocmVhZFBvb2xXcml0ZVNpemUgPSBjb25maWcudGhyZWFkUG9vbFdyaXRlU2l6ZTtcbiAgfVxuXG4gIC8vID09PT09PT09PT1cbiAgLy8gQVRUUklCVVRFU1xuICAvLyA9PT09PT09PT09XG5cbiAgLy8gYWN0aW9uX2F1dG9fY3JlYXRlX2luZGV4X2VuYWJsZWQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBhY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2FjdGlvbl9hdXRvX2NyZWF0ZV9pbmRleF9lbmFibGVkJyk7XG4gIH1cbiAgcHVibGljIHNldCBhY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9hY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCgpIHtcbiAgICB0aGlzLl9hY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FjdGlvbkF1dG9DcmVhdGVJbmRleEVuYWJsZWQ7XG4gIH1cblxuICAvLyBhY3Rpb25fZGVzdHJ1Y3RpdmVfcmVxdWlyZXNfbmFtZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBhY3Rpb25EZXN0cnVjdGl2ZVJlcXVpcmVzTmFtZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdhY3Rpb25fZGVzdHJ1Y3RpdmVfcmVxdWlyZXNfbmFtZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgYWN0aW9uRGVzdHJ1Y3RpdmVSZXF1aXJlc05hbWUodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QWN0aW9uRGVzdHJ1Y3RpdmVSZXF1aXJlc05hbWUoKSB7XG4gICAgdGhpcy5fYWN0aW9uRGVzdHJ1Y3RpdmVSZXF1aXJlc05hbWUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGFjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lO1xuICB9XG5cbiAgLy8gY2x1c3Rlcl9pZCAtIGNvbXB1dGVkOiBmYWxzZSwgb3B0aW9uYWw6IGZhbHNlLCByZXF1aXJlZDogdHJ1ZVxuICBwcml2YXRlIF9jbHVzdGVySWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJJZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2NsdXN0ZXJfaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGNsdXN0ZXJJZCh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fY2x1c3RlcklkID0gdmFsdWU7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGNsdXN0ZXJJZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9jbHVzdGVySWQ7XG4gIH1cblxuICAvLyBjbHVzdGVyX21heF9zaGFyZHNfcGVyX25vZGUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9jbHVzdGVyTWF4U2hhcmRzUGVyTm9kZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgY2x1c3Rlck1heFNoYXJkc1Blck5vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdjbHVzdGVyX21heF9zaGFyZHNfcGVyX25vZGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGNsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9jbHVzdGVyTWF4U2hhcmRzUGVyTm9kZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldENsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlKCkge1xuICAgIHRoaXMuX2NsdXN0ZXJNYXhTaGFyZHNQZXJOb2RlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVyTWF4U2hhcmRzUGVyTm9kZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9jbHVzdGVyTWF4U2hhcmRzUGVyTm9kZTtcbiAgfVxuXG4gIC8vIGNsdXN0ZXJfcm91dGluZ19hbGxvY2F0aW9uX25vZGVfY29uY3VycmVudF9yZWNvdmVyaWVzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBjbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdjbHVzdGVyX3JvdXRpbmdfYWxsb2NhdGlvbl9ub2RlX2NvbmN1cnJlbnRfcmVjb3ZlcmllcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9jbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRDbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXMoKSB7XG4gICAgdGhpcy5fY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVyUm91dGluZ0FsbG9jYXRpb25Ob2RlQ29uY3VycmVudFJlY292ZXJpZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzO1xuICB9XG5cbiAgLy8gZW5hYmxlX3NlY3VyaXR5X2F1ZGl0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZW5hYmxlU2VjdXJpdHlBdWRpdD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgZW5hYmxlU2VjdXJpdHlBdWRpdCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdlbmFibGVfc2VjdXJpdHlfYXVkaXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGVuYWJsZVNlY3VyaXR5QXVkaXQodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2VuYWJsZVNlY3VyaXR5QXVkaXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRFbmFibGVTZWN1cml0eUF1ZGl0KCkge1xuICAgIHRoaXMuX2VuYWJsZVNlY3VyaXR5QXVkaXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGVuYWJsZVNlY3VyaXR5QXVkaXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZW5hYmxlU2VjdXJpdHlBdWRpdDtcbiAgfVxuXG4gIC8vIGh0dHBfbWF4X2NvbnRlbnRfbGVuZ3RoX2J5dGVzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2h0dHBfbWF4X2NvbnRlbnRfbGVuZ3RoX2J5dGVzJyk7XG4gIH1cbiAgcHVibGljIHNldCBodHRwTWF4Q29udGVudExlbmd0aEJ5dGVzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9odHRwTWF4Q29udGVudExlbmd0aEJ5dGVzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcygpIHtcbiAgICB0aGlzLl9odHRwTWF4Q29udGVudExlbmd0aEJ5dGVzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBodHRwTWF4Q29udGVudExlbmd0aEJ5dGVzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2h0dHBNYXhDb250ZW50TGVuZ3RoQnl0ZXM7XG4gIH1cblxuICAvLyBodHRwX21heF9oZWFkZXJfc2l6ZV9ieXRlcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2h0dHBNYXhIZWFkZXJTaXplQnl0ZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGh0dHBNYXhIZWFkZXJTaXplQnl0ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdodHRwX21heF9oZWFkZXJfc2l6ZV9ieXRlcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaHR0cE1heEhlYWRlclNpemVCeXRlcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faHR0cE1heEhlYWRlclNpemVCeXRlcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEh0dHBNYXhIZWFkZXJTaXplQnl0ZXMoKSB7XG4gICAgdGhpcy5faHR0cE1heEhlYWRlclNpemVCeXRlcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaHR0cE1heEhlYWRlclNpemVCeXRlc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9odHRwTWF4SGVhZGVyU2l6ZUJ5dGVzO1xuICB9XG5cbiAgLy8gaHR0cF9tYXhfaW5pdGlhbF9saW5lX2xlbmd0aF9ieXRlcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2h0dHBNYXhJbml0aWFsTGluZUxlbmd0aEJ5dGVzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBodHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2h0dHBfbWF4X2luaXRpYWxfbGluZV9sZW5ndGhfYnl0ZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGh0dHBNYXhJbml0aWFsTGluZUxlbmd0aEJ5dGVzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEh0dHBNYXhJbml0aWFsTGluZUxlbmd0aEJ5dGVzKCkge1xuICAgIHRoaXMuX2h0dHBNYXhJbml0aWFsTGluZUxlbmd0aEJ5dGVzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBodHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9odHRwTWF4SW5pdGlhbExpbmVMZW5ndGhCeXRlcztcbiAgfVxuXG4gIC8vIGlkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGlkKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlkKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9pZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElkKCkge1xuICAgIHRoaXMuX2lkID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pZDtcbiAgfVxuXG4gIC8vIGluZGljZXNfZmllbGRkYXRhX2NhY2hlX3NpemVfcGVyY2VudGFnZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2luZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmRpY2VzRmllbGRkYXRhQ2FjaGVTaXplUGVyY2VudGFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfZmllbGRkYXRhX2NhY2hlX3NpemVfcGVyY2VudGFnZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2luZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2UoKSB7XG4gICAgdGhpcy5faW5kaWNlc0ZpZWxkZGF0YUNhY2hlU2l6ZVBlcmNlbnRhZ2UgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGluZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2luZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlO1xuICB9XG5cbiAgLy8gaW5kaWNlc19tZW1vcnlfaW5kZXhfYnVmZmVyX3NpemVfcGVyY2VudGFnZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2luZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfbWVtb3J5X2luZGV4X2J1ZmZlcl9zaXplX3BlcmNlbnRhZ2UnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlKCkge1xuICAgIHRoaXMuX2luZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRpY2VzTWVtb3J5SW5kZXhCdWZmZXJTaXplUGVyY2VudGFnZTtcbiAgfVxuXG4gIC8vIGluZGljZXNfbWVtb3J5X21heF9pbmRleF9idWZmZXJfc2l6ZV9tYiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2luZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5kaWNlc19tZW1vcnlfbWF4X2luZGV4X2J1ZmZlcl9zaXplX21iJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWIodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2luZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYigpIHtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWIgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGluZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRpY2VzTWVtb3J5TWF4SW5kZXhCdWZmZXJTaXplTWI7XG4gIH1cblxuICAvLyBpbmRpY2VzX21lbW9yeV9taW5faW5kZXhfYnVmZmVyX3NpemVfbWIgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWI/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGluZGljZXNNZW1vcnlNaW5JbmRleEJ1ZmZlclNpemVNYigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfbWVtb3J5X21pbl9pbmRleF9idWZmZXJfc2l6ZV9tYicpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWIgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWIoKSB7XG4gICAgdGhpcy5faW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzTWVtb3J5TWluSW5kZXhCdWZmZXJTaXplTWJJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iO1xuICB9XG5cbiAgLy8gaW5kaWNlc19xdWVyaWVzX2NhY2hlX3NpemVfcGVyY2VudGFnZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2luZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5kaWNlc19xdWVyaWVzX2NhY2hlX3NpemVfcGVyY2VudGFnZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2UgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2UoKSB7XG4gICAgdGhpcy5faW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzUXVlcmllc0NhY2hlU2l6ZVBlcmNlbnRhZ2VJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlO1xuICB9XG5cbiAgLy8gaW5kaWNlc19xdWVyeV9ib29sX21heF9jbGF1c2VfY291bnQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGluZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfcXVlcnlfYm9vbF9tYXhfY2xhdXNlX2NvdW50Jyk7XG4gIH1cbiAgcHVibGljIHNldCBpbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2luZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudCgpIHtcbiAgICB0aGlzLl9pbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGluZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRpY2VzUXVlcnlCb29sTWF4Q2xhdXNlQ291bnQ7XG4gIH1cblxuICAvLyBpbmRpY2VzX3JlY292ZXJ5X21heF9jb25jdXJyZW50X2ZpbGVfY2h1bmtzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5kaWNlc1JlY292ZXJ5TWF4Q29uY3VycmVudEZpbGVDaHVua3M/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGluZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5kaWNlc19yZWNvdmVyeV9tYXhfY29uY3VycmVudF9maWxlX2NodW5rcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5kaWNlc1JlY292ZXJ5TWF4Q29uY3VycmVudEZpbGVDaHVua3ModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5kaWNlc1JlY292ZXJ5TWF4Q29uY3VycmVudEZpbGVDaHVua3MoKSB7XG4gICAgdGhpcy5faW5kaWNlc1JlY292ZXJ5TWF4Q29uY3VycmVudEZpbGVDaHVua3MgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGluZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzO1xuICB9XG5cbiAgLy8gaW5kaWNlc19yZWNvdmVyeV9tYXhfbWJfcGVyX3NlYyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2luZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2luZGljZXNfcmVjb3ZlcnlfbWF4X21iX3Blcl9zZWMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGluZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjKCkge1xuICAgIHRoaXMuX2luZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlY0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRpY2VzUmVjb3ZlcnlNYXhNYlBlclNlYztcbiAgfVxuXG4gIC8vIGlzbV9lbmFibGVkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaXNtRW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgaXNtRW5hYmxlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdpc21fZW5hYmxlZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaXNtRW5hYmxlZCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5faXNtRW5hYmxlZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElzbUVuYWJsZWQoKSB7XG4gICAgdGhpcy5faXNtRW5hYmxlZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaXNtRW5hYmxlZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pc21FbmFibGVkO1xuICB9XG5cbiAgLy8gaXNtX2hpc3RvcnlfZW5hYmxlZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lzbUhpc3RvcnlFbmFibGVkPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBpc21IaXN0b3J5RW5hYmxlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdpc21faGlzdG9yeV9lbmFibGVkJyk7XG4gIH1cbiAgcHVibGljIHNldCBpc21IaXN0b3J5RW5hYmxlZCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeUVuYWJsZWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJc21IaXN0b3J5RW5hYmxlZCgpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5RW5hYmxlZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeUVuYWJsZWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faXNtSGlzdG9yeUVuYWJsZWQ7XG4gIH1cblxuICAvLyBpc21faGlzdG9yeV9tYXhfYWdlX2hvdXJzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaXNtSGlzdG9yeU1heEFnZUhvdXJzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpc21IaXN0b3J5TWF4QWdlSG91cnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpc21faGlzdG9yeV9tYXhfYWdlX2hvdXJzJyk7XG4gIH1cbiAgcHVibGljIHNldCBpc21IaXN0b3J5TWF4QWdlSG91cnModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2lzbUhpc3RvcnlNYXhBZ2VIb3VycyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElzbUhpc3RvcnlNYXhBZ2VIb3VycygpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5TWF4QWdlSG91cnMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlzbUhpc3RvcnlNYXhBZ2VIb3Vyc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pc21IaXN0b3J5TWF4QWdlSG91cnM7XG4gIH1cblxuICAvLyBpc21faGlzdG9yeV9tYXhfZG9jcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lzbUhpc3RvcnlNYXhEb2NzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpc21IaXN0b3J5TWF4RG9jcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lzbV9oaXN0b3J5X21heF9kb2NzJyk7XG4gIH1cbiAgcHVibGljIHNldCBpc21IaXN0b3J5TWF4RG9jcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faXNtSGlzdG9yeU1heERvY3MgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJc21IaXN0b3J5TWF4RG9jcygpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5TWF4RG9jcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaXNtSGlzdG9yeU1heERvY3NJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faXNtSGlzdG9yeU1heERvY3M7XG4gIH1cblxuICAvLyBpc21faGlzdG9yeV9yb2xsb3Zlcl9jaGVja19wZXJpb2RfaG91cnMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaXNtX2hpc3Rvcnlfcm9sbG92ZXJfY2hlY2tfcGVyaW9kX2hvdXJzJyk7XG4gIH1cbiAgcHVibGljIHNldCBpc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3VycygpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpc21IaXN0b3J5Um9sbG92ZXJDaGVja1BlcmlvZEhvdXJzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnM7XG4gIH1cblxuICAvLyBpc21faGlzdG9yeV9yb2xsb3Zlcl9yZXRlbnRpb25fcGVyaW9kX2RheXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaXNtX2hpc3Rvcnlfcm9sbG92ZXJfcmV0ZW50aW9uX3BlcmlvZF9kYXlzJyk7XG4gIH1cbiAgcHVibGljIHNldCBpc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cygpIHtcbiAgICB0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lzbUhpc3RvcnlSb2xsb3ZlclJldGVudGlvblBlcmlvZERheXM7XG4gIH1cblxuICAvLyBvdmVycmlkZV9tYWluX3Jlc3BvbnNlX3ZlcnNpb24gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9vdmVycmlkZU1haW5SZXNwb25zZVZlcnNpb24/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IG92ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdvdmVycmlkZV9tYWluX3Jlc3BvbnNlX3ZlcnNpb24nKTtcbiAgfVxuICBwdWJsaWMgc2V0IG92ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbih2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fb3ZlcnJpZGVNYWluUmVzcG9uc2VWZXJzaW9uID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0T3ZlcnJpZGVNYWluUmVzcG9uc2VWZXJzaW9uKCkge1xuICAgIHRoaXMuX292ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgb3ZlcnJpZGVNYWluUmVzcG9uc2VWZXJzaW9uSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX292ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbjtcbiAgfVxuXG4gIC8vIHBsdWdpbnNfYWxlcnRpbmdfZmlsdGVyX2J5X2JhY2tlbmRfcm9sZXNfZW5hYmxlZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3BsdWdpbnNBbGVydGluZ0ZpbHRlckJ5QmFja2VuZFJvbGVzRW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ3BsdWdpbnNfYWxlcnRpbmdfZmlsdGVyX2J5X2JhY2tlbmRfcm9sZXNfZW5hYmxlZCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9wbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWQoKSB7XG4gICAgdGhpcy5fcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBwbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGx1Z2luc0FsZXJ0aW5nRmlsdGVyQnlCYWNrZW5kUm9sZXNFbmFibGVkO1xuICB9XG5cbiAgLy8gcmVpbmRleF9yZW1vdGVfd2hpdGVsaXN0IC0gY29tcHV0ZWQ6IGZhbHNlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3JlaW5kZXhSZW1vdGVXaGl0ZWxpc3Q/OiBzdHJpbmdbXTsgXG4gIHB1YmxpYyBnZXQgcmVpbmRleFJlbW90ZVdoaXRlbGlzdCgpIHtcbiAgICByZXR1cm4gY2RrdG4uRm4udG9saXN0KHRoaXMuZ2V0TGlzdEF0dHJpYnV0ZSgncmVpbmRleF9yZW1vdGVfd2hpdGVsaXN0JykpO1xuICB9XG4gIHB1YmxpYyBzZXQgcmVpbmRleFJlbW90ZVdoaXRlbGlzdCh2YWx1ZTogc3RyaW5nW10pIHtcbiAgICB0aGlzLl9yZWluZGV4UmVtb3RlV2hpdGVsaXN0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0UmVpbmRleFJlbW90ZVdoaXRlbGlzdCgpIHtcbiAgICB0aGlzLl9yZWluZGV4UmVtb3RlV2hpdGVsaXN0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCByZWluZGV4UmVtb3RlV2hpdGVsaXN0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlaW5kZXhSZW1vdGVXaGl0ZWxpc3Q7XG4gIH1cblxuICAvLyBzY3JpcHRfbWF4X2NvbXBpbGF0aW9uc19yYXRlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3NjcmlwdF9tYXhfY29tcGlsYXRpb25zX3JhdGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNjcmlwdE1heENvbXBpbGF0aW9uc1JhdGUodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3NjcmlwdE1heENvbXBpbGF0aW9uc1JhdGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlKCkge1xuICAgIHRoaXMuX3NjcmlwdE1heENvbXBpbGF0aW9uc1JhdGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNjcmlwdE1heENvbXBpbGF0aW9uc1JhdGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc2NyaXB0TWF4Q29tcGlsYXRpb25zUmF0ZTtcbiAgfVxuXG4gIC8vIHNlYXJjaF9tYXhfYnVja2V0cyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3NlYXJjaE1heEJ1Y2tldHM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHNlYXJjaE1heEJ1Y2tldHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdzZWFyY2hfbWF4X2J1Y2tldHMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNlYXJjaE1heEJ1Y2tldHModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3NlYXJjaE1heEJ1Y2tldHMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTZWFyY2hNYXhCdWNrZXRzKCkge1xuICAgIHRoaXMuX3NlYXJjaE1heEJ1Y2tldHMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNlYXJjaE1heEJ1Y2tldHNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc2VhcmNoTWF4QnVja2V0cztcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX2FuYWx5emVfcXVldWVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xBbmFseXplUXVldWVTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX2FuYWx5emVfcXVldWVfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbEFuYWx5emVRdWV1ZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xBbmFseXplUXVldWVTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbEFuYWx5emVRdWV1ZVNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEFuYWx5emVRdWV1ZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xBbmFseXplUXVldWVTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xBbmFseXplUXVldWVTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfYW5hbHl6ZV9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbEFuYWx5emVTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sQW5hbHl6ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9hbmFseXplX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xBbmFseXplU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEFuYWx5emVTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbEFuYWx5emVTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xBbmFseXplU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEFuYWx5emVTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xBbmFseXplU2l6ZTtcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX2ZvcmNlX21lcmdlX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aHJlYWRQb29sRm9yY2VNZXJnZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX2ZvcmNlX21lcmdlX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZTtcbiAgfVxuXG4gIC8vIHRocmVhZF9wb29sX2dldF9xdWV1ZV9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX2dldF9xdWV1ZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sR2V0UXVldWVTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sR2V0UXVldWVTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sR2V0UXVldWVTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCB0aHJlYWRQb29sR2V0UXVldWVTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xHZXRRdWV1ZVNpemU7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF9nZXRfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xHZXRTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sR2V0U2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX2dldF9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sR2V0U2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbEdldFNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaHJlYWRQb29sR2V0U2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sR2V0U2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbEdldFNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGhyZWFkUG9vbEdldFNpemU7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF9zZWFyY2hfcXVldWVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9zZWFyY2hfcXVldWVfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sU2VhcmNoUXVldWVTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfc2VhcmNoX3NpemUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF90aHJlYWRQb29sU2VhcmNoU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFNlYXJjaFNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF9zZWFyY2hfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbFNlYXJjaFNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VGhyZWFkUG9vbFNlYXJjaFNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RocmVhZFBvb2xTZWFyY2hTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9xdWV1ZV9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfcXVldWVfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRRdWV1ZVNpemUoKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkUXVldWVTaXplO1xuICB9XG5cbiAgLy8gdGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndGhyZWFkX3Bvb2xfc2VhcmNoX3Rocm90dGxlZF9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sU2VhcmNoVGhyb3R0bGVkU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemU7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF93cml0ZV9xdWV1ZV9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbFdyaXRlUXVldWVTaXplPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB0aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCd0aHJlYWRfcG9vbF93cml0ZV9xdWV1ZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCB0aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xXcml0ZVF1ZXVlU2l6ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFRocmVhZFBvb2xXcml0ZVF1ZXVlU2l6ZSgpIHtcbiAgICB0aGlzLl90aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xXcml0ZVF1ZXVlU2l6ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl90aHJlYWRQb29sV3JpdGVRdWV1ZVNpemU7XG4gIH1cblxuICAvLyB0aHJlYWRfcG9vbF93cml0ZV9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdGhyZWFkUG9vbFdyaXRlU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdGhyZWFkUG9vbFdyaXRlU2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3RocmVhZF9wb29sX3dyaXRlX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRocmVhZFBvb2xXcml0ZVNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3RocmVhZFBvb2xXcml0ZVNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRUaHJlYWRQb29sV3JpdGVTaXplKCkge1xuICAgIHRoaXMuX3RocmVhZFBvb2xXcml0ZVNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHRocmVhZFBvb2xXcml0ZVNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGhyZWFkUG9vbFdyaXRlU2l6ZTtcbiAgfVxuXG4gIC8vID09PT09PT09PVxuICAvLyBTWU5USEVTSVNcbiAgLy8gPT09PT09PT09XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICByZXR1cm4ge1xuICAgICAgYWN0aW9uX2F1dG9fY3JlYXRlX2luZGV4X2VuYWJsZWQ6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9hY3Rpb25BdXRvQ3JlYXRlSW5kZXhFbmFibGVkKSxcbiAgICAgIGFjdGlvbl9kZXN0cnVjdGl2ZV9yZXF1aXJlc19uYW1lOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fYWN0aW9uRGVzdHJ1Y3RpdmVSZXF1aXJlc05hbWUpLFxuICAgICAgY2x1c3Rlcl9pZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgIGNsdXN0ZXJfbWF4X3NoYXJkc19wZXJfbm9kZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fY2x1c3Rlck1heFNoYXJkc1Blck5vZGUpLFxuICAgICAgY2x1c3Rlcl9yb3V0aW5nX2FsbG9jYXRpb25fbm9kZV9jb25jdXJyZW50X3JlY292ZXJpZXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJSb3V0aW5nQWxsb2NhdGlvbk5vZGVDb25jdXJyZW50UmVjb3ZlcmllcyksXG4gICAgICBlbmFibGVfc2VjdXJpdHlfYXVkaXQ6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9lbmFibGVTZWN1cml0eUF1ZGl0KSxcbiAgICAgIGh0dHBfbWF4X2NvbnRlbnRfbGVuZ3RoX2J5dGVzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9odHRwTWF4Q29udGVudExlbmd0aEJ5dGVzKSxcbiAgICAgIGh0dHBfbWF4X2hlYWRlcl9zaXplX2J5dGVzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9odHRwTWF4SGVhZGVyU2l6ZUJ5dGVzKSxcbiAgICAgIGh0dHBfbWF4X2luaXRpYWxfbGluZV9sZW5ndGhfYnl0ZXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2h0dHBNYXhJbml0aWFsTGluZUxlbmd0aEJ5dGVzKSxcbiAgICAgIGlkOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9pZCksXG4gICAgICBpbmRpY2VzX2ZpZWxkZGF0YV9jYWNoZV9zaXplX3BlcmNlbnRhZ2U6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlKSxcbiAgICAgIGluZGljZXNfbWVtb3J5X2luZGV4X2J1ZmZlcl9zaXplX3BlcmNlbnRhZ2U6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNNZW1vcnlJbmRleEJ1ZmZlclNpemVQZXJjZW50YWdlKSxcbiAgICAgIGluZGljZXNfbWVtb3J5X21heF9pbmRleF9idWZmZXJfc2l6ZV9tYjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW5kaWNlc01lbW9yeU1heEluZGV4QnVmZmVyU2l6ZU1iKSxcbiAgICAgIGluZGljZXNfbWVtb3J5X21pbl9pbmRleF9idWZmZXJfc2l6ZV9tYjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iKSxcbiAgICAgIGluZGljZXNfcXVlcmllc19jYWNoZV9zaXplX3BlcmNlbnRhZ2U6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNRdWVyaWVzQ2FjaGVTaXplUGVyY2VudGFnZSksXG4gICAgICBpbmRpY2VzX3F1ZXJ5X2Jvb2xfbWF4X2NsYXVzZV9jb3VudDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW5kaWNlc1F1ZXJ5Qm9vbE1heENsYXVzZUNvdW50KSxcbiAgICAgIGluZGljZXNfcmVjb3ZlcnlfbWF4X2NvbmN1cnJlbnRfZmlsZV9jaHVua3M6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzKSxcbiAgICAgIGluZGljZXNfcmVjb3ZlcnlfbWF4X21iX3Blcl9zZWM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2luZGljZXNSZWNvdmVyeU1heE1iUGVyU2VjKSxcbiAgICAgIGlzbV9lbmFibGVkOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5faXNtRW5hYmxlZCksXG4gICAgICBpc21faGlzdG9yeV9lbmFibGVkOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeUVuYWJsZWQpLFxuICAgICAgaXNtX2hpc3RvcnlfbWF4X2FnZV9ob3VyczogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeU1heEFnZUhvdXJzKSxcbiAgICAgIGlzbV9oaXN0b3J5X21heF9kb2NzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pc21IaXN0b3J5TWF4RG9jcyksXG4gICAgICBpc21faGlzdG9yeV9yb2xsb3Zlcl9jaGVja19wZXJpb2RfaG91cnM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlSb2xsb3ZlckNoZWNrUGVyaW9kSG91cnMpLFxuICAgICAgaXNtX2hpc3Rvcnlfcm9sbG92ZXJfcmV0ZW50aW9uX3BlcmlvZF9kYXlzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pc21IaXN0b3J5Um9sbG92ZXJSZXRlbnRpb25QZXJpb2REYXlzKSxcbiAgICAgIG92ZXJyaWRlX21haW5fcmVzcG9uc2VfdmVyc2lvbjogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX292ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbiksXG4gICAgICBwbHVnaW5zX2FsZXJ0aW5nX2ZpbHRlcl9ieV9iYWNrZW5kX3JvbGVzX2VuYWJsZWQ6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9wbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWQpLFxuICAgICAgcmVpbmRleF9yZW1vdGVfd2hpdGVsaXN0OiBjZGt0bi5saXN0TWFwcGVyKGNka3RuLnN0cmluZ1RvVGVycmFmb3JtLCBmYWxzZSkodGhpcy5fcmVpbmRleFJlbW90ZVdoaXRlbGlzdCksXG4gICAgICBzY3JpcHRfbWF4X2NvbXBpbGF0aW9uc19yYXRlOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9zY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlKSxcbiAgICAgIHNlYXJjaF9tYXhfYnVja2V0czogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fc2VhcmNoTWF4QnVja2V0cyksXG4gICAgICB0aHJlYWRfcG9vbF9hbmFseXplX3F1ZXVlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xBbmFseXplUXVldWVTaXplKSxcbiAgICAgIHRocmVhZF9wb29sX2FuYWx5emVfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEFuYWx5emVTaXplKSxcbiAgICAgIHRocmVhZF9wb29sX2ZvcmNlX21lcmdlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xGb3JjZU1lcmdlU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF9nZXRfcXVldWVfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEdldFF1ZXVlU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF9nZXRfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEdldFNpemUpLFxuICAgICAgdGhyZWFkX3Bvb2xfc2VhcmNoX3F1ZXVlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hRdWV1ZVNpemUpLFxuICAgICAgdGhyZWFkX3Bvb2xfc2VhcmNoX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hTaXplKSxcbiAgICAgIHRocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfcXVldWVfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF9zZWFyY2hfdGhyb3R0bGVkX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xTZWFyY2hUaHJvdHRsZWRTaXplKSxcbiAgICAgIHRocmVhZF9wb29sX3dyaXRlX3F1ZXVlX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xXcml0ZVF1ZXVlU2l6ZSksXG4gICAgICB0aHJlYWRfcG9vbF93cml0ZV9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sV3JpdGVTaXplKSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVIY2xBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICBjb25zdCBhdHRycyA9IHtcbiAgICAgIGFjdGlvbl9hdXRvX2NyZWF0ZV9pbmRleF9lbmFibGVkOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fYWN0aW9uQXV0b0NyZWF0ZUluZGV4RW5hYmxlZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBhY3Rpb25fZGVzdHJ1Y3RpdmVfcmVxdWlyZXNfbmFtZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2FjdGlvbkRlc3RydWN0aXZlUmVxdWlyZXNOYW1lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGNsdXN0ZXJfaWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2NsdXN0ZXJJZCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGNsdXN0ZXJfbWF4X3NoYXJkc19wZXJfbm9kZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fY2x1c3Rlck1heFNoYXJkc1Blck5vZGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBjbHVzdGVyX3JvdXRpbmdfYWxsb2NhdGlvbl9ub2RlX2NvbmN1cnJlbnRfcmVjb3Zlcmllczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fY2x1c3RlclJvdXRpbmdBbGxvY2F0aW9uTm9kZUNvbmN1cnJlbnRSZWNvdmVyaWVzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgZW5hYmxlX3NlY3VyaXR5X2F1ZGl0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fZW5hYmxlU2VjdXJpdHlBdWRpdCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBodHRwX21heF9jb250ZW50X2xlbmd0aF9ieXRlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faHR0cE1heENvbnRlbnRMZW5ndGhCeXRlcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGh0dHBfbWF4X2hlYWRlcl9zaXplX2J5dGVzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9odHRwTWF4SGVhZGVyU2l6ZUJ5dGVzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaHR0cF9tYXhfaW5pdGlhbF9saW5lX2xlbmd0aF9ieXRlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faHR0cE1heEluaXRpYWxMaW5lTGVuZ3RoQnl0ZXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBpbmRpY2VzX2ZpZWxkZGF0YV9jYWNoZV9zaXplX3BlcmNlbnRhZ2U6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNGaWVsZGRhdGFDYWNoZVNpemVQZXJjZW50YWdlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5kaWNlc19tZW1vcnlfaW5kZXhfYnVmZmVyX3NpemVfcGVyY2VudGFnZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5kaWNlc01lbW9yeUluZGV4QnVmZmVyU2l6ZVBlcmNlbnRhZ2UpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpbmRpY2VzX21lbW9yeV9tYXhfaW5kZXhfYnVmZmVyX3NpemVfbWI6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNNZW1vcnlNYXhJbmRleEJ1ZmZlclNpemVNYiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGluZGljZXNfbWVtb3J5X21pbl9pbmRleF9idWZmZXJfc2l6ZV9tYjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5kaWNlc01lbW9yeU1pbkluZGV4QnVmZmVyU2l6ZU1iKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5kaWNlc19xdWVyaWVzX2NhY2hlX3NpemVfcGVyY2VudGFnZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5kaWNlc1F1ZXJpZXNDYWNoZVNpemVQZXJjZW50YWdlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5kaWNlc19xdWVyeV9ib29sX21heF9jbGF1c2VfY291bnQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNRdWVyeUJvb2xNYXhDbGF1c2VDb3VudCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGluZGljZXNfcmVjb3ZlcnlfbWF4X2NvbmN1cnJlbnRfZmlsZV9jaHVua3M6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2luZGljZXNSZWNvdmVyeU1heENvbmN1cnJlbnRGaWxlQ2h1bmtzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5kaWNlc19yZWNvdmVyeV9tYXhfbWJfcGVyX3NlYzoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5kaWNlc1JlY292ZXJ5TWF4TWJQZXJTZWMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpc21fZW5hYmxlZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2lzbUVuYWJsZWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgaXNtX2hpc3RvcnlfZW5hYmxlZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlFbmFibGVkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGlzbV9oaXN0b3J5X21heF9hZ2VfaG91cnM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2lzbUhpc3RvcnlNYXhBZ2VIb3VycyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlzbV9oaXN0b3J5X21heF9kb2NzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pc21IaXN0b3J5TWF4RG9jcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlzbV9oaXN0b3J5X3JvbGxvdmVyX2NoZWNrX3BlcmlvZF9ob3Vyczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyQ2hlY2tQZXJpb2RIb3VycyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlzbV9oaXN0b3J5X3JvbGxvdmVyX3JldGVudGlvbl9wZXJpb2RfZGF5czoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faXNtSGlzdG9yeVJvbGxvdmVyUmV0ZW50aW9uUGVyaW9kRGF5cyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG92ZXJyaWRlX21haW5fcmVzcG9uc2VfdmVyc2lvbjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX292ZXJyaWRlTWFpblJlc3BvbnNlVmVyc2lvbiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBwbHVnaW5zX2FsZXJ0aW5nX2ZpbHRlcl9ieV9iYWNrZW5kX3JvbGVzX2VuYWJsZWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9wbHVnaW5zQWxlcnRpbmdGaWx0ZXJCeUJhY2tlbmRSb2xlc0VuYWJsZWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgcmVpbmRleF9yZW1vdGVfd2hpdGVsaXN0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5saXN0TWFwcGVySGNsKGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtLCBmYWxzZSkodGhpcy5fcmVpbmRleFJlbW90ZVdoaXRlbGlzdCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNldFwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ0xpc3RcIixcbiAgICAgIH0sXG4gICAgICBzY3JpcHRfbWF4X2NvbXBpbGF0aW9uc19yYXRlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9zY3JpcHRNYXhDb21waWxhdGlvbnNSYXRlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgc2VhcmNoX21heF9idWNrZXRzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9zZWFyY2hNYXhCdWNrZXRzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfYW5hbHl6ZV9xdWV1ZV9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sQW5hbHl6ZVF1ZXVlU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX2FuYWx5emVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEFuYWx5emVTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfZm9yY2VfbWVyZ2Vfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEZvcmNlTWVyZ2VTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgdGhyZWFkX3Bvb2xfZ2V0X3F1ZXVlX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3RocmVhZFBvb2xHZXRRdWV1ZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF9nZXRfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbEdldFNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF9zZWFyY2hfcXVldWVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFNlYXJjaFF1ZXVlU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX3NlYXJjaF9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sU2VhcmNoU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfcXVldWVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFF1ZXVlU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHRocmVhZF9wb29sX3NlYXJjaF90aHJvdHRsZWRfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fdGhyZWFkUG9vbFNlYXJjaFRocm90dGxlZFNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF93cml0ZV9xdWV1ZV9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sV3JpdGVRdWV1ZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB0aHJlYWRfcG9vbF93cml0ZV9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90aHJlYWRQb29sV3JpdGVTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgIH07XG5cbiAgICAvLyByZW1vdmUgdW5kZWZpbmVkIGF0dHJpYnV0ZXNcbiAgICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGF0dHJzKS5maWx0ZXIoKFtfLCB2YWx1ZV0pID0+IHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUudmFsdWUgIT09IHVuZGVmaW5lZCApKVxuICB9XG59XG4iXX0=