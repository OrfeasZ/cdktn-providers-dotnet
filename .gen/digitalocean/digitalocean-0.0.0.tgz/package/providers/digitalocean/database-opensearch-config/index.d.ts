import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseOpensearchConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#action_auto_create_index_enabled DatabaseOpensearchConfig#action_auto_create_index_enabled}
    */
    readonly actionAutoCreateIndexEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#action_destructive_requires_name DatabaseOpensearchConfig#action_destructive_requires_name}
    */
    readonly actionDestructiveRequiresName?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#cluster_id DatabaseOpensearchConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#cluster_max_shards_per_node DatabaseOpensearchConfig#cluster_max_shards_per_node}
    */
    readonly clusterMaxShardsPerNode?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#cluster_routing_allocation_node_concurrent_recoveries DatabaseOpensearchConfig#cluster_routing_allocation_node_concurrent_recoveries}
    */
    readonly clusterRoutingAllocationNodeConcurrentRecoveries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#enable_security_audit DatabaseOpensearchConfig#enable_security_audit}
    */
    readonly enableSecurityAudit?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#http_max_content_length_bytes DatabaseOpensearchConfig#http_max_content_length_bytes}
    */
    readonly httpMaxContentLengthBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#http_max_header_size_bytes DatabaseOpensearchConfig#http_max_header_size_bytes}
    */
    readonly httpMaxHeaderSizeBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#http_max_initial_line_length_bytes DatabaseOpensearchConfig#http_max_initial_line_length_bytes}
    */
    readonly httpMaxInitialLineLengthBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#id DatabaseOpensearchConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_fielddata_cache_size_percentage DatabaseOpensearchConfig#indices_fielddata_cache_size_percentage}
    */
    readonly indicesFielddataCacheSizePercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_memory_index_buffer_size_percentage DatabaseOpensearchConfig#indices_memory_index_buffer_size_percentage}
    */
    readonly indicesMemoryIndexBufferSizePercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_memory_max_index_buffer_size_mb DatabaseOpensearchConfig#indices_memory_max_index_buffer_size_mb}
    */
    readonly indicesMemoryMaxIndexBufferSizeMb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_memory_min_index_buffer_size_mb DatabaseOpensearchConfig#indices_memory_min_index_buffer_size_mb}
    */
    readonly indicesMemoryMinIndexBufferSizeMb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_queries_cache_size_percentage DatabaseOpensearchConfig#indices_queries_cache_size_percentage}
    */
    readonly indicesQueriesCacheSizePercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_query_bool_max_clause_count DatabaseOpensearchConfig#indices_query_bool_max_clause_count}
    */
    readonly indicesQueryBoolMaxClauseCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_recovery_max_concurrent_file_chunks DatabaseOpensearchConfig#indices_recovery_max_concurrent_file_chunks}
    */
    readonly indicesRecoveryMaxConcurrentFileChunks?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#indices_recovery_max_mb_per_sec DatabaseOpensearchConfig#indices_recovery_max_mb_per_sec}
    */
    readonly indicesRecoveryMaxMbPerSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#ism_enabled DatabaseOpensearchConfig#ism_enabled}
    */
    readonly ismEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#ism_history_enabled DatabaseOpensearchConfig#ism_history_enabled}
    */
    readonly ismHistoryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#ism_history_max_age_hours DatabaseOpensearchConfig#ism_history_max_age_hours}
    */
    readonly ismHistoryMaxAgeHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#ism_history_max_docs DatabaseOpensearchConfig#ism_history_max_docs}
    */
    readonly ismHistoryMaxDocs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#ism_history_rollover_check_period_hours DatabaseOpensearchConfig#ism_history_rollover_check_period_hours}
    */
    readonly ismHistoryRolloverCheckPeriodHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#ism_history_rollover_retention_period_days DatabaseOpensearchConfig#ism_history_rollover_retention_period_days}
    */
    readonly ismHistoryRolloverRetentionPeriodDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#override_main_response_version DatabaseOpensearchConfig#override_main_response_version}
    */
    readonly overrideMainResponseVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#plugins_alerting_filter_by_backend_roles_enabled DatabaseOpensearchConfig#plugins_alerting_filter_by_backend_roles_enabled}
    */
    readonly pluginsAlertingFilterByBackendRolesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#reindex_remote_whitelist DatabaseOpensearchConfig#reindex_remote_whitelist}
    */
    readonly reindexRemoteWhitelist?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#script_max_compilations_rate DatabaseOpensearchConfig#script_max_compilations_rate}
    */
    readonly scriptMaxCompilationsRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#search_max_buckets DatabaseOpensearchConfig#search_max_buckets}
    */
    readonly searchMaxBuckets?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_analyze_queue_size DatabaseOpensearchConfig#thread_pool_analyze_queue_size}
    */
    readonly threadPoolAnalyzeQueueSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_analyze_size DatabaseOpensearchConfig#thread_pool_analyze_size}
    */
    readonly threadPoolAnalyzeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_force_merge_size DatabaseOpensearchConfig#thread_pool_force_merge_size}
    */
    readonly threadPoolForceMergeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_get_queue_size DatabaseOpensearchConfig#thread_pool_get_queue_size}
    */
    readonly threadPoolGetQueueSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_get_size DatabaseOpensearchConfig#thread_pool_get_size}
    */
    readonly threadPoolGetSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_search_queue_size DatabaseOpensearchConfig#thread_pool_search_queue_size}
    */
    readonly threadPoolSearchQueueSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_search_size DatabaseOpensearchConfig#thread_pool_search_size}
    */
    readonly threadPoolSearchSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_search_throttled_queue_size DatabaseOpensearchConfig#thread_pool_search_throttled_queue_size}
    */
    readonly threadPoolSearchThrottledQueueSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_search_throttled_size DatabaseOpensearchConfig#thread_pool_search_throttled_size}
    */
    readonly threadPoolSearchThrottledSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_write_queue_size DatabaseOpensearchConfig#thread_pool_write_queue_size}
    */
    readonly threadPoolWriteQueueSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#thread_pool_write_size DatabaseOpensearchConfig#thread_pool_write_size}
    */
    readonly threadPoolWriteSize?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config digitalocean_database_opensearch_config}
*/
export declare class DatabaseOpensearchConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_opensearch_config";
    /**
    * Generates CDKTN code for importing a DatabaseOpensearchConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseOpensearchConfig to import
    * @param importFromId The id of the existing DatabaseOpensearchConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseOpensearchConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_opensearch_config digitalocean_database_opensearch_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseOpensearchConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseOpensearchConfigConfig);
    private _actionAutoCreateIndexEnabled?;
    get actionAutoCreateIndexEnabled(): boolean | cdktn.IResolvable;
    set actionAutoCreateIndexEnabled(value: boolean | cdktn.IResolvable);
    resetActionAutoCreateIndexEnabled(): void;
    get actionAutoCreateIndexEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _actionDestructiveRequiresName?;
    get actionDestructiveRequiresName(): boolean | cdktn.IResolvable;
    set actionDestructiveRequiresName(value: boolean | cdktn.IResolvable);
    resetActionDestructiveRequiresName(): void;
    get actionDestructiveRequiresNameInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _clusterMaxShardsPerNode?;
    get clusterMaxShardsPerNode(): number;
    set clusterMaxShardsPerNode(value: number);
    resetClusterMaxShardsPerNode(): void;
    get clusterMaxShardsPerNodeInput(): number | undefined;
    private _clusterRoutingAllocationNodeConcurrentRecoveries?;
    get clusterRoutingAllocationNodeConcurrentRecoveries(): number;
    set clusterRoutingAllocationNodeConcurrentRecoveries(value: number);
    resetClusterRoutingAllocationNodeConcurrentRecoveries(): void;
    get clusterRoutingAllocationNodeConcurrentRecoveriesInput(): number | undefined;
    private _enableSecurityAudit?;
    get enableSecurityAudit(): boolean | cdktn.IResolvable;
    set enableSecurityAudit(value: boolean | cdktn.IResolvable);
    resetEnableSecurityAudit(): void;
    get enableSecurityAuditInput(): boolean | cdktn.IResolvable | undefined;
    private _httpMaxContentLengthBytes?;
    get httpMaxContentLengthBytes(): number;
    set httpMaxContentLengthBytes(value: number);
    resetHttpMaxContentLengthBytes(): void;
    get httpMaxContentLengthBytesInput(): number | undefined;
    private _httpMaxHeaderSizeBytes?;
    get httpMaxHeaderSizeBytes(): number;
    set httpMaxHeaderSizeBytes(value: number);
    resetHttpMaxHeaderSizeBytes(): void;
    get httpMaxHeaderSizeBytesInput(): number | undefined;
    private _httpMaxInitialLineLengthBytes?;
    get httpMaxInitialLineLengthBytes(): number;
    set httpMaxInitialLineLengthBytes(value: number);
    resetHttpMaxInitialLineLengthBytes(): void;
    get httpMaxInitialLineLengthBytesInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indicesFielddataCacheSizePercentage?;
    get indicesFielddataCacheSizePercentage(): number;
    set indicesFielddataCacheSizePercentage(value: number);
    resetIndicesFielddataCacheSizePercentage(): void;
    get indicesFielddataCacheSizePercentageInput(): number | undefined;
    private _indicesMemoryIndexBufferSizePercentage?;
    get indicesMemoryIndexBufferSizePercentage(): number;
    set indicesMemoryIndexBufferSizePercentage(value: number);
    resetIndicesMemoryIndexBufferSizePercentage(): void;
    get indicesMemoryIndexBufferSizePercentageInput(): number | undefined;
    private _indicesMemoryMaxIndexBufferSizeMb?;
    get indicesMemoryMaxIndexBufferSizeMb(): number;
    set indicesMemoryMaxIndexBufferSizeMb(value: number);
    resetIndicesMemoryMaxIndexBufferSizeMb(): void;
    get indicesMemoryMaxIndexBufferSizeMbInput(): number | undefined;
    private _indicesMemoryMinIndexBufferSizeMb?;
    get indicesMemoryMinIndexBufferSizeMb(): number;
    set indicesMemoryMinIndexBufferSizeMb(value: number);
    resetIndicesMemoryMinIndexBufferSizeMb(): void;
    get indicesMemoryMinIndexBufferSizeMbInput(): number | undefined;
    private _indicesQueriesCacheSizePercentage?;
    get indicesQueriesCacheSizePercentage(): number;
    set indicesQueriesCacheSizePercentage(value: number);
    resetIndicesQueriesCacheSizePercentage(): void;
    get indicesQueriesCacheSizePercentageInput(): number | undefined;
    private _indicesQueryBoolMaxClauseCount?;
    get indicesQueryBoolMaxClauseCount(): number;
    set indicesQueryBoolMaxClauseCount(value: number);
    resetIndicesQueryBoolMaxClauseCount(): void;
    get indicesQueryBoolMaxClauseCountInput(): number | undefined;
    private _indicesRecoveryMaxConcurrentFileChunks?;
    get indicesRecoveryMaxConcurrentFileChunks(): number;
    set indicesRecoveryMaxConcurrentFileChunks(value: number);
    resetIndicesRecoveryMaxConcurrentFileChunks(): void;
    get indicesRecoveryMaxConcurrentFileChunksInput(): number | undefined;
    private _indicesRecoveryMaxMbPerSec?;
    get indicesRecoveryMaxMbPerSec(): number;
    set indicesRecoveryMaxMbPerSec(value: number);
    resetIndicesRecoveryMaxMbPerSec(): void;
    get indicesRecoveryMaxMbPerSecInput(): number | undefined;
    private _ismEnabled?;
    get ismEnabled(): boolean | cdktn.IResolvable;
    set ismEnabled(value: boolean | cdktn.IResolvable);
    resetIsmEnabled(): void;
    get ismEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ismHistoryEnabled?;
    get ismHistoryEnabled(): boolean | cdktn.IResolvable;
    set ismHistoryEnabled(value: boolean | cdktn.IResolvable);
    resetIsmHistoryEnabled(): void;
    get ismHistoryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ismHistoryMaxAgeHours?;
    get ismHistoryMaxAgeHours(): number;
    set ismHistoryMaxAgeHours(value: number);
    resetIsmHistoryMaxAgeHours(): void;
    get ismHistoryMaxAgeHoursInput(): number | undefined;
    private _ismHistoryMaxDocs?;
    get ismHistoryMaxDocs(): number;
    set ismHistoryMaxDocs(value: number);
    resetIsmHistoryMaxDocs(): void;
    get ismHistoryMaxDocsInput(): number | undefined;
    private _ismHistoryRolloverCheckPeriodHours?;
    get ismHistoryRolloverCheckPeriodHours(): number;
    set ismHistoryRolloverCheckPeriodHours(value: number);
    resetIsmHistoryRolloverCheckPeriodHours(): void;
    get ismHistoryRolloverCheckPeriodHoursInput(): number | undefined;
    private _ismHistoryRolloverRetentionPeriodDays?;
    get ismHistoryRolloverRetentionPeriodDays(): number;
    set ismHistoryRolloverRetentionPeriodDays(value: number);
    resetIsmHistoryRolloverRetentionPeriodDays(): void;
    get ismHistoryRolloverRetentionPeriodDaysInput(): number | undefined;
    private _overrideMainResponseVersion?;
    get overrideMainResponseVersion(): boolean | cdktn.IResolvable;
    set overrideMainResponseVersion(value: boolean | cdktn.IResolvable);
    resetOverrideMainResponseVersion(): void;
    get overrideMainResponseVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _pluginsAlertingFilterByBackendRolesEnabled?;
    get pluginsAlertingFilterByBackendRolesEnabled(): boolean | cdktn.IResolvable;
    set pluginsAlertingFilterByBackendRolesEnabled(value: boolean | cdktn.IResolvable);
    resetPluginsAlertingFilterByBackendRolesEnabled(): void;
    get pluginsAlertingFilterByBackendRolesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _reindexRemoteWhitelist?;
    get reindexRemoteWhitelist(): string[];
    set reindexRemoteWhitelist(value: string[]);
    resetReindexRemoteWhitelist(): void;
    get reindexRemoteWhitelistInput(): string[] | undefined;
    private _scriptMaxCompilationsRate?;
    get scriptMaxCompilationsRate(): string;
    set scriptMaxCompilationsRate(value: string);
    resetScriptMaxCompilationsRate(): void;
    get scriptMaxCompilationsRateInput(): string | undefined;
    private _searchMaxBuckets?;
    get searchMaxBuckets(): number;
    set searchMaxBuckets(value: number);
    resetSearchMaxBuckets(): void;
    get searchMaxBucketsInput(): number | undefined;
    private _threadPoolAnalyzeQueueSize?;
    get threadPoolAnalyzeQueueSize(): number;
    set threadPoolAnalyzeQueueSize(value: number);
    resetThreadPoolAnalyzeQueueSize(): void;
    get threadPoolAnalyzeQueueSizeInput(): number | undefined;
    private _threadPoolAnalyzeSize?;
    get threadPoolAnalyzeSize(): number;
    set threadPoolAnalyzeSize(value: number);
    resetThreadPoolAnalyzeSize(): void;
    get threadPoolAnalyzeSizeInput(): number | undefined;
    private _threadPoolForceMergeSize?;
    get threadPoolForceMergeSize(): number;
    set threadPoolForceMergeSize(value: number);
    resetThreadPoolForceMergeSize(): void;
    get threadPoolForceMergeSizeInput(): number | undefined;
    private _threadPoolGetQueueSize?;
    get threadPoolGetQueueSize(): number;
    set threadPoolGetQueueSize(value: number);
    resetThreadPoolGetQueueSize(): void;
    get threadPoolGetQueueSizeInput(): number | undefined;
    private _threadPoolGetSize?;
    get threadPoolGetSize(): number;
    set threadPoolGetSize(value: number);
    resetThreadPoolGetSize(): void;
    get threadPoolGetSizeInput(): number | undefined;
    private _threadPoolSearchQueueSize?;
    get threadPoolSearchQueueSize(): number;
    set threadPoolSearchQueueSize(value: number);
    resetThreadPoolSearchQueueSize(): void;
    get threadPoolSearchQueueSizeInput(): number | undefined;
    private _threadPoolSearchSize?;
    get threadPoolSearchSize(): number;
    set threadPoolSearchSize(value: number);
    resetThreadPoolSearchSize(): void;
    get threadPoolSearchSizeInput(): number | undefined;
    private _threadPoolSearchThrottledQueueSize?;
    get threadPoolSearchThrottledQueueSize(): number;
    set threadPoolSearchThrottledQueueSize(value: number);
    resetThreadPoolSearchThrottledQueueSize(): void;
    get threadPoolSearchThrottledQueueSizeInput(): number | undefined;
    private _threadPoolSearchThrottledSize?;
    get threadPoolSearchThrottledSize(): number;
    set threadPoolSearchThrottledSize(value: number);
    resetThreadPoolSearchThrottledSize(): void;
    get threadPoolSearchThrottledSizeInput(): number | undefined;
    private _threadPoolWriteQueueSize?;
    get threadPoolWriteQueueSize(): number;
    set threadPoolWriteQueueSize(value: number);
    resetThreadPoolWriteQueueSize(): void;
    get threadPoolWriteQueueSizeInput(): number | undefined;
    private _threadPoolWriteSize?;
    get threadPoolWriteSize(): number;
    set threadPoolWriteSize(value: number);
    resetThreadPoolWriteSize(): void;
    get threadPoolWriteSizeInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
