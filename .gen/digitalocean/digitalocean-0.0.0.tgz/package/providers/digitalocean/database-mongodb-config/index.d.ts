import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseMongodbConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#cluster_id DatabaseMongodbConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#default_read_concern DatabaseMongodbConfig#default_read_concern}
    */
    readonly defaultReadConcern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#default_write_concern DatabaseMongodbConfig#default_write_concern}
    */
    readonly defaultWriteConcern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#id DatabaseMongodbConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#slow_op_threshold_ms DatabaseMongodbConfig#slow_op_threshold_ms}
    */
    readonly slowOpThresholdMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#transaction_lifetime_limit_seconds DatabaseMongodbConfig#transaction_lifetime_limit_seconds}
    */
    readonly transactionLifetimeLimitSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#verbosity DatabaseMongodbConfig#verbosity}
    */
    readonly verbosity?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config digitalocean_database_mongodb_config}
*/
export declare class DatabaseMongodbConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_mongodb_config";
    /**
    * Generates CDKTN code for importing a DatabaseMongodbConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseMongodbConfig to import
    * @param importFromId The id of the existing DatabaseMongodbConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseMongodbConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mongodb_config digitalocean_database_mongodb_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseMongodbConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseMongodbConfigConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _defaultReadConcern?;
    get defaultReadConcern(): string;
    set defaultReadConcern(value: string);
    resetDefaultReadConcern(): void;
    get defaultReadConcernInput(): string | undefined;
    private _defaultWriteConcern?;
    get defaultWriteConcern(): string;
    set defaultWriteConcern(value: string);
    resetDefaultWriteConcern(): void;
    get defaultWriteConcernInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _slowOpThresholdMs?;
    get slowOpThresholdMs(): number;
    set slowOpThresholdMs(value: number);
    resetSlowOpThresholdMs(): void;
    get slowOpThresholdMsInput(): number | undefined;
    private _transactionLifetimeLimitSeconds?;
    get transactionLifetimeLimitSeconds(): number;
    set transactionLifetimeLimitSeconds(value: number);
    resetTransactionLifetimeLimitSeconds(): void;
    get transactionLifetimeLimitSecondsInput(): number | undefined;
    private _verbosity?;
    get verbosity(): number;
    set verbosity(value: number);
    resetVerbosity(): void;
    get verbosityInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
