# `data_digitalocean_gradientai_indexing_job`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_indexing_job`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job).
