import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiIndexingJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job#id DataDigitaloceanGradientaiIndexingJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job#uuid DataDigitaloceanGradientaiIndexingJob#uuid}
    */
    readonly uuid: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job digitalocean_gradientai_indexing_job}
*/
export declare class DataDigitaloceanGradientaiIndexingJob extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_indexing_job";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiIndexingJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiIndexingJob to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiIndexingJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiIndexingJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job digitalocean_gradientai_indexing_job} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiIndexingJobConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiIndexingJobConfig);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get status(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get totalItemsFailed(): string;
    get totalItemsIndexed(): string;
    get totalItemsSkipped(): string;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
