import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanRegionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#id DataDigitaloceanRegions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#filter DataDigitaloceanRegions#filter}
    */
    readonly filter?: DataDigitaloceanRegionsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#sort DataDigitaloceanRegions#sort}
    */
    readonly sort?: DataDigitaloceanRegionsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanRegionsRegions {
}
export declare function dataDigitaloceanRegionsRegionsToTerraform(struct?: DataDigitaloceanRegionsRegions): any;
export declare function dataDigitaloceanRegionsRegionsToHclTerraform(struct?: DataDigitaloceanRegionsRegions): any;
export declare class DataDigitaloceanRegionsRegionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanRegionsRegions | undefined;
    set internalValue(value: DataDigitaloceanRegionsRegions | undefined);
    get available(): cdktn.IResolvable;
    get features(): string[];
    get name(): string;
    get sizes(): string[];
    get slug(): string;
}
export declare class DataDigitaloceanRegionsRegionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanRegionsRegionsOutputReference;
}
export interface DataDigitaloceanRegionsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#all DataDigitaloceanRegions#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#key DataDigitaloceanRegions#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#match_by DataDigitaloceanRegions#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#values DataDigitaloceanRegions#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanRegionsFilterToTerraform(struct?: DataDigitaloceanRegionsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanRegionsFilterToHclTerraform(struct?: DataDigitaloceanRegionsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanRegionsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanRegionsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanRegionsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanRegionsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanRegionsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanRegionsFilterOutputReference;
}
export interface DataDigitaloceanRegionsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#direction DataDigitaloceanRegions#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#key DataDigitaloceanRegions#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanRegionsSortToTerraform(struct?: DataDigitaloceanRegionsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanRegionsSortToHclTerraform(struct?: DataDigitaloceanRegionsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanRegionsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanRegionsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanRegionsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanRegionsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanRegionsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanRegionsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions digitalocean_regions}
*/
export declare class DataDigitaloceanRegions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_regions";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanRegions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanRegions to import
    * @param importFromId The id of the existing DataDigitaloceanRegions that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanRegions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/regions digitalocean_regions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanRegionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanRegionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _regions;
    get regions(): DataDigitaloceanRegionsRegionsList;
    private _filter;
    get filter(): DataDigitaloceanRegionsFilterList;
    putFilter(value: DataDigitaloceanRegionsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanRegionsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanRegionsSortList;
    putSort(value: DataDigitaloceanRegionsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanRegionsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
