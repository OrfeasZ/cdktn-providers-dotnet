import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanSshKeysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#id DataDigitaloceanSshKeys#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#filter DataDigitaloceanSshKeys#filter}
    */
    readonly filter?: DataDigitaloceanSshKeysFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#sort DataDigitaloceanSshKeys#sort}
    */
    readonly sort?: DataDigitaloceanSshKeysSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanSshKeysSshKeys {
}
export declare function dataDigitaloceanSshKeysSshKeysToTerraform(struct?: DataDigitaloceanSshKeysSshKeys): any;
export declare function dataDigitaloceanSshKeysSshKeysToHclTerraform(struct?: DataDigitaloceanSshKeysSshKeys): any;
export declare class DataDigitaloceanSshKeysSshKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSshKeysSshKeys | undefined;
    set internalValue(value: DataDigitaloceanSshKeysSshKeys | undefined);
    get fingerprint(): string;
    get id(): number;
    get name(): string;
    get publicKey(): string;
}
export declare class DataDigitaloceanSshKeysSshKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSshKeysSshKeysOutputReference;
}
export interface DataDigitaloceanSshKeysFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#all DataDigitaloceanSshKeys#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#key DataDigitaloceanSshKeys#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#match_by DataDigitaloceanSshKeys#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#values DataDigitaloceanSshKeys#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanSshKeysFilterToTerraform(struct?: DataDigitaloceanSshKeysFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanSshKeysFilterToHclTerraform(struct?: DataDigitaloceanSshKeysFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanSshKeysFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSshKeysFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanSshKeysFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanSshKeysFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanSshKeysFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSshKeysFilterOutputReference;
}
export interface DataDigitaloceanSshKeysSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#direction DataDigitaloceanSshKeys#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#key DataDigitaloceanSshKeys#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanSshKeysSortToTerraform(struct?: DataDigitaloceanSshKeysSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanSshKeysSortToHclTerraform(struct?: DataDigitaloceanSshKeysSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanSshKeysSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSshKeysSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanSshKeysSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanSshKeysSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanSshKeysSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSshKeysSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys digitalocean_ssh_keys}
*/
export declare class DataDigitaloceanSshKeys extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_ssh_keys";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanSshKeys resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanSshKeys to import
    * @param importFromId The id of the existing DataDigitaloceanSshKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanSshKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/ssh_keys digitalocean_ssh_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanSshKeysConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanSshKeysConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _sshKeys;
    get sshKeys(): DataDigitaloceanSshKeysSshKeysList;
    private _filter;
    get filter(): DataDigitaloceanSshKeysFilterList;
    putFilter(value: DataDigitaloceanSshKeysFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanSshKeysFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanSshKeysSortList;
    putSort(value: DataDigitaloceanSshKeysSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanSshKeysSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
