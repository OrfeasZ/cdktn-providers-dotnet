import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiOpenaiApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_openai_api_key#id DataDigitaloceanGradientaiOpenaiApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * OpenAI API Key Uuid
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_openai_api_key#uuid DataDigitaloceanGradientaiOpenaiApiKey#uuid}
    */
    readonly uuid: string;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreement {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeyModelsAgreementToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreement): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeyModelsAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreement): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeyModelsVersions {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeyModelsVersionsToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeyModelsVersions): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeyModelsVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeyModelsVersions): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeyModelsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeyModelsVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeyModelsVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeyModelsVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeyModelsVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeyModels {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeyModelsToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeyModels): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeyModelsToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeyModels): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeyModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeyModels | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeyModels | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiOpenaiApiKeyModelsAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGradientaiOpenaiApiKeyModelsVersionsList;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeyModelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeyModelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_openai_api_key digitalocean_gradientai_openai_api_key}
*/
export declare class DataDigitaloceanGradientaiOpenaiApiKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_openai_api_key";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiOpenaiApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiOpenaiApiKey to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiOpenaiApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_openai_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiOpenaiApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_openai_api_key digitalocean_gradientai_openai_api_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiOpenaiApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiOpenaiApiKeyConfig);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _models;
    get models(): DataDigitaloceanGradientaiOpenaiApiKeyModelsList;
    get name(): string;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
