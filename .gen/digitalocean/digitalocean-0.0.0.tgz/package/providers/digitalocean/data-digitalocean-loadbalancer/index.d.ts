import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanLoadbalancerConfig extends cdktn.TerraformMetaArguments {
    /**
    * id of the load balancer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/loadbalancer#id DataDigitaloceanLoadbalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * name of the load balancer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/loadbalancer#name DataDigitaloceanLoadbalancer#name}
    */
    readonly name?: string;
}
export interface DataDigitaloceanLoadbalancerDomains {
}
export declare function dataDigitaloceanLoadbalancerDomainsToTerraform(struct?: DataDigitaloceanLoadbalancerDomains): any;
export declare function dataDigitaloceanLoadbalancerDomainsToHclTerraform(struct?: DataDigitaloceanLoadbalancerDomains): any;
export declare class DataDigitaloceanLoadbalancerDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerDomains | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerDomains | undefined);
    get certificateId(): string;
    get certificateName(): string;
    get isManaged(): cdktn.IResolvable;
    get name(): string;
    get sslValidationErrorReasons(): string[];
    get verificationErrorReasons(): string[];
}
export declare class DataDigitaloceanLoadbalancerDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerDomainsOutputReference;
}
export interface DataDigitaloceanLoadbalancerFirewall {
}
export declare function dataDigitaloceanLoadbalancerFirewallToTerraform(struct?: DataDigitaloceanLoadbalancerFirewall): any;
export declare function dataDigitaloceanLoadbalancerFirewallToHclTerraform(struct?: DataDigitaloceanLoadbalancerFirewall): any;
export declare class DataDigitaloceanLoadbalancerFirewallOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerFirewall | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerFirewall | undefined);
    get allow(): string[];
    get deny(): string[];
}
export declare class DataDigitaloceanLoadbalancerFirewallList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerFirewallOutputReference;
}
export interface DataDigitaloceanLoadbalancerForwardingRule {
}
export declare function dataDigitaloceanLoadbalancerForwardingRuleToTerraform(struct?: DataDigitaloceanLoadbalancerForwardingRule): any;
export declare function dataDigitaloceanLoadbalancerForwardingRuleToHclTerraform(struct?: DataDigitaloceanLoadbalancerForwardingRule): any;
export declare class DataDigitaloceanLoadbalancerForwardingRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerForwardingRule | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerForwardingRule | undefined);
    get certificateId(): string;
    get certificateName(): string;
    get entryPort(): number;
    get entryProtocol(): string;
    get targetPort(): number;
    get targetProtocol(): string;
    get tlsPassthrough(): cdktn.IResolvable;
}
export declare class DataDigitaloceanLoadbalancerForwardingRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerForwardingRuleOutputReference;
}
export interface DataDigitaloceanLoadbalancerGlbSettingsCdn {
}
export declare function dataDigitaloceanLoadbalancerGlbSettingsCdnToTerraform(struct?: DataDigitaloceanLoadbalancerGlbSettingsCdn): any;
export declare function dataDigitaloceanLoadbalancerGlbSettingsCdnToHclTerraform(struct?: DataDigitaloceanLoadbalancerGlbSettingsCdn): any;
export declare class DataDigitaloceanLoadbalancerGlbSettingsCdnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerGlbSettingsCdn | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerGlbSettingsCdn | undefined);
    get isEnabled(): cdktn.IResolvable;
}
export declare class DataDigitaloceanLoadbalancerGlbSettingsCdnList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerGlbSettingsCdnOutputReference;
}
export interface DataDigitaloceanLoadbalancerGlbSettings {
}
export declare function dataDigitaloceanLoadbalancerGlbSettingsToTerraform(struct?: DataDigitaloceanLoadbalancerGlbSettings): any;
export declare function dataDigitaloceanLoadbalancerGlbSettingsToHclTerraform(struct?: DataDigitaloceanLoadbalancerGlbSettings): any;
export declare class DataDigitaloceanLoadbalancerGlbSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerGlbSettings | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerGlbSettings | undefined);
    private _cdn;
    get cdn(): DataDigitaloceanLoadbalancerGlbSettingsCdnList;
    get failoverThreshold(): number;
    private _regionPriorities;
    get regionPriorities(): cdktn.NumberMap;
    get targetPort(): number;
    get targetProtocol(): string;
}
export declare class DataDigitaloceanLoadbalancerGlbSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerGlbSettingsOutputReference;
}
export interface DataDigitaloceanLoadbalancerHealthcheck {
}
export declare function dataDigitaloceanLoadbalancerHealthcheckToTerraform(struct?: DataDigitaloceanLoadbalancerHealthcheck): any;
export declare function dataDigitaloceanLoadbalancerHealthcheckToHclTerraform(struct?: DataDigitaloceanLoadbalancerHealthcheck): any;
export declare class DataDigitaloceanLoadbalancerHealthcheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerHealthcheck | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerHealthcheck | undefined);
    get checkIntervalSeconds(): number;
    get healthyThreshold(): number;
    get path(): string;
    get port(): number;
    get protocol(): string;
    get responseTimeoutSeconds(): number;
    get unhealthyThreshold(): number;
}
export declare class DataDigitaloceanLoadbalancerHealthcheckList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerHealthcheckOutputReference;
}
export interface DataDigitaloceanLoadbalancerStickySessions {
}
export declare function dataDigitaloceanLoadbalancerStickySessionsToTerraform(struct?: DataDigitaloceanLoadbalancerStickySessions): any;
export declare function dataDigitaloceanLoadbalancerStickySessionsToHclTerraform(struct?: DataDigitaloceanLoadbalancerStickySessions): any;
export declare class DataDigitaloceanLoadbalancerStickySessionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanLoadbalancerStickySessions | undefined;
    set internalValue(value: DataDigitaloceanLoadbalancerStickySessions | undefined);
    get cookieName(): string;
    get cookieTtlSeconds(): number;
    get type(): string;
}
export declare class DataDigitaloceanLoadbalancerStickySessionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanLoadbalancerStickySessionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/loadbalancer digitalocean_loadbalancer}
*/
export declare class DataDigitaloceanLoadbalancer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_loadbalancer";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanLoadbalancer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanLoadbalancer to import
    * @param importFromId The id of the existing DataDigitaloceanLoadbalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/loadbalancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanLoadbalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/loadbalancer digitalocean_loadbalancer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanLoadbalancerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanLoadbalancerConfig);
    get algorithm(): string;
    get disableLetsEncryptDnsRecords(): cdktn.IResolvable;
    private _domains;
    get domains(): DataDigitaloceanLoadbalancerDomainsList;
    get dropletIds(): number[];
    get dropletTag(): string;
    get enableBackendKeepalive(): cdktn.IResolvable;
    get enableProxyProtocol(): cdktn.IResolvable;
    private _firewall;
    get firewall(): DataDigitaloceanLoadbalancerFirewallList;
    private _forwardingRule;
    get forwardingRule(): DataDigitaloceanLoadbalancerForwardingRuleList;
    private _glbSettings;
    get glbSettings(): DataDigitaloceanLoadbalancerGlbSettingsList;
    private _healthcheck;
    get healthcheck(): DataDigitaloceanLoadbalancerHealthcheckList;
    get httpIdleTimeoutSeconds(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ip(): string;
    get ipv6(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get network(): string;
    get projectId(): string;
    get redirectHttpToHttps(): cdktn.IResolvable;
    get region(): string;
    get size(): string;
    get sizeUnit(): number;
    get status(): string;
    private _stickySessions;
    get stickySessions(): DataDigitaloceanLoadbalancerStickySessionsList;
    get targetLoadBalancerIds(): string[];
    get type(): string;
    get urn(): string;
    get vpcUuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
