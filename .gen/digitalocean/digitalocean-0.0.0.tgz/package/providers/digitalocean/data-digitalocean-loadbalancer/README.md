# `data_digitalocean_loadbalancer`

Refer to the Terraform Registry for docs: [`data_digitalocean_loadbalancer`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/loadbalancer).
