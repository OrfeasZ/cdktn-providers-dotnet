import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanReservedIpv6Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/reserved_ipv6#id DataDigitaloceanReservedIpv6#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * reserved ipv6 address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/reserved_ipv6#ip DataDigitaloceanReservedIpv6#ip}
    */
    readonly ip: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/reserved_ipv6 digitalocean_reserved_ipv6}
*/
export declare class DataDigitaloceanReservedIpv6 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_reserved_ipv6";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanReservedIpv6 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanReservedIpv6 to import
    * @param importFromId The id of the existing DataDigitaloceanReservedIpv6 that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/reserved_ipv6#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanReservedIpv6 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/reserved_ipv6 digitalocean_reserved_ipv6} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanReservedIpv6Config
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanReservedIpv6Config);
    get dropletId(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    get regionSlug(): string;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
