import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiIndexingJobCancelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_indexing_job_cancel#id GradientaiIndexingJobCancel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The UUID of the indexing job to cancel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_indexing_job_cancel#uuid GradientaiIndexingJobCancel#uuid}
    */
    readonly uuid: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_indexing_job_cancel digitalocean_gradientai_indexing_job_cancel}
*/
export declare class GradientaiIndexingJobCancel extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_indexing_job_cancel";
    /**
    * Generates CDKTN code for importing a GradientaiIndexingJobCancel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiIndexingJobCancel to import
    * @param importFromId The id of the existing GradientaiIndexingJobCancel that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_indexing_job_cancel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiIndexingJobCancel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_indexing_job_cancel digitalocean_gradientai_indexing_job_cancel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiIndexingJobCancelConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiIndexingJobCancelConfig);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get status(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get totalItemsFailed(): number;
    get totalItemsIndexed(): number;
    get totalItemsSkipped(): number;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
