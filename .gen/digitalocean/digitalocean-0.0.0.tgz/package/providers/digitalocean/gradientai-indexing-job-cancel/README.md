# `digitalocean_gradientai_indexing_job_cancel`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_indexing_job_cancel`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_indexing_job_cancel).
