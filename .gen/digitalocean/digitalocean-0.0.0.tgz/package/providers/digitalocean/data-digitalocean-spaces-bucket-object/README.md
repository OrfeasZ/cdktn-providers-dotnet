# `data_digitalocean_spaces_bucket_object`

Refer to the Terraform Registry for docs: [`data_digitalocean_spaces_bucket_object`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_bucket_object).
