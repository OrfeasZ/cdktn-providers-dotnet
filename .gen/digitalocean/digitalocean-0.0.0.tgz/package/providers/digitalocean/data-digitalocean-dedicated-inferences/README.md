# `data_digitalocean_dedicated_inferences`

Refer to the Terraform Registry for docs: [`data_digitalocean_dedicated_inferences`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inferences).
