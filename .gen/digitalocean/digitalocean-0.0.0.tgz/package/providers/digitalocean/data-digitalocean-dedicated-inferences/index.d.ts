import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDedicatedInferencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#id DataDigitaloceanDedicatedInferences#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#filter DataDigitaloceanDedicatedInferences#filter}
    */
    readonly filter?: DataDigitaloceanDedicatedInferencesFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#sort DataDigitaloceanDedicatedInferences#sort}
    */
    readonly sort?: DataDigitaloceanDedicatedInferencesSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanDedicatedInferencesDedicatedInferences {
}
export declare function dataDigitaloceanDedicatedInferencesDedicatedInferencesToTerraform(struct?: DataDigitaloceanDedicatedInferencesDedicatedInferences): any;
export declare function dataDigitaloceanDedicatedInferencesDedicatedInferencesToHclTerraform(struct?: DataDigitaloceanDedicatedInferencesDedicatedInferences): any;
export declare class DataDigitaloceanDedicatedInferencesDedicatedInferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferencesDedicatedInferences | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferencesDedicatedInferences | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    get privateEndpointFqdn(): string;
    get providerModelId(): string[];
    get publicEndpointFqdn(): string;
    get region(): string;
    get status(): string;
    get updatedAt(): string;
    get vpcUuid(): string;
}
export declare class DataDigitaloceanDedicatedInferencesDedicatedInferencesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferencesDedicatedInferencesOutputReference;
}
export interface DataDigitaloceanDedicatedInferencesFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#all DataDigitaloceanDedicatedInferences#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#key DataDigitaloceanDedicatedInferences#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#match_by DataDigitaloceanDedicatedInferences#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#values DataDigitaloceanDedicatedInferences#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanDedicatedInferencesFilterToTerraform(struct?: DataDigitaloceanDedicatedInferencesFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanDedicatedInferencesFilterToHclTerraform(struct?: DataDigitaloceanDedicatedInferencesFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanDedicatedInferencesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferencesFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferencesFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanDedicatedInferencesFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDedicatedInferencesFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferencesFilterOutputReference;
}
export interface DataDigitaloceanDedicatedInferencesSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#direction DataDigitaloceanDedicatedInferences#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#key DataDigitaloceanDedicatedInferences#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanDedicatedInferencesSortToTerraform(struct?: DataDigitaloceanDedicatedInferencesSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanDedicatedInferencesSortToHclTerraform(struct?: DataDigitaloceanDedicatedInferencesSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanDedicatedInferencesSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferencesSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferencesSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanDedicatedInferencesSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDedicatedInferencesSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferencesSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences digitalocean_dedicated_inferences}
*/
export declare class DataDigitaloceanDedicatedInferences extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_dedicated_inferences";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDedicatedInferences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDedicatedInferences to import
    * @param importFromId The id of the existing DataDigitaloceanDedicatedInferences that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDedicatedInferences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inferences digitalocean_dedicated_inferences} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDedicatedInferencesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDedicatedInferencesConfig);
    private _dedicatedInferences;
    get dedicatedInferences(): DataDigitaloceanDedicatedInferencesDedicatedInferencesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanDedicatedInferencesFilterList;
    putFilter(value: DataDigitaloceanDedicatedInferencesFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanDedicatedInferencesFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanDedicatedInferencesSortList;
    putSort(value: DataDigitaloceanDedicatedInferencesSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanDedicatedInferencesSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
