# `data_digitalocean_partner_attachment`

Refer to the Terraform Registry for docs: [`data_digitalocean_partner_attachment`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/partner_attachment).
