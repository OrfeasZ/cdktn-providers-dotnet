import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanPartnerAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Partner Attachment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#id DataDigitaloceanPartnerAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Partner Attachment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#name DataDigitaloceanPartnerAttachment#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#redundancy_zone DataDigitaloceanPartnerAttachment#redundancy_zone}
    */
    readonly redundancyZone?: string;
    /**
    * bgp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#bgp DataDigitaloceanPartnerAttachment#bgp}
    */
    readonly bgp?: DataDigitaloceanPartnerAttachmentBgp;
}
export interface DataDigitaloceanPartnerAttachmentBgp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#local_router_ip DataDigitaloceanPartnerAttachment#local_router_ip}
    */
    readonly localRouterIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#peer_router_asn DataDigitaloceanPartnerAttachment#peer_router_asn}
    */
    readonly peerRouterAsn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#peer_router_ip DataDigitaloceanPartnerAttachment#peer_router_ip}
    */
    readonly peerRouterIp?: string;
}
export declare function dataDigitaloceanPartnerAttachmentBgpToTerraform(struct?: DataDigitaloceanPartnerAttachmentBgpOutputReference | DataDigitaloceanPartnerAttachmentBgp): any;
export declare function dataDigitaloceanPartnerAttachmentBgpToHclTerraform(struct?: DataDigitaloceanPartnerAttachmentBgpOutputReference | DataDigitaloceanPartnerAttachmentBgp): any;
export declare class DataDigitaloceanPartnerAttachmentBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanPartnerAttachmentBgp | undefined;
    set internalValue(value: DataDigitaloceanPartnerAttachmentBgp | undefined);
    private _localRouterIp?;
    get localRouterIp(): string;
    set localRouterIp(value: string);
    resetLocalRouterIp(): void;
    get localRouterIpInput(): string | undefined;
    private _peerRouterAsn?;
    get peerRouterAsn(): number;
    set peerRouterAsn(value: number);
    resetPeerRouterAsn(): void;
    get peerRouterAsnInput(): number | undefined;
    private _peerRouterIp?;
    get peerRouterIp(): string;
    set peerRouterIp(value: string);
    resetPeerRouterIp(): void;
    get peerRouterIpInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment digitalocean_partner_attachment}
*/
export declare class DataDigitaloceanPartnerAttachment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_partner_attachment";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanPartnerAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanPartnerAttachment to import
    * @param importFromId The id of the existing DataDigitaloceanPartnerAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanPartnerAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment digitalocean_partner_attachment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanPartnerAttachmentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanPartnerAttachmentConfig);
    get children(): string[];
    get connectionBandwidthInMbps(): number;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get naasProvider(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get parentUuid(): string;
    private _redundancyZone?;
    get redundancyZone(): string;
    set redundancyZone(value: string);
    resetRedundancyZone(): void;
    get redundancyZoneInput(): string | undefined;
    get region(): string;
    get state(): string;
    get vpcIds(): string[];
    private _bgp;
    get bgp(): DataDigitaloceanPartnerAttachmentBgpOutputReference;
    putBgp(value: DataDigitaloceanPartnerAttachmentBgp): void;
    resetBgp(): void;
    get bgpInput(): DataDigitaloceanPartnerAttachmentBgp | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
