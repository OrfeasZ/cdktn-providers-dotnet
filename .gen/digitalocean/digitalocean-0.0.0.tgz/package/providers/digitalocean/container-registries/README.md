# `digitalocean_container_registries`

Refer to the Terraform Registry for docs: [`digitalocean_container_registries`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registries).
