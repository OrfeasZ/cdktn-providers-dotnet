# `data_digitalocean_nfs`

Refer to the Terraform Registry for docs: [`data_digitalocean_nfs`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/nfs).
