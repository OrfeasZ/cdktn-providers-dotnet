import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseKafkaSchemaRegistryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry#cluster_id DatabaseKafkaSchemaRegistry#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry#id DatabaseKafkaSchemaRegistry#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry#schema DatabaseKafkaSchemaRegistry#schema}
    */
    readonly schema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry#schema_type DatabaseKafkaSchemaRegistry#schema_type}
    */
    readonly schemaType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry#subject_name DatabaseKafkaSchemaRegistry#subject_name}
    */
    readonly subjectName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry digitalocean_database_kafka_schema_registry}
*/
export declare class DatabaseKafkaSchemaRegistry extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_kafka_schema_registry";
    /**
    * Generates CDKTN code for importing a DatabaseKafkaSchemaRegistry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseKafkaSchemaRegistry to import
    * @param importFromId The id of the existing DatabaseKafkaSchemaRegistry that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseKafkaSchemaRegistry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_schema_registry digitalocean_database_kafka_schema_registry} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseKafkaSchemaRegistryConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseKafkaSchemaRegistryConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _schemaType?;
    get schemaType(): string;
    set schemaType(value: string);
    get schemaTypeInput(): string | undefined;
    private _subjectName?;
    get subjectName(): string;
    set subjectName(value: string);
    get subjectNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
