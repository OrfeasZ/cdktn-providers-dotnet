# `data_digitalocean_volume`

Refer to the Terraform Registry for docs: [`data_digitalocean_volume`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/volume).
