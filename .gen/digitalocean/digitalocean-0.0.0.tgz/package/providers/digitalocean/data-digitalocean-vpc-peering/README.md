# `data_digitalocean_vpc_peering`

Refer to the Terraform Registry for docs: [`data_digitalocean_vpc_peering`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering).
