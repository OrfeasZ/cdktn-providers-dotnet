import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanVpcPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the VPC Peering
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering#id DataDigitaloceanVpcPeering#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the VPC Peering
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering#name DataDigitaloceanVpcPeering#name}
    */
    readonly name?: string;
    /**
    * The list of VPCs to be peered
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering#vpc_ids DataDigitaloceanVpcPeering#vpc_ids}
    */
    readonly vpcIds?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering digitalocean_vpc_peering}
*/
export declare class DataDigitaloceanVpcPeering extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_vpc_peering";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanVpcPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanVpcPeering to import
    * @param importFromId The id of the existing DataDigitaloceanVpcPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanVpcPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/vpc_peering digitalocean_vpc_peering} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanVpcPeeringConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanVpcPeeringConfig);
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get status(): string;
    private _vpcIds?;
    get vpcIds(): string[];
    set vpcIds(value: string[]);
    resetVpcIds(): void;
    get vpcIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
