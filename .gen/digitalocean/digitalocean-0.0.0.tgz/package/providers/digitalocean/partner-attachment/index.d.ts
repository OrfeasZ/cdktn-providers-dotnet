import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PartnerAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The connection bandwidth in Mbps
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#connection_bandwidth_in_mbps PartnerAttachment#connection_bandwidth_in_mbps}
    */
    readonly connectionBandwidthInMbps: number;
    /**
    * The NaaS provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#naas_provider PartnerAttachment#naas_provider}
    */
    readonly naasProvider: string;
    /**
    * The name of the Partner Attachment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#name PartnerAttachment#name}
    */
    readonly name: string;
    /**
    * The UUID of the Parent Partner Attachment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#parent_uuid PartnerAttachment#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * The redundancy zone for the NaaS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#redundancy_zone PartnerAttachment#redundancy_zone}
    */
    readonly redundancyZone?: string;
    /**
    * The region where the Partner Attachment will be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#region PartnerAttachment#region}
    */
    readonly region: string;
    /**
    * The list of VPC IDs to attach the Partner Attachment to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#vpc_ids PartnerAttachment#vpc_ids}
    */
    readonly vpcIds: string[];
    /**
    * bgp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#bgp PartnerAttachment#bgp}
    */
    readonly bgp?: PartnerAttachmentBgp;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#timeouts PartnerAttachment#timeouts}
    */
    readonly timeouts?: PartnerAttachmentTimeouts;
}
export interface PartnerAttachmentBgp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#auth_key PartnerAttachment#auth_key}
    */
    readonly authKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#local_router_ip PartnerAttachment#local_router_ip}
    */
    readonly localRouterIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#peer_router_asn PartnerAttachment#peer_router_asn}
    */
    readonly peerRouterAsn?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#peer_router_ip PartnerAttachment#peer_router_ip}
    */
    readonly peerRouterIp?: string;
}
export declare function partnerAttachmentBgpToTerraform(struct?: PartnerAttachmentBgpOutputReference | PartnerAttachmentBgp): any;
export declare function partnerAttachmentBgpToHclTerraform(struct?: PartnerAttachmentBgpOutputReference | PartnerAttachmentBgp): any;
export declare class PartnerAttachmentBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PartnerAttachmentBgp | undefined;
    set internalValue(value: PartnerAttachmentBgp | undefined);
    private _authKey?;
    get authKey(): string;
    set authKey(value: string);
    resetAuthKey(): void;
    get authKeyInput(): string | undefined;
    private _localRouterIp?;
    get localRouterIp(): string;
    set localRouterIp(value: string);
    resetLocalRouterIp(): void;
    get localRouterIpInput(): string | undefined;
    private _peerRouterAsn?;
    get peerRouterAsn(): number;
    set peerRouterAsn(value: number);
    resetPeerRouterAsn(): void;
    get peerRouterAsnInput(): number | undefined;
    private _peerRouterIp?;
    get peerRouterIp(): string;
    set peerRouterIp(value: string);
    resetPeerRouterIp(): void;
    get peerRouterIpInput(): string | undefined;
}
export interface PartnerAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#create PartnerAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#delete PartnerAttachment#delete}
    */
    readonly delete?: string;
}
export declare function partnerAttachmentTimeoutsToTerraform(struct?: PartnerAttachmentTimeouts | cdktn.IResolvable): any;
export declare function partnerAttachmentTimeoutsToHclTerraform(struct?: PartnerAttachmentTimeouts | cdktn.IResolvable): any;
export declare class PartnerAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PartnerAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PartnerAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment digitalocean_partner_attachment}
*/
export declare class PartnerAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_partner_attachment";
    /**
    * Generates CDKTN code for importing a PartnerAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PartnerAttachment to import
    * @param importFromId The id of the existing PartnerAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PartnerAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/partner_attachment digitalocean_partner_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PartnerAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: PartnerAttachmentConfig);
    get children(): string[];
    private _connectionBandwidthInMbps?;
    get connectionBandwidthInMbps(): number;
    set connectionBandwidthInMbps(value: number);
    get connectionBandwidthInMbpsInput(): number | undefined;
    get createdAt(): string;
    get id(): string;
    private _naasProvider?;
    get naasProvider(): string;
    set naasProvider(value: string);
    get naasProviderInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _redundancyZone?;
    get redundancyZone(): string;
    set redundancyZone(value: string);
    resetRedundancyZone(): void;
    get redundancyZoneInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get state(): string;
    private _vpcIds?;
    get vpcIds(): string[];
    set vpcIds(value: string[]);
    get vpcIdsInput(): string[] | undefined;
    private _bgp;
    get bgp(): PartnerAttachmentBgpOutputReference;
    putBgp(value: PartnerAttachmentBgp): void;
    resetBgp(): void;
    get bgpInput(): PartnerAttachmentBgp | undefined;
    private _timeouts;
    get timeouts(): PartnerAttachmentTimeoutsOutputReference;
    putTimeouts(value: PartnerAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PartnerAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
