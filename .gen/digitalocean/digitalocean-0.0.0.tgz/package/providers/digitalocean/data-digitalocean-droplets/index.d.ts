import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDropletsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#gpus DataDigitaloceanDroplets#gpus}
    */
    readonly gpus?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#id DataDigitaloceanDroplets#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#filter DataDigitaloceanDroplets#filter}
    */
    readonly filter?: DataDigitaloceanDropletsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#sort DataDigitaloceanDroplets#sort}
    */
    readonly sort?: DataDigitaloceanDropletsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanDropletsDroplets {
}
export declare function dataDigitaloceanDropletsDropletsToTerraform(struct?: DataDigitaloceanDropletsDroplets): any;
export declare function dataDigitaloceanDropletsDropletsToHclTerraform(struct?: DataDigitaloceanDropletsDroplets): any;
export declare class DataDigitaloceanDropletsDropletsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDropletsDroplets | undefined;
    set internalValue(value: DataDigitaloceanDropletsDroplets | undefined);
    get backups(): cdktn.IResolvable;
    get createdAt(): string;
    get disk(): number;
    get id(): number;
    get image(): string;
    get ipv4Address(): string;
    get ipv4AddressPrivate(): string;
    get ipv6(): cdktn.IResolvable;
    get ipv6Address(): string;
    get ipv6AddressPrivate(): string;
    get locked(): cdktn.IResolvable;
    get memory(): number;
    get monitoring(): cdktn.IResolvable;
    get name(): string;
    get priceHourly(): number;
    get priceMonthly(): number;
    get privateNetworking(): cdktn.IResolvable;
    get region(): string;
    get size(): string;
    get status(): string;
    get tags(): string[];
    get urn(): string;
    get vcpus(): number;
    get volumeIds(): string[];
    get vpcUuid(): string;
}
export declare class DataDigitaloceanDropletsDropletsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDropletsDropletsOutputReference;
}
export interface DataDigitaloceanDropletsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#all DataDigitaloceanDroplets#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#key DataDigitaloceanDroplets#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#match_by DataDigitaloceanDroplets#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#values DataDigitaloceanDroplets#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanDropletsFilterToTerraform(struct?: DataDigitaloceanDropletsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanDropletsFilterToHclTerraform(struct?: DataDigitaloceanDropletsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanDropletsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDropletsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDropletsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanDropletsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDropletsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDropletsFilterOutputReference;
}
export interface DataDigitaloceanDropletsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#direction DataDigitaloceanDroplets#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#key DataDigitaloceanDroplets#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanDropletsSortToTerraform(struct?: DataDigitaloceanDropletsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanDropletsSortToHclTerraform(struct?: DataDigitaloceanDropletsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanDropletsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDropletsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDropletsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanDropletsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDropletsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDropletsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets digitalocean_droplets}
*/
export declare class DataDigitaloceanDroplets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_droplets";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDroplets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDroplets to import
    * @param importFromId The id of the existing DataDigitaloceanDroplets that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDroplets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/droplets digitalocean_droplets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDropletsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDropletsConfig);
    private _droplets;
    get droplets(): DataDigitaloceanDropletsDropletsList;
    private _gpus?;
    get gpus(): boolean | cdktn.IResolvable;
    set gpus(value: boolean | cdktn.IResolvable);
    resetGpus(): void;
    get gpusInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanDropletsFilterList;
    putFilter(value: DataDigitaloceanDropletsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanDropletsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanDropletsSortList;
    putSort(value: DataDigitaloceanDropletsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanDropletsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
