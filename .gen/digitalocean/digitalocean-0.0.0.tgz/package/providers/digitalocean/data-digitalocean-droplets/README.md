# `data_digitalocean_droplets`

Refer to the Terraform Registry for docs: [`data_digitalocean_droplets`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplets).
