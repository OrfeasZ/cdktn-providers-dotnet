# `data_digitalocean_kubernetes_versions`

Refer to the Terraform Registry for docs: [`data_digitalocean_kubernetes_versions`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_versions).
