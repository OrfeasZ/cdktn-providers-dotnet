import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanKubernetesVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/kubernetes_versions#id DataDigitaloceanKubernetesVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/kubernetes_versions#version_prefix DataDigitaloceanKubernetesVersions#version_prefix}
    */
    readonly versionPrefix?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/kubernetes_versions digitalocean_kubernetes_versions}
*/
export declare class DataDigitaloceanKubernetesVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_kubernetes_versions";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanKubernetesVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanKubernetesVersions to import
    * @param importFromId The id of the existing DataDigitaloceanKubernetesVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/kubernetes_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanKubernetesVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/kubernetes_versions digitalocean_kubernetes_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanKubernetesVersionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanKubernetesVersionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestVersion(): string;
    get validVersions(): string[];
    private _versionPrefix?;
    get versionPrefix(): string;
    set versionPrefix(value: string);
    resetVersionPrefix(): void;
    get versionPrefixInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
