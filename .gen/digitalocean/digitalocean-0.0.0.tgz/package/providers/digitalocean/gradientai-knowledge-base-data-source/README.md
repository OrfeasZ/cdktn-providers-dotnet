# `digitalocean_gradientai_knowledge_base_data_source`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_knowledge_base_data_source`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_knowledge_base_data_source).
