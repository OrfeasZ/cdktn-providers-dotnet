import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiKnowledgeBaseDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#id GradientaiKnowledgeBaseDataSource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#knowledge_base_uuid GradientaiKnowledgeBaseDataSource#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
    /**
    * spaces_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#spaces_data_source GradientaiKnowledgeBaseDataSource#spaces_data_source}
    */
    readonly spacesDataSource?: GradientaiKnowledgeBaseDataSourceSpacesDataSource;
    /**
    * web_crawler_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#web_crawler_data_source GradientaiKnowledgeBaseDataSource#web_crawler_data_source}
    */
    readonly webCrawlerDataSource?: GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource;
}
export interface GradientaiKnowledgeBaseDataSourceSpacesDataSource {
    /**
    * The name of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#bucket_name GradientaiKnowledgeBaseDataSource#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The path to the item in the bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#item_path GradientaiKnowledgeBaseDataSource#item_path}
    */
    readonly itemPath?: string;
    /**
    * The region of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#region GradientaiKnowledgeBaseDataSource#region}
    */
    readonly region?: string;
}
export declare function gradientaiKnowledgeBaseDataSourceSpacesDataSourceToTerraform(struct?: GradientaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference | GradientaiKnowledgeBaseDataSourceSpacesDataSource): any;
export declare function gradientaiKnowledgeBaseDataSourceSpacesDataSourceToHclTerraform(struct?: GradientaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference | GradientaiKnowledgeBaseDataSourceSpacesDataSource): any;
export declare class GradientaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GradientaiKnowledgeBaseDataSourceSpacesDataSource | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDataSourceSpacesDataSource | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _itemPath?;
    get itemPath(): string;
    set itemPath(value: string);
    resetItemPath(): void;
    get itemPathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource {
    /**
    * The base URL to crawl
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#base_url GradientaiKnowledgeBaseDataSource#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Options for specifying how URLs found on pages should be handled.
    * - UNKNOWN: Default unknown value
    * - SCOPED: Only include the base URL.
    * - PATH: Crawl the base URL and linked pages within the URL path.
    * - DOMAIN: Crawl the base URL and linked pages within the same domain.
    * - SUBDOMAINS: Crawl the base URL and linked pages for any subdomain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#crawling_option GradientaiKnowledgeBaseDataSource#crawling_option}
    */
    readonly crawlingOption?: string;
    /**
    * Whether to embed media content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#embed_media GradientaiKnowledgeBaseDataSource#embed_media}
    */
    readonly embedMedia?: boolean | cdktn.IResolvable;
}
export declare function gradientaiKnowledgeBaseDataSourceWebCrawlerDataSourceToTerraform(struct?: GradientaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference | GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource): any;
export declare function gradientaiKnowledgeBaseDataSourceWebCrawlerDataSourceToHclTerraform(struct?: GradientaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference | GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource): any;
export declare class GradientaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource | undefined;
    set internalValue(value: GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource | undefined);
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _crawlingOption?;
    get crawlingOption(): string;
    set crawlingOption(value: string);
    resetCrawlingOption(): void;
    get crawlingOptionInput(): string | undefined;
    private _embedMedia?;
    get embedMedia(): boolean | cdktn.IResolvable;
    set embedMedia(value: boolean | cdktn.IResolvable);
    resetEmbedMedia(): void;
    get embedMediaInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source digitalocean_gradientai_knowledge_base_data_source}
*/
export declare class GradientaiKnowledgeBaseDataSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_knowledge_base_data_source";
    /**
    * Generates CDKTN code for importing a GradientaiKnowledgeBaseDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiKnowledgeBaseDataSource to import
    * @param importFromId The id of the existing GradientaiKnowledgeBaseDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiKnowledgeBaseDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_knowledge_base_data_source digitalocean_gradientai_knowledge_base_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiKnowledgeBaseDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiKnowledgeBaseDataSourceConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    private _spacesDataSource;
    get spacesDataSource(): GradientaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference;
    putSpacesDataSource(value: GradientaiKnowledgeBaseDataSourceSpacesDataSource): void;
    resetSpacesDataSource(): void;
    get spacesDataSourceInput(): GradientaiKnowledgeBaseDataSourceSpacesDataSource | undefined;
    private _webCrawlerDataSource;
    get webCrawlerDataSource(): GradientaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference;
    putWebCrawlerDataSource(value: GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource): void;
    resetWebCrawlerDataSource(): void;
    get webCrawlerDataSourceInput(): GradientaiKnowledgeBaseDataSourceWebCrawlerDataSource | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
