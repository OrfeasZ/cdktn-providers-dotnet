import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional Anthropic API key ID to use with Anthropic models
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#anthropic_key_uuid GradientaiAgent#anthropic_key_uuid}
    */
    readonly anthropicKeyUuid?: string;
    /**
    * Timestamp when the Agent was created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_at GradientaiAgent#created_at}
    */
    readonly createdAt?: string;
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#id GradientaiAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If case condition
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#if_case GradientaiAgent#if_case}
    */
    readonly ifCase?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#instruction GradientaiAgent#instruction}
    */
    readonly instruction: string;
    /**
    * K value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#k GradientaiAgent#k}
    */
    readonly k?: number;
    /**
    * Ids of the knowledge base(s) to attach to the agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#knowledge_base_uuid GradientaiAgent#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid?: string[];
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#max_tokens GradientaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Model UUID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#model_uuid GradientaiAgent#model_uuid}
    */
    readonly modelUuid: string;
    /**
    * Name of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name: string;
    /**
    * Optional OpenAI API key ID to use with OpenAI models
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#open_ai_key_uuid GradientaiAgent#open_ai_key_uuid}
    */
    readonly openAiKeyUuid?: string;
    /**
    * Project ID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#project_id GradientaiAgent#project_id}
    */
    readonly projectId: string;
    /**
    * Indicates if the agent should provide citations in responses
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#provide_citations GradientaiAgent#provide_citations}
    */
    readonly provideCitations?: boolean | cdktn.IResolvable;
    /**
    * Region where the Agent is deployed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#region GradientaiAgent#region}
    */
    readonly region: string;
    /**
    * Retrieval method used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#retrieval_method GradientaiAgent#retrieval_method}
    */
    readonly retrievalMethod?: string;
    /**
    * User who created the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#route_created_by GradientaiAgent#route_created_by}
    */
    readonly routeCreatedBy?: string;
    /**
    * Route name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#route_name GradientaiAgent#route_name}
    */
    readonly routeName?: string;
    /**
    * Route UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#route_uuid GradientaiAgent#route_uuid}
    */
    readonly routeUuid?: string;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#tags GradientaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#temperature GradientaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#top_p GradientaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * URL for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * User ID linked with the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#user_id GradientaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * Identifier for the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#workspace_uuid GradientaiAgent#workspace_uuid}
    */
    readonly workspaceUuid?: string;
    /**
    * agent_guardrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#agent_guardrail GradientaiAgent#agent_guardrail}
    */
    readonly agentGuardrail?: GradientaiAgentAgentGuardrail[] | cdktn.IResolvable;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#anthropic_api_key GradientaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: GradientaiAgentAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key_infos GradientaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: GradientaiAgentApiKeyInfos[] | cdktn.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_keys GradientaiAgent#api_keys}
    */
    readonly apiKeys?: GradientaiAgentApiKeys[] | cdktn.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#chatbot GradientaiAgent#chatbot}
    */
    readonly chatbot?: GradientaiAgentChatbot[] | cdktn.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#chatbot_identifiers GradientaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: GradientaiAgentChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * child_agents block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#child_agents GradientaiAgent#child_agents}
    */
    readonly childAgents?: GradientaiAgentChildAgents[] | cdktn.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#deployment GradientaiAgent#deployment}
    */
    readonly deployment?: GradientaiAgentDeployment[] | cdktn.IResolvable;
    /**
    * functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#functions GradientaiAgent#functions}
    */
    readonly functions?: GradientaiAgentFunctions[] | cdktn.IResolvable;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#knowledge_bases GradientaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: GradientaiAgentKnowledgeBases[] | cdktn.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#model GradientaiAgent#model}
    */
    readonly model?: GradientaiAgentModel[] | cdktn.IResolvable;
    /**
    * open_ai_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#open_ai_api_key GradientaiAgent#open_ai_api_key}
    */
    readonly openAiApiKey?: GradientaiAgentOpenAiApiKey[] | cdktn.IResolvable;
    /**
    * parent_agents block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#parent_agents GradientaiAgent#parent_agents}
    */
    readonly parentAgents?: GradientaiAgentParentAgents[] | cdktn.IResolvable;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#template GradientaiAgent#template}
    */
    readonly template?: GradientaiAgentTemplate[] | cdktn.IResolvable;
}
export interface GradientaiAgentAgentGuardrail {
    /**
    * Agent UUID for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#agent_uuid GradientaiAgent#agent_uuid}
    */
    readonly agentUuid?: string;
    /**
    * Default response for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#default_response GradientaiAgent#default_response}
    */
    readonly defaultResponse?: string;
    /**
    * Description of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#guardrail_uuid GradientaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Indicates if the Guardrail is default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#is_default GradientaiAgent#is_default}
    */
    readonly isDefault?: boolean | cdktn.IResolvable;
    /**
    * Name of Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Priority of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#priority GradientaiAgent#priority}
    */
    readonly priority?: number;
    /**
    * Type of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#type GradientaiAgent#type}
    */
    readonly type?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentAgentGuardrailToTerraform(struct?: GradientaiAgentAgentGuardrail | cdktn.IResolvable): any;
export declare function gradientaiAgentAgentGuardrailToHclTerraform(struct?: GradientaiAgentAgentGuardrail | cdktn.IResolvable): any;
export declare class GradientaiAgentAgentGuardrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentAgentGuardrail | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentAgentGuardrail | cdktn.IResolvable | undefined);
    private _agentUuid?;
    get agentUuid(): string;
    set agentUuid(value: string);
    resetAgentUuid(): void;
    get agentUuidInput(): string | undefined;
    get createdAt(): string;
    private _defaultResponse?;
    get defaultResponse(): string;
    set defaultResponse(value: string);
    resetDefaultResponse(): void;
    get defaultResponseInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    get isAttached(): cdktn.IResolvable;
    private _isDefault?;
    get isDefault(): boolean | cdktn.IResolvable;
    set isDefault(value: boolean | cdktn.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentAgentGuardrailList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentAgentGuardrail[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentAgentGuardrailOutputReference;
}
export interface GradientaiAgentAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentAnthropicApiKeyToTerraform(struct?: GradientaiAgentAnthropicApiKey | cdktn.IResolvable): any;
export declare function gradientaiAgentAnthropicApiKeyToHclTerraform(struct?: GradientaiAgentAnthropicApiKey | cdktn.IResolvable): any;
export declare class GradientaiAgentAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentAnthropicApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentAnthropicApiKey | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentAnthropicApiKeyList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentAnthropicApiKeyOutputReference;
}
export interface GradientaiAgentApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#secret_key GradientaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentApiKeyInfosToTerraform(struct?: GradientaiAgentApiKeyInfos | cdktn.IResolvable): any;
export declare function gradientaiAgentApiKeyInfosToHclTerraform(struct?: GradientaiAgentApiKeyInfos | cdktn.IResolvable): any;
export declare class GradientaiAgentApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentApiKeyInfos | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentApiKeyInfos | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentApiKeyInfosList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentApiKeyInfos[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentApiKeyInfosOutputReference;
}
export interface GradientaiAgentApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key GradientaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function gradientaiAgentApiKeysToTerraform(struct?: GradientaiAgentApiKeys | cdktn.IResolvable): any;
export declare function gradientaiAgentApiKeysToHclTerraform(struct?: GradientaiAgentApiKeys | cdktn.IResolvable): any;
export declare class GradientaiAgentApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentApiKeys | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentApiKeys | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class GradientaiAgentApiKeysList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentApiKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentApiKeysOutputReference;
}
export interface GradientaiAgentChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#button_background_color GradientaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#logo GradientaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#primary_color GradientaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#secondary_color GradientaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#starting_message GradientaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function gradientaiAgentChatbotToTerraform(struct?: GradientaiAgentChatbot | cdktn.IResolvable): any;
export declare function gradientaiAgentChatbotToHclTerraform(struct?: GradientaiAgentChatbot | cdktn.IResolvable): any;
export declare class GradientaiAgentChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChatbot | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChatbot | cdktn.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class GradientaiAgentChatbotList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChatbot[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChatbotOutputReference;
}
export interface GradientaiAgentChatbotIdentifiers {
}
export declare function gradientaiAgentChatbotIdentifiersToTerraform(struct?: GradientaiAgentChatbotIdentifiers | cdktn.IResolvable): any;
export declare function gradientaiAgentChatbotIdentifiersToHclTerraform(struct?: GradientaiAgentChatbotIdentifiers | cdktn.IResolvable): any;
export declare class GradientaiAgentChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChatbotIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChatbotIdentifiers | cdktn.IResolvable | undefined);
    get chatbotId(): string;
}
export declare class GradientaiAgentChatbotIdentifiersList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChatbotIdentifiersOutputReference;
}
export interface GradientaiAgentChildAgentsAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentChildAgentsAnthropicApiKeyToTerraform(struct?: GradientaiAgentChildAgentsAnthropicApiKey | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsAnthropicApiKeyToHclTerraform(struct?: GradientaiAgentChildAgentsAnthropicApiKey | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgentsAnthropicApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgentsAnthropicApiKey | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentChildAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgentsAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsAnthropicApiKeyOutputReference;
}
export interface GradientaiAgentChildAgentsApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#secret_key GradientaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentChildAgentsApiKeyInfosToTerraform(struct?: GradientaiAgentChildAgentsApiKeyInfos | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsApiKeyInfosToHclTerraform(struct?: GradientaiAgentChildAgentsApiKeyInfos | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgentsApiKeyInfos | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgentsApiKeyInfos | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentChildAgentsApiKeyInfosList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgentsApiKeyInfos[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsApiKeyInfosOutputReference;
}
export interface GradientaiAgentChildAgentsApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key GradientaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function gradientaiAgentChildAgentsApiKeysToTerraform(struct?: GradientaiAgentChildAgentsApiKeys | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsApiKeysToHclTerraform(struct?: GradientaiAgentChildAgentsApiKeys | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgentsApiKeys | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgentsApiKeys | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class GradientaiAgentChildAgentsApiKeysList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgentsApiKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsApiKeysOutputReference;
}
export interface GradientaiAgentChildAgentsChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#button_background_color GradientaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#logo GradientaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#primary_color GradientaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#secondary_color GradientaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#starting_message GradientaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function gradientaiAgentChildAgentsChatbotToTerraform(struct?: GradientaiAgentChildAgentsChatbot | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsChatbotToHclTerraform(struct?: GradientaiAgentChildAgentsChatbot | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgentsChatbot | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgentsChatbot | cdktn.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class GradientaiAgentChildAgentsChatbotList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgentsChatbot[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsChatbotOutputReference;
}
export interface GradientaiAgentChildAgentsChatbotIdentifiers {
}
export declare function gradientaiAgentChildAgentsChatbotIdentifiersToTerraform(struct?: GradientaiAgentChildAgentsChatbotIdentifiers | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsChatbotIdentifiersToHclTerraform(struct?: GradientaiAgentChildAgentsChatbotIdentifiers | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgentsChatbotIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgentsChatbotIdentifiers | cdktn.IResolvable | undefined);
    get chatbotId(): string;
}
export declare class GradientaiAgentChildAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgentsChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsChatbotIdentifiersOutputReference;
}
export interface GradientaiAgentChildAgentsDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#status GradientaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#visibility GradientaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function gradientaiAgentChildAgentsDeploymentToTerraform(struct?: GradientaiAgentChildAgentsDeployment | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsDeploymentToHclTerraform(struct?: GradientaiAgentChildAgentsDeployment | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgentsDeployment | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgentsDeployment | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class GradientaiAgentChildAgentsDeploymentList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgentsDeployment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsDeploymentOutputReference;
}
export interface GradientaiAgentChildAgents {
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#instruction GradientaiAgent#instruction}
    */
    readonly instruction: string;
    /**
    * Model UUID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#model_uuid GradientaiAgent#model_uuid}
    */
    readonly modelUuid: string;
    /**
    * Name of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name: string;
    /**
    * Project ID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#project_id GradientaiAgent#project_id}
    */
    readonly projectId: string;
    /**
    * Region where the Agent is deployed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#region GradientaiAgent#region}
    */
    readonly region: string;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#anthropic_api_key GradientaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: GradientaiAgentChildAgentsAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key_infos GradientaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: GradientaiAgentChildAgentsApiKeyInfos[] | cdktn.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_keys GradientaiAgent#api_keys}
    */
    readonly apiKeys?: GradientaiAgentChildAgentsApiKeys[] | cdktn.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#chatbot GradientaiAgent#chatbot}
    */
    readonly chatbot?: GradientaiAgentChildAgentsChatbot[] | cdktn.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#chatbot_identifiers GradientaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: GradientaiAgentChildAgentsChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#deployment GradientaiAgent#deployment}
    */
    readonly deployment?: GradientaiAgentChildAgentsDeployment[] | cdktn.IResolvable;
}
export declare function gradientaiAgentChildAgentsToTerraform(struct?: GradientaiAgentChildAgents | cdktn.IResolvable): any;
export declare function gradientaiAgentChildAgentsToHclTerraform(struct?: GradientaiAgentChildAgents | cdktn.IResolvable): any;
export declare class GradientaiAgentChildAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentChildAgents | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentChildAgents | cdktn.IResolvable | undefined);
    get agentId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    get instructionInput(): string | undefined;
    private _modelUuid?;
    get modelUuid(): string;
    set modelUuid(value: string);
    get modelUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): GradientaiAgentChildAgentsAnthropicApiKeyList;
    putAnthropicApiKey(value: GradientaiAgentChildAgentsAnthropicApiKey[] | cdktn.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktn.IResolvable | GradientaiAgentChildAgentsAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): GradientaiAgentChildAgentsApiKeyInfosList;
    putApiKeyInfos(value: GradientaiAgentChildAgentsApiKeyInfos[] | cdktn.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktn.IResolvable | GradientaiAgentChildAgentsApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): GradientaiAgentChildAgentsApiKeysList;
    putApiKeys(value: GradientaiAgentChildAgentsApiKeys[] | cdktn.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktn.IResolvable | GradientaiAgentChildAgentsApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): GradientaiAgentChildAgentsChatbotList;
    putChatbot(value: GradientaiAgentChildAgentsChatbot[] | cdktn.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktn.IResolvable | GradientaiAgentChildAgentsChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): GradientaiAgentChildAgentsChatbotIdentifiersList;
    putChatbotIdentifiers(value: GradientaiAgentChildAgentsChatbotIdentifiers[] | cdktn.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktn.IResolvable | GradientaiAgentChildAgentsChatbotIdentifiers[] | undefined;
    private _deployment;
    get deployment(): GradientaiAgentChildAgentsDeploymentList;
    putDeployment(value: GradientaiAgentChildAgentsDeployment[] | cdktn.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktn.IResolvable | GradientaiAgentChildAgentsDeployment[] | undefined;
}
export declare class GradientaiAgentChildAgentsList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentChildAgents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentChildAgentsOutputReference;
}
export interface GradientaiAgentDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#status GradientaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#visibility GradientaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function gradientaiAgentDeploymentToTerraform(struct?: GradientaiAgentDeployment | cdktn.IResolvable): any;
export declare function gradientaiAgentDeploymentToHclTerraform(struct?: GradientaiAgentDeployment | cdktn.IResolvable): any;
export declare class GradientaiAgentDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentDeployment | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentDeployment | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class GradientaiAgentDeploymentList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentDeployment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentDeploymentOutputReference;
}
export interface GradientaiAgentFunctions {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key GradientaiAgent#api_key}
    */
    readonly apiKey?: string;
    /**
    * Description of the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#faasname GradientaiAgent#faasname}
    */
    readonly faasname?: string;
    /**
    * Namespace of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#faasnamespace GradientaiAgent#faasnamespace}
    */
    readonly faasnamespace?: string;
    /**
    * Guardrail UUID for the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#guardrail_uuid GradientaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentFunctionsToTerraform(struct?: GradientaiAgentFunctions | cdktn.IResolvable): any;
export declare function gradientaiAgentFunctionsToHclTerraform(struct?: GradientaiAgentFunctions | cdktn.IResolvable): any;
export declare class GradientaiAgentFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentFunctions | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _faasname?;
    get faasname(): string;
    set faasname(value: string);
    resetFaasname(): void;
    get faasnameInput(): string | undefined;
    private _faasnamespace?;
    get faasnamespace(): string;
    set faasnamespace(value: string);
    resetFaasnamespace(): void;
    get faasnamespaceInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentFunctionsList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentFunctionsOutputReference;
}
export interface GradientaiAgentKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#completed_datasources GradientaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#data_source_uuids GradientaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#phase GradientaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#tokens GradientaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#total_datasources GradientaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentKnowledgeBasesLastIndexingJobToTerraform(struct?: GradientaiAgentKnowledgeBasesLastIndexingJobOutputReference | GradientaiAgentKnowledgeBasesLastIndexingJob): any;
export declare function gradientaiAgentKnowledgeBasesLastIndexingJobToHclTerraform(struct?: GradientaiAgentKnowledgeBasesLastIndexingJobOutputReference | GradientaiAgentKnowledgeBasesLastIndexingJob): any;
export declare class GradientaiAgentKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GradientaiAgentKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: GradientaiAgentKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface GradientaiAgentKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#database_id GradientaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#embedding_model_uuid GradientaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#is_public GradientaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#project_id GradientaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#region GradientaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#tags GradientaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#user_id GradientaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#last_indexing_job GradientaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: GradientaiAgentKnowledgeBasesLastIndexingJob;
}
export declare function gradientaiAgentKnowledgeBasesToTerraform(struct?: GradientaiAgentKnowledgeBases | cdktn.IResolvable): any;
export declare function gradientaiAgentKnowledgeBasesToHclTerraform(struct?: GradientaiAgentKnowledgeBases | cdktn.IResolvable): any;
export declare class GradientaiAgentKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentKnowledgeBases | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentKnowledgeBases | cdktn.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktn.IResolvable;
    set isPublic(value: boolean | cdktn.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): GradientaiAgentKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: GradientaiAgentKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): GradientaiAgentKnowledgeBasesLastIndexingJob | undefined;
}
export declare class GradientaiAgentKnowledgeBasesList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentKnowledgeBases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentKnowledgeBasesOutputReference;
}
export interface GradientaiAgentModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentModelAgreementToTerraform(struct?: GradientaiAgentModelAgreement | cdktn.IResolvable): any;
export declare function gradientaiAgentModelAgreementToHclTerraform(struct?: GradientaiAgentModelAgreement | cdktn.IResolvable): any;
export declare class GradientaiAgentModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentModelAgreement | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentModelAgreement | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentModelAgreementList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentModelAgreement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentModelAgreementOutputReference;
}
export interface GradientaiAgentModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#major GradientaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#minor GradientaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#patch GradientaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function gradientaiAgentModelVersionsToTerraform(struct?: GradientaiAgentModelVersions | cdktn.IResolvable): any;
export declare function gradientaiAgentModelVersionsToHclTerraform(struct?: GradientaiAgentModelVersions | cdktn.IResolvable): any;
export declare class GradientaiAgentModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentModelVersions | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentModelVersions | cdktn.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class GradientaiAgentModelVersionsList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentModelVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentModelVersionsOutputReference;
}
export interface GradientaiAgentModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#inference_name GradientaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#inference_version GradientaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#is_foundational GradientaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#parent_uuid GradientaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#provider GradientaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#upload_complete GradientaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktn.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#usecases GradientaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#agreement GradientaiAgent#agreement}
    */
    readonly agreement?: GradientaiAgentModelAgreement[] | cdktn.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#versions GradientaiAgent#versions}
    */
    readonly versions?: GradientaiAgentModelVersions[] | cdktn.IResolvable;
}
export declare function gradientaiAgentModelToTerraform(struct?: GradientaiAgentModel | cdktn.IResolvable): any;
export declare function gradientaiAgentModelToHclTerraform(struct?: GradientaiAgentModel | cdktn.IResolvable): any;
export declare class GradientaiAgentModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentModel | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentModel | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktn.IResolvable;
    set isFoundational(value: boolean | cdktn.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktn.IResolvable;
    set uploadComplete(value: boolean | cdktn.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): GradientaiAgentModelAgreementList;
    putAgreement(value: GradientaiAgentModelAgreement[] | cdktn.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktn.IResolvable | GradientaiAgentModelAgreement[] | undefined;
    private _versions;
    get versions(): GradientaiAgentModelVersionsList;
    putVersions(value: GradientaiAgentModelVersions[] | cdktn.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktn.IResolvable | GradientaiAgentModelVersions[] | undefined;
}
export declare class GradientaiAgentModelList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentModelOutputReference;
}
export interface GradientaiAgentOpenAiApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentOpenAiApiKeyToTerraform(struct?: GradientaiAgentOpenAiApiKey | cdktn.IResolvable): any;
export declare function gradientaiAgentOpenAiApiKeyToHclTerraform(struct?: GradientaiAgentOpenAiApiKey | cdktn.IResolvable): any;
export declare class GradientaiAgentOpenAiApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentOpenAiApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentOpenAiApiKey | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentOpenAiApiKeyList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentOpenAiApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentOpenAiApiKeyOutputReference;
}
export interface GradientaiAgentParentAgentsAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentParentAgentsAnthropicApiKeyToTerraform(struct?: GradientaiAgentParentAgentsAnthropicApiKey | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsAnthropicApiKeyToHclTerraform(struct?: GradientaiAgentParentAgentsAnthropicApiKey | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgentsAnthropicApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgentsAnthropicApiKey | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentParentAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgentsAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsAnthropicApiKeyOutputReference;
}
export interface GradientaiAgentParentAgentsApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#created_by GradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#secret_key GradientaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentParentAgentsApiKeyInfosToTerraform(struct?: GradientaiAgentParentAgentsApiKeyInfos | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsApiKeyInfosToHclTerraform(struct?: GradientaiAgentParentAgentsApiKeyInfos | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgentsApiKeyInfos | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgentsApiKeyInfos | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentParentAgentsApiKeyInfosList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgentsApiKeyInfos[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsApiKeyInfosOutputReference;
}
export interface GradientaiAgentParentAgentsApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key GradientaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function gradientaiAgentParentAgentsApiKeysToTerraform(struct?: GradientaiAgentParentAgentsApiKeys | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsApiKeysToHclTerraform(struct?: GradientaiAgentParentAgentsApiKeys | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgentsApiKeys | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgentsApiKeys | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class GradientaiAgentParentAgentsApiKeysList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgentsApiKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsApiKeysOutputReference;
}
export interface GradientaiAgentParentAgentsChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#button_background_color GradientaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#logo GradientaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#primary_color GradientaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#secondary_color GradientaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#starting_message GradientaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function gradientaiAgentParentAgentsChatbotToTerraform(struct?: GradientaiAgentParentAgentsChatbot | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsChatbotToHclTerraform(struct?: GradientaiAgentParentAgentsChatbot | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgentsChatbot | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgentsChatbot | cdktn.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class GradientaiAgentParentAgentsChatbotList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgentsChatbot[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsChatbotOutputReference;
}
export interface GradientaiAgentParentAgentsChatbotIdentifiers {
}
export declare function gradientaiAgentParentAgentsChatbotIdentifiersToTerraform(struct?: GradientaiAgentParentAgentsChatbotIdentifiers | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsChatbotIdentifiersToHclTerraform(struct?: GradientaiAgentParentAgentsChatbotIdentifiers | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgentsChatbotIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgentsChatbotIdentifiers | cdktn.IResolvable | undefined);
    get chatbotId(): string;
}
export declare class GradientaiAgentParentAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgentsChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsChatbotIdentifiersOutputReference;
}
export interface GradientaiAgentParentAgentsDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#status GradientaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#visibility GradientaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function gradientaiAgentParentAgentsDeploymentToTerraform(struct?: GradientaiAgentParentAgentsDeployment | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsDeploymentToHclTerraform(struct?: GradientaiAgentParentAgentsDeployment | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgentsDeployment | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgentsDeployment | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class GradientaiAgentParentAgentsDeploymentList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgentsDeployment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsDeploymentOutputReference;
}
export interface GradientaiAgentParentAgents {
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#instruction GradientaiAgent#instruction}
    */
    readonly instruction: string;
    /**
    * Model UUID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#model_uuid GradientaiAgent#model_uuid}
    */
    readonly modelUuid: string;
    /**
    * Name of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name: string;
    /**
    * Project ID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#project_id GradientaiAgent#project_id}
    */
    readonly projectId: string;
    /**
    * Region where the Agent is deployed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#region GradientaiAgent#region}
    */
    readonly region: string;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#anthropic_api_key GradientaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: GradientaiAgentParentAgentsAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_key_infos GradientaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: GradientaiAgentParentAgentsApiKeyInfos[] | cdktn.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#api_keys GradientaiAgent#api_keys}
    */
    readonly apiKeys?: GradientaiAgentParentAgentsApiKeys[] | cdktn.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#chatbot GradientaiAgent#chatbot}
    */
    readonly chatbot?: GradientaiAgentParentAgentsChatbot[] | cdktn.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#chatbot_identifiers GradientaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: GradientaiAgentParentAgentsChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#deployment GradientaiAgent#deployment}
    */
    readonly deployment?: GradientaiAgentParentAgentsDeployment[] | cdktn.IResolvable;
}
export declare function gradientaiAgentParentAgentsToTerraform(struct?: GradientaiAgentParentAgents | cdktn.IResolvable): any;
export declare function gradientaiAgentParentAgentsToHclTerraform(struct?: GradientaiAgentParentAgents | cdktn.IResolvable): any;
export declare class GradientaiAgentParentAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentParentAgents | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentParentAgents | cdktn.IResolvable | undefined);
    get agentId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    get instructionInput(): string | undefined;
    private _modelUuid?;
    get modelUuid(): string;
    set modelUuid(value: string);
    get modelUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): GradientaiAgentParentAgentsAnthropicApiKeyList;
    putAnthropicApiKey(value: GradientaiAgentParentAgentsAnthropicApiKey[] | cdktn.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktn.IResolvable | GradientaiAgentParentAgentsAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): GradientaiAgentParentAgentsApiKeyInfosList;
    putApiKeyInfos(value: GradientaiAgentParentAgentsApiKeyInfos[] | cdktn.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktn.IResolvable | GradientaiAgentParentAgentsApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): GradientaiAgentParentAgentsApiKeysList;
    putApiKeys(value: GradientaiAgentParentAgentsApiKeys[] | cdktn.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktn.IResolvable | GradientaiAgentParentAgentsApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): GradientaiAgentParentAgentsChatbotList;
    putChatbot(value: GradientaiAgentParentAgentsChatbot[] | cdktn.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktn.IResolvable | GradientaiAgentParentAgentsChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): GradientaiAgentParentAgentsChatbotIdentifiersList;
    putChatbotIdentifiers(value: GradientaiAgentParentAgentsChatbotIdentifiers[] | cdktn.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktn.IResolvable | GradientaiAgentParentAgentsChatbotIdentifiers[] | undefined;
    private _deployment;
    get deployment(): GradientaiAgentParentAgentsDeploymentList;
    putDeployment(value: GradientaiAgentParentAgentsDeployment[] | cdktn.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktn.IResolvable | GradientaiAgentParentAgentsDeployment[] | undefined;
}
export declare class GradientaiAgentParentAgentsList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentParentAgents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentParentAgentsOutputReference;
}
export interface GradientaiAgentTemplateKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#completed_datasources GradientaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#data_source_uuids GradientaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#phase GradientaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#tokens GradientaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#total_datasources GradientaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: GradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | GradientaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare function gradientaiAgentTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: GradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | GradientaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare class GradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GradientaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: GradientaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface GradientaiAgentTemplateKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#database_id GradientaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#embedding_model_uuid GradientaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#is_public GradientaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#project_id GradientaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#region GradientaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#tags GradientaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#user_id GradientaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#last_indexing_job GradientaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: GradientaiAgentTemplateKnowledgeBasesLastIndexingJob;
}
export declare function gradientaiAgentTemplateKnowledgeBasesToTerraform(struct?: GradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable): any;
export declare function gradientaiAgentTemplateKnowledgeBasesToHclTerraform(struct?: GradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable): any;
export declare class GradientaiAgentTemplateKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktn.IResolvable;
    set isPublic(value: boolean | cdktn.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): GradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: GradientaiAgentTemplateKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): GradientaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
}
export declare class GradientaiAgentTemplateKnowledgeBasesList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentTemplateKnowledgeBases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentTemplateKnowledgeBasesOutputReference;
}
export interface GradientaiAgentTemplateModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiAgentTemplateModelAgreementToTerraform(struct?: GradientaiAgentTemplateModelAgreement | cdktn.IResolvable): any;
export declare function gradientaiAgentTemplateModelAgreementToHclTerraform(struct?: GradientaiAgentTemplateModelAgreement | cdktn.IResolvable): any;
export declare class GradientaiAgentTemplateModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentTemplateModelAgreement | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentTemplateModelAgreement | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiAgentTemplateModelAgreementList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentTemplateModelAgreement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentTemplateModelAgreementOutputReference;
}
export interface GradientaiAgentTemplateModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#major GradientaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#minor GradientaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#patch GradientaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function gradientaiAgentTemplateModelVersionsToTerraform(struct?: GradientaiAgentTemplateModelVersions | cdktn.IResolvable): any;
export declare function gradientaiAgentTemplateModelVersionsToHclTerraform(struct?: GradientaiAgentTemplateModelVersions | cdktn.IResolvable): any;
export declare class GradientaiAgentTemplateModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentTemplateModelVersions | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentTemplateModelVersions | cdktn.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class GradientaiAgentTemplateModelVersionsList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentTemplateModelVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentTemplateModelVersionsOutputReference;
}
export interface GradientaiAgentTemplateModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#inference_name GradientaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#inference_version GradientaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#is_foundational GradientaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#parent_uuid GradientaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#provider GradientaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#upload_complete GradientaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktn.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#url GradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#usecases GradientaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#agreement GradientaiAgent#agreement}
    */
    readonly agreement?: GradientaiAgentTemplateModelAgreement[] | cdktn.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#versions GradientaiAgent#versions}
    */
    readonly versions?: GradientaiAgentTemplateModelVersions[] | cdktn.IResolvable;
}
export declare function gradientaiAgentTemplateModelToTerraform(struct?: GradientaiAgentTemplateModel | cdktn.IResolvable): any;
export declare function gradientaiAgentTemplateModelToHclTerraform(struct?: GradientaiAgentTemplateModel | cdktn.IResolvable): any;
export declare class GradientaiAgentTemplateModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentTemplateModel | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentTemplateModel | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktn.IResolvable;
    set isFoundational(value: boolean | cdktn.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktn.IResolvable;
    set uploadComplete(value: boolean | cdktn.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): GradientaiAgentTemplateModelAgreementList;
    putAgreement(value: GradientaiAgentTemplateModelAgreement[] | cdktn.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktn.IResolvable | GradientaiAgentTemplateModelAgreement[] | undefined;
    private _versions;
    get versions(): GradientaiAgentTemplateModelVersionsList;
    putVersions(value: GradientaiAgentTemplateModelVersions[] | cdktn.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktn.IResolvable | GradientaiAgentTemplateModelVersions[] | undefined;
}
export declare class GradientaiAgentTemplateModelList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentTemplateModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentTemplateModelOutputReference;
}
export interface GradientaiAgentTemplate {
    /**
    * Description of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#description GradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#instruction GradientaiAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * K value for the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#k GradientaiAgent#k}
    */
    readonly k?: number;
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#max_tokens GradientaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Name of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#name GradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#temperature GradientaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#top_p GradientaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * uuid of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#uuid GradientaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#knowledge_bases GradientaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: GradientaiAgentTemplateKnowledgeBases[] | cdktn.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#model GradientaiAgent#model}
    */
    readonly model?: GradientaiAgentTemplateModel[] | cdktn.IResolvable;
}
export declare function gradientaiAgentTemplateToTerraform(struct?: GradientaiAgentTemplate | cdktn.IResolvable): any;
export declare function gradientaiAgentTemplateToHclTerraform(struct?: GradientaiAgentTemplate | cdktn.IResolvable): any;
export declare class GradientaiAgentTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiAgentTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiAgentTemplate | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): GradientaiAgentTemplateKnowledgeBasesList;
    putKnowledgeBases(value: GradientaiAgentTemplateKnowledgeBases[] | cdktn.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktn.IResolvable | GradientaiAgentTemplateKnowledgeBases[] | undefined;
    private _model;
    get model(): GradientaiAgentTemplateModelList;
    putModel(value: GradientaiAgentTemplateModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | GradientaiAgentTemplateModel[] | undefined;
}
export declare class GradientaiAgentTemplateList extends cdktn.ComplexList {
    internalValue?: GradientaiAgentTemplate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiAgentTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent digitalocean_gradientai_agent}
*/
export declare class GradientaiAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_agent";
    /**
    * Generates CDKTN code for importing a GradientaiAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiAgent to import
    * @param importFromId The id of the existing GradientaiAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent digitalocean_gradientai_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiAgentConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiAgentConfig);
    private _anthropicKeyUuid?;
    get anthropicKeyUuid(): string;
    set anthropicKeyUuid(value: string);
    resetAnthropicKeyUuid(): void;
    get anthropicKeyUuidInput(): string | undefined;
    private _createdAt?;
    get createdAt(): string;
    set createdAt(value: string);
    resetCreatedAt(): void;
    get createdAtInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifCase?;
    get ifCase(): string;
    set ifCase(value: string);
    resetIfCase(): void;
    get ifCaseInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    get instructionInput(): string | undefined;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string[];
    set knowledgeBaseUuid(value: string[]);
    resetKnowledgeBaseUuid(): void;
    get knowledgeBaseUuidInput(): string[] | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelUuid?;
    get modelUuid(): string;
    set modelUuid(value: string);
    get modelUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _openAiKeyUuid?;
    get openAiKeyUuid(): string;
    set openAiKeyUuid(value: string);
    resetOpenAiKeyUuid(): void;
    get openAiKeyUuidInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _provideCitations?;
    get provideCitations(): boolean | cdktn.IResolvable;
    set provideCitations(value: boolean | cdktn.IResolvable);
    resetProvideCitations(): void;
    get provideCitationsInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _retrievalMethod?;
    get retrievalMethod(): string;
    set retrievalMethod(value: string);
    resetRetrievalMethod(): void;
    get retrievalMethodInput(): string | undefined;
    get routeCreatedAt(): string;
    private _routeCreatedBy?;
    get routeCreatedBy(): string;
    set routeCreatedBy(value: string);
    resetRouteCreatedBy(): void;
    get routeCreatedByInput(): string | undefined;
    private _routeName?;
    get routeName(): string;
    set routeName(value: string);
    resetRouteName(): void;
    get routeNameInput(): string | undefined;
    private _routeUuid?;
    get routeUuid(): string;
    set routeUuid(value: string);
    resetRouteUuid(): void;
    get routeUuidInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _workspaceUuid?;
    get workspaceUuid(): string;
    set workspaceUuid(value: string);
    resetWorkspaceUuid(): void;
    get workspaceUuidInput(): string | undefined;
    private _agentGuardrail;
    get agentGuardrail(): GradientaiAgentAgentGuardrailList;
    putAgentGuardrail(value: GradientaiAgentAgentGuardrail[] | cdktn.IResolvable): void;
    resetAgentGuardrail(): void;
    get agentGuardrailInput(): cdktn.IResolvable | GradientaiAgentAgentGuardrail[] | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): GradientaiAgentAnthropicApiKeyList;
    putAnthropicApiKey(value: GradientaiAgentAnthropicApiKey[] | cdktn.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktn.IResolvable | GradientaiAgentAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): GradientaiAgentApiKeyInfosList;
    putApiKeyInfos(value: GradientaiAgentApiKeyInfos[] | cdktn.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktn.IResolvable | GradientaiAgentApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): GradientaiAgentApiKeysList;
    putApiKeys(value: GradientaiAgentApiKeys[] | cdktn.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktn.IResolvable | GradientaiAgentApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): GradientaiAgentChatbotList;
    putChatbot(value: GradientaiAgentChatbot[] | cdktn.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktn.IResolvable | GradientaiAgentChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): GradientaiAgentChatbotIdentifiersList;
    putChatbotIdentifiers(value: GradientaiAgentChatbotIdentifiers[] | cdktn.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktn.IResolvable | GradientaiAgentChatbotIdentifiers[] | undefined;
    private _childAgents;
    get childAgents(): GradientaiAgentChildAgentsList;
    putChildAgents(value: GradientaiAgentChildAgents[] | cdktn.IResolvable): void;
    resetChildAgents(): void;
    get childAgentsInput(): cdktn.IResolvable | GradientaiAgentChildAgents[] | undefined;
    private _deployment;
    get deployment(): GradientaiAgentDeploymentList;
    putDeployment(value: GradientaiAgentDeployment[] | cdktn.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktn.IResolvable | GradientaiAgentDeployment[] | undefined;
    private _functions;
    get functions(): GradientaiAgentFunctionsList;
    putFunctions(value: GradientaiAgentFunctions[] | cdktn.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktn.IResolvable | GradientaiAgentFunctions[] | undefined;
    private _knowledgeBases;
    get knowledgeBases(): GradientaiAgentKnowledgeBasesList;
    putKnowledgeBases(value: GradientaiAgentKnowledgeBases[] | cdktn.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktn.IResolvable | GradientaiAgentKnowledgeBases[] | undefined;
    private _model;
    get model(): GradientaiAgentModelList;
    putModel(value: GradientaiAgentModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | GradientaiAgentModel[] | undefined;
    private _openAiApiKey;
    get openAiApiKey(): GradientaiAgentOpenAiApiKeyList;
    putOpenAiApiKey(value: GradientaiAgentOpenAiApiKey[] | cdktn.IResolvable): void;
    resetOpenAiApiKey(): void;
    get openAiApiKeyInput(): cdktn.IResolvable | GradientaiAgentOpenAiApiKey[] | undefined;
    private _parentAgents;
    get parentAgents(): GradientaiAgentParentAgentsList;
    putParentAgents(value: GradientaiAgentParentAgents[] | cdktn.IResolvable): void;
    resetParentAgents(): void;
    get parentAgentsInput(): cdktn.IResolvable | GradientaiAgentParentAgents[] | undefined;
    private _template;
    get template(): GradientaiAgentTemplateList;
    putTemplate(value: GradientaiAgentTemplate[] | cdktn.IResolvable): void;
    resetTemplate(): void;
    get templateInput(): cdktn.IResolvable | GradientaiAgentTemplate[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
