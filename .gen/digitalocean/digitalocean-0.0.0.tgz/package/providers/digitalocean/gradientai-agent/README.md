# `digitalocean_gradientai_agent`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_agent`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent).
