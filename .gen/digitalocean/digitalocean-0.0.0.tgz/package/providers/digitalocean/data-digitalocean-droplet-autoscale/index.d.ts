import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDropletAutoscaleConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Droplet autoscale pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/droplet_autoscale#id DataDigitaloceanDropletAutoscale#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the Droplet autoscale pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/droplet_autoscale#name DataDigitaloceanDropletAutoscale#name}
    */
    readonly name?: string;
}
export interface DataDigitaloceanDropletAutoscaleConfigA {
}
export declare function dataDigitaloceanDropletAutoscaleConfigAToTerraform(struct?: DataDigitaloceanDropletAutoscaleConfigA): any;
export declare function dataDigitaloceanDropletAutoscaleConfigAToHclTerraform(struct?: DataDigitaloceanDropletAutoscaleConfigA): any;
export declare class DataDigitaloceanDropletAutoscaleConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDropletAutoscaleConfigA | undefined;
    set internalValue(value: DataDigitaloceanDropletAutoscaleConfigA | undefined);
    get cooldownMinutes(): number;
    get maxInstances(): number;
    get minInstances(): number;
    get targetCpuUtilization(): number;
    get targetMemoryUtilization(): number;
    get targetNumberInstances(): number;
}
export declare class DataDigitaloceanDropletAutoscaleConfigAList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDropletAutoscaleConfigAOutputReference;
}
export interface DataDigitaloceanDropletAutoscaleCurrentUtilization {
}
export declare function dataDigitaloceanDropletAutoscaleCurrentUtilizationToTerraform(struct?: DataDigitaloceanDropletAutoscaleCurrentUtilization): any;
export declare function dataDigitaloceanDropletAutoscaleCurrentUtilizationToHclTerraform(struct?: DataDigitaloceanDropletAutoscaleCurrentUtilization): any;
export declare class DataDigitaloceanDropletAutoscaleCurrentUtilizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDropletAutoscaleCurrentUtilization | undefined;
    set internalValue(value: DataDigitaloceanDropletAutoscaleCurrentUtilization | undefined);
    get cpu(): number;
    get memory(): number;
}
export declare class DataDigitaloceanDropletAutoscaleCurrentUtilizationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDropletAutoscaleCurrentUtilizationOutputReference;
}
export interface DataDigitaloceanDropletAutoscaleDropletTemplate {
}
export declare function dataDigitaloceanDropletAutoscaleDropletTemplateToTerraform(struct?: DataDigitaloceanDropletAutoscaleDropletTemplate): any;
export declare function dataDigitaloceanDropletAutoscaleDropletTemplateToHclTerraform(struct?: DataDigitaloceanDropletAutoscaleDropletTemplate): any;
export declare class DataDigitaloceanDropletAutoscaleDropletTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDropletAutoscaleDropletTemplate | undefined;
    set internalValue(value: DataDigitaloceanDropletAutoscaleDropletTemplate | undefined);
    get image(): string;
    get ipv6(): cdktn.IResolvable;
    get projectId(): string;
    get publicNetworking(): cdktn.IResolvable;
    get region(): string;
    get size(): string;
    get sshKeys(): string[];
    get tags(): string[];
    get userData(): string;
    get vpcUuid(): string;
    get withDropletAgent(): cdktn.IResolvable;
}
export declare class DataDigitaloceanDropletAutoscaleDropletTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDropletAutoscaleDropletTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/droplet_autoscale digitalocean_droplet_autoscale}
*/
export declare class DataDigitaloceanDropletAutoscale extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_droplet_autoscale";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDropletAutoscale resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDropletAutoscale to import
    * @param importFromId The id of the existing DataDigitaloceanDropletAutoscale that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/droplet_autoscale#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDropletAutoscale to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/droplet_autoscale digitalocean_droplet_autoscale} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDropletAutoscaleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDropletAutoscaleConfig);
    private _config;
    get config(): DataDigitaloceanDropletAutoscaleConfigAList;
    get createdAt(): string;
    private _currentUtilization;
    get currentUtilization(): DataDigitaloceanDropletAutoscaleCurrentUtilizationList;
    private _dropletTemplate;
    get dropletTemplate(): DataDigitaloceanDropletAutoscaleDropletTemplateList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
