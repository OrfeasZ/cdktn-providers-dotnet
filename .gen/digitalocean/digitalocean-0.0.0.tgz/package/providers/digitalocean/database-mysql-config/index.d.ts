import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseMysqlConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#backup_hour DatabaseMysqlConfig#backup_hour}
    */
    readonly backupHour?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#backup_minute DatabaseMysqlConfig#backup_minute}
    */
    readonly backupMinute?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#binlog_retention_period DatabaseMysqlConfig#binlog_retention_period}
    */
    readonly binlogRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#cluster_id DatabaseMysqlConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#connect_timeout DatabaseMysqlConfig#connect_timeout}
    */
    readonly connectTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#default_time_zone DatabaseMysqlConfig#default_time_zone}
    */
    readonly defaultTimeZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#group_concat_max_len DatabaseMysqlConfig#group_concat_max_len}
    */
    readonly groupConcatMaxLen?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#id DatabaseMysqlConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#information_schema_stats_expiry DatabaseMysqlConfig#information_schema_stats_expiry}
    */
    readonly informationSchemaStatsExpiry?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_ft_min_token_size DatabaseMysqlConfig#innodb_ft_min_token_size}
    */
    readonly innodbFtMinTokenSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_ft_server_stopword_table DatabaseMysqlConfig#innodb_ft_server_stopword_table}
    */
    readonly innodbFtServerStopwordTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_lock_wait_timeout DatabaseMysqlConfig#innodb_lock_wait_timeout}
    */
    readonly innodbLockWaitTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_log_buffer_size DatabaseMysqlConfig#innodb_log_buffer_size}
    */
    readonly innodbLogBufferSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_online_alter_log_max_size DatabaseMysqlConfig#innodb_online_alter_log_max_size}
    */
    readonly innodbOnlineAlterLogMaxSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_print_all_deadlocks DatabaseMysqlConfig#innodb_print_all_deadlocks}
    */
    readonly innodbPrintAllDeadlocks?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#innodb_rollback_on_timeout DatabaseMysqlConfig#innodb_rollback_on_timeout}
    */
    readonly innodbRollbackOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#interactive_timeout DatabaseMysqlConfig#interactive_timeout}
    */
    readonly interactiveTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#internal_tmp_mem_storage_engine DatabaseMysqlConfig#internal_tmp_mem_storage_engine}
    */
    readonly internalTmpMemStorageEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#long_query_time DatabaseMysqlConfig#long_query_time}
    */
    readonly longQueryTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#max_allowed_packet DatabaseMysqlConfig#max_allowed_packet}
    */
    readonly maxAllowedPacket?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#max_heap_table_size DatabaseMysqlConfig#max_heap_table_size}
    */
    readonly maxHeapTableSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#net_read_timeout DatabaseMysqlConfig#net_read_timeout}
    */
    readonly netReadTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#net_write_timeout DatabaseMysqlConfig#net_write_timeout}
    */
    readonly netWriteTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#slow_query_log DatabaseMysqlConfig#slow_query_log}
    */
    readonly slowQueryLog?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#sort_buffer_size DatabaseMysqlConfig#sort_buffer_size}
    */
    readonly sortBufferSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#sql_mode DatabaseMysqlConfig#sql_mode}
    */
    readonly sqlMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#sql_require_primary_key DatabaseMysqlConfig#sql_require_primary_key}
    */
    readonly sqlRequirePrimaryKey?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#tmp_table_size DatabaseMysqlConfig#tmp_table_size}
    */
    readonly tmpTableSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#wait_timeout DatabaseMysqlConfig#wait_timeout}
    */
    readonly waitTimeout?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config digitalocean_database_mysql_config}
*/
export declare class DatabaseMysqlConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_mysql_config";
    /**
    * Generates CDKTN code for importing a DatabaseMysqlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseMysqlConfig to import
    * @param importFromId The id of the existing DatabaseMysqlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseMysqlConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_mysql_config digitalocean_database_mysql_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseMysqlConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseMysqlConfigConfig);
    private _backupHour?;
    get backupHour(): number;
    set backupHour(value: number);
    resetBackupHour(): void;
    get backupHourInput(): number | undefined;
    private _backupMinute?;
    get backupMinute(): number;
    set backupMinute(value: number);
    resetBackupMinute(): void;
    get backupMinuteInput(): number | undefined;
    private _binlogRetentionPeriod?;
    get binlogRetentionPeriod(): number;
    set binlogRetentionPeriod(value: number);
    resetBinlogRetentionPeriod(): void;
    get binlogRetentionPeriodInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _connectTimeout?;
    get connectTimeout(): number;
    set connectTimeout(value: number);
    resetConnectTimeout(): void;
    get connectTimeoutInput(): number | undefined;
    private _defaultTimeZone?;
    get defaultTimeZone(): string;
    set defaultTimeZone(value: string);
    resetDefaultTimeZone(): void;
    get defaultTimeZoneInput(): string | undefined;
    private _groupConcatMaxLen?;
    get groupConcatMaxLen(): number;
    set groupConcatMaxLen(value: number);
    resetGroupConcatMaxLen(): void;
    get groupConcatMaxLenInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _informationSchemaStatsExpiry?;
    get informationSchemaStatsExpiry(): number;
    set informationSchemaStatsExpiry(value: number);
    resetInformationSchemaStatsExpiry(): void;
    get informationSchemaStatsExpiryInput(): number | undefined;
    private _innodbFtMinTokenSize?;
    get innodbFtMinTokenSize(): number;
    set innodbFtMinTokenSize(value: number);
    resetInnodbFtMinTokenSize(): void;
    get innodbFtMinTokenSizeInput(): number | undefined;
    private _innodbFtServerStopwordTable?;
    get innodbFtServerStopwordTable(): string;
    set innodbFtServerStopwordTable(value: string);
    resetInnodbFtServerStopwordTable(): void;
    get innodbFtServerStopwordTableInput(): string | undefined;
    private _innodbLockWaitTimeout?;
    get innodbLockWaitTimeout(): number;
    set innodbLockWaitTimeout(value: number);
    resetInnodbLockWaitTimeout(): void;
    get innodbLockWaitTimeoutInput(): number | undefined;
    private _innodbLogBufferSize?;
    get innodbLogBufferSize(): number;
    set innodbLogBufferSize(value: number);
    resetInnodbLogBufferSize(): void;
    get innodbLogBufferSizeInput(): number | undefined;
    private _innodbOnlineAlterLogMaxSize?;
    get innodbOnlineAlterLogMaxSize(): number;
    set innodbOnlineAlterLogMaxSize(value: number);
    resetInnodbOnlineAlterLogMaxSize(): void;
    get innodbOnlineAlterLogMaxSizeInput(): number | undefined;
    private _innodbPrintAllDeadlocks?;
    get innodbPrintAllDeadlocks(): boolean | cdktn.IResolvable;
    set innodbPrintAllDeadlocks(value: boolean | cdktn.IResolvable);
    resetInnodbPrintAllDeadlocks(): void;
    get innodbPrintAllDeadlocksInput(): boolean | cdktn.IResolvable | undefined;
    private _innodbRollbackOnTimeout?;
    get innodbRollbackOnTimeout(): boolean | cdktn.IResolvable;
    set innodbRollbackOnTimeout(value: boolean | cdktn.IResolvable);
    resetInnodbRollbackOnTimeout(): void;
    get innodbRollbackOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _interactiveTimeout?;
    get interactiveTimeout(): number;
    set interactiveTimeout(value: number);
    resetInteractiveTimeout(): void;
    get interactiveTimeoutInput(): number | undefined;
    private _internalTmpMemStorageEngine?;
    get internalTmpMemStorageEngine(): string;
    set internalTmpMemStorageEngine(value: string);
    resetInternalTmpMemStorageEngine(): void;
    get internalTmpMemStorageEngineInput(): string | undefined;
    private _longQueryTime?;
    get longQueryTime(): number;
    set longQueryTime(value: number);
    resetLongQueryTime(): void;
    get longQueryTimeInput(): number | undefined;
    private _maxAllowedPacket?;
    get maxAllowedPacket(): number;
    set maxAllowedPacket(value: number);
    resetMaxAllowedPacket(): void;
    get maxAllowedPacketInput(): number | undefined;
    private _maxHeapTableSize?;
    get maxHeapTableSize(): number;
    set maxHeapTableSize(value: number);
    resetMaxHeapTableSize(): void;
    get maxHeapTableSizeInput(): number | undefined;
    private _netReadTimeout?;
    get netReadTimeout(): number;
    set netReadTimeout(value: number);
    resetNetReadTimeout(): void;
    get netReadTimeoutInput(): number | undefined;
    private _netWriteTimeout?;
    get netWriteTimeout(): number;
    set netWriteTimeout(value: number);
    resetNetWriteTimeout(): void;
    get netWriteTimeoutInput(): number | undefined;
    private _slowQueryLog?;
    get slowQueryLog(): boolean | cdktn.IResolvable;
    set slowQueryLog(value: boolean | cdktn.IResolvable);
    resetSlowQueryLog(): void;
    get slowQueryLogInput(): boolean | cdktn.IResolvable | undefined;
    private _sortBufferSize?;
    get sortBufferSize(): number;
    set sortBufferSize(value: number);
    resetSortBufferSize(): void;
    get sortBufferSizeInput(): number | undefined;
    private _sqlMode?;
    get sqlMode(): string;
    set sqlMode(value: string);
    resetSqlMode(): void;
    get sqlModeInput(): string | undefined;
    private _sqlRequirePrimaryKey?;
    get sqlRequirePrimaryKey(): boolean | cdktn.IResolvable;
    set sqlRequirePrimaryKey(value: boolean | cdktn.IResolvable);
    resetSqlRequirePrimaryKey(): void;
    get sqlRequirePrimaryKeyInput(): boolean | cdktn.IResolvable | undefined;
    private _tmpTableSize?;
    get tmpTableSize(): number;
    set tmpTableSize(value: number);
    resetTmpTableSize(): void;
    get tmpTableSizeInput(): number | undefined;
    private _waitTimeout?;
    get waitTimeout(): number;
    set waitTimeout(value: number);
    resetWaitTimeout(): void;
    get waitTimeoutInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
