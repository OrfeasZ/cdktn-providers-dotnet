"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseMysqlConfig = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config digitalocean_database_mysql_config}
*/
class DatabaseMysqlConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseMysqlConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseMysqlConfig to import
    * @param importFromId The id of the existing DatabaseMysqlConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseMysqlConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_mysql_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_mysql_config digitalocean_database_mysql_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseMysqlConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_mysql_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._backupHour = config.backupHour;
        this._backupMinute = config.backupMinute;
        this._binlogRetentionPeriod = config.binlogRetentionPeriod;
        this._clusterId = config.clusterId;
        this._connectTimeout = config.connectTimeout;
        this._defaultTimeZone = config.defaultTimeZone;
        this._groupConcatMaxLen = config.groupConcatMaxLen;
        this._id = config.id;
        this._informationSchemaStatsExpiry = config.informationSchemaStatsExpiry;
        this._innodbFtMinTokenSize = config.innodbFtMinTokenSize;
        this._innodbFtServerStopwordTable = config.innodbFtServerStopwordTable;
        this._innodbLockWaitTimeout = config.innodbLockWaitTimeout;
        this._innodbLogBufferSize = config.innodbLogBufferSize;
        this._innodbOnlineAlterLogMaxSize = config.innodbOnlineAlterLogMaxSize;
        this._innodbPrintAllDeadlocks = config.innodbPrintAllDeadlocks;
        this._innodbRollbackOnTimeout = config.innodbRollbackOnTimeout;
        this._interactiveTimeout = config.interactiveTimeout;
        this._internalTmpMemStorageEngine = config.internalTmpMemStorageEngine;
        this._longQueryTime = config.longQueryTime;
        this._maxAllowedPacket = config.maxAllowedPacket;
        this._maxHeapTableSize = config.maxHeapTableSize;
        this._netReadTimeout = config.netReadTimeout;
        this._netWriteTimeout = config.netWriteTimeout;
        this._slowQueryLog = config.slowQueryLog;
        this._sortBufferSize = config.sortBufferSize;
        this._sqlMode = config.sqlMode;
        this._sqlRequirePrimaryKey = config.sqlRequirePrimaryKey;
        this._tmpTableSize = config.tmpTableSize;
        this._waitTimeout = config.waitTimeout;
    }
    get backupHour() {
        return this.getNumberAttribute('backup_hour');
    }
    set backupHour(value) {
        this._backupHour = value;
    }
    resetBackupHour() {
        this._backupHour = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupHourInput() {
        return this._backupHour;
    }
    get backupMinute() {
        return this.getNumberAttribute('backup_minute');
    }
    set backupMinute(value) {
        this._backupMinute = value;
    }
    resetBackupMinute() {
        this._backupMinute = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get backupMinuteInput() {
        return this._backupMinute;
    }
    get binlogRetentionPeriod() {
        return this.getNumberAttribute('binlog_retention_period');
    }
    set binlogRetentionPeriod(value) {
        this._binlogRetentionPeriod = value;
    }
    resetBinlogRetentionPeriod() {
        this._binlogRetentionPeriod = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get binlogRetentionPeriodInput() {
        return this._binlogRetentionPeriod;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get connectTimeout() {
        return this.getNumberAttribute('connect_timeout');
    }
    set connectTimeout(value) {
        this._connectTimeout = value;
    }
    resetConnectTimeout() {
        this._connectTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get connectTimeoutInput() {
        return this._connectTimeout;
    }
    get defaultTimeZone() {
        return this.getStringAttribute('default_time_zone');
    }
    set defaultTimeZone(value) {
        this._defaultTimeZone = value;
    }
    resetDefaultTimeZone() {
        this._defaultTimeZone = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get defaultTimeZoneInput() {
        return this._defaultTimeZone;
    }
    get groupConcatMaxLen() {
        return this.getNumberAttribute('group_concat_max_len');
    }
    set groupConcatMaxLen(value) {
        this._groupConcatMaxLen = value;
    }
    resetGroupConcatMaxLen() {
        this._groupConcatMaxLen = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupConcatMaxLenInput() {
        return this._groupConcatMaxLen;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get informationSchemaStatsExpiry() {
        return this.getNumberAttribute('information_schema_stats_expiry');
    }
    set informationSchemaStatsExpiry(value) {
        this._informationSchemaStatsExpiry = value;
    }
    resetInformationSchemaStatsExpiry() {
        this._informationSchemaStatsExpiry = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get informationSchemaStatsExpiryInput() {
        return this._informationSchemaStatsExpiry;
    }
    get innodbFtMinTokenSize() {
        return this.getNumberAttribute('innodb_ft_min_token_size');
    }
    set innodbFtMinTokenSize(value) {
        this._innodbFtMinTokenSize = value;
    }
    resetInnodbFtMinTokenSize() {
        this._innodbFtMinTokenSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbFtMinTokenSizeInput() {
        return this._innodbFtMinTokenSize;
    }
    get innodbFtServerStopwordTable() {
        return this.getStringAttribute('innodb_ft_server_stopword_table');
    }
    set innodbFtServerStopwordTable(value) {
        this._innodbFtServerStopwordTable = value;
    }
    resetInnodbFtServerStopwordTable() {
        this._innodbFtServerStopwordTable = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbFtServerStopwordTableInput() {
        return this._innodbFtServerStopwordTable;
    }
    get innodbLockWaitTimeout() {
        return this.getNumberAttribute('innodb_lock_wait_timeout');
    }
    set innodbLockWaitTimeout(value) {
        this._innodbLockWaitTimeout = value;
    }
    resetInnodbLockWaitTimeout() {
        this._innodbLockWaitTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbLockWaitTimeoutInput() {
        return this._innodbLockWaitTimeout;
    }
    get innodbLogBufferSize() {
        return this.getNumberAttribute('innodb_log_buffer_size');
    }
    set innodbLogBufferSize(value) {
        this._innodbLogBufferSize = value;
    }
    resetInnodbLogBufferSize() {
        this._innodbLogBufferSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbLogBufferSizeInput() {
        return this._innodbLogBufferSize;
    }
    get innodbOnlineAlterLogMaxSize() {
        return this.getNumberAttribute('innodb_online_alter_log_max_size');
    }
    set innodbOnlineAlterLogMaxSize(value) {
        this._innodbOnlineAlterLogMaxSize = value;
    }
    resetInnodbOnlineAlterLogMaxSize() {
        this._innodbOnlineAlterLogMaxSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbOnlineAlterLogMaxSizeInput() {
        return this._innodbOnlineAlterLogMaxSize;
    }
    get innodbPrintAllDeadlocks() {
        return this.getBooleanAttribute('innodb_print_all_deadlocks');
    }
    set innodbPrintAllDeadlocks(value) {
        this._innodbPrintAllDeadlocks = value;
    }
    resetInnodbPrintAllDeadlocks() {
        this._innodbPrintAllDeadlocks = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbPrintAllDeadlocksInput() {
        return this._innodbPrintAllDeadlocks;
    }
    get innodbRollbackOnTimeout() {
        return this.getBooleanAttribute('innodb_rollback_on_timeout');
    }
    set innodbRollbackOnTimeout(value) {
        this._innodbRollbackOnTimeout = value;
    }
    resetInnodbRollbackOnTimeout() {
        this._innodbRollbackOnTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get innodbRollbackOnTimeoutInput() {
        return this._innodbRollbackOnTimeout;
    }
    get interactiveTimeout() {
        return this.getNumberAttribute('interactive_timeout');
    }
    set interactiveTimeout(value) {
        this._interactiveTimeout = value;
    }
    resetInteractiveTimeout() {
        this._interactiveTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get interactiveTimeoutInput() {
        return this._interactiveTimeout;
    }
    get internalTmpMemStorageEngine() {
        return this.getStringAttribute('internal_tmp_mem_storage_engine');
    }
    set internalTmpMemStorageEngine(value) {
        this._internalTmpMemStorageEngine = value;
    }
    resetInternalTmpMemStorageEngine() {
        this._internalTmpMemStorageEngine = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get internalTmpMemStorageEngineInput() {
        return this._internalTmpMemStorageEngine;
    }
    get longQueryTime() {
        return this.getNumberAttribute('long_query_time');
    }
    set longQueryTime(value) {
        this._longQueryTime = value;
    }
    resetLongQueryTime() {
        this._longQueryTime = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get longQueryTimeInput() {
        return this._longQueryTime;
    }
    get maxAllowedPacket() {
        return this.getNumberAttribute('max_allowed_packet');
    }
    set maxAllowedPacket(value) {
        this._maxAllowedPacket = value;
    }
    resetMaxAllowedPacket() {
        this._maxAllowedPacket = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxAllowedPacketInput() {
        return this._maxAllowedPacket;
    }
    get maxHeapTableSize() {
        return this.getNumberAttribute('max_heap_table_size');
    }
    set maxHeapTableSize(value) {
        this._maxHeapTableSize = value;
    }
    resetMaxHeapTableSize() {
        this._maxHeapTableSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get maxHeapTableSizeInput() {
        return this._maxHeapTableSize;
    }
    get netReadTimeout() {
        return this.getNumberAttribute('net_read_timeout');
    }
    set netReadTimeout(value) {
        this._netReadTimeout = value;
    }
    resetNetReadTimeout() {
        this._netReadTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get netReadTimeoutInput() {
        return this._netReadTimeout;
    }
    get netWriteTimeout() {
        return this.getNumberAttribute('net_write_timeout');
    }
    set netWriteTimeout(value) {
        this._netWriteTimeout = value;
    }
    resetNetWriteTimeout() {
        this._netWriteTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get netWriteTimeoutInput() {
        return this._netWriteTimeout;
    }
    get slowQueryLog() {
        return this.getBooleanAttribute('slow_query_log');
    }
    set slowQueryLog(value) {
        this._slowQueryLog = value;
    }
    resetSlowQueryLog() {
        this._slowQueryLog = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get slowQueryLogInput() {
        return this._slowQueryLog;
    }
    get sortBufferSize() {
        return this.getNumberAttribute('sort_buffer_size');
    }
    set sortBufferSize(value) {
        this._sortBufferSize = value;
    }
    resetSortBufferSize() {
        this._sortBufferSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sortBufferSizeInput() {
        return this._sortBufferSize;
    }
    get sqlMode() {
        return this.getStringAttribute('sql_mode');
    }
    set sqlMode(value) {
        this._sqlMode = value;
    }
    resetSqlMode() {
        this._sqlMode = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sqlModeInput() {
        return this._sqlMode;
    }
    get sqlRequirePrimaryKey() {
        return this.getBooleanAttribute('sql_require_primary_key');
    }
    set sqlRequirePrimaryKey(value) {
        this._sqlRequirePrimaryKey = value;
    }
    resetSqlRequirePrimaryKey() {
        this._sqlRequirePrimaryKey = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get sqlRequirePrimaryKeyInput() {
        return this._sqlRequirePrimaryKey;
    }
    get tmpTableSize() {
        return this.getNumberAttribute('tmp_table_size');
    }
    set tmpTableSize(value) {
        this._tmpTableSize = value;
    }
    resetTmpTableSize() {
        this._tmpTableSize = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get tmpTableSizeInput() {
        return this._tmpTableSize;
    }
    get waitTimeout() {
        return this.getNumberAttribute('wait_timeout');
    }
    set waitTimeout(value) {
        this._waitTimeout = value;
    }
    resetWaitTimeout() {
        this._waitTimeout = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get waitTimeoutInput() {
        return this._waitTimeout;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            backup_hour: cdktn.numberToTerraform(this._backupHour),
            backup_minute: cdktn.numberToTerraform(this._backupMinute),
            binlog_retention_period: cdktn.numberToTerraform(this._binlogRetentionPeriod),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            connect_timeout: cdktn.numberToTerraform(this._connectTimeout),
            default_time_zone: cdktn.stringToTerraform(this._defaultTimeZone),
            group_concat_max_len: cdktn.numberToTerraform(this._groupConcatMaxLen),
            id: cdktn.stringToTerraform(this._id),
            information_schema_stats_expiry: cdktn.numberToTerraform(this._informationSchemaStatsExpiry),
            innodb_ft_min_token_size: cdktn.numberToTerraform(this._innodbFtMinTokenSize),
            innodb_ft_server_stopword_table: cdktn.stringToTerraform(this._innodbFtServerStopwordTable),
            innodb_lock_wait_timeout: cdktn.numberToTerraform(this._innodbLockWaitTimeout),
            innodb_log_buffer_size: cdktn.numberToTerraform(this._innodbLogBufferSize),
            innodb_online_alter_log_max_size: cdktn.numberToTerraform(this._innodbOnlineAlterLogMaxSize),
            innodb_print_all_deadlocks: cdktn.booleanToTerraform(this._innodbPrintAllDeadlocks),
            innodb_rollback_on_timeout: cdktn.booleanToTerraform(this._innodbRollbackOnTimeout),
            interactive_timeout: cdktn.numberToTerraform(this._interactiveTimeout),
            internal_tmp_mem_storage_engine: cdktn.stringToTerraform(this._internalTmpMemStorageEngine),
            long_query_time: cdktn.numberToTerraform(this._longQueryTime),
            max_allowed_packet: cdktn.numberToTerraform(this._maxAllowedPacket),
            max_heap_table_size: cdktn.numberToTerraform(this._maxHeapTableSize),
            net_read_timeout: cdktn.numberToTerraform(this._netReadTimeout),
            net_write_timeout: cdktn.numberToTerraform(this._netWriteTimeout),
            slow_query_log: cdktn.booleanToTerraform(this._slowQueryLog),
            sort_buffer_size: cdktn.numberToTerraform(this._sortBufferSize),
            sql_mode: cdktn.stringToTerraform(this._sqlMode),
            sql_require_primary_key: cdktn.booleanToTerraform(this._sqlRequirePrimaryKey),
            tmp_table_size: cdktn.numberToTerraform(this._tmpTableSize),
            wait_timeout: cdktn.numberToTerraform(this._waitTimeout),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            backup_hour: {
                value: cdktn.numberToHclTerraform(this._backupHour),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            backup_minute: {
                value: cdktn.numberToHclTerraform(this._backupMinute),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            binlog_retention_period: {
                value: cdktn.numberToHclTerraform(this._binlogRetentionPeriod),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            connect_timeout: {
                value: cdktn.numberToHclTerraform(this._connectTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            default_time_zone: {
                value: cdktn.stringToHclTerraform(this._defaultTimeZone),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            group_concat_max_len: {
                value: cdktn.numberToHclTerraform(this._groupConcatMaxLen),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            information_schema_stats_expiry: {
                value: cdktn.numberToHclTerraform(this._informationSchemaStatsExpiry),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_ft_min_token_size: {
                value: cdktn.numberToHclTerraform(this._innodbFtMinTokenSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_ft_server_stopword_table: {
                value: cdktn.stringToHclTerraform(this._innodbFtServerStopwordTable),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            innodb_lock_wait_timeout: {
                value: cdktn.numberToHclTerraform(this._innodbLockWaitTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_log_buffer_size: {
                value: cdktn.numberToHclTerraform(this._innodbLogBufferSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_online_alter_log_max_size: {
                value: cdktn.numberToHclTerraform(this._innodbOnlineAlterLogMaxSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            innodb_print_all_deadlocks: {
                value: cdktn.booleanToHclTerraform(this._innodbPrintAllDeadlocks),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            innodb_rollback_on_timeout: {
                value: cdktn.booleanToHclTerraform(this._innodbRollbackOnTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            interactive_timeout: {
                value: cdktn.numberToHclTerraform(this._interactiveTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            internal_tmp_mem_storage_engine: {
                value: cdktn.stringToHclTerraform(this._internalTmpMemStorageEngine),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            long_query_time: {
                value: cdktn.numberToHclTerraform(this._longQueryTime),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_allowed_packet: {
                value: cdktn.numberToHclTerraform(this._maxAllowedPacket),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            max_heap_table_size: {
                value: cdktn.numberToHclTerraform(this._maxHeapTableSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            net_read_timeout: {
                value: cdktn.numberToHclTerraform(this._netReadTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            net_write_timeout: {
                value: cdktn.numberToHclTerraform(this._netWriteTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            slow_query_log: {
                value: cdktn.booleanToHclTerraform(this._slowQueryLog),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            sort_buffer_size: {
                value: cdktn.numberToHclTerraform(this._sortBufferSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            sql_mode: {
                value: cdktn.stringToHclTerraform(this._sqlMode),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            sql_require_primary_key: {
                value: cdktn.booleanToHclTerraform(this._sqlRequirePrimaryKey),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            tmp_table_size: {
                value: cdktn.numberToHclTerraform(this._tmpTableSize),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            wait_timeout: {
                value: cdktn.numberToHclTerraform(this._waitTimeout),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseMysqlConfig = DatabaseMysqlConfig;
_a = JSII_RTTI_SYMBOL_1;
DatabaseMysqlConfig[_a] = { fqn: "digitalocean.databaseMysqlConfig.DatabaseMysqlConfig", version: "0.0.0" };
// =================
// STATIC PROPERTIES
// =================
DatabaseMysqlConfig.tfResourceType = "digitalocean_database_mysql_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUlBLCtCQUErQjtBQThIL0I7O0VBRUU7QUFDRixNQUFhLG1CQUFvQixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPOUQsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLG9DQUFvQyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM1SixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBaUM7UUFDaEYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSxvQ0FBb0M7WUFDM0QsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDckMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7UUFDM0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUM3QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQztRQUMvQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzNELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxNQUFNLENBQUMsbUJBQW1CLENBQUM7UUFDdkQsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLHVCQUF1QixDQUFDO1FBQy9ELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxNQUFNLENBQUMsdUJBQXVCLENBQUM7UUFDL0QsSUFBSSxDQUFDLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQztRQUNyRCxJQUFJLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDO1FBQ3ZFLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUMzQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1FBQ2pELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUM7UUFDakQsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1FBQzdDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDO1FBQy9DLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUN6QyxJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7UUFDN0MsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQy9CLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQztJQUN6QyxDQUFDO0lBUUQsSUFBVyxVQUFVO1FBQ25CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDRCxJQUFXLFVBQVUsQ0FBQyxLQUFhO1FBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0lBQzNCLENBQUM7SUFDTSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDO0lBQy9CLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxlQUFlO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUMxQixDQUFDO0lBSUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFDRCxJQUFXLFlBQVksQ0FBQyxLQUFhO1FBQ25DLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFDTSxpQkFBaUI7UUFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7SUFDakMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDNUIsQ0FBQztJQUlELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUNELElBQVcscUJBQXFCLENBQUMsS0FBYTtRQUM1QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7SUFDTSwwQkFBMEI7UUFDL0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsQ0FBQztJQUMxQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JDLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBQ0QsSUFBVyxjQUFjLENBQUMsS0FBYTtRQUNyQyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBQ00sbUJBQW1CO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO0lBQ25DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFJRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0QsSUFBVyxlQUFlLENBQUMsS0FBYTtRQUN0QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQ2hDLENBQUM7SUFDTSxvQkFBb0I7UUFDekIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFNBQVMsQ0FBQztJQUNwQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxFQUFFO1FBQ1gsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELElBQVcsRUFBRSxDQUFDLEtBQWE7UUFDekIsSUFBSSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7SUFDbkIsQ0FBQztJQUNNLE9BQU87UUFDWixJQUFJLENBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQztJQUN2QixDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsT0FBTztRQUNoQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDbEIsQ0FBQztJQUlELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlDQUFpQyxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUNELElBQVcsNEJBQTRCLENBQUMsS0FBYTtRQUNuRCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFDTSxpQ0FBaUM7UUFDdEMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLFNBQVMsQ0FBQztJQUNqRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDO0lBQzVDLENBQUM7SUFJRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFDRCxJQUFXLG9CQUFvQixDQUFDLEtBQWE7UUFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQVcscUJBQXFCLENBQUMsS0FBYTtRQUM1QyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3RDLENBQUM7SUFDTSwwQkFBMEI7UUFDL0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsQ0FBQztJQUMxQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMEJBQTBCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JDLENBQUM7SUFJRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxJQUFXLG1CQUFtQixDQUFDLEtBQWE7UUFDMUMsSUFBSSxDQUFDLG9CQUFvQixHQUFHLEtBQUssQ0FBQztJQUNwQyxDQUFDO0lBQ00sd0JBQXdCO1FBQzdCLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxTQUFTLENBQUM7SUFDeEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHdCQUF3QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUNuQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsa0NBQWtDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBa0M7UUFDbkUsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQztJQUN4QyxDQUFDO0lBQ00sNEJBQTRCO1FBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxTQUFTLENBQUM7SUFDNUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztJQUN2QyxDQUFDO0lBSUQsSUFBVyx1QkFBdUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBQ0QsSUFBVyx1QkFBdUIsQ0FBQyxLQUFrQztRQUNuRSxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsYUFBYTtRQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFDRCxJQUFXLGFBQWEsQ0FBQyxLQUFhO1FBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFDTSxrQkFBa0I7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7SUFDbEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUlELElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFJRCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGdCQUFnQixDQUFDLEtBQWE7UUFDdkMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBQ00scUJBQXFCO1FBQzFCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxTQUFTLENBQUM7SUFDckMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHFCQUFxQjtRQUM5QixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztJQUNoQyxDQUFDO0lBSUQsSUFBVyxjQUFjO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDckQsQ0FBQztJQUNELElBQVcsY0FBYyxDQUFDLEtBQWE7UUFDckMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQUNNLG1CQUFtQjtRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztJQUNuQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsbUJBQW1CO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBSUQsSUFBVyxlQUFlO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUNELElBQVcsZUFBZSxDQUFDLEtBQWE7UUFDdEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztJQUNoQyxDQUFDO0lBQ00sb0JBQW9CO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxTQUFTLENBQUM7SUFDcEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG9CQUFvQjtRQUM3QixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUMvQixDQUFDO0lBSUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUNELElBQVcsWUFBWSxDQUFDLEtBQWtDO1FBQ3hELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFDTSxpQkFBaUI7UUFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7SUFDakMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDNUIsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsT0FBTztRQUNoQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsSUFBVyxPQUFPLENBQUMsS0FBYTtRQUM5QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUN4QixDQUFDO0lBQ00sWUFBWTtRQUNqQixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztJQUM1QixDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsWUFBWTtRQUNyQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDdkIsQ0FBQztJQUlELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQVcsb0JBQW9CLENBQUMsS0FBa0M7UUFDaEUsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBSUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUNELElBQVcsWUFBWSxDQUFDLEtBQWE7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUNNLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUJBQWlCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBSUQsSUFBVyxXQUFXO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFDRCxJQUFXLFdBQVcsQ0FBQyxLQUFhO1FBQ2xDLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO0lBQzVCLENBQUM7SUFDTSxnQkFBZ0I7UUFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUM7SUFDaEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDM0IsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsV0FBVyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBQ3RELGFBQWEsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUMxRCx1QkFBdUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzdFLFVBQVUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUNwRCxlQUFlLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDOUQsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNqRSxvQkFBb0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3RFLEVBQUUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNyQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO1lBQzVGLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7WUFDN0UsK0JBQStCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUMzRix3QkFBd0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzlFLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDMUUsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUM1RiwwQkFBMEIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ25GLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7WUFDbkYsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN0RSwrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO1lBQzNGLGVBQWUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUM3RCxrQkFBa0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ25FLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDcEUsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNqRSxjQUFjLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDNUQsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsUUFBUSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ2hELHVCQUF1QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7WUFDN0UsY0FBYyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQzNELFlBQVksRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUN6RCxDQUFDO0lBQ0osQ0FBQztJQUVTLHVCQUF1QjtRQUMvQixNQUFNLEtBQUssR0FBRztZQUNaLFdBQVcsRUFBRTtnQkFDWCxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7Z0JBQ25ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsdUJBQXVCLEVBQUU7Z0JBQ3ZCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGVBQWUsRUFBRTtnQkFDZixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7Z0JBQ3ZELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQkFBaUIsRUFBRTtnQkFDakIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxFQUFFLEVBQUU7Z0JBQ0YsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUMzQyxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsK0JBQStCLEVBQUU7Z0JBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDO2dCQUNyRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO2dCQUM3RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsK0JBQStCLEVBQUU7Z0JBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0Qsc0JBQXNCLEVBQUU7Z0JBQ3RCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO2dCQUM1RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZ0NBQWdDLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsMEJBQTBCLEVBQUU7Z0JBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO2dCQUNqRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsMEJBQTBCLEVBQUU7Z0JBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO2dCQUNqRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsK0JBQStCLEVBQUU7Z0JBQy9CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDekQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDekQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGdCQUFnQixFQUFFO2dCQUNoQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7Z0JBQ3ZELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQkFBaUIsRUFBRTtnQkFDakIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxjQUFjLEVBQUU7Z0JBQ2QsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUN0RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsZ0JBQWdCLEVBQUU7Z0JBQ2hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDdkQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELFFBQVEsRUFBRTtnQkFDUixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ2hELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCxjQUFjLEVBQUU7Z0JBQ2QsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDcEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtTQUNGLENBQUM7UUFFRiw4QkFBOEI7UUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUUsQ0FBQyxDQUFBO0lBQzVILENBQUM7O0FBMXZCSCxrREEydkJDOzs7QUF6dkJDLG9CQUFvQjtBQUNwQixvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ0csa0NBQWMsR0FBRyxvQ0FBb0MsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWdcbi8vIGdlbmVyYXRlZCBmcm9tIHRlcnJhZm9ybSByZXNvdXJjZSBzY2hlbWFcblxuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBjZGt0biBmcm9tICdjZGt0bic7XG5cbi8vIENvbmZpZ3VyYXRpb25cblxuZXhwb3J0IGludGVyZmFjZSBEYXRhYmFzZU15c3FsQ29uZmlnQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtTWV0YUFyZ3VtZW50cyB7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNiYWNrdXBfaG91ciBEYXRhYmFzZU15c3FsQ29uZmlnI2JhY2t1cF9ob3VyfVxuICAqL1xuICByZWFkb25seSBiYWNrdXBIb3VyPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjYmFja3VwX21pbnV0ZSBEYXRhYmFzZU15c3FsQ29uZmlnI2JhY2t1cF9taW51dGV9XG4gICovXG4gIHJlYWRvbmx5IGJhY2t1cE1pbnV0ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2JpbmxvZ19yZXRlbnRpb25fcGVyaW9kIERhdGFiYXNlTXlzcWxDb25maWcjYmlubG9nX3JldGVudGlvbl9wZXJpb2R9XG4gICovXG4gIHJlYWRvbmx5IGJpbmxvZ1JldGVudGlvblBlcmlvZD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2NsdXN0ZXJfaWQgRGF0YWJhc2VNeXNxbENvbmZpZyNjbHVzdGVyX2lkfVxuICAqL1xuICByZWFkb25seSBjbHVzdGVySWQ6IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2Nvbm5lY3RfdGltZW91dCBEYXRhYmFzZU15c3FsQ29uZmlnI2Nvbm5lY3RfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgY29ubmVjdFRpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNkZWZhdWx0X3RpbWVfem9uZSBEYXRhYmFzZU15c3FsQ29uZmlnI2RlZmF1bHRfdGltZV96b25lfVxuICAqL1xuICByZWFkb25seSBkZWZhdWx0VGltZVpvbmU/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNncm91cF9jb25jYXRfbWF4X2xlbiBEYXRhYmFzZU15c3FsQ29uZmlnI2dyb3VwX2NvbmNhdF9tYXhfbGVufVxuICAqL1xuICByZWFkb25seSBncm91cENvbmNhdE1heExlbj86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2lkIERhdGFiYXNlTXlzcWxDb25maWcjaWR9XG4gICpcbiAgKiBQbGVhc2UgYmUgYXdhcmUgdGhhdCB0aGUgaWQgZmllbGQgaXMgYXV0b21hdGljYWxseSBhZGRlZCB0byBhbGwgcmVzb3VyY2VzIGluIFRlcnJhZm9ybSBwcm92aWRlcnMgdXNpbmcgYSBUZXJyYWZvcm0gcHJvdmlkZXIgU0RLIHZlcnNpb24gYmVsb3cgMi5cbiAgKiBJZiB5b3UgZXhwZXJpZW5jZSBwcm9ibGVtcyBzZXR0aW5nIHRoaXMgdmFsdWUgaXQgbWlnaHQgbm90IGJlIHNldHRhYmxlLiBQbGVhc2UgdGFrZSBhIGxvb2sgYXQgdGhlIHByb3ZpZGVyIGRvY3VtZW50YXRpb24gdG8gZW5zdXJlIGl0IHNob3VsZCBiZSBzZXR0YWJsZS5cbiAgKi9cbiAgcmVhZG9ubHkgaWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbmZvcm1hdGlvbl9zY2hlbWFfc3RhdHNfZXhwaXJ5IERhdGFiYXNlTXlzcWxDb25maWcjaW5mb3JtYXRpb25fc2NoZW1hX3N0YXRzX2V4cGlyeX1cbiAgKi9cbiAgcmVhZG9ubHkgaW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2lubm9kYl9mdF9taW5fdG9rZW5fc2l6ZSBEYXRhYmFzZU15c3FsQ29uZmlnI2lubm9kYl9mdF9taW5fdG9rZW5fc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgaW5ub2RiRnRNaW5Ub2tlblNpemU/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbm5vZGJfZnRfc2VydmVyX3N0b3B3b3JkX3RhYmxlIERhdGFiYXNlTXlzcWxDb25maWcjaW5ub2RiX2Z0X3NlcnZlcl9zdG9wd29yZF90YWJsZX1cbiAgKi9cbiAgcmVhZG9ubHkgaW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW5ub2RiX2xvY2tfd2FpdF90aW1lb3V0IERhdGFiYXNlTXlzcWxDb25maWcjaW5ub2RiX2xvY2tfd2FpdF90aW1lb3V0fVxuICAqL1xuICByZWFkb25seSBpbm5vZGJMb2NrV2FpdFRpbWVvdXQ/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbm5vZGJfbG9nX2J1ZmZlcl9zaXplIERhdGFiYXNlTXlzcWxDb25maWcjaW5ub2RiX2xvZ19idWZmZXJfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgaW5ub2RiTG9nQnVmZmVyU2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2lubm9kYl9vbmxpbmVfYWx0ZXJfbG9nX21heF9zaXplIERhdGFiYXNlTXlzcWxDb25maWcjaW5ub2RiX29ubGluZV9hbHRlcl9sb2dfbWF4X3NpemV9XG4gICovXG4gIHJlYWRvbmx5IGlubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2lubm9kYl9wcmludF9hbGxfZGVhZGxvY2tzIERhdGFiYXNlTXlzcWxDb25maWcjaW5ub2RiX3ByaW50X2FsbF9kZWFkbG9ja3N9XG4gICovXG4gIHJlYWRvbmx5IGlubm9kYlByaW50QWxsRGVhZGxvY2tzPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW5ub2RiX3JvbGxiYWNrX29uX3RpbWVvdXQgRGF0YWJhc2VNeXNxbENvbmZpZyNpbm5vZGJfcm9sbGJhY2tfb25fdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgaW5ub2RiUm9sbGJhY2tPblRpbWVvdXQ/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyNpbnRlcmFjdGl2ZV90aW1lb3V0IERhdGFiYXNlTXlzcWxDb25maWcjaW50ZXJhY3RpdmVfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgaW50ZXJhY3RpdmVUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW50ZXJuYWxfdG1wX21lbV9zdG9yYWdlX2VuZ2luZSBEYXRhYmFzZU15c3FsQ29uZmlnI2ludGVybmFsX3RtcF9tZW1fc3RvcmFnZV9lbmdpbmV9XG4gICovXG4gIHJlYWRvbmx5IGludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI2xvbmdfcXVlcnlfdGltZSBEYXRhYmFzZU15c3FsQ29uZmlnI2xvbmdfcXVlcnlfdGltZX1cbiAgKi9cbiAgcmVhZG9ubHkgbG9uZ1F1ZXJ5VGltZT86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI21heF9hbGxvd2VkX3BhY2tldCBEYXRhYmFzZU15c3FsQ29uZmlnI21heF9hbGxvd2VkX3BhY2tldH1cbiAgKi9cbiAgcmVhZG9ubHkgbWF4QWxsb3dlZFBhY2tldD86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI21heF9oZWFwX3RhYmxlX3NpemUgRGF0YWJhc2VNeXNxbENvbmZpZyNtYXhfaGVhcF90YWJsZV9zaXplfVxuICAqL1xuICByZWFkb25seSBtYXhIZWFwVGFibGVTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjbmV0X3JlYWRfdGltZW91dCBEYXRhYmFzZU15c3FsQ29uZmlnI25ldF9yZWFkX3RpbWVvdXR9XG4gICovXG4gIHJlYWRvbmx5IG5ldFJlYWRUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjbmV0X3dyaXRlX3RpbWVvdXQgRGF0YWJhc2VNeXNxbENvbmZpZyNuZXRfd3JpdGVfdGltZW91dH1cbiAgKi9cbiAgcmVhZG9ubHkgbmV0V3JpdGVUaW1lb3V0PzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjc2xvd19xdWVyeV9sb2cgRGF0YWJhc2VNeXNxbENvbmZpZyNzbG93X3F1ZXJ5X2xvZ31cbiAgKi9cbiAgcmVhZG9ubHkgc2xvd1F1ZXJ5TG9nPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjc29ydF9idWZmZXJfc2l6ZSBEYXRhYmFzZU15c3FsQ29uZmlnI3NvcnRfYnVmZmVyX3NpemV9XG4gICovXG4gIHJlYWRvbmx5IHNvcnRCdWZmZXJTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjc3FsX21vZGUgRGF0YWJhc2VNeXNxbENvbmZpZyNzcWxfbW9kZX1cbiAgKi9cbiAgcmVhZG9ubHkgc3FsTW9kZT86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2VfbXlzcWxfY29uZmlnI3NxbF9yZXF1aXJlX3ByaW1hcnlfa2V5IERhdGFiYXNlTXlzcWxDb25maWcjc3FsX3JlcXVpcmVfcHJpbWFyeV9rZXl9XG4gICovXG4gIHJlYWRvbmx5IHNxbFJlcXVpcmVQcmltYXJ5S2V5PzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjdG1wX3RhYmxlX3NpemUgRGF0YWJhc2VNeXNxbENvbmZpZyN0bXBfdGFibGVfc2l6ZX1cbiAgKi9cbiAgcmVhZG9ubHkgdG1wVGFibGVTaXplPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjd2FpdF90aW1lb3V0IERhdGFiYXNlTXlzcWxDb25maWcjd2FpdF90aW1lb3V0fVxuICAqL1xuICByZWFkb25seSB3YWl0VGltZW91dD86IG51bWJlcjtcbn1cblxuLyoqXG4qIFJlcHJlc2VudHMgYSB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2VfbXlzcWxfY29uZmlnfVxuKi9cbmV4cG9ydCBjbGFzcyBEYXRhYmFzZU15c3FsQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtUmVzb3VyY2Uge1xuXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIC8vIFNUQVRJQyBQUk9QRVJUSUVTXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgdGZSZXNvdXJjZVR5cGUgPSBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9teXNxbF9jb25maWdcIjtcblxuICAvLyA9PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgTWV0aG9kc1xuICAvLyA9PT09PT09PT09PT09PVxuICAvKipcbiAgKiBHZW5lcmF0ZXMgQ0RLVE4gY29kZSBmb3IgaW1wb3J0aW5nIGEgRGF0YWJhc2VNeXNxbENvbmZpZyByZXNvdXJjZSB1cG9uIHJ1bm5pbmcgXCJjZGt0biBwbGFuIDxzdGFjay1uYW1lPlwiXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaW1wb3J0VG9JZCBUaGUgY29uc3RydWN0IGlkIHVzZWQgaW4gdGhlIGdlbmVyYXRlZCBjb25maWcgZm9yIHRoZSBEYXRhYmFzZU15c3FsQ29uZmlnIHRvIGltcG9ydFxuICAqIEBwYXJhbSBpbXBvcnRGcm9tSWQgVGhlIGlkIG9mIHRoZSBleGlzdGluZyBEYXRhYmFzZU15c3FsQ29uZmlnIHRoYXQgc2hvdWxkIGJlIGltcG9ydGVkLiBSZWZlciB0byB0aGUge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9teXNxbF9jb25maWcjaW1wb3J0IGltcG9ydCBzZWN0aW9ufSBpbiB0aGUgZG9jdW1lbnRhdGlvbiBvZiB0aGlzIHJlc291cmNlIGZvciB0aGUgaWQgdG8gdXNlXG4gICogQHBhcmFtIHByb3ZpZGVyPyBPcHRpb25hbCBpbnN0YW5jZSBvZiB0aGUgcHJvdmlkZXIgd2hlcmUgdGhlIERhdGFiYXNlTXlzcWxDb25maWcgdG8gaW1wb3J0IGlzIGZvdW5kXG4gICovXG4gIHB1YmxpYyBzdGF0aWMgZ2VuZXJhdGVDb25maWdGb3JJbXBvcnQoc2NvcGU6IENvbnN0cnVjdCwgaW1wb3J0VG9JZDogc3RyaW5nLCBpbXBvcnRGcm9tSWQ6IHN0cmluZywgcHJvdmlkZXI/OiBjZGt0bi5UZXJyYWZvcm1Qcm92aWRlcikge1xuICAgICAgICByZXR1cm4gbmV3IGNka3RuLkltcG9ydGFibGVSZXNvdXJjZShzY29wZSwgaW1wb3J0VG9JZCwgeyB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6IFwiZGlnaXRhbG9jZWFuX2RhdGFiYXNlX215c3FsX2NvbmZpZ1wiLCBpbXBvcnRJZDogaW1wb3J0RnJvbUlkLCBwcm92aWRlciB9KTtcbiAgICAgIH1cblxuICAvLyA9PT09PT09PT09PVxuICAvLyBJTklUSUFMSVpFUlxuICAvLyA9PT09PT09PT09PVxuXG4gIC8qKlxuICAqIENyZWF0ZSBhIG5ldyB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX215c3FsX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2VfbXlzcWxfY29uZmlnfSBSZXNvdXJjZVxuICAqXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaWQgVGhlIHNjb3BlZCBjb25zdHJ1Y3QgSUQuIE11c3QgYmUgdW5pcXVlIGFtb25nc3Qgc2libGluZ3MgaW4gdGhlIHNhbWUgc2NvcGVcbiAgKiBAcGFyYW0gb3B0aW9ucyBEYXRhYmFzZU15c3FsQ29uZmlnQ29uZmlnXG4gICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBjb25maWc6IERhdGFiYXNlTXlzcWxDb25maWdDb25maWcpIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIHRlcnJhZm9ybVJlc291cmNlVHlwZTogJ2RpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9teXNxbF9jb25maWcnLFxuICAgICAgdGVycmFmb3JtR2VuZXJhdG9yTWV0YWRhdGE6IHtcbiAgICAgICAgcHJvdmlkZXJOYW1lOiAnZGlnaXRhbG9jZWFuJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uOiAnMi44Ny4wJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uQ29uc3RyYWludDogJzIuODcuMCdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcjogY29uZmlnLnByb3ZpZGVyLFxuICAgICAgZGVwZW5kc09uOiBjb25maWcuZGVwZW5kc09uLFxuICAgICAgY291bnQ6IGNvbmZpZy5jb3VudCxcbiAgICAgIGxpZmVjeWNsZTogY29uZmlnLmxpZmVjeWNsZSxcbiAgICAgIHByb3Zpc2lvbmVyczogY29uZmlnLnByb3Zpc2lvbmVycyxcbiAgICAgIGNvbm5lY3Rpb246IGNvbmZpZy5jb25uZWN0aW9uLFxuICAgICAgZm9yRWFjaDogY29uZmlnLmZvckVhY2hcbiAgICB9KTtcbiAgICB0aGlzLl9iYWNrdXBIb3VyID0gY29uZmlnLmJhY2t1cEhvdXI7XG4gICAgdGhpcy5fYmFja3VwTWludXRlID0gY29uZmlnLmJhY2t1cE1pbnV0ZTtcbiAgICB0aGlzLl9iaW5sb2dSZXRlbnRpb25QZXJpb2QgPSBjb25maWcuYmlubG9nUmV0ZW50aW9uUGVyaW9kO1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IGNvbmZpZy5jbHVzdGVySWQ7XG4gICAgdGhpcy5fY29ubmVjdFRpbWVvdXQgPSBjb25maWcuY29ubmVjdFRpbWVvdXQ7XG4gICAgdGhpcy5fZGVmYXVsdFRpbWVab25lID0gY29uZmlnLmRlZmF1bHRUaW1lWm9uZTtcbiAgICB0aGlzLl9ncm91cENvbmNhdE1heExlbiA9IGNvbmZpZy5ncm91cENvbmNhdE1heExlbjtcbiAgICB0aGlzLl9pZCA9IGNvbmZpZy5pZDtcbiAgICB0aGlzLl9pbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5ID0gY29uZmlnLmluZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnk7XG4gICAgdGhpcy5faW5ub2RiRnRNaW5Ub2tlblNpemUgPSBjb25maWcuaW5ub2RiRnRNaW5Ub2tlblNpemU7XG4gICAgdGhpcy5faW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlID0gY29uZmlnLmlubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZTtcbiAgICB0aGlzLl9pbm5vZGJMb2NrV2FpdFRpbWVvdXQgPSBjb25maWcuaW5ub2RiTG9ja1dhaXRUaW1lb3V0O1xuICAgIHRoaXMuX2lubm9kYkxvZ0J1ZmZlclNpemUgPSBjb25maWcuaW5ub2RiTG9nQnVmZmVyU2l6ZTtcbiAgICB0aGlzLl9pbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemUgPSBjb25maWcuaW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplO1xuICAgIHRoaXMuX2lubm9kYlByaW50QWxsRGVhZGxvY2tzID0gY29uZmlnLmlubm9kYlByaW50QWxsRGVhZGxvY2tzO1xuICAgIHRoaXMuX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0ID0gY29uZmlnLmlubm9kYlJvbGxiYWNrT25UaW1lb3V0O1xuICAgIHRoaXMuX2ludGVyYWN0aXZlVGltZW91dCA9IGNvbmZpZy5pbnRlcmFjdGl2ZVRpbWVvdXQ7XG4gICAgdGhpcy5faW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lID0gY29uZmlnLmludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZTtcbiAgICB0aGlzLl9sb25nUXVlcnlUaW1lID0gY29uZmlnLmxvbmdRdWVyeVRpbWU7XG4gICAgdGhpcy5fbWF4QWxsb3dlZFBhY2tldCA9IGNvbmZpZy5tYXhBbGxvd2VkUGFja2V0O1xuICAgIHRoaXMuX21heEhlYXBUYWJsZVNpemUgPSBjb25maWcubWF4SGVhcFRhYmxlU2l6ZTtcbiAgICB0aGlzLl9uZXRSZWFkVGltZW91dCA9IGNvbmZpZy5uZXRSZWFkVGltZW91dDtcbiAgICB0aGlzLl9uZXRXcml0ZVRpbWVvdXQgPSBjb25maWcubmV0V3JpdGVUaW1lb3V0O1xuICAgIHRoaXMuX3Nsb3dRdWVyeUxvZyA9IGNvbmZpZy5zbG93UXVlcnlMb2c7XG4gICAgdGhpcy5fc29ydEJ1ZmZlclNpemUgPSBjb25maWcuc29ydEJ1ZmZlclNpemU7XG4gICAgdGhpcy5fc3FsTW9kZSA9IGNvbmZpZy5zcWxNb2RlO1xuICAgIHRoaXMuX3NxbFJlcXVpcmVQcmltYXJ5S2V5ID0gY29uZmlnLnNxbFJlcXVpcmVQcmltYXJ5S2V5O1xuICAgIHRoaXMuX3RtcFRhYmxlU2l6ZSA9IGNvbmZpZy50bXBUYWJsZVNpemU7XG4gICAgdGhpcy5fd2FpdFRpbWVvdXQgPSBjb25maWcud2FpdFRpbWVvdXQ7XG4gIH1cblxuICAvLyA9PT09PT09PT09XG4gIC8vIEFUVFJJQlVURVNcbiAgLy8gPT09PT09PT09PVxuXG4gIC8vIGJhY2t1cF9ob3VyIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYmFja3VwSG91cj86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmFja3VwSG91cigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2JhY2t1cF9ob3VyJyk7XG4gIH1cbiAgcHVibGljIHNldCBiYWNrdXBIb3VyKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9iYWNrdXBIb3VyID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QmFja3VwSG91cigpIHtcbiAgICB0aGlzLl9iYWNrdXBIb3VyID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBiYWNrdXBIb3VySW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2JhY2t1cEhvdXI7XG4gIH1cblxuICAvLyBiYWNrdXBfbWludXRlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYmFja3VwTWludXRlPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBiYWNrdXBNaW51dGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdiYWNrdXBfbWludXRlJyk7XG4gIH1cbiAgcHVibGljIHNldCBiYWNrdXBNaW51dGUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2JhY2t1cE1pbnV0ZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEJhY2t1cE1pbnV0ZSgpIHtcbiAgICB0aGlzLl9iYWNrdXBNaW51dGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGJhY2t1cE1pbnV0ZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9iYWNrdXBNaW51dGU7XG4gIH1cblxuICAvLyBiaW5sb2dfcmV0ZW50aW9uX3BlcmlvZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2JpbmxvZ1JldGVudGlvblBlcmlvZD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgYmlubG9nUmV0ZW50aW9uUGVyaW9kKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnYmlubG9nX3JldGVudGlvbl9wZXJpb2QnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGJpbmxvZ1JldGVudGlvblBlcmlvZCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fYmlubG9nUmV0ZW50aW9uUGVyaW9kID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0QmlubG9nUmV0ZW50aW9uUGVyaW9kKCkge1xuICAgIHRoaXMuX2JpbmxvZ1JldGVudGlvblBlcmlvZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYmlubG9nUmV0ZW50aW9uUGVyaW9kSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2JpbmxvZ1JldGVudGlvblBlcmlvZDtcbiAgfVxuXG4gIC8vIGNsdXN0ZXJfaWQgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiBmYWxzZSwgcmVxdWlyZWQ6IHRydWVcbiAgcHJpdmF0ZSBfY2x1c3RlcklkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBjbHVzdGVySWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdjbHVzdGVyX2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBjbHVzdGVySWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IHZhbHVlO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVySWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3RlcklkO1xuICB9XG5cbiAgLy8gY29ubmVjdF90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfY29ubmVjdFRpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGNvbm5lY3RUaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnY29ubmVjdF90aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBjb25uZWN0VGltZW91dCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fY29ubmVjdFRpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRDb25uZWN0VGltZW91dCgpIHtcbiAgICB0aGlzLl9jb25uZWN0VGltZW91dCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgY29ubmVjdFRpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubmVjdFRpbWVvdXQ7XG4gIH1cblxuICAvLyBkZWZhdWx0X3RpbWVfem9uZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2RlZmF1bHRUaW1lWm9uZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgZGVmYXVsdFRpbWVab25lKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnZGVmYXVsdF90aW1lX3pvbmUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGRlZmF1bHRUaW1lWm9uZSh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fZGVmYXVsdFRpbWVab25lID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0RGVmYXVsdFRpbWVab25lKCkge1xuICAgIHRoaXMuX2RlZmF1bHRUaW1lWm9uZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgZGVmYXVsdFRpbWVab25lSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RlZmF1bHRUaW1lWm9uZTtcbiAgfVxuXG4gIC8vIGdyb3VwX2NvbmNhdF9tYXhfbGVuIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfZ3JvdXBDb25jYXRNYXhMZW4/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGdyb3VwQ29uY2F0TWF4TGVuKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnZ3JvdXBfY29uY2F0X21heF9sZW4nKTtcbiAgfVxuICBwdWJsaWMgc2V0IGdyb3VwQ29uY2F0TWF4TGVuKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9ncm91cENvbmNhdE1heExlbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEdyb3VwQ29uY2F0TWF4TGVuKCkge1xuICAgIHRoaXMuX2dyb3VwQ29uY2F0TWF4TGVuID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBncm91cENvbmNhdE1heExlbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9ncm91cENvbmNhdE1heExlbjtcbiAgfVxuXG4gIC8vIGlkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGlkKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlkKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9pZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElkKCkge1xuICAgIHRoaXMuX2lkID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pZDtcbiAgfVxuXG4gIC8vIGluZm9ybWF0aW9uX3NjaGVtYV9zdGF0c19leHBpcnkgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBpbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5mb3JtYXRpb25fc2NoZW1hX3N0YXRzX2V4cGlyeScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEluZm9ybWF0aW9uU2NoZW1hU3RhdHNFeHBpcnkoKSB7XG4gICAgdGhpcy5faW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5O1xuICB9XG5cbiAgLy8gaW5ub2RiX2Z0X21pbl90b2tlbl9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5ub2RiRnRNaW5Ub2tlblNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGlubm9kYkZ0TWluVG9rZW5TaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5ub2RiX2Z0X21pbl90b2tlbl9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbm5vZGJGdE1pblRva2VuU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5ub2RiRnRNaW5Ub2tlblNpemUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbm5vZGJGdE1pblRva2VuU2l6ZSgpIHtcbiAgICB0aGlzLl9pbm5vZGJGdE1pblRva2VuU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5ub2RiRnRNaW5Ub2tlblNpemVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5ub2RiRnRNaW5Ub2tlblNpemU7XG4gIH1cblxuICAvLyBpbm5vZGJfZnRfc2VydmVyX3N0b3B3b3JkX3RhYmxlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5ub2RiRnRTZXJ2ZXJTdG9wd29yZFRhYmxlPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBpbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdpbm5vZGJfZnRfc2VydmVyX3N0b3B3b3JkX3RhYmxlJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2lubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZSgpIHtcbiAgICB0aGlzLl9pbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pbm5vZGJGdFNlcnZlclN0b3B3b3JkVGFibGU7XG4gIH1cblxuICAvLyBpbm5vZGJfbG9ja193YWl0X3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9pbm5vZGJMb2NrV2FpdFRpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGlubm9kYkxvY2tXYWl0VGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2lubm9kYl9sb2NrX3dhaXRfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5ub2RiTG9ja1dhaXRUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbm5vZGJMb2NrV2FpdFRpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbm5vZGJMb2NrV2FpdFRpbWVvdXQoKSB7XG4gICAgdGhpcy5faW5ub2RiTG9ja1dhaXRUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbm5vZGJMb2NrV2FpdFRpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5ub2RiTG9ja1dhaXRUaW1lb3V0O1xuICB9XG5cbiAgLy8gaW5ub2RiX2xvZ19idWZmZXJfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lubm9kYkxvZ0J1ZmZlclNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGlubm9kYkxvZ0J1ZmZlclNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdpbm5vZGJfbG9nX2J1ZmZlcl9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbm5vZGJMb2dCdWZmZXJTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbm5vZGJMb2dCdWZmZXJTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5ub2RiTG9nQnVmZmVyU2l6ZSgpIHtcbiAgICB0aGlzLl9pbm5vZGJMb2dCdWZmZXJTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbm5vZGJMb2dCdWZmZXJTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lubm9kYkxvZ0J1ZmZlclNpemU7XG4gIH1cblxuICAvLyBpbm5vZGJfb25saW5lX2FsdGVyX2xvZ19tYXhfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW5ub2RiX29ubGluZV9hbHRlcl9sb2dfbWF4X3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5faW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplKCkge1xuICAgIHRoaXMuX2lubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5ub2RiT25saW5lQWx0ZXJMb2dNYXhTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lubm9kYk9ubGluZUFsdGVyTG9nTWF4U2l6ZTtcbiAgfVxuXG4gIC8vIGlubm9kYl9wcmludF9hbGxfZGVhZGxvY2tzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaW5ub2RiUHJpbnRBbGxEZWFkbG9ja3M/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IGlubm9kYlByaW50QWxsRGVhZGxvY2tzKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2lubm9kYl9wcmludF9hbGxfZGVhZGxvY2tzJyk7XG4gIH1cbiAgcHVibGljIHNldCBpbm5vZGJQcmludEFsbERlYWRsb2Nrcyh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5faW5ub2RiUHJpbnRBbGxEZWFkbG9ja3MgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbm5vZGJQcmludEFsbERlYWRsb2NrcygpIHtcbiAgICB0aGlzLl9pbm5vZGJQcmludEFsbERlYWRsb2NrcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaW5ub2RiUHJpbnRBbGxEZWFkbG9ja3NJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW5ub2RiUHJpbnRBbGxEZWFkbG9ja3M7XG4gIH1cblxuICAvLyBpbm5vZGJfcm9sbGJhY2tfb25fdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0PzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBpbm5vZGJSb2xsYmFja09uVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdpbm5vZGJfcm9sbGJhY2tfb25fdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW5ub2RiUm9sbGJhY2tPblRpbWVvdXQodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SW5ub2RiUm9sbGJhY2tPblRpbWVvdXQoKSB7XG4gICAgdGhpcy5faW5ub2RiUm9sbGJhY2tPblRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGlubm9kYlJvbGxiYWNrT25UaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0O1xuICB9XG5cbiAgLy8gaW50ZXJhY3RpdmVfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2ludGVyYWN0aXZlVGltZW91dD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgaW50ZXJhY3RpdmVUaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnaW50ZXJhY3RpdmVfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW50ZXJhY3RpdmVUaW1lb3V0KHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9pbnRlcmFjdGl2ZVRpbWVvdXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbnRlcmFjdGl2ZVRpbWVvdXQoKSB7XG4gICAgdGhpcy5faW50ZXJhY3RpdmVUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbnRlcmFjdGl2ZVRpbWVvdXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW50ZXJhY3RpdmVUaW1lb3V0O1xuICB9XG5cbiAgLy8gaW50ZXJuYWxfdG1wX21lbV9zdG9yYWdlX2VuZ2luZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2ludGVybmFsVG1wTWVtU3RvcmFnZUVuZ2luZT86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgaW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnaW50ZXJuYWxfdG1wX21lbV9zdG9yYWdlX2VuZ2luZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgaW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9pbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRJbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmUoKSB7XG4gICAgdGhpcy5faW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5faW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lO1xuICB9XG5cbiAgLy8gbG9uZ19xdWVyeV90aW1lIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9uZ1F1ZXJ5VGltZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbG9uZ1F1ZXJ5VGltZSgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xvbmdfcXVlcnlfdGltZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9uZ1F1ZXJ5VGltZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9uZ1F1ZXJ5VGltZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvbmdRdWVyeVRpbWUoKSB7XG4gICAgdGhpcy5fbG9uZ1F1ZXJ5VGltZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9uZ1F1ZXJ5VGltZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb25nUXVlcnlUaW1lO1xuICB9XG5cbiAgLy8gbWF4X2FsbG93ZWRfcGFja2V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbWF4QWxsb3dlZFBhY2tldD86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWF4QWxsb3dlZFBhY2tldCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ21heF9hbGxvd2VkX3BhY2tldCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgbWF4QWxsb3dlZFBhY2tldCh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWF4QWxsb3dlZFBhY2tldCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE1heEFsbG93ZWRQYWNrZXQoKSB7XG4gICAgdGhpcy5fbWF4QWxsb3dlZFBhY2tldCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWF4QWxsb3dlZFBhY2tldElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9tYXhBbGxvd2VkUGFja2V0O1xuICB9XG5cbiAgLy8gbWF4X2hlYXBfdGFibGVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21heEhlYXBUYWJsZVNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG1heEhlYXBUYWJsZVNpemUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0TnVtYmVyQXR0cmlidXRlKCdtYXhfaGVhcF90YWJsZV9zaXplJyk7XG4gIH1cbiAgcHVibGljIHNldCBtYXhIZWFwVGFibGVTaXplKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9tYXhIZWFwVGFibGVTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWF4SGVhcFRhYmxlU2l6ZSgpIHtcbiAgICB0aGlzLl9tYXhIZWFwVGFibGVTaXplID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBtYXhIZWFwVGFibGVTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21heEhlYXBUYWJsZVNpemU7XG4gIH1cblxuICAvLyBuZXRfcmVhZF90aW1lb3V0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbmV0UmVhZFRpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG5ldFJlYWRUaW1lb3V0KCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbmV0X3JlYWRfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgbmV0UmVhZFRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX25ldFJlYWRUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TmV0UmVhZFRpbWVvdXQoKSB7XG4gICAgdGhpcy5fbmV0UmVhZFRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG5ldFJlYWRUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX25ldFJlYWRUaW1lb3V0O1xuICB9XG5cbiAgLy8gbmV0X3dyaXRlX3RpbWVvdXQgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9uZXRXcml0ZVRpbWVvdXQ/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IG5ldFdyaXRlVGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ25ldF93cml0ZV90aW1lb3V0Jyk7XG4gIH1cbiAgcHVibGljIHNldCBuZXRXcml0ZVRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX25ldFdyaXRlVGltZW91dCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE5ldFdyaXRlVGltZW91dCgpIHtcbiAgICB0aGlzLl9uZXRXcml0ZVRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IG5ldFdyaXRlVGltZW91dElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9uZXRXcml0ZVRpbWVvdXQ7XG4gIH1cblxuICAvLyBzbG93X3F1ZXJ5X2xvZyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3Nsb3dRdWVyeUxvZz86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgc2xvd1F1ZXJ5TG9nKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ3Nsb3dfcXVlcnlfbG9nJyk7XG4gIH1cbiAgcHVibGljIHNldCBzbG93UXVlcnlMb2codmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX3Nsb3dRdWVyeUxvZyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFNsb3dRdWVyeUxvZygpIHtcbiAgICB0aGlzLl9zbG93UXVlcnlMb2cgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNsb3dRdWVyeUxvZ0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9zbG93UXVlcnlMb2c7XG4gIH1cblxuICAvLyBzb3J0X2J1ZmZlcl9zaXplIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc29ydEJ1ZmZlclNpemU/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IHNvcnRCdWZmZXJTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnc29ydF9idWZmZXJfc2l6ZScpO1xuICB9XG4gIHB1YmxpYyBzZXQgc29ydEJ1ZmZlclNpemUodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3NvcnRCdWZmZXJTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0U29ydEJ1ZmZlclNpemUoKSB7XG4gICAgdGhpcy5fc29ydEJ1ZmZlclNpemUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNvcnRCdWZmZXJTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NvcnRCdWZmZXJTaXplO1xuICB9XG5cbiAgLy8gc3FsX21vZGUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9zcWxNb2RlPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBzcWxNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnc3FsX21vZGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHNxbE1vZGUodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3NxbE1vZGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTcWxNb2RlKCkge1xuICAgIHRoaXMuX3NxbE1vZGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHNxbE1vZGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc3FsTW9kZTtcbiAgfVxuXG4gIC8vIHNxbF9yZXF1aXJlX3ByaW1hcnlfa2V5IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfc3FsUmVxdWlyZVByaW1hcnlLZXk/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7IFxuICBwdWJsaWMgZ2V0IHNxbFJlcXVpcmVQcmltYXJ5S2V5KCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ3NxbF9yZXF1aXJlX3ByaW1hcnlfa2V5Jyk7XG4gIH1cbiAgcHVibGljIHNldCBzcWxSZXF1aXJlUHJpbWFyeUtleSh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fc3FsUmVxdWlyZVByaW1hcnlLZXkgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRTcWxSZXF1aXJlUHJpbWFyeUtleSgpIHtcbiAgICB0aGlzLl9zcWxSZXF1aXJlUHJpbWFyeUtleSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgc3FsUmVxdWlyZVByaW1hcnlLZXlJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc3FsUmVxdWlyZVByaW1hcnlLZXk7XG4gIH1cblxuICAvLyB0bXBfdGFibGVfc2l6ZSAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3RtcFRhYmxlU2l6ZT86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgdG1wVGFibGVTaXplKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgndG1wX3RhYmxlX3NpemUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHRtcFRhYmxlU2l6ZSh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fdG1wVGFibGVTaXplID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0VG1wVGFibGVTaXplKCkge1xuICAgIHRoaXMuX3RtcFRhYmxlU2l6ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgdG1wVGFibGVTaXplSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3RtcFRhYmxlU2l6ZTtcbiAgfVxuXG4gIC8vIHdhaXRfdGltZW91dCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3dhaXRUaW1lb3V0PzogbnVtYmVyOyBcbiAgcHVibGljIGdldCB3YWl0VGltZW91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ3dhaXRfdGltZW91dCcpO1xuICB9XG4gIHB1YmxpYyBzZXQgd2FpdFRpbWVvdXQodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX3dhaXRUaW1lb3V0ID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0V2FpdFRpbWVvdXQoKSB7XG4gICAgdGhpcy5fd2FpdFRpbWVvdXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHdhaXRUaW1lb3V0SW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dhaXRUaW1lb3V0O1xuICB9XG5cbiAgLy8gPT09PT09PT09XG4gIC8vIFNZTlRIRVNJU1xuICAvLyA9PT09PT09PT1cblxuICBwcm90ZWN0ZWQgc3ludGhlc2l6ZUF0dHJpYnV0ZXMoKTogeyBbbmFtZTogc3RyaW5nXTogYW55IH0ge1xuICAgIHJldHVybiB7XG4gICAgICBiYWNrdXBfaG91cjogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fYmFja3VwSG91ciksXG4gICAgICBiYWNrdXBfbWludXRlOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9iYWNrdXBNaW51dGUpLFxuICAgICAgYmlubG9nX3JldGVudGlvbl9wZXJpb2Q6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2JpbmxvZ1JldGVudGlvblBlcmlvZCksXG4gICAgICBjbHVzdGVyX2lkOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9jbHVzdGVySWQpLFxuICAgICAgY29ubmVjdF90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9jb25uZWN0VGltZW91dCksXG4gICAgICBkZWZhdWx0X3RpbWVfem9uZTogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fZGVmYXVsdFRpbWVab25lKSxcbiAgICAgIGdyb3VwX2NvbmNhdF9tYXhfbGVuOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9ncm91cENvbmNhdE1heExlbiksXG4gICAgICBpZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgaW5mb3JtYXRpb25fc2NoZW1hX3N0YXRzX2V4cGlyeTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5faW5mb3JtYXRpb25TY2hlbWFTdGF0c0V4cGlyeSksXG4gICAgICBpbm5vZGJfZnRfbWluX3Rva2VuX3NpemU6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2lubm9kYkZ0TWluVG9rZW5TaXplKSxcbiAgICAgIGlubm9kYl9mdF9zZXJ2ZXJfc3RvcHdvcmRfdGFibGU6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2lubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZSksXG4gICAgICBpbm5vZGJfbG9ja193YWl0X3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2lubm9kYkxvY2tXYWl0VGltZW91dCksXG4gICAgICBpbm5vZGJfbG9nX2J1ZmZlcl9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJMb2dCdWZmZXJTaXplKSxcbiAgICAgIGlubm9kYl9vbmxpbmVfYWx0ZXJfbG9nX21heF9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemUpLFxuICAgICAgaW5ub2RiX3ByaW50X2FsbF9kZWFkbG9ja3M6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9pbm5vZGJQcmludEFsbERlYWRsb2NrcyksXG4gICAgICBpbm5vZGJfcm9sbGJhY2tfb25fdGltZW91dDogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2lubm9kYlJvbGxiYWNrT25UaW1lb3V0KSxcbiAgICAgIGludGVyYWN0aXZlX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2ludGVyYWN0aXZlVGltZW91dCksXG4gICAgICBpbnRlcm5hbF90bXBfbWVtX3N0b3JhZ2VfZW5naW5lOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9pbnRlcm5hbFRtcE1lbVN0b3JhZ2VFbmdpbmUpLFxuICAgICAgbG9uZ19xdWVyeV90aW1lOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9sb25nUXVlcnlUaW1lKSxcbiAgICAgIG1heF9hbGxvd2VkX3BhY2tldDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fbWF4QWxsb3dlZFBhY2tldCksXG4gICAgICBtYXhfaGVhcF90YWJsZV9zaXplOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tYXhIZWFwVGFibGVTaXplKSxcbiAgICAgIG5ldF9yZWFkX3RpbWVvdXQ6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX25ldFJlYWRUaW1lb3V0KSxcbiAgICAgIG5ldF93cml0ZV90aW1lb3V0OiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9uZXRXcml0ZVRpbWVvdXQpLFxuICAgICAgc2xvd19xdWVyeV9sb2c6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9zbG93UXVlcnlMb2cpLFxuICAgICAgc29ydF9idWZmZXJfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fc29ydEJ1ZmZlclNpemUpLFxuICAgICAgc3FsX21vZGU6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX3NxbE1vZGUpLFxuICAgICAgc3FsX3JlcXVpcmVfcHJpbWFyeV9rZXk6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9zcWxSZXF1aXJlUHJpbWFyeUtleSksXG4gICAgICB0bXBfdGFibGVfc2l6ZTogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fdG1wVGFibGVTaXplKSxcbiAgICAgIHdhaXRfdGltZW91dDogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fd2FpdFRpbWVvdXQpLFxuICAgIH07XG4gIH1cblxuICBwcm90ZWN0ZWQgc3ludGhlc2l6ZUhjbEF0dHJpYnV0ZXMoKTogeyBbbmFtZTogc3RyaW5nXTogYW55IH0ge1xuICAgIGNvbnN0IGF0dHJzID0ge1xuICAgICAgYmFja3VwX2hvdXI6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2JhY2t1cEhvdXIpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiYWNrdXBfbWludXRlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9iYWNrdXBNaW51dGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBiaW5sb2dfcmV0ZW50aW9uX3BlcmlvZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fYmlubG9nUmV0ZW50aW9uUGVyaW9kKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgY2x1c3Rlcl9pZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgY29ubmVjdF90aW1lb3V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9jb25uZWN0VGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGRlZmF1bHRfdGltZV96b25lOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9kZWZhdWx0VGltZVpvbmUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBncm91cF9jb25jYXRfbWF4X2xlbjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fZ3JvdXBDb25jYXRNYXhMZW4pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBpbmZvcm1hdGlvbl9zY2hlbWFfc3RhdHNfZXhwaXJ5OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbmZvcm1hdGlvblNjaGVtYVN0YXRzRXhwaXJ5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5ub2RiX2Z0X21pbl90b2tlbl9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbm5vZGJGdE1pblRva2VuU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlubm9kYl9mdF9zZXJ2ZXJfc3RvcHdvcmRfdGFibGU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2lubm9kYkZ0U2VydmVyU3RvcHdvcmRUYWJsZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGlubm9kYl9sb2NrX3dhaXRfdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5ub2RiTG9ja1dhaXRUaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW5ub2RiX2xvZ19idWZmZXJfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW5ub2RiTG9nQnVmZmVyU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGlubm9kYl9vbmxpbmVfYWx0ZXJfbG9nX21heF9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9pbm5vZGJPbmxpbmVBbHRlckxvZ01heFNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpbm5vZGJfcHJpbnRfYWxsX2RlYWRsb2Nrczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2lubm9kYlByaW50QWxsRGVhZGxvY2tzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGlubm9kYl9yb2xsYmFja19vbl90aW1lb3V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5faW5ub2RiUm9sbGJhY2tPblRpbWVvdXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgaW50ZXJhY3RpdmVfdGltZW91dDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5faW50ZXJhY3RpdmVUaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgaW50ZXJuYWxfdG1wX21lbV9zdG9yYWdlX2VuZ2luZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5faW50ZXJuYWxUbXBNZW1TdG9yYWdlRW5naW5lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9uZ19xdWVyeV90aW1lOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb25nUXVlcnlUaW1lKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X2FsbG93ZWRfcGFja2V0OiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tYXhBbGxvd2VkUGFja2V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbWF4X2hlYXBfdGFibGVfc2l6ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbWF4SGVhcFRhYmxlU2l6ZSksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG5ldF9yZWFkX3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX25ldFJlYWRUaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbmV0X3dyaXRlX3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX25ldFdyaXRlVGltZW91dCksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIHNsb3dfcXVlcnlfbG9nOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fc2xvd1F1ZXJ5TG9nKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIHNvcnRfYnVmZmVyX3NpemU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3NvcnRCdWZmZXJTaXplKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgc3FsX21vZGU6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3NxbE1vZGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBzcWxfcmVxdWlyZV9wcmltYXJ5X2tleToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX3NxbFJlcXVpcmVQcmltYXJ5S2V5KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIHRtcF90YWJsZV9zaXplOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl90bXBUYWJsZVNpemUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICB3YWl0X3RpbWVvdXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX3dhaXRUaW1lb3V0KSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgIH07XG5cbiAgICAvLyByZW1vdmUgdW5kZWZpbmVkIGF0dHJpYnV0ZXNcbiAgICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGF0dHJzKS5maWx0ZXIoKFtfLCB2YWx1ZV0pID0+IHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUudmFsdWUgIT09IHVuZGVmaW5lZCApKVxuICB9XG59XG4iXX0=