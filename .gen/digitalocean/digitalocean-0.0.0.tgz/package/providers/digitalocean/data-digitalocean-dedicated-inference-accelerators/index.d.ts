import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDedicatedInferenceAcceleratorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the dedicated inference endpoint to list accelerators for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#dedicated_inference_id DataDigitaloceanDedicatedInferenceAccelerators#dedicated_inference_id}
    */
    readonly dedicatedInferenceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#id DataDigitaloceanDedicatedInferenceAccelerators#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#filter DataDigitaloceanDedicatedInferenceAccelerators#filter}
    */
    readonly filter?: DataDigitaloceanDedicatedInferenceAcceleratorsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#sort DataDigitaloceanDedicatedInferenceAccelerators#sort}
    */
    readonly sort?: DataDigitaloceanDedicatedInferenceAcceleratorsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanDedicatedInferenceAcceleratorsAccelerators {
}
export declare function dataDigitaloceanDedicatedInferenceAcceleratorsAcceleratorsToTerraform(struct?: DataDigitaloceanDedicatedInferenceAcceleratorsAccelerators): any;
export declare function dataDigitaloceanDedicatedInferenceAcceleratorsAcceleratorsToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceAcceleratorsAccelerators): any;
export declare class DataDigitaloceanDedicatedInferenceAcceleratorsAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceAcceleratorsAccelerators | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceAcceleratorsAccelerators | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    get slug(): string;
    get status(): string;
}
export declare class DataDigitaloceanDedicatedInferenceAcceleratorsAcceleratorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceAcceleratorsAcceleratorsOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceAcceleratorsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#all DataDigitaloceanDedicatedInferenceAccelerators#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#key DataDigitaloceanDedicatedInferenceAccelerators#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#match_by DataDigitaloceanDedicatedInferenceAccelerators#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#values DataDigitaloceanDedicatedInferenceAccelerators#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanDedicatedInferenceAcceleratorsFilterToTerraform(struct?: DataDigitaloceanDedicatedInferenceAcceleratorsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanDedicatedInferenceAcceleratorsFilterToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceAcceleratorsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanDedicatedInferenceAcceleratorsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceAcceleratorsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceAcceleratorsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanDedicatedInferenceAcceleratorsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDedicatedInferenceAcceleratorsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceAcceleratorsFilterOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceAcceleratorsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#direction DataDigitaloceanDedicatedInferenceAccelerators#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#key DataDigitaloceanDedicatedInferenceAccelerators#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanDedicatedInferenceAcceleratorsSortToTerraform(struct?: DataDigitaloceanDedicatedInferenceAcceleratorsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanDedicatedInferenceAcceleratorsSortToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceAcceleratorsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanDedicatedInferenceAcceleratorsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceAcceleratorsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceAcceleratorsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanDedicatedInferenceAcceleratorsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDedicatedInferenceAcceleratorsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceAcceleratorsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators digitalocean_dedicated_inference_accelerators}
*/
export declare class DataDigitaloceanDedicatedInferenceAccelerators extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_dedicated_inference_accelerators";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDedicatedInferenceAccelerators resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDedicatedInferenceAccelerators to import
    * @param importFromId The id of the existing DataDigitaloceanDedicatedInferenceAccelerators that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDedicatedInferenceAccelerators to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_accelerators digitalocean_dedicated_inference_accelerators} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDedicatedInferenceAcceleratorsConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanDedicatedInferenceAcceleratorsConfig);
    private _accelerators;
    get accelerators(): DataDigitaloceanDedicatedInferenceAcceleratorsAcceleratorsList;
    private _dedicatedInferenceId?;
    get dedicatedInferenceId(): string;
    set dedicatedInferenceId(value: string);
    get dedicatedInferenceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanDedicatedInferenceAcceleratorsFilterList;
    putFilter(value: DataDigitaloceanDedicatedInferenceAcceleratorsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanDedicatedInferenceAcceleratorsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanDedicatedInferenceAcceleratorsSortList;
    putSort(value: DataDigitaloceanDedicatedInferenceAcceleratorsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanDedicatedInferenceAcceleratorsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
