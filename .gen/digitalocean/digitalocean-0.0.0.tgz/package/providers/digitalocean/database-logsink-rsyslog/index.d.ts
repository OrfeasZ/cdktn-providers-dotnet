import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseLogsinkRsyslogConfig extends cdktn.TerraformMetaArguments {
    /**
    * CA certificate for TLS verification (PEM format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#ca_cert DatabaseLogsinkRsyslog#ca_cert}
    */
    readonly caCert?: string;
    /**
    * Client certificate for mTLS (PEM format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#client_cert DatabaseLogsinkRsyslog#client_cert}
    */
    readonly clientCert?: string;
    /**
    * Client private key for mTLS (PEM format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#client_key DatabaseLogsinkRsyslog#client_key}
    */
    readonly clientKey?: string;
    /**
    * UUID of the source database cluster that will forward logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#cluster_id DatabaseLogsinkRsyslog#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Log format: rfc5424, rfc3164, or custom
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#format DatabaseLogsinkRsyslog#format}
    */
    readonly format?: string;
    /**
    * Custom logline template (required when format is 'custom')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#logline DatabaseLogsinkRsyslog#logline}
    */
    readonly logline?: string;
    /**
    * Display name for the logsink
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#name DatabaseLogsinkRsyslog#name}
    */
    readonly name: string;
    /**
    * Port number for the rsyslog server (1-65535)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#port DatabaseLogsinkRsyslog#port}
    */
    readonly port: number;
    /**
    * Hostname or IP address of the rsyslog server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#server DatabaseLogsinkRsyslog#server}
    */
    readonly server: string;
    /**
    * Structured data for rsyslog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#structured_data DatabaseLogsinkRsyslog#structured_data}
    */
    readonly structuredData?: string;
    /**
    * Enable TLS encryption for rsyslog connection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#tls DatabaseLogsinkRsyslog#tls}
    */
    readonly tls?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog digitalocean_database_logsink_rsyslog}
*/
export declare class DatabaseLogsinkRsyslog extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_logsink_rsyslog";
    /**
    * Generates CDKTN code for importing a DatabaseLogsinkRsyslog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseLogsinkRsyslog to import
    * @param importFromId The id of the existing DatabaseLogsinkRsyslog that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseLogsinkRsyslog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_logsink_rsyslog digitalocean_database_logsink_rsyslog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseLogsinkRsyslogConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseLogsinkRsyslogConfig);
    private _caCert?;
    get caCert(): string;
    set caCert(value: string);
    resetCaCert(): void;
    get caCertInput(): string | undefined;
    private _clientCert?;
    get clientCert(): string;
    set clientCert(value: string);
    resetClientCert(): void;
    get clientCertInput(): string | undefined;
    private _clientKey?;
    get clientKey(): string;
    set clientKey(value: string);
    resetClientKey(): void;
    get clientKeyInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    get id(): string;
    private _logline?;
    get logline(): string;
    set logline(value: string);
    resetLogline(): void;
    get loglineInput(): string | undefined;
    get logsinkId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
    private _structuredData?;
    get structuredData(): string;
    set structuredData(value: string);
    resetStructuredData(): void;
    get structuredDataInput(): string | undefined;
    private _tls?;
    get tls(): boolean | cdktn.IResolvable;
    set tls(value: boolean | cdktn.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
