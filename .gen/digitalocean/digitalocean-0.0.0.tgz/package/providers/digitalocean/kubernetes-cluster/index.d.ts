import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KubernetesClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#auto_upgrade KubernetesCluster#auto_upgrade}
    */
    readonly autoUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#cluster_subnet KubernetesCluster#cluster_subnet}
    */
    readonly clusterSubnet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#destroy_all_associated_resources KubernetesCluster#destroy_all_associated_resources}
    */
    readonly destroyAllAssociatedResources?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#ha KubernetesCluster#ha}
    */
    readonly ha?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#id KubernetesCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#kubeconfig_expire_seconds KubernetesCluster#kubeconfig_expire_seconds}
    */
    readonly kubeconfigExpireSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#name KubernetesCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#region KubernetesCluster#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#registry_integration KubernetesCluster#registry_integration}
    */
    readonly registryIntegration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#service_subnet KubernetesCluster#service_subnet}
    */
    readonly serviceSubnet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#surge_upgrade KubernetesCluster#surge_upgrade}
    */
    readonly surgeUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#tags KubernetesCluster#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#version KubernetesCluster#version}
    */
    readonly version: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#vpc_uuid KubernetesCluster#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * amd_gpu_device_metrics_exporter_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#amd_gpu_device_metrics_exporter_plugin KubernetesCluster#amd_gpu_device_metrics_exporter_plugin}
    */
    readonly amdGpuDeviceMetricsExporterPlugin?: KubernetesClusterAmdGpuDeviceMetricsExporterPlugin;
    /**
    * amd_gpu_device_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#amd_gpu_device_plugin KubernetesCluster#amd_gpu_device_plugin}
    */
    readonly amdGpuDevicePlugin?: KubernetesClusterAmdGpuDevicePlugin;
    /**
    * cluster_autoscaler_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#cluster_autoscaler_configuration KubernetesCluster#cluster_autoscaler_configuration}
    */
    readonly clusterAutoscalerConfiguration?: KubernetesClusterClusterAutoscalerConfiguration[] | cdktn.IResolvable;
    /**
    * control_plane_firewall block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#control_plane_firewall KubernetesCluster#control_plane_firewall}
    */
    readonly controlPlaneFirewall?: KubernetesClusterControlPlaneFirewall;
    /**
    * maintenance_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#maintenance_policy KubernetesCluster#maintenance_policy}
    */
    readonly maintenancePolicy?: KubernetesClusterMaintenancePolicy;
    /**
    * node_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#node_pool KubernetesCluster#node_pool}
    */
    readonly nodePool: KubernetesClusterNodePool;
    /**
    * nvidia_gpu_device_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#nvidia_gpu_device_plugin KubernetesCluster#nvidia_gpu_device_plugin}
    */
    readonly nvidiaGpuDevicePlugin?: KubernetesClusterNvidiaGpuDevicePlugin;
    /**
    * rdma_shared_device_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#rdma_shared_device_plugin KubernetesCluster#rdma_shared_device_plugin}
    */
    readonly rdmaSharedDevicePlugin?: KubernetesClusterRdmaSharedDevicePlugin;
    /**
    * routing_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#routing_agent KubernetesCluster#routing_agent}
    */
    readonly routingAgent?: KubernetesClusterRoutingAgent;
    /**
    * sso block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#sso KubernetesCluster#sso}
    */
    readonly sso?: KubernetesClusterSso;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#timeouts KubernetesCluster#timeouts}
    */
    readonly timeouts?: KubernetesClusterTimeouts;
}
export interface KubernetesClusterKubeConfig {
}
export declare function kubernetesClusterKubeConfigToTerraform(struct?: KubernetesClusterKubeConfig): any;
export declare function kubernetesClusterKubeConfigToHclTerraform(struct?: KubernetesClusterKubeConfig): any;
export declare class KubernetesClusterKubeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): KubernetesClusterKubeConfig | undefined;
    set internalValue(value: KubernetesClusterKubeConfig | undefined);
    get clientCertificate(): string;
    get clientKey(): string;
    get clusterCaCertificate(): string;
    get expiresAt(): string;
    get host(): string;
    get rawConfig(): string;
    get token(): string;
}
export declare class KubernetesClusterKubeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): KubernetesClusterKubeConfigOutputReference;
}
export interface KubernetesClusterAmdGpuDeviceMetricsExporterPlugin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterAmdGpuDeviceMetricsExporterPluginToTerraform(struct?: KubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference | KubernetesClusterAmdGpuDeviceMetricsExporterPlugin): any;
export declare function kubernetesClusterAmdGpuDeviceMetricsExporterPluginToHclTerraform(struct?: KubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference | KubernetesClusterAmdGpuDeviceMetricsExporterPlugin): any;
export declare class KubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterAmdGpuDeviceMetricsExporterPlugin | undefined;
    set internalValue(value: KubernetesClusterAmdGpuDeviceMetricsExporterPlugin | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterAmdGpuDevicePlugin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterAmdGpuDevicePluginToTerraform(struct?: KubernetesClusterAmdGpuDevicePluginOutputReference | KubernetesClusterAmdGpuDevicePlugin): any;
export declare function kubernetesClusterAmdGpuDevicePluginToHclTerraform(struct?: KubernetesClusterAmdGpuDevicePluginOutputReference | KubernetesClusterAmdGpuDevicePlugin): any;
export declare class KubernetesClusterAmdGpuDevicePluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterAmdGpuDevicePlugin | undefined;
    set internalValue(value: KubernetesClusterAmdGpuDevicePlugin | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterClusterAutoscalerConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#expanders KubernetesCluster#expanders}
    */
    readonly expanders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#scale_down_unneeded_time KubernetesCluster#scale_down_unneeded_time}
    */
    readonly scaleDownUnneededTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#scale_down_utilization_threshold KubernetesCluster#scale_down_utilization_threshold}
    */
    readonly scaleDownUtilizationThreshold?: number;
}
export declare function kubernetesClusterClusterAutoscalerConfigurationToTerraform(struct?: KubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable): any;
export declare function kubernetesClusterClusterAutoscalerConfigurationToHclTerraform(struct?: KubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable): any;
export declare class KubernetesClusterClusterAutoscalerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): KubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: KubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable | undefined);
    private _expanders?;
    get expanders(): string[];
    set expanders(value: string[]);
    resetExpanders(): void;
    get expandersInput(): string[] | undefined;
    private _scaleDownUnneededTime?;
    get scaleDownUnneededTime(): string;
    set scaleDownUnneededTime(value: string);
    resetScaleDownUnneededTime(): void;
    get scaleDownUnneededTimeInput(): string | undefined;
    private _scaleDownUtilizationThreshold?;
    get scaleDownUtilizationThreshold(): number;
    set scaleDownUtilizationThreshold(value: number);
    resetScaleDownUtilizationThreshold(): void;
    get scaleDownUtilizationThresholdInput(): number | undefined;
}
export declare class KubernetesClusterClusterAutoscalerConfigurationList extends cdktn.ComplexList {
    internalValue?: KubernetesClusterClusterAutoscalerConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): KubernetesClusterClusterAutoscalerConfigurationOutputReference;
}
export interface KubernetesClusterControlPlaneFirewall {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#allowed_addresses KubernetesCluster#allowed_addresses}
    */
    readonly allowedAddresses: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterControlPlaneFirewallToTerraform(struct?: KubernetesClusterControlPlaneFirewallOutputReference | KubernetesClusterControlPlaneFirewall): any;
export declare function kubernetesClusterControlPlaneFirewallToHclTerraform(struct?: KubernetesClusterControlPlaneFirewallOutputReference | KubernetesClusterControlPlaneFirewall): any;
export declare class KubernetesClusterControlPlaneFirewallOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterControlPlaneFirewall | undefined;
    set internalValue(value: KubernetesClusterControlPlaneFirewall | undefined);
    private _allowedAddresses?;
    get allowedAddresses(): string[];
    set allowedAddresses(value: string[]);
    get allowedAddressesInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterMaintenancePolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#day KubernetesCluster#day}
    */
    readonly day?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#start_time KubernetesCluster#start_time}
    */
    readonly startTime?: string;
}
export declare function kubernetesClusterMaintenancePolicyToTerraform(struct?: KubernetesClusterMaintenancePolicyOutputReference | KubernetesClusterMaintenancePolicy): any;
export declare function kubernetesClusterMaintenancePolicyToHclTerraform(struct?: KubernetesClusterMaintenancePolicyOutputReference | KubernetesClusterMaintenancePolicy): any;
export declare class KubernetesClusterMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterMaintenancePolicy | undefined;
    set internalValue(value: KubernetesClusterMaintenancePolicy | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    resetDay(): void;
    get dayInput(): string | undefined;
    get duration(): string;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface KubernetesClusterNodePoolNodes {
}
export declare function kubernetesClusterNodePoolNodesToTerraform(struct?: KubernetesClusterNodePoolNodes): any;
export declare function kubernetesClusterNodePoolNodesToHclTerraform(struct?: KubernetesClusterNodePoolNodes): any;
export declare class KubernetesClusterNodePoolNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): KubernetesClusterNodePoolNodes | undefined;
    set internalValue(value: KubernetesClusterNodePoolNodes | undefined);
    get createdAt(): string;
    get dropletId(): string;
    get id(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
}
export declare class KubernetesClusterNodePoolNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): KubernetesClusterNodePoolNodesOutputReference;
}
export interface KubernetesClusterNodePoolTaint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#effect KubernetesCluster#effect}
    */
    readonly effect: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#key KubernetesCluster#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#value KubernetesCluster#value}
    */
    readonly value: string;
}
export declare function kubernetesClusterNodePoolTaintToTerraform(struct?: KubernetesClusterNodePoolTaint | cdktn.IResolvable): any;
export declare function kubernetesClusterNodePoolTaintToHclTerraform(struct?: KubernetesClusterNodePoolTaint | cdktn.IResolvable): any;
export declare class KubernetesClusterNodePoolTaintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): KubernetesClusterNodePoolTaint | cdktn.IResolvable | undefined;
    set internalValue(value: KubernetesClusterNodePoolTaint | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class KubernetesClusterNodePoolTaintList extends cdktn.ComplexList {
    internalValue?: KubernetesClusterNodePoolTaint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): KubernetesClusterNodePoolTaintOutputReference;
}
export interface KubernetesClusterNodePool {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#auto_scale KubernetesCluster#auto_scale}
    */
    readonly autoScale?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#labels KubernetesCluster#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#max_nodes KubernetesCluster#max_nodes}
    */
    readonly maxNodes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#min_nodes KubernetesCluster#min_nodes}
    */
    readonly minNodes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#name KubernetesCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#node_count KubernetesCluster#node_count}
    */
    readonly nodeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#size KubernetesCluster#size}
    */
    readonly size: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#tags KubernetesCluster#tags}
    */
    readonly tags?: string[];
    /**
    * taint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#taint KubernetesCluster#taint}
    */
    readonly taint?: KubernetesClusterNodePoolTaint[] | cdktn.IResolvable;
}
export declare function kubernetesClusterNodePoolToTerraform(struct?: KubernetesClusterNodePoolOutputReference | KubernetesClusterNodePool): any;
export declare function kubernetesClusterNodePoolToHclTerraform(struct?: KubernetesClusterNodePoolOutputReference | KubernetesClusterNodePool): any;
export declare class KubernetesClusterNodePoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterNodePool | undefined;
    set internalValue(value: KubernetesClusterNodePool | undefined);
    get actualNodeCount(): number;
    private _autoScale?;
    get autoScale(): boolean | cdktn.IResolvable;
    set autoScale(value: boolean | cdktn.IResolvable);
    resetAutoScale(): void;
    get autoScaleInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _maxNodes?;
    get maxNodes(): number;
    set maxNodes(value: number);
    resetMaxNodes(): void;
    get maxNodesInput(): number | undefined;
    private _minNodes?;
    get minNodes(): number;
    set minNodes(value: number);
    resetMinNodes(): void;
    get minNodesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    resetNodeCount(): void;
    get nodeCountInput(): number | undefined;
    private _nodes;
    get nodes(): KubernetesClusterNodePoolNodesList;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _taint;
    get taint(): KubernetesClusterNodePoolTaintList;
    putTaint(value: KubernetesClusterNodePoolTaint[] | cdktn.IResolvable): void;
    resetTaint(): void;
    get taintInput(): cdktn.IResolvable | KubernetesClusterNodePoolTaint[] | undefined;
}
export interface KubernetesClusterNvidiaGpuDevicePlugin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterNvidiaGpuDevicePluginToTerraform(struct?: KubernetesClusterNvidiaGpuDevicePluginOutputReference | KubernetesClusterNvidiaGpuDevicePlugin): any;
export declare function kubernetesClusterNvidiaGpuDevicePluginToHclTerraform(struct?: KubernetesClusterNvidiaGpuDevicePluginOutputReference | KubernetesClusterNvidiaGpuDevicePlugin): any;
export declare class KubernetesClusterNvidiaGpuDevicePluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterNvidiaGpuDevicePlugin | undefined;
    set internalValue(value: KubernetesClusterNvidiaGpuDevicePlugin | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterRdmaSharedDevicePlugin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterRdmaSharedDevicePluginToTerraform(struct?: KubernetesClusterRdmaSharedDevicePluginOutputReference | KubernetesClusterRdmaSharedDevicePlugin): any;
export declare function kubernetesClusterRdmaSharedDevicePluginToHclTerraform(struct?: KubernetesClusterRdmaSharedDevicePluginOutputReference | KubernetesClusterRdmaSharedDevicePlugin): any;
export declare class KubernetesClusterRdmaSharedDevicePluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterRdmaSharedDevicePlugin | undefined;
    set internalValue(value: KubernetesClusterRdmaSharedDevicePlugin | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterRoutingAgent {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterRoutingAgentToTerraform(struct?: KubernetesClusterRoutingAgentOutputReference | KubernetesClusterRoutingAgent): any;
export declare function kubernetesClusterRoutingAgentToHclTerraform(struct?: KubernetesClusterRoutingAgentOutputReference | KubernetesClusterRoutingAgent): any;
export declare class KubernetesClusterRoutingAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterRoutingAgent | undefined;
    set internalValue(value: KubernetesClusterRoutingAgent | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterSso {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#client_id KubernetesCluster#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#enabled KubernetesCluster#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#issuer_url KubernetesCluster#issuer_url}
    */
    readonly issuerUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#required KubernetesCluster#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
}
export declare function kubernetesClusterSsoToTerraform(struct?: KubernetesClusterSsoOutputReference | KubernetesClusterSso): any;
export declare function kubernetesClusterSsoToHclTerraform(struct?: KubernetesClusterSsoOutputReference | KubernetesClusterSso): any;
export declare class KubernetesClusterSsoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterSso | undefined;
    set internalValue(value: KubernetesClusterSso | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _issuerUrl?;
    get issuerUrl(): string;
    set issuerUrl(value: string);
    resetIssuerUrl(): void;
    get issuerUrlInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
}
export interface KubernetesClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#create KubernetesCluster#create}
    */
    readonly create?: string;
}
export declare function kubernetesClusterTimeoutsToTerraform(struct?: KubernetesClusterTimeouts | cdktn.IResolvable): any;
export declare function kubernetesClusterTimeoutsToHclTerraform(struct?: KubernetesClusterTimeouts | cdktn.IResolvable): any;
export declare class KubernetesClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: KubernetesClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster digitalocean_kubernetes_cluster}
*/
export declare class KubernetesCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_kubernetes_cluster";
    /**
    * Generates CDKTN code for importing a KubernetesCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KubernetesCluster to import
    * @param importFromId The id of the existing KubernetesCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KubernetesCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/kubernetes_cluster digitalocean_kubernetes_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KubernetesClusterConfig
    */
    constructor(scope: Construct, id: string, config: KubernetesClusterConfig);
    private _autoUpgrade?;
    get autoUpgrade(): boolean | cdktn.IResolvable;
    set autoUpgrade(value: boolean | cdktn.IResolvable);
    resetAutoUpgrade(): void;
    get autoUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterSubnet?;
    get clusterSubnet(): string;
    set clusterSubnet(value: string);
    resetClusterSubnet(): void;
    get clusterSubnetInput(): string | undefined;
    get createdAt(): string;
    private _destroyAllAssociatedResources?;
    get destroyAllAssociatedResources(): boolean | cdktn.IResolvable;
    set destroyAllAssociatedResources(value: boolean | cdktn.IResolvable);
    resetDestroyAllAssociatedResources(): void;
    get destroyAllAssociatedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    get endpoint(): string;
    private _ha?;
    get ha(): boolean | cdktn.IResolvable;
    set ha(value: boolean | cdktn.IResolvable);
    resetHa(): void;
    get haInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipv4Address(): string;
    private _kubeConfig;
    get kubeConfig(): KubernetesClusterKubeConfigList;
    private _kubeconfigExpireSeconds?;
    get kubeconfigExpireSeconds(): number;
    set kubeconfigExpireSeconds(value: number);
    resetKubeconfigExpireSeconds(): void;
    get kubeconfigExpireSecondsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _registryIntegration?;
    get registryIntegration(): boolean | cdktn.IResolvable;
    set registryIntegration(value: boolean | cdktn.IResolvable);
    resetRegistryIntegration(): void;
    get registryIntegrationInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceSubnet?;
    get serviceSubnet(): string;
    set serviceSubnet(value: string);
    resetServiceSubnet(): void;
    get serviceSubnetInput(): string | undefined;
    get status(): string;
    private _surgeUpgrade?;
    get surgeUpgrade(): boolean | cdktn.IResolvable;
    set surgeUpgrade(value: boolean | cdktn.IResolvable);
    resetSurgeUpgrade(): void;
    get surgeUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    get urn(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _amdGpuDeviceMetricsExporterPlugin;
    get amdGpuDeviceMetricsExporterPlugin(): KubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference;
    putAmdGpuDeviceMetricsExporterPlugin(value: KubernetesClusterAmdGpuDeviceMetricsExporterPlugin): void;
    resetAmdGpuDeviceMetricsExporterPlugin(): void;
    get amdGpuDeviceMetricsExporterPluginInput(): KubernetesClusterAmdGpuDeviceMetricsExporterPlugin | undefined;
    private _amdGpuDevicePlugin;
    get amdGpuDevicePlugin(): KubernetesClusterAmdGpuDevicePluginOutputReference;
    putAmdGpuDevicePlugin(value: KubernetesClusterAmdGpuDevicePlugin): void;
    resetAmdGpuDevicePlugin(): void;
    get amdGpuDevicePluginInput(): KubernetesClusterAmdGpuDevicePlugin | undefined;
    private _clusterAutoscalerConfiguration;
    get clusterAutoscalerConfiguration(): KubernetesClusterClusterAutoscalerConfigurationList;
    putClusterAutoscalerConfiguration(value: KubernetesClusterClusterAutoscalerConfiguration[] | cdktn.IResolvable): void;
    resetClusterAutoscalerConfiguration(): void;
    get clusterAutoscalerConfigurationInput(): cdktn.IResolvable | KubernetesClusterClusterAutoscalerConfiguration[] | undefined;
    private _controlPlaneFirewall;
    get controlPlaneFirewall(): KubernetesClusterControlPlaneFirewallOutputReference;
    putControlPlaneFirewall(value: KubernetesClusterControlPlaneFirewall): void;
    resetControlPlaneFirewall(): void;
    get controlPlaneFirewallInput(): KubernetesClusterControlPlaneFirewall | undefined;
    private _maintenancePolicy;
    get maintenancePolicy(): KubernetesClusterMaintenancePolicyOutputReference;
    putMaintenancePolicy(value: KubernetesClusterMaintenancePolicy): void;
    resetMaintenancePolicy(): void;
    get maintenancePolicyInput(): KubernetesClusterMaintenancePolicy | undefined;
    private _nodePool;
    get nodePool(): KubernetesClusterNodePoolOutputReference;
    putNodePool(value: KubernetesClusterNodePool): void;
    get nodePoolInput(): KubernetesClusterNodePool | undefined;
    private _nvidiaGpuDevicePlugin;
    get nvidiaGpuDevicePlugin(): KubernetesClusterNvidiaGpuDevicePluginOutputReference;
    putNvidiaGpuDevicePlugin(value: KubernetesClusterNvidiaGpuDevicePlugin): void;
    resetNvidiaGpuDevicePlugin(): void;
    get nvidiaGpuDevicePluginInput(): KubernetesClusterNvidiaGpuDevicePlugin | undefined;
    private _rdmaSharedDevicePlugin;
    get rdmaSharedDevicePlugin(): KubernetesClusterRdmaSharedDevicePluginOutputReference;
    putRdmaSharedDevicePlugin(value: KubernetesClusterRdmaSharedDevicePlugin): void;
    resetRdmaSharedDevicePlugin(): void;
    get rdmaSharedDevicePluginInput(): KubernetesClusterRdmaSharedDevicePlugin | undefined;
    private _routingAgent;
    get routingAgent(): KubernetesClusterRoutingAgentOutputReference;
    putRoutingAgent(value: KubernetesClusterRoutingAgent): void;
    resetRoutingAgent(): void;
    get routingAgentInput(): KubernetesClusterRoutingAgent | undefined;
    private _sso;
    get sso(): KubernetesClusterSsoOutputReference;
    putSso(value: KubernetesClusterSso): void;
    resetSso(): void;
    get ssoInput(): KubernetesClusterSso | undefined;
    private _timeouts;
    get timeouts(): KubernetesClusterTimeoutsOutputReference;
    putTimeouts(value: KubernetesClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | KubernetesClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
