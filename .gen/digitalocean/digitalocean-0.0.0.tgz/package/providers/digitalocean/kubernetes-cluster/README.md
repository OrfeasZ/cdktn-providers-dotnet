# `digitalocean_kubernetes_cluster`

Refer to the Terraform Registry for docs: [`digitalocean_kubernetes_cluster`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/kubernetes_cluster).
