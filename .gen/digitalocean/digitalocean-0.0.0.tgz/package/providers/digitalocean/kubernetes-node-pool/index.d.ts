import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KubernetesNodePoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#auto_scale KubernetesNodePool#auto_scale}
    */
    readonly autoScale?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#cluster_id KubernetesNodePool#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#id KubernetesNodePool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#labels KubernetesNodePool#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#max_nodes KubernetesNodePool#max_nodes}
    */
    readonly maxNodes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#min_nodes KubernetesNodePool#min_nodes}
    */
    readonly minNodes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#name KubernetesNodePool#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#node_count KubernetesNodePool#node_count}
    */
    readonly nodeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#size KubernetesNodePool#size}
    */
    readonly size: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#tags KubernetesNodePool#tags}
    */
    readonly tags?: string[];
    /**
    * taint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#taint KubernetesNodePool#taint}
    */
    readonly taint?: KubernetesNodePoolTaint[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#timeouts KubernetesNodePool#timeouts}
    */
    readonly timeouts?: KubernetesNodePoolTimeouts;
}
export interface KubernetesNodePoolNodes {
}
export declare function kubernetesNodePoolNodesToTerraform(struct?: KubernetesNodePoolNodes): any;
export declare function kubernetesNodePoolNodesToHclTerraform(struct?: KubernetesNodePoolNodes): any;
export declare class KubernetesNodePoolNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): KubernetesNodePoolNodes | undefined;
    set internalValue(value: KubernetesNodePoolNodes | undefined);
    get createdAt(): string;
    get dropletId(): string;
    get id(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
}
export declare class KubernetesNodePoolNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): KubernetesNodePoolNodesOutputReference;
}
export interface KubernetesNodePoolTaint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#effect KubernetesNodePool#effect}
    */
    readonly effect: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#key KubernetesNodePool#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#value KubernetesNodePool#value}
    */
    readonly value: string;
}
export declare function kubernetesNodePoolTaintToTerraform(struct?: KubernetesNodePoolTaint | cdktn.IResolvable): any;
export declare function kubernetesNodePoolTaintToHclTerraform(struct?: KubernetesNodePoolTaint | cdktn.IResolvable): any;
export declare class KubernetesNodePoolTaintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): KubernetesNodePoolTaint | cdktn.IResolvable | undefined;
    set internalValue(value: KubernetesNodePoolTaint | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class KubernetesNodePoolTaintList extends cdktn.ComplexList {
    internalValue?: KubernetesNodePoolTaint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): KubernetesNodePoolTaintOutputReference;
}
export interface KubernetesNodePoolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#create KubernetesNodePool#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#delete KubernetesNodePool#delete}
    */
    readonly delete?: string;
}
export declare function kubernetesNodePoolTimeoutsToTerraform(struct?: KubernetesNodePoolTimeouts | cdktn.IResolvable): any;
export declare function kubernetesNodePoolTimeoutsToHclTerraform(struct?: KubernetesNodePoolTimeouts | cdktn.IResolvable): any;
export declare class KubernetesNodePoolTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KubernetesNodePoolTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: KubernetesNodePoolTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool digitalocean_kubernetes_node_pool}
*/
export declare class KubernetesNodePool extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_kubernetes_node_pool";
    /**
    * Generates CDKTN code for importing a KubernetesNodePool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KubernetesNodePool to import
    * @param importFromId The id of the existing KubernetesNodePool that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KubernetesNodePool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/kubernetes_node_pool digitalocean_kubernetes_node_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KubernetesNodePoolConfig
    */
    constructor(scope: Construct, id: string, config: KubernetesNodePoolConfig);
    get actualNodeCount(): number;
    private _autoScale?;
    get autoScale(): boolean | cdktn.IResolvable;
    set autoScale(value: boolean | cdktn.IResolvable);
    resetAutoScale(): void;
    get autoScaleInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _maxNodes?;
    get maxNodes(): number;
    set maxNodes(value: number);
    resetMaxNodes(): void;
    get maxNodesInput(): number | undefined;
    private _minNodes?;
    get minNodes(): number;
    set minNodes(value: number);
    resetMinNodes(): void;
    get minNodesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    resetNodeCount(): void;
    get nodeCountInput(): number | undefined;
    private _nodes;
    get nodes(): KubernetesNodePoolNodesList;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _taint;
    get taint(): KubernetesNodePoolTaintList;
    putTaint(value: KubernetesNodePoolTaint[] | cdktn.IResolvable): void;
    resetTaint(): void;
    get taintInput(): cdktn.IResolvable | KubernetesNodePoolTaint[] | undefined;
    private _timeouts;
    get timeouts(): KubernetesNodePoolTimeoutsOutputReference;
    putTimeouts(value: KubernetesNodePoolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | KubernetesNodePoolTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
