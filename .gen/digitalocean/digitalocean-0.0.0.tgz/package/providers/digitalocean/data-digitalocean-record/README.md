# `data_digitalocean_record`

Refer to the Terraform Registry for docs: [`data_digitalocean_record`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/record).
