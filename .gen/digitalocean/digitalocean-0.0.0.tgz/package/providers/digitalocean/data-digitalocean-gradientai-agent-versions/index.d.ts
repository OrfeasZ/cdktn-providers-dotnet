import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiAgentVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the agent to fetch versions for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#agent_id DataDigitaloceanGradientaiAgentVersions#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#id DataDigitaloceanGradientaiAgentVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#filter DataDigitaloceanGradientaiAgentVersions#filter}
    */
    readonly filter?: DataDigitaloceanGradientaiAgentVersionsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#sort DataDigitaloceanGradientaiAgentVersions#sort}
    */
    readonly sort?: DataDigitaloceanGradientaiAgentVersionsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgents {
}
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgents): any;
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgents): any;
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgents | undefined);
    get agentName(): string;
    get childAgentUuid(): string;
    get ifCase(): string;
    get isDeleted(): cdktn.IResolvable;
    get routeName(): string;
}
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctions {
}
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctionsToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctions): any;
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctions): any;
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctions | undefined);
    get description(): string;
    get faasName(): string;
    get faasNamespace(): string;
    get isDeleted(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrails {
}
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrailsToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrails): any;
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrailsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrails): any;
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrails | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrails | undefined);
    get isDeleted(): cdktn.IResolvable;
    get name(): string;
    get priority(): number;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrailsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBases {
}
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBases): any;
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBases): any;
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBases | undefined);
    get isDeleted(): cdktn.IResolvable;
    get name(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentVersionsAgentVersions {
}
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersions): any;
export declare function dataDigitaloceanGradientaiAgentVersionsAgentVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsAgentVersions): any;
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsAgentVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsAgentVersions | undefined);
    get agentUuid(): string;
    private _attachedChildAgents;
    get attachedChildAgents(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedChildAgentsList;
    private _attachedFunctions;
    get attachedFunctions(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedFunctionsList;
    private _attachedGuardrails;
    get attachedGuardrails(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedGuardrailsList;
    private _attachedKnowledgeBases;
    get attachedKnowledgeBases(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsAttachedKnowledgeBasesList;
    get canRollback(): cdktn.IResolvable;
    get createdAt(): string;
    get createdByEmail(): string;
    get currentlyApplied(): cdktn.IResolvable;
    get description(): string;
    get id(): string;
    get instruction(): string;
    get k(): number;
    get maxTokens(): number;
    get modelName(): string;
    get name(): string;
    get provideCitations(): cdktn.IResolvable;
    get retrievalMethod(): string;
    get tags(): string[];
    get temperature(): number;
    get topP(): number;
    get triggerAction(): string;
    get versionHash(): string;
}
export declare class DataDigitaloceanGradientaiAgentVersionsAgentVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsAgentVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentVersionsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#all DataDigitaloceanGradientaiAgentVersions#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#key DataDigitaloceanGradientaiAgentVersions#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#match_by DataDigitaloceanGradientaiAgentVersions#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#values DataDigitaloceanGradientaiAgentVersions#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGradientaiAgentVersionsFilterToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentVersionsFilterToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentVersionsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGradientaiAgentVersionsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentVersionsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsFilterOutputReference;
}
export interface DataDigitaloceanGradientaiAgentVersionsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#direction DataDigitaloceanGradientaiAgentVersions#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#key DataDigitaloceanGradientaiAgentVersions#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGradientaiAgentVersionsSortToTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentVersionsSortToHclTerraform(struct?: DataDigitaloceanGradientaiAgentVersionsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentVersionsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentVersionsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentVersionsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentVersionsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentVersionsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentVersionsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions digitalocean_gradientai_agent_versions}
*/
export declare class DataDigitaloceanGradientaiAgentVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_agent_versions";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiAgentVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiAgentVersions to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiAgentVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiAgentVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent_versions digitalocean_gradientai_agent_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiAgentVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiAgentVersionsConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersions;
    get agentVersions(): DataDigitaloceanGradientaiAgentVersionsAgentVersionsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanGradientaiAgentVersionsFilterList;
    putFilter(value: DataDigitaloceanGradientaiAgentVersionsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentVersionsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGradientaiAgentVersionsSortList;
    putSort(value: DataDigitaloceanGradientaiAgentVersionsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentVersionsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
