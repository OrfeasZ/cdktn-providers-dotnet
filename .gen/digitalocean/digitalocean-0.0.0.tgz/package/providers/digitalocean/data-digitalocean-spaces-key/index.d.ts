import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanSpacesKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The access key for the Spaces key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_key#access_key DataDigitaloceanSpacesKey#access_key}
    */
    readonly accessKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_key#id DataDigitaloceanSpacesKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDigitaloceanSpacesKeyGrant {
}
export declare function dataDigitaloceanSpacesKeyGrantToTerraform(struct?: DataDigitaloceanSpacesKeyGrant): any;
export declare function dataDigitaloceanSpacesKeyGrantToHclTerraform(struct?: DataDigitaloceanSpacesKeyGrant): any;
export declare class DataDigitaloceanSpacesKeyGrantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSpacesKeyGrant | undefined;
    set internalValue(value: DataDigitaloceanSpacesKeyGrant | undefined);
    get bucket(): string;
    get permission(): string;
}
export declare class DataDigitaloceanSpacesKeyGrantList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSpacesKeyGrantOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_key digitalocean_spaces_key}
*/
export declare class DataDigitaloceanSpacesKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_spaces_key";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanSpacesKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanSpacesKey to import
    * @param importFromId The id of the existing DataDigitaloceanSpacesKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanSpacesKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_key digitalocean_spaces_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanSpacesKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanSpacesKeyConfig);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    get accessKeyInput(): string | undefined;
    get createdAt(): string;
    private _grant;
    get grant(): DataDigitaloceanSpacesKeyGrantList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
