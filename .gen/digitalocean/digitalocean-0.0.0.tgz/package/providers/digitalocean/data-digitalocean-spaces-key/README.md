# `data_digitalocean_spaces_key`

Refer to the Terraform Registry for docs: [`data_digitalocean_spaces_key`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/spaces_key).
