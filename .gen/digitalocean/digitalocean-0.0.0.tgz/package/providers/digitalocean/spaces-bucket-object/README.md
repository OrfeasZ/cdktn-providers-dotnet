# `digitalocean_spaces_bucket_object`

Refer to the Terraform Registry for docs: [`digitalocean_spaces_bucket_object`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_bucket_object).
