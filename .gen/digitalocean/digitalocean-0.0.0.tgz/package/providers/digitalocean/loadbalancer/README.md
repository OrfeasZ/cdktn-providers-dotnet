# `digitalocean_loadbalancer`

Refer to the Terraform Registry for docs: [`digitalocean_loadbalancer`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/loadbalancer).
