import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadbalancerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#algorithm Loadbalancer#algorithm}
    */
    readonly algorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#disable_lets_encrypt_dns_records Loadbalancer#disable_lets_encrypt_dns_records}
    */
    readonly disableLetsEncryptDnsRecords?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#droplet_ids Loadbalancer#droplet_ids}
    */
    readonly dropletIds?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#droplet_tag Loadbalancer#droplet_tag}
    */
    readonly dropletTag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#enable_backend_keepalive Loadbalancer#enable_backend_keepalive}
    */
    readonly enableBackendKeepalive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#enable_proxy_protocol Loadbalancer#enable_proxy_protocol}
    */
    readonly enableProxyProtocol?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#http_idle_timeout_seconds Loadbalancer#http_idle_timeout_seconds}
    */
    readonly httpIdleTimeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#id Loadbalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#name Loadbalancer#name}
    */
    readonly name: string;
    /**
    * the type of network the load balancer is accessible from (EXTERNAL or INTERNAL)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#network Loadbalancer#network}
    */
    readonly network?: string;
    /**
    * The network stack determines the allocation of ipv4/ipv6 addresses to the load balancer. Enum: 'IPV4' 'DUALSTACK'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#network_stack Loadbalancer#network_stack}
    */
    readonly networkStack?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#project_id Loadbalancer#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#redirect_http_to_https Loadbalancer#redirect_http_to_https}
    */
    readonly redirectHttpToHttps?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#region Loadbalancer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#size Loadbalancer#size}
    */
    readonly size?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#size_unit Loadbalancer#size_unit}
    */
    readonly sizeUnit?: number;
    /**
    * list of load balancer IDs to put behind a global load balancer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#target_load_balancer_ids Loadbalancer#target_load_balancer_ids}
    */
    readonly targetLoadBalancerIds?: string[];
    /**
    * The tls cipher policy to be used for the load balancer. Enum: 'DEFAULT' 'STRONG'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#tls_cipher_policy Loadbalancer#tls_cipher_policy}
    */
    readonly tlsCipherPolicy?: string;
    /**
    * the type of the load balancer (GLOBAL, REGIONAL, or REGIONAL_NETWORK)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#type Loadbalancer#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#vpc_uuid Loadbalancer#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * domains block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#domains Loadbalancer#domains}
    */
    readonly domains?: LoadbalancerDomains[] | cdktn.IResolvable;
    /**
    * firewall block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#firewall Loadbalancer#firewall}
    */
    readonly firewall?: LoadbalancerFirewall;
    /**
    * forwarding_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#forwarding_rule Loadbalancer#forwarding_rule}
    */
    readonly forwardingRule?: LoadbalancerForwardingRule[] | cdktn.IResolvable;
    /**
    * glb_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#glb_settings Loadbalancer#glb_settings}
    */
    readonly glbSettings?: LoadbalancerGlbSettings;
    /**
    * healthcheck block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#healthcheck Loadbalancer#healthcheck}
    */
    readonly healthcheck?: LoadbalancerHealthcheck;
    /**
    * sticky_sessions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#sticky_sessions Loadbalancer#sticky_sessions}
    */
    readonly stickySessions?: LoadbalancerStickySessions;
}
export interface LoadbalancerDomains {
    /**
    * name of certificate required for TLS handshaking
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#certificate_name Loadbalancer#certificate_name}
    */
    readonly certificateName?: string;
    /**
    * flag indicating if domain is managed by DigitalOcean
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#is_managed Loadbalancer#is_managed}
    */
    readonly isManaged?: boolean | cdktn.IResolvable;
    /**
    * domain name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#name Loadbalancer#name}
    */
    readonly name: string;
}
export declare function loadbalancerDomainsToTerraform(struct?: LoadbalancerDomains | cdktn.IResolvable): any;
export declare function loadbalancerDomainsToHclTerraform(struct?: LoadbalancerDomains | cdktn.IResolvable): any;
export declare class LoadbalancerDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerDomains | cdktn.IResolvable | undefined;
    set internalValue(value: LoadbalancerDomains | cdktn.IResolvable | undefined);
    get certificateId(): string;
    private _certificateName?;
    get certificateName(): string;
    set certificateName(value: string);
    resetCertificateName(): void;
    get certificateNameInput(): string | undefined;
    private _isManaged?;
    get isManaged(): boolean | cdktn.IResolvable;
    set isManaged(value: boolean | cdktn.IResolvable);
    resetIsManaged(): void;
    get isManagedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get sslValidationErrorReasons(): string[];
    get verificationErrorReasons(): string[];
}
export declare class LoadbalancerDomainsList extends cdktn.ComplexList {
    internalValue?: LoadbalancerDomains[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerDomainsOutputReference;
}
export interface LoadbalancerFirewall {
    /**
    * the rules for ALLOWING traffic to the LB (strings in the form: 'ip:1.2.3.4' or 'cidr:1.2.0.0/16')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#allow Loadbalancer#allow}
    */
    readonly allow?: string[];
    /**
    * the rules for DENYING traffic to the LB (strings in the form: 'ip:1.2.3.4' or 'cidr:1.2.0.0/16')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#deny Loadbalancer#deny}
    */
    readonly deny?: string[];
}
export declare function loadbalancerFirewallToTerraform(struct?: LoadbalancerFirewallOutputReference | LoadbalancerFirewall): any;
export declare function loadbalancerFirewallToHclTerraform(struct?: LoadbalancerFirewallOutputReference | LoadbalancerFirewall): any;
export declare class LoadbalancerFirewallOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerFirewall | undefined;
    set internalValue(value: LoadbalancerFirewall | undefined);
    private _allow?;
    get allow(): string[];
    set allow(value: string[]);
    resetAllow(): void;
    get allowInput(): string[] | undefined;
    private _deny?;
    get deny(): string[];
    set deny(value: string[]);
    resetDeny(): void;
    get denyInput(): string[] | undefined;
}
export interface LoadbalancerForwardingRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#certificate_id Loadbalancer#certificate_id}
    */
    readonly certificateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#certificate_name Loadbalancer#certificate_name}
    */
    readonly certificateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#entry_port Loadbalancer#entry_port}
    */
    readonly entryPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#entry_protocol Loadbalancer#entry_protocol}
    */
    readonly entryProtocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#target_port Loadbalancer#target_port}
    */
    readonly targetPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#target_protocol Loadbalancer#target_protocol}
    */
    readonly targetProtocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#tls_passthrough Loadbalancer#tls_passthrough}
    */
    readonly tlsPassthrough?: boolean | cdktn.IResolvable;
}
export declare function loadbalancerForwardingRuleToTerraform(struct?: LoadbalancerForwardingRule | cdktn.IResolvable): any;
export declare function loadbalancerForwardingRuleToHclTerraform(struct?: LoadbalancerForwardingRule | cdktn.IResolvable): any;
export declare class LoadbalancerForwardingRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerForwardingRule | cdktn.IResolvable | undefined;
    set internalValue(value: LoadbalancerForwardingRule | cdktn.IResolvable | undefined);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    resetCertificateId(): void;
    get certificateIdInput(): string | undefined;
    private _certificateName?;
    get certificateName(): string;
    set certificateName(value: string);
    resetCertificateName(): void;
    get certificateNameInput(): string | undefined;
    private _entryPort?;
    get entryPort(): number;
    set entryPort(value: number);
    get entryPortInput(): number | undefined;
    private _entryProtocol?;
    get entryProtocol(): string;
    set entryProtocol(value: string);
    get entryProtocolInput(): string | undefined;
    private _targetPort?;
    get targetPort(): number;
    set targetPort(value: number);
    get targetPortInput(): number | undefined;
    private _targetProtocol?;
    get targetProtocol(): string;
    set targetProtocol(value: string);
    get targetProtocolInput(): string | undefined;
    private _tlsPassthrough?;
    get tlsPassthrough(): boolean | cdktn.IResolvable;
    set tlsPassthrough(value: boolean | cdktn.IResolvable);
    resetTlsPassthrough(): void;
    get tlsPassthroughInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class LoadbalancerForwardingRuleList extends cdktn.ComplexList {
    internalValue?: LoadbalancerForwardingRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerForwardingRuleOutputReference;
}
export interface LoadbalancerGlbSettingsCdn {
    /**
    * cache enable flag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#is_enabled Loadbalancer#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
}
export declare function loadbalancerGlbSettingsCdnToTerraform(struct?: LoadbalancerGlbSettingsCdnOutputReference | LoadbalancerGlbSettingsCdn): any;
export declare function loadbalancerGlbSettingsCdnToHclTerraform(struct?: LoadbalancerGlbSettingsCdnOutputReference | LoadbalancerGlbSettingsCdn): any;
export declare class LoadbalancerGlbSettingsCdnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerGlbSettingsCdn | undefined;
    set internalValue(value: LoadbalancerGlbSettingsCdn | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LoadbalancerGlbSettings {
    /**
    * fail-over threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#failover_threshold Loadbalancer#failover_threshold}
    */
    readonly failoverThreshold?: number;
    /**
    * region priority map
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#region_priorities Loadbalancer#region_priorities}
    */
    readonly regionPriorities?: {
        [key: string]: number;
    };
    /**
    * target port rules
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#target_port Loadbalancer#target_port}
    */
    readonly targetPort: number;
    /**
    * target protocol rules
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#target_protocol Loadbalancer#target_protocol}
    */
    readonly targetProtocol: string;
    /**
    * cdn block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#cdn Loadbalancer#cdn}
    */
    readonly cdn?: LoadbalancerGlbSettingsCdn;
}
export declare function loadbalancerGlbSettingsToTerraform(struct?: LoadbalancerGlbSettingsOutputReference | LoadbalancerGlbSettings): any;
export declare function loadbalancerGlbSettingsToHclTerraform(struct?: LoadbalancerGlbSettingsOutputReference | LoadbalancerGlbSettings): any;
export declare class LoadbalancerGlbSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerGlbSettings | undefined;
    set internalValue(value: LoadbalancerGlbSettings | undefined);
    private _failoverThreshold?;
    get failoverThreshold(): number;
    set failoverThreshold(value: number);
    resetFailoverThreshold(): void;
    get failoverThresholdInput(): number | undefined;
    private _regionPriorities?;
    get regionPriorities(): {
        [key: string]: number;
    };
    set regionPriorities(value: {
        [key: string]: number;
    });
    resetRegionPriorities(): void;
    get regionPrioritiesInput(): {
        [key: string]: number;
    } | undefined;
    private _targetPort?;
    get targetPort(): number;
    set targetPort(value: number);
    get targetPortInput(): number | undefined;
    private _targetProtocol?;
    get targetProtocol(): string;
    set targetProtocol(value: string);
    get targetProtocolInput(): string | undefined;
    private _cdn;
    get cdn(): LoadbalancerGlbSettingsCdnOutputReference;
    putCdn(value: LoadbalancerGlbSettingsCdn): void;
    resetCdn(): void;
    get cdnInput(): LoadbalancerGlbSettingsCdn | undefined;
}
export interface LoadbalancerHealthcheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#check_interval_seconds Loadbalancer#check_interval_seconds}
    */
    readonly checkIntervalSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#healthy_threshold Loadbalancer#healthy_threshold}
    */
    readonly healthyThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#path Loadbalancer#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#port Loadbalancer#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#protocol Loadbalancer#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#response_timeout_seconds Loadbalancer#response_timeout_seconds}
    */
    readonly responseTimeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#unhealthy_threshold Loadbalancer#unhealthy_threshold}
    */
    readonly unhealthyThreshold?: number;
}
export declare function loadbalancerHealthcheckToTerraform(struct?: LoadbalancerHealthcheckOutputReference | LoadbalancerHealthcheck): any;
export declare function loadbalancerHealthcheckToHclTerraform(struct?: LoadbalancerHealthcheckOutputReference | LoadbalancerHealthcheck): any;
export declare class LoadbalancerHealthcheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerHealthcheck | undefined;
    set internalValue(value: LoadbalancerHealthcheck | undefined);
    private _checkIntervalSeconds?;
    get checkIntervalSeconds(): number;
    set checkIntervalSeconds(value: number);
    resetCheckIntervalSeconds(): void;
    get checkIntervalSecondsInput(): number | undefined;
    private _healthyThreshold?;
    get healthyThreshold(): number;
    set healthyThreshold(value: number);
    resetHealthyThreshold(): void;
    get healthyThresholdInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _responseTimeoutSeconds?;
    get responseTimeoutSeconds(): number;
    set responseTimeoutSeconds(value: number);
    resetResponseTimeoutSeconds(): void;
    get responseTimeoutSecondsInput(): number | undefined;
    private _unhealthyThreshold?;
    get unhealthyThreshold(): number;
    set unhealthyThreshold(value: number);
    resetUnhealthyThreshold(): void;
    get unhealthyThresholdInput(): number | undefined;
}
export interface LoadbalancerStickySessions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#cookie_name Loadbalancer#cookie_name}
    */
    readonly cookieName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#cookie_ttl_seconds Loadbalancer#cookie_ttl_seconds}
    */
    readonly cookieTtlSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#type Loadbalancer#type}
    */
    readonly type?: string;
}
export declare function loadbalancerStickySessionsToTerraform(struct?: LoadbalancerStickySessionsOutputReference | LoadbalancerStickySessions): any;
export declare function loadbalancerStickySessionsToHclTerraform(struct?: LoadbalancerStickySessionsOutputReference | LoadbalancerStickySessions): any;
export declare class LoadbalancerStickySessionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerStickySessions | undefined;
    set internalValue(value: LoadbalancerStickySessions | undefined);
    private _cookieName?;
    get cookieName(): string;
    set cookieName(value: string);
    resetCookieName(): void;
    get cookieNameInput(): string | undefined;
    private _cookieTtlSeconds?;
    get cookieTtlSeconds(): number;
    set cookieTtlSeconds(value: number);
    resetCookieTtlSeconds(): void;
    get cookieTtlSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer digitalocean_loadbalancer}
*/
export declare class Loadbalancer extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_loadbalancer";
    /**
    * Generates CDKTN code for importing a Loadbalancer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Loadbalancer to import
    * @param importFromId The id of the existing Loadbalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Loadbalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/loadbalancer digitalocean_loadbalancer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadbalancerConfig
    */
    constructor(scope: Construct, id: string, config: LoadbalancerConfig);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _disableLetsEncryptDnsRecords?;
    get disableLetsEncryptDnsRecords(): boolean | cdktn.IResolvable;
    set disableLetsEncryptDnsRecords(value: boolean | cdktn.IResolvable);
    resetDisableLetsEncryptDnsRecords(): void;
    get disableLetsEncryptDnsRecordsInput(): boolean | cdktn.IResolvable | undefined;
    private _dropletIds?;
    get dropletIds(): number[];
    set dropletIds(value: number[]);
    resetDropletIds(): void;
    get dropletIdsInput(): number[] | undefined;
    private _dropletTag?;
    get dropletTag(): string;
    set dropletTag(value: string);
    resetDropletTag(): void;
    get dropletTagInput(): string | undefined;
    private _enableBackendKeepalive?;
    get enableBackendKeepalive(): boolean | cdktn.IResolvable;
    set enableBackendKeepalive(value: boolean | cdktn.IResolvable);
    resetEnableBackendKeepalive(): void;
    get enableBackendKeepaliveInput(): boolean | cdktn.IResolvable | undefined;
    private _enableProxyProtocol?;
    get enableProxyProtocol(): boolean | cdktn.IResolvable;
    set enableProxyProtocol(value: boolean | cdktn.IResolvable);
    resetEnableProxyProtocol(): void;
    get enableProxyProtocolInput(): boolean | cdktn.IResolvable | undefined;
    private _httpIdleTimeoutSeconds?;
    get httpIdleTimeoutSeconds(): number;
    set httpIdleTimeoutSeconds(value: number);
    resetHttpIdleTimeoutSeconds(): void;
    get httpIdleTimeoutSecondsInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ip(): string;
    get ipv6(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    resetNetwork(): void;
    get networkInput(): string | undefined;
    private _networkStack?;
    get networkStack(): string;
    set networkStack(value: string);
    resetNetworkStack(): void;
    get networkStackInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _redirectHttpToHttps?;
    get redirectHttpToHttps(): boolean | cdktn.IResolvable;
    set redirectHttpToHttps(value: boolean | cdktn.IResolvable);
    resetRedirectHttpToHttps(): void;
    get redirectHttpToHttpsInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    resetSize(): void;
    get sizeInput(): string | undefined;
    private _sizeUnit?;
    get sizeUnit(): number;
    set sizeUnit(value: number);
    resetSizeUnit(): void;
    get sizeUnitInput(): number | undefined;
    get status(): string;
    private _targetLoadBalancerIds?;
    get targetLoadBalancerIds(): string[];
    set targetLoadBalancerIds(value: string[]);
    resetTargetLoadBalancerIds(): void;
    get targetLoadBalancerIdsInput(): string[] | undefined;
    private _tlsCipherPolicy?;
    get tlsCipherPolicy(): string;
    set tlsCipherPolicy(value: string);
    resetTlsCipherPolicy(): void;
    get tlsCipherPolicyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get urn(): string;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _domains;
    get domains(): LoadbalancerDomainsList;
    putDomains(value: LoadbalancerDomains[] | cdktn.IResolvable): void;
    resetDomains(): void;
    get domainsInput(): cdktn.IResolvable | LoadbalancerDomains[] | undefined;
    private _firewall;
    get firewall(): LoadbalancerFirewallOutputReference;
    putFirewall(value: LoadbalancerFirewall): void;
    resetFirewall(): void;
    get firewallInput(): LoadbalancerFirewall | undefined;
    private _forwardingRule;
    get forwardingRule(): LoadbalancerForwardingRuleList;
    putForwardingRule(value: LoadbalancerForwardingRule[] | cdktn.IResolvable): void;
    resetForwardingRule(): void;
    get forwardingRuleInput(): cdktn.IResolvable | LoadbalancerForwardingRule[] | undefined;
    private _glbSettings;
    get glbSettings(): LoadbalancerGlbSettingsOutputReference;
    putGlbSettings(value: LoadbalancerGlbSettings): void;
    resetGlbSettings(): void;
    get glbSettingsInput(): LoadbalancerGlbSettings | undefined;
    private _healthcheck;
    get healthcheck(): LoadbalancerHealthcheckOutputReference;
    putHealthcheck(value: LoadbalancerHealthcheck): void;
    resetHealthcheck(): void;
    get healthcheckInput(): LoadbalancerHealthcheck | undefined;
    private _stickySessions;
    get stickySessions(): LoadbalancerStickySessionsOutputReference;
    putStickySessions(value: LoadbalancerStickySessions): void;
    resetStickySessions(): void;
    get stickySessionsInput(): LoadbalancerStickySessions | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
