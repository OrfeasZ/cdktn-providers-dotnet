# `data_digitalocean_byoip_prefix_resources`

Refer to the Terraform Registry for docs: [`data_digitalocean_byoip_prefix_resources`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/byoip_prefix_resources).
