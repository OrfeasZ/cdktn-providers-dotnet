import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanByoipPrefixResourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * UUID of the BYOIP prefix to list assigned addresses from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/byoip_prefix_resources#byoip_prefix_uuid DataDigitaloceanByoipPrefixResources#byoip_prefix_uuid}
    */
    readonly byoipPrefixUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/byoip_prefix_resources#id DataDigitaloceanByoipPrefixResources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDigitaloceanByoipPrefixResourcesAddresses {
}
export declare function dataDigitaloceanByoipPrefixResourcesAddressesToTerraform(struct?: DataDigitaloceanByoipPrefixResourcesAddresses): any;
export declare function dataDigitaloceanByoipPrefixResourcesAddressesToHclTerraform(struct?: DataDigitaloceanByoipPrefixResourcesAddresses): any;
export declare class DataDigitaloceanByoipPrefixResourcesAddressesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanByoipPrefixResourcesAddresses | undefined;
    set internalValue(value: DataDigitaloceanByoipPrefixResourcesAddresses | undefined);
    get assignedAt(): string;
    get id(): number;
    get ipAddress(): string;
    get region(): string;
}
export declare class DataDigitaloceanByoipPrefixResourcesAddressesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanByoipPrefixResourcesAddressesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/byoip_prefix_resources digitalocean_byoip_prefix_resources}
*/
export declare class DataDigitaloceanByoipPrefixResources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_byoip_prefix_resources";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanByoipPrefixResources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanByoipPrefixResources to import
    * @param importFromId The id of the existing DataDigitaloceanByoipPrefixResources that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/byoip_prefix_resources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanByoipPrefixResources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/byoip_prefix_resources digitalocean_byoip_prefix_resources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanByoipPrefixResourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanByoipPrefixResourcesConfig);
    private _addresses;
    get addresses(): DataDigitaloceanByoipPrefixResourcesAddressesList;
    private _byoipPrefixUuid?;
    get byoipPrefixUuid(): string;
    set byoipPrefixUuid(value: string);
    get byoipPrefixUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
