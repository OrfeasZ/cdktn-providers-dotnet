import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ContainerRegistryDockerCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials#expiry_seconds ContainerRegistryDockerCredentials#expiry_seconds}
    */
    readonly expirySeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials#id ContainerRegistryDockerCredentials#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials#registry_name ContainerRegistryDockerCredentials#registry_name}
    */
    readonly registryName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials#write ContainerRegistryDockerCredentials#write}
    */
    readonly write?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials digitalocean_container_registry_docker_credentials}
*/
export declare class ContainerRegistryDockerCredentials extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_container_registry_docker_credentials";
    /**
    * Generates CDKTN code for importing a ContainerRegistryDockerCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ContainerRegistryDockerCredentials to import
    * @param importFromId The id of the existing ContainerRegistryDockerCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ContainerRegistryDockerCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/container_registry_docker_credentials digitalocean_container_registry_docker_credentials} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContainerRegistryDockerCredentialsConfig
    */
    constructor(scope: Construct, id: string, config: ContainerRegistryDockerCredentialsConfig);
    get credentialExpirationTime(): string;
    get dockerCredentials(): string;
    private _expirySeconds?;
    get expirySeconds(): number;
    set expirySeconds(value: number);
    resetExpirySeconds(): void;
    get expirySecondsInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    get registryNameInput(): string | undefined;
    private _write?;
    get write(): boolean | cdktn.IResolvable;
    set write(value: boolean | cdktn.IResolvable);
    resetWrite(): void;
    get writeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
