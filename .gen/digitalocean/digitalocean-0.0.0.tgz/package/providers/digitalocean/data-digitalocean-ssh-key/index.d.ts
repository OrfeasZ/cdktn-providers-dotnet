import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanSshKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * name of the ssh key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/ssh_key#name DataDigitaloceanSshKey#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/ssh_key digitalocean_ssh_key}
*/
export declare class DataDigitaloceanSshKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_ssh_key";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanSshKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanSshKey to import
    * @param importFromId The id of the existing DataDigitaloceanSshKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/ssh_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanSshKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/ssh_key digitalocean_ssh_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanSshKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanSshKeyConfig);
    get fingerprint(): string;
    get id(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicKey(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
