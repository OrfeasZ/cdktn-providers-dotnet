# `data_digitalocean_reserved_ip`

Refer to the Terraform Registry for docs: [`data_digitalocean_reserved_ip`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/reserved_ip).
