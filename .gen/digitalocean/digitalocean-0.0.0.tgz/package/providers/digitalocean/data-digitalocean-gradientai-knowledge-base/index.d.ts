import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiKnowledgeBaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Timestamp when the Knowledge Base was added to the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#added_to_agent_at DataDigitaloceanGradientaiKnowledgeBase#added_to_agent_at}
    */
    readonly addedToAgentAt?: string;
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#database_id DataDigitaloceanGradientaiKnowledgeBase#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#embedding_model_uuid DataDigitaloceanGradientaiKnowledgeBase#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#id DataDigitaloceanGradientaiKnowledgeBase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#is_public DataDigitaloceanGradientaiKnowledgeBase#is_public}
    */
    readonly isPublic?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#name DataDigitaloceanGradientaiKnowledgeBase#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#project_id DataDigitaloceanGradientaiKnowledgeBase#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#region DataDigitaloceanGradientaiKnowledgeBase#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#tags DataDigitaloceanGradientaiKnowledgeBase#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#user_id DataDigitaloceanGradientaiKnowledgeBase#user_id}
    */
    readonly userId?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#uuid DataDigitaloceanGradientaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#last_indexing_job DataDigitaloceanGradientaiKnowledgeBase#last_indexing_job}
    */
    readonly lastIndexingJob?: DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#completed_datasources DataDigitaloceanGradientaiKnowledgeBase#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#data_source_uuids DataDigitaloceanGradientaiKnowledgeBase#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#phase DataDigitaloceanGradientaiKnowledgeBase#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#tokens DataDigitaloceanGradientaiKnowledgeBase#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#total_datasources DataDigitaloceanGradientaiKnowledgeBase#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#uuid DataDigitaloceanGradientaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob | cdktn.IResolvable | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJobList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJobOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base digitalocean_gradientai_knowledge_base}
*/
export declare class DataDigitaloceanGradientaiKnowledgeBase extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_knowledge_base";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiKnowledgeBase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiKnowledgeBase to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiKnowledgeBase that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiKnowledgeBase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base digitalocean_gradientai_knowledge_base} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiKnowledgeBaseConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGradientaiKnowledgeBaseConfig);
    private _addedToAgentAt?;
    get addedToAgentAt(): string;
    set addedToAgentAt(value: string);
    resetAddedToAgentAt(): void;
    get addedToAgentAtInput(): string | undefined;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktn.IResolvable;
    set isPublic(value: boolean | cdktn.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJobList;
    putLastIndexingJob(value: DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob[] | cdktn.IResolvable): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): cdktn.IResolvable | DataDigitaloceanGradientaiKnowledgeBaseLastIndexingJob[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
