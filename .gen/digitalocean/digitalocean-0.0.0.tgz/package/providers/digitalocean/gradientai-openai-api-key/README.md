# `digitalocean_gradientai_openai_api_key`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_openai_api_key`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_openai_api_key).
