import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiOpenaiApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The OpenAI API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#api_key GradientaiOpenaiApiKey#api_key}
    */
    readonly apiKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#id GradientaiOpenaiApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A name for the API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#name GradientaiOpenaiApiKey#name}
    */
    readonly name: string;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#model GradientaiOpenaiApiKey#model}
    */
    readonly model?: GradientaiOpenaiApiKeyModel[] | cdktn.IResolvable;
}
export interface GradientaiOpenaiApiKeyModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#description GradientaiOpenaiApiKey#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#name GradientaiOpenaiApiKey#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#url GradientaiOpenaiApiKey#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#uuid GradientaiOpenaiApiKey#uuid}
    */
    readonly uuid?: string;
}
export declare function gradientaiOpenaiApiKeyModelAgreementToTerraform(struct?: GradientaiOpenaiApiKeyModelAgreement | cdktn.IResolvable): any;
export declare function gradientaiOpenaiApiKeyModelAgreementToHclTerraform(struct?: GradientaiOpenaiApiKeyModelAgreement | cdktn.IResolvable): any;
export declare class GradientaiOpenaiApiKeyModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiOpenaiApiKeyModelAgreement | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiOpenaiApiKeyModelAgreement | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GradientaiOpenaiApiKeyModelAgreementList extends cdktn.ComplexList {
    internalValue?: GradientaiOpenaiApiKeyModelAgreement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiOpenaiApiKeyModelAgreementOutputReference;
}
export interface GradientaiOpenaiApiKeyModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#major GradientaiOpenaiApiKey#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#minor GradientaiOpenaiApiKey#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#patch GradientaiOpenaiApiKey#patch}
    */
    readonly patch?: number;
}
export declare function gradientaiOpenaiApiKeyModelVersionsToTerraform(struct?: GradientaiOpenaiApiKeyModelVersions | cdktn.IResolvable): any;
export declare function gradientaiOpenaiApiKeyModelVersionsToHclTerraform(struct?: GradientaiOpenaiApiKeyModelVersions | cdktn.IResolvable): any;
export declare class GradientaiOpenaiApiKeyModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiOpenaiApiKeyModelVersions | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiOpenaiApiKeyModelVersions | cdktn.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class GradientaiOpenaiApiKeyModelVersionsList extends cdktn.ComplexList {
    internalValue?: GradientaiOpenaiApiKeyModelVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiOpenaiApiKeyModelVersionsOutputReference;
}
export interface GradientaiOpenaiApiKeyModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#inference_name GradientaiOpenaiApiKey#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#inference_version GradientaiOpenaiApiKey#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#is_foundational GradientaiOpenaiApiKey#is_foundational}
    */
    readonly isFoundational?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#name GradientaiOpenaiApiKey#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#parent_uuid GradientaiOpenaiApiKey#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#provider GradientaiOpenaiApiKey#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#upload_complete GradientaiOpenaiApiKey#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktn.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#url GradientaiOpenaiApiKey#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#usecases GradientaiOpenaiApiKey#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#agreement GradientaiOpenaiApiKey#agreement}
    */
    readonly agreement?: GradientaiOpenaiApiKeyModelAgreement[] | cdktn.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#versions GradientaiOpenaiApiKey#versions}
    */
    readonly versions?: GradientaiOpenaiApiKeyModelVersions[] | cdktn.IResolvable;
}
export declare function gradientaiOpenaiApiKeyModelToTerraform(struct?: GradientaiOpenaiApiKeyModel | cdktn.IResolvable): any;
export declare function gradientaiOpenaiApiKeyModelToHclTerraform(struct?: GradientaiOpenaiApiKeyModel | cdktn.IResolvable): any;
export declare class GradientaiOpenaiApiKeyModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GradientaiOpenaiApiKeyModel | cdktn.IResolvable | undefined;
    set internalValue(value: GradientaiOpenaiApiKeyModel | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktn.IResolvable;
    set isFoundational(value: boolean | cdktn.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktn.IResolvable;
    set uploadComplete(value: boolean | cdktn.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): GradientaiOpenaiApiKeyModelAgreementList;
    putAgreement(value: GradientaiOpenaiApiKeyModelAgreement[] | cdktn.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktn.IResolvable | GradientaiOpenaiApiKeyModelAgreement[] | undefined;
    private _versions;
    get versions(): GradientaiOpenaiApiKeyModelVersionsList;
    putVersions(value: GradientaiOpenaiApiKeyModelVersions[] | cdktn.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktn.IResolvable | GradientaiOpenaiApiKeyModelVersions[] | undefined;
}
export declare class GradientaiOpenaiApiKeyModelList extends cdktn.ComplexList {
    internalValue?: GradientaiOpenaiApiKeyModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GradientaiOpenaiApiKeyModelOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key digitalocean_gradientai_openai_api_key}
*/
export declare class GradientaiOpenaiApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_openai_api_key";
    /**
    * Generates CDKTN code for importing a GradientaiOpenaiApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiOpenaiApiKey to import
    * @param importFromId The id of the existing GradientaiOpenaiApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiOpenaiApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_openai_api_key digitalocean_gradientai_openai_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiOpenaiApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiOpenaiApiKeyConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get updatedAt(): string;
    get uuid(): string;
    private _model;
    get model(): GradientaiOpenaiApiKeyModelList;
    putModel(value: GradientaiOpenaiApiKeyModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | GradientaiOpenaiApiKeyModel[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
