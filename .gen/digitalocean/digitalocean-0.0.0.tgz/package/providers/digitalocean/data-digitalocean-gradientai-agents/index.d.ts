import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiAgentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#id DataDigitaloceanGradientaiAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#only_deployed DataDigitaloceanGradientaiAgents#only_deployed}
    */
    readonly onlyDeployed?: boolean | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#filter DataDigitaloceanGradientaiAgents#filter}
    */
    readonly filter?: DataDigitaloceanGradientaiAgentsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#sort DataDigitaloceanGradientaiAgents#sort}
    */
    readonly sort?: DataDigitaloceanGradientaiAgentsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiAgentsAgentsAgentGuardrail {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsAgentGuardrailToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsAgentGuardrail): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsAgentGuardrailToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsAgentGuardrail): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsAgentGuardrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsAgentGuardrail | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsAgentGuardrail | undefined);
    get agentUuid(): string;
    get createdAt(): string;
    get defaultResponse(): string;
    get description(): string;
    get guardrailUuid(): string;
    get isAttached(): cdktn.IResolvable;
    get isDefault(): cdktn.IResolvable;
    get name(): string;
    get priority(): number;
    get type(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsAgentGuardrailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsAgentGuardrailOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsChildAgents {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgents): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsChildAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsChildAgents): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsChildAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsChildAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsChildAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsFunctions {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsFunctionsToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsFunctions): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsFunctionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsFunctions): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsFunctions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsFunctions | undefined);
    get apiKey(): string;
    get createdAt(): string;
    get description(): string;
    get faasname(): string;
    get faasnamespace(): string;
    get guardrailUuid(): string;
    get name(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsFunctionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsFunctionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsKnowledgeBases {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsKnowledgeBases): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsKnowledgeBases): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktn.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsModelAgreement {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsModelAgreementToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsModelAgreement): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsModelAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsModelAgreement): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsModelAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsModelAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsModelVersions {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsModelVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsModelVersions): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsModelVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsModelVersions): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsModelVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsModelVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsModel {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsModelToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsModel): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsModelToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsModel): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsModel | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiAgentsAgentsModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGradientaiAgentsAgentsModelVersionsList;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsModelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsModelOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsOpenAiApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsOpenAiApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKey | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsParentAgents {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgents): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsParentAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsParentAgents): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsParentAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsParentAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsParentAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsParentAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBases {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBases): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBases): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktn.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreement {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreementToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreement): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreement): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersions {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateModelVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersions): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateModelVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersions): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsTemplateModel {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateModelToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateModel): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateModelToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplateModel): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsTemplateModel | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsTemplateModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiAgentsAgentsTemplateModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGradientaiAgentsAgentsTemplateModelVersionsList;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateModelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsTemplateModelOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgentsTemplate {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplate): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsTemplateToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgentsTemplate): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgentsTemplate | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgentsTemplate | undefined);
    get createdAt(): string;
    get description(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiAgentsAgentsTemplateKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGradientaiAgentsAgentsTemplateModelList;
    get name(): string;
    get temperature(): number;
    get topP(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsTemplateOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsAgents {
}
export declare function dataDigitaloceanGradientaiAgentsAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentsAgents): any;
export declare function dataDigitaloceanGradientaiAgentsAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsAgents): any;
export declare class DataDigitaloceanGradientaiAgentsAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsAgents | undefined);
    private _agentGuardrail;
    get agentGuardrail(): DataDigitaloceanGradientaiAgentsAgentsAgentGuardrailList;
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentsAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentsAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentsAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentsAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentsAgentsChatbotIdentifiersList;
    private _childAgents;
    get childAgents(): DataDigitaloceanGradientaiAgentsAgentsChildAgentsList;
    get createdAt(): string;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentsAgentsDeploymentList;
    get description(): string;
    private _functions;
    get functions(): DataDigitaloceanGradientaiAgentsAgentsFunctionsList;
    get ifCase(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiAgentsAgentsKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGradientaiAgentsAgentsModelList;
    get modelUuid(): string;
    get name(): string;
    private _openAiApiKey;
    get openAiApiKey(): DataDigitaloceanGradientaiAgentsAgentsOpenAiApiKeyList;
    private _parentAgents;
    get parentAgents(): DataDigitaloceanGradientaiAgentsAgentsParentAgentsList;
    get projectId(): string;
    get region(): string;
    get retrievalMethod(): string;
    get routeCreatedAt(): string;
    get routeCreatedBy(): string;
    get routeName(): string;
    get routeUuid(): string;
    get tags(): string[];
    get temperature(): number;
    private _template;
    get template(): DataDigitaloceanGradientaiAgentsAgentsTemplateList;
    get topP(): number;
    get updatedAt(): string;
    get url(): string;
    get userId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#all DataDigitaloceanGradientaiAgents#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#key DataDigitaloceanGradientaiAgents#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#match_by DataDigitaloceanGradientaiAgents#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#values DataDigitaloceanGradientaiAgents#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGradientaiAgentsFilterToTerraform(struct?: DataDigitaloceanGradientaiAgentsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentsFilterToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGradientaiAgentsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsFilterOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#direction DataDigitaloceanGradientaiAgents#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#key DataDigitaloceanGradientaiAgents#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGradientaiAgentsSortToTerraform(struct?: DataDigitaloceanGradientaiAgentsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentsSortToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents digitalocean_gradientai_agents}
*/
export declare class DataDigitaloceanGradientaiAgents extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_agents";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiAgents resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiAgents to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiAgents that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiAgents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_agents digitalocean_gradientai_agents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiAgentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGradientaiAgentsConfig);
    private _agents;
    get agents(): DataDigitaloceanGradientaiAgentsAgentsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _onlyDeployed?;
    get onlyDeployed(): boolean | cdktn.IResolvable;
    set onlyDeployed(value: boolean | cdktn.IResolvable);
    resetOnlyDeployed(): void;
    get onlyDeployedInput(): boolean | cdktn.IResolvable | undefined;
    private _filter;
    get filter(): DataDigitaloceanGradientaiAgentsFilterList;
    putFilter(value: DataDigitaloceanGradientaiAgentsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGradientaiAgentsSortList;
    putSort(value: DataDigitaloceanGradientaiAgentsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
