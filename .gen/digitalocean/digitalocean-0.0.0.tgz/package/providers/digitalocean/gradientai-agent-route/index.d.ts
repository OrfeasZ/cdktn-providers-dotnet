import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiAgentRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * The UUID of the child agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#child_agent_uuid GradientaiAgentRoute#child_agent_uuid}
    */
    readonly childAgentUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#id GradientaiAgentRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * if-case condition for the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#if_case GradientaiAgentRoute#if_case}
    */
    readonly ifCase?: string;
    /**
    * The UUID of the parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#parent_agent_uuid GradientaiAgentRoute#parent_agent_uuid}
    */
    readonly parentAgentUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#rollback GradientaiAgentRoute#rollback}
    */
    readonly rollback?: boolean | cdktn.IResolvable;
    /**
    * A name for the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#route_name GradientaiAgentRoute#route_name}
    */
    readonly routeName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route digitalocean_gradientai_agent_route}
*/
export declare class GradientaiAgentRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_agent_route";
    /**
    * Generates CDKTN code for importing a GradientaiAgentRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiAgentRoute to import
    * @param importFromId The id of the existing GradientaiAgentRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiAgentRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/gradientai_agent_route digitalocean_gradientai_agent_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiAgentRouteConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiAgentRouteConfig);
    private _childAgentUuid?;
    get childAgentUuid(): string;
    set childAgentUuid(value: string);
    get childAgentUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifCase?;
    get ifCase(): string;
    set ifCase(value: string);
    resetIfCase(): void;
    get ifCaseInput(): string | undefined;
    private _parentAgentUuid?;
    get parentAgentUuid(): string;
    set parentAgentUuid(value: string);
    get parentAgentUuidInput(): string | undefined;
    private _rollback?;
    get rollback(): boolean | cdktn.IResolvable;
    set rollback(value: boolean | cdktn.IResolvable);
    resetRollback(): void;
    get rollbackInput(): boolean | cdktn.IResolvable | undefined;
    private _routeName?;
    get routeName(): string;
    set routeName(value: string);
    resetRouteName(): void;
    get routeNameInput(): string | undefined;
    get uuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
