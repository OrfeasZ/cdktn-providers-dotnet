# `digitalocean_gradientai_agent_route`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_agent_route`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_route).
