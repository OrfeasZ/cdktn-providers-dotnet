# `digitalocean_nfs`

Refer to the Terraform Registry for docs: [`digitalocean_nfs`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/nfs).
