# `data_digitalocean_domain`

Refer to the Terraform Registry for docs: [`data_digitalocean_domain`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domain).
