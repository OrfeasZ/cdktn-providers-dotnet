# `digitalocean_nfs_attachment`

Refer to the Terraform Registry for docs: [`digitalocean_nfs_attachment`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/nfs_attachment).
