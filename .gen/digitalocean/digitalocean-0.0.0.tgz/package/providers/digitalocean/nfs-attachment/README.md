# `digitalocean_nfs_attachment`

Refer to the Terraform Registry for docs: [`digitalocean_nfs_attachment`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/nfs_attachment).
