import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VpcPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the VPC Peering
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering#name VpcPeering#name}
    */
    readonly name: string;
    /**
    * The list of VPCs to be peered
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering#vpc_ids VpcPeering#vpc_ids}
    */
    readonly vpcIds: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering#timeouts VpcPeering#timeouts}
    */
    readonly timeouts?: VpcPeeringTimeouts;
}
export interface VpcPeeringTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering#create VpcPeering#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering#delete VpcPeering#delete}
    */
    readonly delete?: string;
}
export declare function vpcPeeringTimeoutsToTerraform(struct?: VpcPeeringTimeouts | cdktn.IResolvable): any;
export declare function vpcPeeringTimeoutsToHclTerraform(struct?: VpcPeeringTimeouts | cdktn.IResolvable): any;
export declare class VpcPeeringTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpcPeeringTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: VpcPeeringTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering digitalocean_vpc_peering}
*/
export declare class VpcPeering extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_vpc_peering";
    /**
    * Generates CDKTN code for importing a VpcPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpcPeering to import
    * @param importFromId The id of the existing VpcPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpcPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/vpc_peering digitalocean_vpc_peering} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpcPeeringConfig
    */
    constructor(scope: Construct, id: string, config: VpcPeeringConfig);
    get createdAt(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _vpcIds?;
    get vpcIds(): string[];
    set vpcIds(value: string[]);
    get vpcIdsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): VpcPeeringTimeoutsOutputReference;
    putTimeouts(value: VpcPeeringTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | VpcPeeringTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
