import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Number of deployments to request per page when polling for deployments
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deployment_per_page App#deployment_per_page}
    */
    readonly deploymentPerPage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#id App#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#project_id App#project_id}
    */
    readonly projectId?: string;
    /**
    * dedicated_ips block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#dedicated_ips App#dedicated_ips}
    */
    readonly dedicatedIps?: AppDedicatedIps[] | cdktn.IResolvable;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#spec App#spec}
    */
    readonly spec?: AppSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#timeouts App#timeouts}
    */
    readonly timeouts?: AppTimeouts;
}
export interface AppDedicatedIps {
    /**
    * The ID of the dedicated egress IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#id App#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IP address of the dedicated egress IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#ip App#ip}
    */
    readonly ip?: string;
    /**
    * The status of the dedicated egress IP: 'UNKNOWN', 'ASSIGNING', 'ASSIGNED', or 'REMOVED'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#status App#status}
    */
    readonly status?: string;
}
export declare function appDedicatedIpsToTerraform(struct?: AppDedicatedIps | cdktn.IResolvable): any;
export declare function appDedicatedIpsToHclTerraform(struct?: AppDedicatedIps | cdktn.IResolvable): any;
export declare class AppDedicatedIpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppDedicatedIps | cdktn.IResolvable | undefined;
    set internalValue(value: AppDedicatedIps | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class AppDedicatedIpsList extends cdktn.ComplexList {
    internalValue?: AppDedicatedIps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppDedicatedIpsOutputReference;
}
export interface AppSpecAlertDestinationsSlackWebhooks {
    /**
    * The Slack channel to send notifications to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#channel App#channel}
    */
    readonly channel: string;
    /**
    * The Slack webhook URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appSpecAlertDestinationsSlackWebhooksToTerraform(struct?: AppSpecAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare function appSpecAlertDestinationsSlackWebhooksToHclTerraform(struct?: AppSpecAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare class AppSpecAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AppSpecAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    internalValue?: AppSpecAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecAlertDestinationsSlackWebhooksOutputReference;
}
export interface AppSpecAlertDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#emails App#emails}
    */
    readonly emails?: string[];
    /**
    * slack_webhooks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#slack_webhooks App#slack_webhooks}
    */
    readonly slackWebhooks?: AppSpecAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
}
export declare function appSpecAlertDestinationsToTerraform(struct?: AppSpecAlertDestinationsOutputReference | AppSpecAlertDestinations): any;
export declare function appSpecAlertDestinationsToHclTerraform(struct?: AppSpecAlertDestinationsOutputReference | AppSpecAlertDestinations): any;
export declare class AppSpecAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecAlertDestinations | undefined;
    set internalValue(value: AppSpecAlertDestinations | undefined);
    private _emails?;
    get emails(): string[];
    set emails(value: string[]);
    resetEmails(): void;
    get emailsInput(): string[] | undefined;
    private _slackWebhooks;
    get slackWebhooks(): AppSpecAlertDestinationsSlackWebhooksList;
    putSlackWebhooks(value: AppSpecAlertDestinationsSlackWebhooks[] | cdktn.IResolvable): void;
    resetSlackWebhooks(): void;
    get slackWebhooksInput(): cdktn.IResolvable | AppSpecAlertDestinationsSlackWebhooks[] | undefined;
}
export interface AppSpecAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disabled App#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rule App#rule}
    */
    readonly rule: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#destinations App#destinations}
    */
    readonly destinations?: AppSpecAlertDestinations;
}
export declare function appSpecAlertToTerraform(struct?: AppSpecAlert | cdktn.IResolvable): any;
export declare function appSpecAlertToHclTerraform(struct?: AppSpecAlert | cdktn.IResolvable): any;
export declare class AppSpecAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecAlert | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecAlert | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _destinations;
    get destinations(): AppSpecAlertDestinationsOutputReference;
    putDestinations(value: AppSpecAlertDestinations): void;
    resetDestinations(): void;
    get destinationsInput(): AppSpecAlertDestinations | undefined;
}
export declare class AppSpecAlertList extends cdktn.ComplexList {
    internalValue?: AppSpecAlert[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecAlertOutputReference;
}
export interface AppSpecDatabase {
    /**
    * The name of the underlying DigitalOcean DBaaS cluster. This is required for production databases. For dev databases, if cluster_name is not set, a new cluster will be provisioned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cluster_name App#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * The name of the MySQL or PostgreSQL database to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#db_name App#db_name}
    */
    readonly dbName?: string;
    /**
    * The name of the MySQL or PostgreSQL user to configure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#db_user App#db_user}
    */
    readonly dbUser?: string;
    /**
    * The database engine to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#engine App#engine}
    */
    readonly engine?: string;
    /**
    * The name of the component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name?: string;
    /**
    * Whether this is a production or dev database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#production App#production}
    */
    readonly production?: boolean | cdktn.IResolvable;
    /**
    * The version of the database engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#version App#version}
    */
    readonly version?: string;
}
export declare function appSpecDatabaseToTerraform(struct?: AppSpecDatabase | cdktn.IResolvable): any;
export declare function appSpecDatabaseToHclTerraform(struct?: AppSpecDatabase | cdktn.IResolvable): any;
export declare class AppSpecDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecDatabase | cdktn.IResolvable | undefined);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _dbName?;
    get dbName(): string;
    set dbName(value: string);
    resetDbName(): void;
    get dbNameInput(): string | undefined;
    private _dbUser?;
    get dbUser(): string;
    set dbUser(value: string);
    resetDbUser(): void;
    get dbUserInput(): string | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _production?;
    get production(): boolean | cdktn.IResolvable;
    set production(value: boolean | cdktn.IResolvable);
    resetProduction(): void;
    get productionInput(): boolean | cdktn.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class AppSpecDatabaseList extends cdktn.ComplexList {
    internalValue?: AppSpecDatabase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecDatabaseOutputReference;
}
export interface AppSpecDomain {
    /**
    * The hostname for the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * The type of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * Indicates whether the domain includes all sub-domains, in addition to the given domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#wildcard App#wildcard}
    */
    readonly wildcard?: boolean | cdktn.IResolvable;
    /**
    * If the domain uses DigitalOcean DNS and you would like App Platform to automatically manage it for you, set this to the name of the domain on your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#zone App#zone}
    */
    readonly zone?: string;
}
export declare function appSpecDomainToTerraform(struct?: AppSpecDomain | cdktn.IResolvable): any;
export declare function appSpecDomainToHclTerraform(struct?: AppSpecDomain | cdktn.IResolvable): any;
export declare class AppSpecDomainOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecDomain | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecDomain | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _wildcard?;
    get wildcard(): boolean | cdktn.IResolvable;
    set wildcard(value: boolean | cdktn.IResolvable);
    resetWildcard(): void;
    get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
}
export declare class AppSpecDomainList extends cdktn.ComplexList {
    internalValue?: AppSpecDomain[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecDomainOutputReference;
}
export interface AppSpecEgress {
    /**
    * The app egress type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
}
export declare function appSpecEgressToTerraform(struct?: AppSpecEgress | cdktn.IResolvable): any;
export declare function appSpecEgressToHclTerraform(struct?: AppSpecEgress | cdktn.IResolvable): any;
export declare class AppSpecEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecEgress | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecEgress | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class AppSpecEgressList extends cdktn.ComplexList {
    internalValue?: AppSpecEgress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecEgressOutputReference;
}
export interface AppSpecEnv {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * The visibility scope of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scope App#scope}
    */
    readonly scope?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecEnvToTerraform(struct?: AppSpecEnv | cdktn.IResolvable): any;
export declare function appSpecEnvToHclTerraform(struct?: AppSpecEnv | cdktn.IResolvable): any;
export declare class AppSpecEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecEnv | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecEnv | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppSpecEnvList extends cdktn.ComplexList {
    internalValue?: AppSpecEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecEnvOutputReference;
}
export interface AppSpecFunctionAlertDestinationsSlackWebhooks {
    /**
    * The Slack channel to send notifications to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#channel App#channel}
    */
    readonly channel: string;
    /**
    * The Slack webhook URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appSpecFunctionAlertDestinationsSlackWebhooksToTerraform(struct?: AppSpecFunctionAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare function appSpecFunctionAlertDestinationsSlackWebhooksToHclTerraform(struct?: AppSpecFunctionAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare class AppSpecFunctionAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecFunctionAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecFunctionAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AppSpecFunctionAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    internalValue?: AppSpecFunctionAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecFunctionAlertDestinationsSlackWebhooksOutputReference;
}
export interface AppSpecFunctionAlertDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#emails App#emails}
    */
    readonly emails?: string[];
    /**
    * slack_webhooks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#slack_webhooks App#slack_webhooks}
    */
    readonly slackWebhooks?: AppSpecFunctionAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
}
export declare function appSpecFunctionAlertDestinationsToTerraform(struct?: AppSpecFunctionAlertDestinationsOutputReference | AppSpecFunctionAlertDestinations): any;
export declare function appSpecFunctionAlertDestinationsToHclTerraform(struct?: AppSpecFunctionAlertDestinationsOutputReference | AppSpecFunctionAlertDestinations): any;
export declare class AppSpecFunctionAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionAlertDestinations | undefined;
    set internalValue(value: AppSpecFunctionAlertDestinations | undefined);
    private _emails?;
    get emails(): string[];
    set emails(value: string[]);
    resetEmails(): void;
    get emailsInput(): string[] | undefined;
    private _slackWebhooks;
    get slackWebhooks(): AppSpecFunctionAlertDestinationsSlackWebhooksList;
    putSlackWebhooks(value: AppSpecFunctionAlertDestinationsSlackWebhooks[] | cdktn.IResolvable): void;
    resetSlackWebhooks(): void;
    get slackWebhooksInput(): cdktn.IResolvable | AppSpecFunctionAlertDestinationsSlackWebhooks[] | undefined;
}
export interface AppSpecFunctionAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disabled App#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#operator App#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rule App#rule}
    */
    readonly rule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#window App#window}
    */
    readonly window: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#destinations App#destinations}
    */
    readonly destinations?: AppSpecFunctionAlertDestinations;
}
export declare function appSpecFunctionAlertToTerraform(struct?: AppSpecFunctionAlert | cdktn.IResolvable): any;
export declare function appSpecFunctionAlertToHclTerraform(struct?: AppSpecFunctionAlert | cdktn.IResolvable): any;
export declare class AppSpecFunctionAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecFunctionAlert | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecFunctionAlert | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
    private _window?;
    get window(): string;
    set window(value: string);
    get windowInput(): string | undefined;
    private _destinations;
    get destinations(): AppSpecFunctionAlertDestinationsOutputReference;
    putDestinations(value: AppSpecFunctionAlertDestinations): void;
    resetDestinations(): void;
    get destinationsInput(): AppSpecFunctionAlertDestinations | undefined;
}
export declare class AppSpecFunctionAlertList extends cdktn.ComplexList {
    internalValue?: AppSpecFunctionAlert[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecFunctionAlertOutputReference;
}
export interface AppSpecFunctionBitbucket {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecFunctionBitbucketToTerraform(struct?: AppSpecFunctionBitbucketOutputReference | AppSpecFunctionBitbucket): any;
export declare function appSpecFunctionBitbucketToHclTerraform(struct?: AppSpecFunctionBitbucketOutputReference | AppSpecFunctionBitbucket): any;
export declare class AppSpecFunctionBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionBitbucket | undefined;
    set internalValue(value: AppSpecFunctionBitbucket | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecFunctionCorsAllowOrigins {
    /**
    * Exact string match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#exact App#exact}
    */
    readonly exact?: string;
    /**
    * Prefix-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#prefix App#prefix}
    */
    readonly prefix?: string;
    /**
    * RE2 style regex-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#regex App#regex}
    */
    readonly regex?: string;
}
export declare function appSpecFunctionCorsAllowOriginsToTerraform(struct?: AppSpecFunctionCorsAllowOriginsOutputReference | AppSpecFunctionCorsAllowOrigins): any;
export declare function appSpecFunctionCorsAllowOriginsToHclTerraform(struct?: AppSpecFunctionCorsAllowOriginsOutputReference | AppSpecFunctionCorsAllowOrigins): any;
export declare class AppSpecFunctionCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionCorsAllowOrigins | undefined;
    set internalValue(value: AppSpecFunctionCorsAllowOrigins | undefined);
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
}
export interface AppSpecFunctionCors {
    /**
    * Whether browsers should expose the response to the client-side JavaScript code when the request’s credentials mode is `include`. This configures the Access-Control-Allow-Credentials header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_credentials App#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * The set of allowed HTTP request headers. This configures the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_headers App#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * The set of allowed HTTP methods. This configures the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_methods App#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * The set of HTTP response headers that browsers are allowed to access. This configures the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#expose_headers App#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * An optional duration specifying how long browsers can cache the results of a preflight request. This configures the Access-Control-Max-Age header. Example: `5h30m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#max_age App#max_age}
    */
    readonly maxAge?: string;
    /**
    * allow_origins block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_origins App#allow_origins}
    */
    readonly allowOrigins?: AppSpecFunctionCorsAllowOrigins;
}
export declare function appSpecFunctionCorsToTerraform(struct?: AppSpecFunctionCorsOutputReference | AppSpecFunctionCors): any;
export declare function appSpecFunctionCorsToHclTerraform(struct?: AppSpecFunctionCorsOutputReference | AppSpecFunctionCors): any;
export declare class AppSpecFunctionCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionCors | undefined;
    set internalValue(value: AppSpecFunctionCors | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): string;
    set maxAge(value: string);
    resetMaxAge(): void;
    get maxAgeInput(): string | undefined;
    private _allowOrigins;
    get allowOrigins(): AppSpecFunctionCorsAllowOriginsOutputReference;
    putAllowOrigins(value: AppSpecFunctionCorsAllowOrigins): void;
    resetAllowOrigins(): void;
    get allowOriginsInput(): AppSpecFunctionCorsAllowOrigins | undefined;
}
export interface AppSpecFunctionEnv {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * The visibility scope of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scope App#scope}
    */
    readonly scope?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecFunctionEnvToTerraform(struct?: AppSpecFunctionEnv | cdktn.IResolvable): any;
export declare function appSpecFunctionEnvToHclTerraform(struct?: AppSpecFunctionEnv | cdktn.IResolvable): any;
export declare class AppSpecFunctionEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecFunctionEnv | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecFunctionEnv | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppSpecFunctionEnvList extends cdktn.ComplexList {
    internalValue?: AppSpecFunctionEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecFunctionEnvOutputReference;
}
export interface AppSpecFunctionGit {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * The clone URL of the repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo_clone_url App#repo_clone_url}
    */
    readonly repoCloneUrl?: string;
}
export declare function appSpecFunctionGitToTerraform(struct?: AppSpecFunctionGitOutputReference | AppSpecFunctionGit): any;
export declare function appSpecFunctionGitToHclTerraform(struct?: AppSpecFunctionGitOutputReference | AppSpecFunctionGit): any;
export declare class AppSpecFunctionGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionGit | undefined;
    set internalValue(value: AppSpecFunctionGit | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _repoCloneUrl?;
    get repoCloneUrl(): string;
    set repoCloneUrl(value: string);
    resetRepoCloneUrl(): void;
    get repoCloneUrlInput(): string | undefined;
}
export interface AppSpecFunctionGithub {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecFunctionGithubToTerraform(struct?: AppSpecFunctionGithubOutputReference | AppSpecFunctionGithub): any;
export declare function appSpecFunctionGithubToHclTerraform(struct?: AppSpecFunctionGithubOutputReference | AppSpecFunctionGithub): any;
export declare class AppSpecFunctionGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionGithub | undefined;
    set internalValue(value: AppSpecFunctionGithub | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecFunctionGitlab {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecFunctionGitlabToTerraform(struct?: AppSpecFunctionGitlabOutputReference | AppSpecFunctionGitlab): any;
export declare function appSpecFunctionGitlabToHclTerraform(struct?: AppSpecFunctionGitlabOutputReference | AppSpecFunctionGitlab): any;
export declare class AppSpecFunctionGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionGitlab | undefined;
    set internalValue(value: AppSpecFunctionGitlab | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecFunctionLogDestinationDatadog {
    /**
    * Datadog API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#api_key App#api_key}
    */
    readonly apiKey: string;
    /**
    * Datadog HTTP log intake endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appSpecFunctionLogDestinationDatadogToTerraform(struct?: AppSpecFunctionLogDestinationDatadogOutputReference | AppSpecFunctionLogDestinationDatadog): any;
export declare function appSpecFunctionLogDestinationDatadogToHclTerraform(struct?: AppSpecFunctionLogDestinationDatadogOutputReference | AppSpecFunctionLogDestinationDatadog): any;
export declare class AppSpecFunctionLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionLogDestinationDatadog | undefined;
    set internalValue(value: AppSpecFunctionLogDestinationDatadog | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppSpecFunctionLogDestinationLogtail {
    /**
    * Logtail token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#token App#token}
    */
    readonly token: string;
}
export declare function appSpecFunctionLogDestinationLogtailToTerraform(struct?: AppSpecFunctionLogDestinationLogtailOutputReference | AppSpecFunctionLogDestinationLogtail): any;
export declare function appSpecFunctionLogDestinationLogtailToHclTerraform(struct?: AppSpecFunctionLogDestinationLogtailOutputReference | AppSpecFunctionLogDestinationLogtail): any;
export declare class AppSpecFunctionLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionLogDestinationLogtail | undefined;
    set internalValue(value: AppSpecFunctionLogDestinationLogtail | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface AppSpecFunctionLogDestinationOpenSearchBasicAuth {
    /**
    * Password for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#password App#password}
    */
    readonly password?: string;
    /**
    * user for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#user App#user}
    */
    readonly user?: string;
}
export declare function appSpecFunctionLogDestinationOpenSearchBasicAuthToTerraform(struct?: AppSpecFunctionLogDestinationOpenSearchBasicAuthOutputReference | AppSpecFunctionLogDestinationOpenSearchBasicAuth): any;
export declare function appSpecFunctionLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: AppSpecFunctionLogDestinationOpenSearchBasicAuthOutputReference | AppSpecFunctionLogDestinationOpenSearchBasicAuth): any;
export declare class AppSpecFunctionLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: AppSpecFunctionLogDestinationOpenSearchBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface AppSpecFunctionLogDestinationOpenSearch {
    /**
    * OpenSearch cluster name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cluster_name App#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * OpenSearch endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
    /**
    * OpenSearch index name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#index_name App#index_name}
    */
    readonly indexName?: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#basic_auth App#basic_auth}
    */
    readonly basicAuth: AppSpecFunctionLogDestinationOpenSearchBasicAuth;
}
export declare function appSpecFunctionLogDestinationOpenSearchToTerraform(struct?: AppSpecFunctionLogDestinationOpenSearchOutputReference | AppSpecFunctionLogDestinationOpenSearch): any;
export declare function appSpecFunctionLogDestinationOpenSearchToHclTerraform(struct?: AppSpecFunctionLogDestinationOpenSearchOutputReference | AppSpecFunctionLogDestinationOpenSearch): any;
export declare class AppSpecFunctionLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionLogDestinationOpenSearch | undefined;
    set internalValue(value: AppSpecFunctionLogDestinationOpenSearch | undefined);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    resetIndexName(): void;
    get indexNameInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): AppSpecFunctionLogDestinationOpenSearchBasicAuthOutputReference;
    putBasicAuth(value: AppSpecFunctionLogDestinationOpenSearchBasicAuth): void;
    get basicAuthInput(): AppSpecFunctionLogDestinationOpenSearchBasicAuth | undefined;
}
export interface AppSpecFunctionLogDestinationPapertrail {
    /**
    * Papertrail syslog endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint: string;
}
export declare function appSpecFunctionLogDestinationPapertrailToTerraform(struct?: AppSpecFunctionLogDestinationPapertrailOutputReference | AppSpecFunctionLogDestinationPapertrail): any;
export declare function appSpecFunctionLogDestinationPapertrailToHclTerraform(struct?: AppSpecFunctionLogDestinationPapertrailOutputReference | AppSpecFunctionLogDestinationPapertrail): any;
export declare class AppSpecFunctionLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecFunctionLogDestinationPapertrail | undefined;
    set internalValue(value: AppSpecFunctionLogDestinationPapertrail | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
}
export interface AppSpecFunctionLogDestination {
    /**
    * Name of the log destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#datadog App#datadog}
    */
    readonly datadog?: AppSpecFunctionLogDestinationDatadog;
    /**
    * logtail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#logtail App#logtail}
    */
    readonly logtail?: AppSpecFunctionLogDestinationLogtail;
    /**
    * open_search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#open_search App#open_search}
    */
    readonly openSearch?: AppSpecFunctionLogDestinationOpenSearch;
    /**
    * papertrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#papertrail App#papertrail}
    */
    readonly papertrail?: AppSpecFunctionLogDestinationPapertrail;
}
export declare function appSpecFunctionLogDestinationToTerraform(struct?: AppSpecFunctionLogDestination | cdktn.IResolvable): any;
export declare function appSpecFunctionLogDestinationToHclTerraform(struct?: AppSpecFunctionLogDestination | cdktn.IResolvable): any;
export declare class AppSpecFunctionLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecFunctionLogDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecFunctionLogDestination | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _datadog;
    get datadog(): AppSpecFunctionLogDestinationDatadogOutputReference;
    putDatadog(value: AppSpecFunctionLogDestinationDatadog): void;
    resetDatadog(): void;
    get datadogInput(): AppSpecFunctionLogDestinationDatadog | undefined;
    private _logtail;
    get logtail(): AppSpecFunctionLogDestinationLogtailOutputReference;
    putLogtail(value: AppSpecFunctionLogDestinationLogtail): void;
    resetLogtail(): void;
    get logtailInput(): AppSpecFunctionLogDestinationLogtail | undefined;
    private _openSearch;
    get openSearch(): AppSpecFunctionLogDestinationOpenSearchOutputReference;
    putOpenSearch(value: AppSpecFunctionLogDestinationOpenSearch): void;
    resetOpenSearch(): void;
    get openSearchInput(): AppSpecFunctionLogDestinationOpenSearch | undefined;
    private _papertrail;
    get papertrail(): AppSpecFunctionLogDestinationPapertrailOutputReference;
    putPapertrail(value: AppSpecFunctionLogDestinationPapertrail): void;
    resetPapertrail(): void;
    get papertrailInput(): AppSpecFunctionLogDestinationPapertrail | undefined;
}
export declare class AppSpecFunctionLogDestinationList extends cdktn.ComplexList {
    internalValue?: AppSpecFunctionLogDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecFunctionLogDestinationOutputReference;
}
export interface AppSpecFunctionRoutes {
    /**
    * Path specifies an route by HTTP path prefix. Paths must start with / and must be unique within the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#path App#path}
    */
    readonly path?: string;
    /**
    *  An optional flag to preserve the path that is forwarded to the backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#preserve_path_prefix App#preserve_path_prefix}
    */
    readonly preservePathPrefix?: boolean | cdktn.IResolvable;
}
export declare function appSpecFunctionRoutesToTerraform(struct?: AppSpecFunctionRoutes | cdktn.IResolvable): any;
export declare function appSpecFunctionRoutesToHclTerraform(struct?: AppSpecFunctionRoutes | cdktn.IResolvable): any;
export declare class AppSpecFunctionRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecFunctionRoutes | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecFunctionRoutes | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _preservePathPrefix?;
    get preservePathPrefix(): boolean | cdktn.IResolvable;
    set preservePathPrefix(value: boolean | cdktn.IResolvable);
    resetPreservePathPrefix(): void;
    get preservePathPrefixInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppSpecFunctionRoutesList extends cdktn.ComplexList {
    internalValue?: AppSpecFunctionRoutes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecFunctionRoutesOutputReference;
}
export interface AppSpecFunction {
    /**
    * The name of the component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * An optional path to the working directory to use for the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#source_dir App#source_dir}
    */
    readonly sourceDir?: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#alert App#alert}
    */
    readonly alert?: AppSpecFunctionAlert[] | cdktn.IResolvable;
    /**
    * bitbucket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#bitbucket App#bitbucket}
    */
    readonly bitbucket?: AppSpecFunctionBitbucket;
    /**
    * cors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cors App#cors}
    */
    readonly cors?: AppSpecFunctionCors;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#env App#env}
    */
    readonly env?: AppSpecFunctionEnv[] | cdktn.IResolvable;
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#git App#git}
    */
    readonly git?: AppSpecFunctionGit;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#github App#github}
    */
    readonly github?: AppSpecFunctionGithub;
    /**
    * gitlab block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#gitlab App#gitlab}
    */
    readonly gitlab?: AppSpecFunctionGitlab;
    /**
    * log_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#log_destination App#log_destination}
    */
    readonly logDestination?: AppSpecFunctionLogDestination[] | cdktn.IResolvable;
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#routes App#routes}
    */
    readonly routes?: AppSpecFunctionRoutes[] | cdktn.IResolvable;
}
export declare function appSpecFunctionToTerraform(struct?: AppSpecFunction | cdktn.IResolvable): any;
export declare function appSpecFunctionToHclTerraform(struct?: AppSpecFunction | cdktn.IResolvable): any;
export declare class AppSpecFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecFunction | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecFunction | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sourceDir?;
    get sourceDir(): string;
    set sourceDir(value: string);
    resetSourceDir(): void;
    get sourceDirInput(): string | undefined;
    private _alert;
    get alert(): AppSpecFunctionAlertList;
    putAlert(value: AppSpecFunctionAlert[] | cdktn.IResolvable): void;
    resetAlert(): void;
    get alertInput(): cdktn.IResolvable | AppSpecFunctionAlert[] | undefined;
    private _bitbucket;
    get bitbucket(): AppSpecFunctionBitbucketOutputReference;
    putBitbucket(value: AppSpecFunctionBitbucket): void;
    resetBitbucket(): void;
    get bitbucketInput(): AppSpecFunctionBitbucket | undefined;
    private _cors;
    get cors(): AppSpecFunctionCorsOutputReference;
    putCors(value: AppSpecFunctionCors): void;
    resetCors(): void;
    get corsInput(): AppSpecFunctionCors | undefined;
    private _env;
    get env(): AppSpecFunctionEnvList;
    putEnv(value: AppSpecFunctionEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | AppSpecFunctionEnv[] | undefined;
    private _git;
    get git(): AppSpecFunctionGitOutputReference;
    putGit(value: AppSpecFunctionGit): void;
    resetGit(): void;
    get gitInput(): AppSpecFunctionGit | undefined;
    private _github;
    get github(): AppSpecFunctionGithubOutputReference;
    putGithub(value: AppSpecFunctionGithub): void;
    resetGithub(): void;
    get githubInput(): AppSpecFunctionGithub | undefined;
    private _gitlab;
    get gitlab(): AppSpecFunctionGitlabOutputReference;
    putGitlab(value: AppSpecFunctionGitlab): void;
    resetGitlab(): void;
    get gitlabInput(): AppSpecFunctionGitlab | undefined;
    private _logDestination;
    get logDestination(): AppSpecFunctionLogDestinationList;
    putLogDestination(value: AppSpecFunctionLogDestination[] | cdktn.IResolvable): void;
    resetLogDestination(): void;
    get logDestinationInput(): cdktn.IResolvable | AppSpecFunctionLogDestination[] | undefined;
    private _routes;
    get routes(): AppSpecFunctionRoutesList;
    putRoutes(value: AppSpecFunctionRoutes[] | cdktn.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktn.IResolvable | AppSpecFunctionRoutes[] | undefined;
}
export declare class AppSpecFunctionList extends cdktn.ComplexList {
    internalValue?: AppSpecFunction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecFunctionOutputReference;
}
export interface AppSpecIngressRuleComponent {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#preserve_path_prefix App#preserve_path_prefix}
    */
    readonly preservePathPrefix?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rewrite App#rewrite}
    */
    readonly rewrite?: string;
}
export declare function appSpecIngressRuleComponentToTerraform(struct?: AppSpecIngressRuleComponentOutputReference | AppSpecIngressRuleComponent): any;
export declare function appSpecIngressRuleComponentToHclTerraform(struct?: AppSpecIngressRuleComponentOutputReference | AppSpecIngressRuleComponent): any;
export declare class AppSpecIngressRuleComponentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleComponent | undefined;
    set internalValue(value: AppSpecIngressRuleComponent | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _preservePathPrefix?;
    get preservePathPrefix(): boolean | cdktn.IResolvable;
    set preservePathPrefix(value: boolean | cdktn.IResolvable);
    resetPreservePathPrefix(): void;
    get preservePathPrefixInput(): boolean | cdktn.IResolvable | undefined;
    private _rewrite?;
    get rewrite(): string;
    set rewrite(value: string);
    resetRewrite(): void;
    get rewriteInput(): string | undefined;
}
export interface AppSpecIngressRuleCorsAllowOrigins {
    /**
    * Exact string match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#exact App#exact}
    */
    readonly exact?: string;
    /**
    * Prefix-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#prefix App#prefix}
    */
    readonly prefix?: string;
    /**
    * RE2 style regex-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#regex App#regex}
    */
    readonly regex?: string;
}
export declare function appSpecIngressRuleCorsAllowOriginsToTerraform(struct?: AppSpecIngressRuleCorsAllowOriginsOutputReference | AppSpecIngressRuleCorsAllowOrigins): any;
export declare function appSpecIngressRuleCorsAllowOriginsToHclTerraform(struct?: AppSpecIngressRuleCorsAllowOriginsOutputReference | AppSpecIngressRuleCorsAllowOrigins): any;
export declare class AppSpecIngressRuleCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleCorsAllowOrigins | undefined;
    set internalValue(value: AppSpecIngressRuleCorsAllowOrigins | undefined);
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
}
export interface AppSpecIngressRuleCors {
    /**
    * Whether browsers should expose the response to the client-side JavaScript code when the request’s credentials mode is `include`. This configures the Access-Control-Allow-Credentials header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_credentials App#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * The set of allowed HTTP request headers. This configures the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_headers App#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * The set of allowed HTTP methods. This configures the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_methods App#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * The set of HTTP response headers that browsers are allowed to access. This configures the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#expose_headers App#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * An optional duration specifying how long browsers can cache the results of a preflight request. This configures the Access-Control-Max-Age header. Example: `5h30m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#max_age App#max_age}
    */
    readonly maxAge?: string;
    /**
    * allow_origins block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_origins App#allow_origins}
    */
    readonly allowOrigins?: AppSpecIngressRuleCorsAllowOrigins;
}
export declare function appSpecIngressRuleCorsToTerraform(struct?: AppSpecIngressRuleCorsOutputReference | AppSpecIngressRuleCors): any;
export declare function appSpecIngressRuleCorsToHclTerraform(struct?: AppSpecIngressRuleCorsOutputReference | AppSpecIngressRuleCors): any;
export declare class AppSpecIngressRuleCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleCors | undefined;
    set internalValue(value: AppSpecIngressRuleCors | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): string;
    set maxAge(value: string);
    resetMaxAge(): void;
    get maxAgeInput(): string | undefined;
    private _allowOrigins;
    get allowOrigins(): AppSpecIngressRuleCorsAllowOriginsOutputReference;
    putAllowOrigins(value: AppSpecIngressRuleCorsAllowOrigins): void;
    resetAllowOrigins(): void;
    get allowOriginsInput(): AppSpecIngressRuleCorsAllowOrigins | undefined;
}
export interface AppSpecIngressRuleMatchAuthority {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#exact App#exact}
    */
    readonly exact?: string;
}
export declare function appSpecIngressRuleMatchAuthorityToTerraform(struct?: AppSpecIngressRuleMatchAuthorityOutputReference | AppSpecIngressRuleMatchAuthority): any;
export declare function appSpecIngressRuleMatchAuthorityToHclTerraform(struct?: AppSpecIngressRuleMatchAuthorityOutputReference | AppSpecIngressRuleMatchAuthority): any;
export declare class AppSpecIngressRuleMatchAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleMatchAuthority | undefined;
    set internalValue(value: AppSpecIngressRuleMatchAuthority | undefined);
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
}
export interface AppSpecIngressRuleMatchPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#prefix App#prefix}
    */
    readonly prefix?: string;
}
export declare function appSpecIngressRuleMatchPathToTerraform(struct?: AppSpecIngressRuleMatchPathOutputReference | AppSpecIngressRuleMatchPath): any;
export declare function appSpecIngressRuleMatchPathToHclTerraform(struct?: AppSpecIngressRuleMatchPathOutputReference | AppSpecIngressRuleMatchPath): any;
export declare class AppSpecIngressRuleMatchPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleMatchPath | undefined;
    set internalValue(value: AppSpecIngressRuleMatchPath | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export interface AppSpecIngressRuleMatch {
    /**
    * authority block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#authority App#authority}
    */
    readonly authority?: AppSpecIngressRuleMatchAuthority;
    /**
    * path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#path App#path}
    */
    readonly path?: AppSpecIngressRuleMatchPath;
}
export declare function appSpecIngressRuleMatchToTerraform(struct?: AppSpecIngressRuleMatchOutputReference | AppSpecIngressRuleMatch): any;
export declare function appSpecIngressRuleMatchToHclTerraform(struct?: AppSpecIngressRuleMatchOutputReference | AppSpecIngressRuleMatch): any;
export declare class AppSpecIngressRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleMatch | undefined;
    set internalValue(value: AppSpecIngressRuleMatch | undefined);
    private _authority;
    get authority(): AppSpecIngressRuleMatchAuthorityOutputReference;
    putAuthority(value: AppSpecIngressRuleMatchAuthority): void;
    resetAuthority(): void;
    get authorityInput(): AppSpecIngressRuleMatchAuthority | undefined;
    private _path;
    get path(): AppSpecIngressRuleMatchPathOutputReference;
    putPath(value: AppSpecIngressRuleMatchPath): void;
    resetPath(): void;
    get pathInput(): AppSpecIngressRuleMatchPath | undefined;
}
export interface AppSpecIngressRuleRedirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#authority App#authority}
    */
    readonly authority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#port App#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#redirect_code App#redirect_code}
    */
    readonly redirectCode?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scheme App#scheme}
    */
    readonly scheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#uri App#uri}
    */
    readonly uri?: string;
}
export declare function appSpecIngressRuleRedirectToTerraform(struct?: AppSpecIngressRuleRedirectOutputReference | AppSpecIngressRuleRedirect): any;
export declare function appSpecIngressRuleRedirectToHclTerraform(struct?: AppSpecIngressRuleRedirectOutputReference | AppSpecIngressRuleRedirect): any;
export declare class AppSpecIngressRuleRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressRuleRedirect | undefined;
    set internalValue(value: AppSpecIngressRuleRedirect | undefined);
    private _authority?;
    get authority(): string;
    set authority(value: string);
    resetAuthority(): void;
    get authorityInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _redirectCode?;
    get redirectCode(): number;
    set redirectCode(value: number);
    resetRedirectCode(): void;
    get redirectCodeInput(): number | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface AppSpecIngressRule {
    /**
    * component block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#component App#component}
    */
    readonly component?: AppSpecIngressRuleComponent;
    /**
    * cors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cors App#cors}
    */
    readonly cors?: AppSpecIngressRuleCors;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#match App#match}
    */
    readonly match?: AppSpecIngressRuleMatch;
    /**
    * redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#redirect App#redirect}
    */
    readonly redirect?: AppSpecIngressRuleRedirect;
}
export declare function appSpecIngressRuleToTerraform(struct?: AppSpecIngressRule | cdktn.IResolvable): any;
export declare function appSpecIngressRuleToHclTerraform(struct?: AppSpecIngressRule | cdktn.IResolvable): any;
export declare class AppSpecIngressRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecIngressRule | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecIngressRule | cdktn.IResolvable | undefined);
    private _component;
    get component(): AppSpecIngressRuleComponentOutputReference;
    putComponent(value: AppSpecIngressRuleComponent): void;
    resetComponent(): void;
    get componentInput(): AppSpecIngressRuleComponent | undefined;
    private _cors;
    get cors(): AppSpecIngressRuleCorsOutputReference;
    putCors(value: AppSpecIngressRuleCors): void;
    resetCors(): void;
    get corsInput(): AppSpecIngressRuleCors | undefined;
    private _match;
    get match(): AppSpecIngressRuleMatchOutputReference;
    putMatch(value: AppSpecIngressRuleMatch): void;
    resetMatch(): void;
    get matchInput(): AppSpecIngressRuleMatch | undefined;
    private _redirect;
    get redirect(): AppSpecIngressRuleRedirectOutputReference;
    putRedirect(value: AppSpecIngressRuleRedirect): void;
    resetRedirect(): void;
    get redirectInput(): AppSpecIngressRuleRedirect | undefined;
}
export declare class AppSpecIngressRuleList extends cdktn.ComplexList {
    internalValue?: AppSpecIngressRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecIngressRuleOutputReference;
}
export interface AppSpecIngressSecureHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecIngressSecureHeaderToTerraform(struct?: AppSpecIngressSecureHeaderOutputReference | AppSpecIngressSecureHeader): any;
export declare function appSpecIngressSecureHeaderToHclTerraform(struct?: AppSpecIngressSecureHeaderOutputReference | AppSpecIngressSecureHeader): any;
export declare class AppSpecIngressSecureHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngressSecureHeader | undefined;
    set internalValue(value: AppSpecIngressSecureHeader | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AppSpecIngress {
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rule App#rule}
    */
    readonly rule?: AppSpecIngressRule[] | cdktn.IResolvable;
    /**
    * secure_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#secure_header App#secure_header}
    */
    readonly secureHeader?: AppSpecIngressSecureHeader;
}
export declare function appSpecIngressToTerraform(struct?: AppSpecIngressOutputReference | AppSpecIngress): any;
export declare function appSpecIngressToHclTerraform(struct?: AppSpecIngressOutputReference | AppSpecIngress): any;
export declare class AppSpecIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecIngress | undefined;
    set internalValue(value: AppSpecIngress | undefined);
    private _rule;
    get rule(): AppSpecIngressRuleList;
    putRule(value: AppSpecIngressRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AppSpecIngressRule[] | undefined;
    private _secureHeader;
    get secureHeader(): AppSpecIngressSecureHeaderOutputReference;
    putSecureHeader(value: AppSpecIngressSecureHeader): void;
    resetSecureHeader(): void;
    get secureHeaderInput(): AppSpecIngressSecureHeader | undefined;
}
export interface AppSpecJobAlertDestinationsSlackWebhooks {
    /**
    * The Slack channel to send notifications to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#channel App#channel}
    */
    readonly channel: string;
    /**
    * The Slack webhook URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appSpecJobAlertDestinationsSlackWebhooksToTerraform(struct?: AppSpecJobAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare function appSpecJobAlertDestinationsSlackWebhooksToHclTerraform(struct?: AppSpecJobAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare class AppSpecJobAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecJobAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecJobAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AppSpecJobAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    internalValue?: AppSpecJobAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecJobAlertDestinationsSlackWebhooksOutputReference;
}
export interface AppSpecJobAlertDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#emails App#emails}
    */
    readonly emails?: string[];
    /**
    * slack_webhooks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#slack_webhooks App#slack_webhooks}
    */
    readonly slackWebhooks?: AppSpecJobAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
}
export declare function appSpecJobAlertDestinationsToTerraform(struct?: AppSpecJobAlertDestinationsOutputReference | AppSpecJobAlertDestinations): any;
export declare function appSpecJobAlertDestinationsToHclTerraform(struct?: AppSpecJobAlertDestinationsOutputReference | AppSpecJobAlertDestinations): any;
export declare class AppSpecJobAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobAlertDestinations | undefined;
    set internalValue(value: AppSpecJobAlertDestinations | undefined);
    private _emails?;
    get emails(): string[];
    set emails(value: string[]);
    resetEmails(): void;
    get emailsInput(): string[] | undefined;
    private _slackWebhooks;
    get slackWebhooks(): AppSpecJobAlertDestinationsSlackWebhooksList;
    putSlackWebhooks(value: AppSpecJobAlertDestinationsSlackWebhooks[] | cdktn.IResolvable): void;
    resetSlackWebhooks(): void;
    get slackWebhooksInput(): cdktn.IResolvable | AppSpecJobAlertDestinationsSlackWebhooks[] | undefined;
}
export interface AppSpecJobAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disabled App#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#operator App#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rule App#rule}
    */
    readonly rule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#window App#window}
    */
    readonly window: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#destinations App#destinations}
    */
    readonly destinations?: AppSpecJobAlertDestinations;
}
export declare function appSpecJobAlertToTerraform(struct?: AppSpecJobAlert | cdktn.IResolvable): any;
export declare function appSpecJobAlertToHclTerraform(struct?: AppSpecJobAlert | cdktn.IResolvable): any;
export declare class AppSpecJobAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecJobAlert | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecJobAlert | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
    private _window?;
    get window(): string;
    set window(value: string);
    get windowInput(): string | undefined;
    private _destinations;
    get destinations(): AppSpecJobAlertDestinationsOutputReference;
    putDestinations(value: AppSpecJobAlertDestinations): void;
    resetDestinations(): void;
    get destinationsInput(): AppSpecJobAlertDestinations | undefined;
}
export declare class AppSpecJobAlertList extends cdktn.ComplexList {
    internalValue?: AppSpecJobAlert[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecJobAlertOutputReference;
}
export interface AppSpecJobBitbucket {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecJobBitbucketToTerraform(struct?: AppSpecJobBitbucketOutputReference | AppSpecJobBitbucket): any;
export declare function appSpecJobBitbucketToHclTerraform(struct?: AppSpecJobBitbucketOutputReference | AppSpecJobBitbucket): any;
export declare class AppSpecJobBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobBitbucket | undefined;
    set internalValue(value: AppSpecJobBitbucket | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecJobEnv {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * The visibility scope of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scope App#scope}
    */
    readonly scope?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecJobEnvToTerraform(struct?: AppSpecJobEnv | cdktn.IResolvable): any;
export declare function appSpecJobEnvToHclTerraform(struct?: AppSpecJobEnv | cdktn.IResolvable): any;
export declare class AppSpecJobEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecJobEnv | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecJobEnv | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppSpecJobEnvList extends cdktn.ComplexList {
    internalValue?: AppSpecJobEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecJobEnvOutputReference;
}
export interface AppSpecJobGit {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * The clone URL of the repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo_clone_url App#repo_clone_url}
    */
    readonly repoCloneUrl?: string;
}
export declare function appSpecJobGitToTerraform(struct?: AppSpecJobGitOutputReference | AppSpecJobGit): any;
export declare function appSpecJobGitToHclTerraform(struct?: AppSpecJobGitOutputReference | AppSpecJobGit): any;
export declare class AppSpecJobGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobGit | undefined;
    set internalValue(value: AppSpecJobGit | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _repoCloneUrl?;
    get repoCloneUrl(): string;
    set repoCloneUrl(value: string);
    resetRepoCloneUrl(): void;
    get repoCloneUrlInput(): string | undefined;
}
export interface AppSpecJobGithub {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecJobGithubToTerraform(struct?: AppSpecJobGithubOutputReference | AppSpecJobGithub): any;
export declare function appSpecJobGithubToHclTerraform(struct?: AppSpecJobGithubOutputReference | AppSpecJobGithub): any;
export declare class AppSpecJobGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobGithub | undefined;
    set internalValue(value: AppSpecJobGithub | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecJobGitlab {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecJobGitlabToTerraform(struct?: AppSpecJobGitlabOutputReference | AppSpecJobGitlab): any;
export declare function appSpecJobGitlabToHclTerraform(struct?: AppSpecJobGitlabOutputReference | AppSpecJobGitlab): any;
export declare class AppSpecJobGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobGitlab | undefined;
    set internalValue(value: AppSpecJobGitlab | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecJobImageDeployOnPush {
    /**
    * Whether to automatically deploy images pushed to DOCR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#enabled App#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function appSpecJobImageDeployOnPushToTerraform(struct?: AppSpecJobImageDeployOnPush | cdktn.IResolvable): any;
export declare function appSpecJobImageDeployOnPushToHclTerraform(struct?: AppSpecJobImageDeployOnPush | cdktn.IResolvable): any;
export declare class AppSpecJobImageDeployOnPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecJobImageDeployOnPush | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecJobImageDeployOnPush | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppSpecJobImageDeployOnPushList extends cdktn.ComplexList {
    internalValue?: AppSpecJobImageDeployOnPush[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecJobImageDeployOnPushOutputReference;
}
export interface AppSpecJobImage {
    /**
    * The image digest. Cannot be specified if tag is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#digest App#digest}
    */
    readonly digest?: string;
    /**
    * The registry name. Must be left empty for the DOCR registry type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry App#registry}
    */
    readonly registry?: string;
    /**
    * Access credentials for third-party registries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry_credentials App#registry_credentials}
    */
    readonly registryCredentials?: string;
    /**
    * The registry type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry_type App#registry_type}
    */
    readonly registryType: string;
    /**
    * The repository name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repository App#repository}
    */
    readonly repository: string;
    /**
    * The repository tag. Defaults to latest if not provided. Cannot be specified if digest is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#tag App#tag}
    */
    readonly tag?: string;
    /**
    * deploy_on_push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: AppSpecJobImageDeployOnPush[] | cdktn.IResolvable;
}
export declare function appSpecJobImageToTerraform(struct?: AppSpecJobImageOutputReference | AppSpecJobImage): any;
export declare function appSpecJobImageToHclTerraform(struct?: AppSpecJobImageOutputReference | AppSpecJobImage): any;
export declare class AppSpecJobImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobImage | undefined;
    set internalValue(value: AppSpecJobImage | undefined);
    private _digest?;
    get digest(): string;
    set digest(value: string);
    resetDigest(): void;
    get digestInput(): string | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    resetRegistry(): void;
    get registryInput(): string | undefined;
    private _registryCredentials?;
    get registryCredentials(): string;
    set registryCredentials(value: string);
    resetRegistryCredentials(): void;
    get registryCredentialsInput(): string | undefined;
    private _registryType?;
    get registryType(): string;
    set registryType(value: string);
    get registryTypeInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _deployOnPush;
    get deployOnPush(): AppSpecJobImageDeployOnPushList;
    putDeployOnPush(value: AppSpecJobImageDeployOnPush[] | cdktn.IResolvable): void;
    resetDeployOnPush(): void;
    get deployOnPushInput(): cdktn.IResolvable | AppSpecJobImageDeployOnPush[] | undefined;
}
export interface AppSpecJobLogDestinationDatadog {
    /**
    * Datadog API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#api_key App#api_key}
    */
    readonly apiKey: string;
    /**
    * Datadog HTTP log intake endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appSpecJobLogDestinationDatadogToTerraform(struct?: AppSpecJobLogDestinationDatadogOutputReference | AppSpecJobLogDestinationDatadog): any;
export declare function appSpecJobLogDestinationDatadogToHclTerraform(struct?: AppSpecJobLogDestinationDatadogOutputReference | AppSpecJobLogDestinationDatadog): any;
export declare class AppSpecJobLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobLogDestinationDatadog | undefined;
    set internalValue(value: AppSpecJobLogDestinationDatadog | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppSpecJobLogDestinationLogtail {
    /**
    * Logtail token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#token App#token}
    */
    readonly token: string;
}
export declare function appSpecJobLogDestinationLogtailToTerraform(struct?: AppSpecJobLogDestinationLogtailOutputReference | AppSpecJobLogDestinationLogtail): any;
export declare function appSpecJobLogDestinationLogtailToHclTerraform(struct?: AppSpecJobLogDestinationLogtailOutputReference | AppSpecJobLogDestinationLogtail): any;
export declare class AppSpecJobLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobLogDestinationLogtail | undefined;
    set internalValue(value: AppSpecJobLogDestinationLogtail | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface AppSpecJobLogDestinationOpenSearchBasicAuth {
    /**
    * Password for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#password App#password}
    */
    readonly password?: string;
    /**
    * user for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#user App#user}
    */
    readonly user?: string;
}
export declare function appSpecJobLogDestinationOpenSearchBasicAuthToTerraform(struct?: AppSpecJobLogDestinationOpenSearchBasicAuthOutputReference | AppSpecJobLogDestinationOpenSearchBasicAuth): any;
export declare function appSpecJobLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: AppSpecJobLogDestinationOpenSearchBasicAuthOutputReference | AppSpecJobLogDestinationOpenSearchBasicAuth): any;
export declare class AppSpecJobLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: AppSpecJobLogDestinationOpenSearchBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface AppSpecJobLogDestinationOpenSearch {
    /**
    * OpenSearch cluster name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cluster_name App#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * OpenSearch endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
    /**
    * OpenSearch index name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#index_name App#index_name}
    */
    readonly indexName?: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#basic_auth App#basic_auth}
    */
    readonly basicAuth: AppSpecJobLogDestinationOpenSearchBasicAuth;
}
export declare function appSpecJobLogDestinationOpenSearchToTerraform(struct?: AppSpecJobLogDestinationOpenSearchOutputReference | AppSpecJobLogDestinationOpenSearch): any;
export declare function appSpecJobLogDestinationOpenSearchToHclTerraform(struct?: AppSpecJobLogDestinationOpenSearchOutputReference | AppSpecJobLogDestinationOpenSearch): any;
export declare class AppSpecJobLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobLogDestinationOpenSearch | undefined;
    set internalValue(value: AppSpecJobLogDestinationOpenSearch | undefined);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    resetIndexName(): void;
    get indexNameInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): AppSpecJobLogDestinationOpenSearchBasicAuthOutputReference;
    putBasicAuth(value: AppSpecJobLogDestinationOpenSearchBasicAuth): void;
    get basicAuthInput(): AppSpecJobLogDestinationOpenSearchBasicAuth | undefined;
}
export interface AppSpecJobLogDestinationPapertrail {
    /**
    * Papertrail syslog endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint: string;
}
export declare function appSpecJobLogDestinationPapertrailToTerraform(struct?: AppSpecJobLogDestinationPapertrailOutputReference | AppSpecJobLogDestinationPapertrail): any;
export declare function appSpecJobLogDestinationPapertrailToHclTerraform(struct?: AppSpecJobLogDestinationPapertrailOutputReference | AppSpecJobLogDestinationPapertrail): any;
export declare class AppSpecJobLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobLogDestinationPapertrail | undefined;
    set internalValue(value: AppSpecJobLogDestinationPapertrail | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
}
export interface AppSpecJobLogDestination {
    /**
    * Name of the log destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#datadog App#datadog}
    */
    readonly datadog?: AppSpecJobLogDestinationDatadog;
    /**
    * logtail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#logtail App#logtail}
    */
    readonly logtail?: AppSpecJobLogDestinationLogtail;
    /**
    * open_search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#open_search App#open_search}
    */
    readonly openSearch?: AppSpecJobLogDestinationOpenSearch;
    /**
    * papertrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#papertrail App#papertrail}
    */
    readonly papertrail?: AppSpecJobLogDestinationPapertrail;
}
export declare function appSpecJobLogDestinationToTerraform(struct?: AppSpecJobLogDestination | cdktn.IResolvable): any;
export declare function appSpecJobLogDestinationToHclTerraform(struct?: AppSpecJobLogDestination | cdktn.IResolvable): any;
export declare class AppSpecJobLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecJobLogDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecJobLogDestination | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _datadog;
    get datadog(): AppSpecJobLogDestinationDatadogOutputReference;
    putDatadog(value: AppSpecJobLogDestinationDatadog): void;
    resetDatadog(): void;
    get datadogInput(): AppSpecJobLogDestinationDatadog | undefined;
    private _logtail;
    get logtail(): AppSpecJobLogDestinationLogtailOutputReference;
    putLogtail(value: AppSpecJobLogDestinationLogtail): void;
    resetLogtail(): void;
    get logtailInput(): AppSpecJobLogDestinationLogtail | undefined;
    private _openSearch;
    get openSearch(): AppSpecJobLogDestinationOpenSearchOutputReference;
    putOpenSearch(value: AppSpecJobLogDestinationOpenSearch): void;
    resetOpenSearch(): void;
    get openSearchInput(): AppSpecJobLogDestinationOpenSearch | undefined;
    private _papertrail;
    get papertrail(): AppSpecJobLogDestinationPapertrailOutputReference;
    putPapertrail(value: AppSpecJobLogDestinationPapertrail): void;
    resetPapertrail(): void;
    get papertrailInput(): AppSpecJobLogDestinationPapertrail | undefined;
}
export declare class AppSpecJobLogDestinationList extends cdktn.ComplexList {
    internalValue?: AppSpecJobLogDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecJobLogDestinationOutputReference;
}
export interface AppSpecJobTermination {
    /**
    * The number of seconds to wait between sending a TERM signal to a container and issuing a KILL which causes immediate shutdown. Default: 120, Minimum 1, Maximum 600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#grace_period_seconds App#grace_period_seconds}
    */
    readonly gracePeriodSeconds?: number;
}
export declare function appSpecJobTerminationToTerraform(struct?: AppSpecJobTerminationOutputReference | AppSpecJobTermination): any;
export declare function appSpecJobTerminationToHclTerraform(struct?: AppSpecJobTerminationOutputReference | AppSpecJobTermination): any;
export declare class AppSpecJobTerminationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecJobTermination | undefined;
    set internalValue(value: AppSpecJobTermination | undefined);
    private _gracePeriodSeconds?;
    get gracePeriodSeconds(): number;
    set gracePeriodSeconds(value: number);
    resetGracePeriodSeconds(): void;
    get gracePeriodSecondsInput(): number | undefined;
}
export interface AppSpecJob {
    /**
    * An optional build command to run while building this component from source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#build_command App#build_command}
    */
    readonly buildCommand?: string;
    /**
    * The path to a Dockerfile relative to the root of the repo. If set, overrides usage of buildpacks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#dockerfile_path App#dockerfile_path}
    */
    readonly dockerfilePath?: string;
    /**
    * An environment slug describing the type of this app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#environment_slug App#environment_slug}
    */
    readonly environmentSlug?: string;
    /**
    * The amount of instances that this component should be scaled to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#instance_count App#instance_count}
    */
    readonly instanceCount?: number;
    /**
    * The instance size to use for this component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#instance_size_slug App#instance_size_slug}
    */
    readonly instanceSizeSlug?: string;
    /**
    * The type of job and when it will be run during the deployment process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#kind App#kind}
    */
    readonly kind?: string;
    /**
    * The name of the component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * An optional run command to override the component's default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#run_command App#run_command}
    */
    readonly runCommand?: string;
    /**
    * An optional path to the working directory to use for the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#source_dir App#source_dir}
    */
    readonly sourceDir?: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#alert App#alert}
    */
    readonly alert?: AppSpecJobAlert[] | cdktn.IResolvable;
    /**
    * bitbucket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#bitbucket App#bitbucket}
    */
    readonly bitbucket?: AppSpecJobBitbucket;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#env App#env}
    */
    readonly env?: AppSpecJobEnv[] | cdktn.IResolvable;
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#git App#git}
    */
    readonly git?: AppSpecJobGit;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#github App#github}
    */
    readonly github?: AppSpecJobGithub;
    /**
    * gitlab block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#gitlab App#gitlab}
    */
    readonly gitlab?: AppSpecJobGitlab;
    /**
    * image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#image App#image}
    */
    readonly image?: AppSpecJobImage;
    /**
    * log_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#log_destination App#log_destination}
    */
    readonly logDestination?: AppSpecJobLogDestination[] | cdktn.IResolvable;
    /**
    * termination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#termination App#termination}
    */
    readonly termination?: AppSpecJobTermination;
}
export declare function appSpecJobToTerraform(struct?: AppSpecJob | cdktn.IResolvable): any;
export declare function appSpecJobToHclTerraform(struct?: AppSpecJob | cdktn.IResolvable): any;
export declare class AppSpecJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecJob | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecJob | cdktn.IResolvable | undefined);
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _dockerfilePath?;
    get dockerfilePath(): string;
    set dockerfilePath(value: string);
    resetDockerfilePath(): void;
    get dockerfilePathInput(): string | undefined;
    private _environmentSlug?;
    get environmentSlug(): string;
    set environmentSlug(value: string);
    resetEnvironmentSlug(): void;
    get environmentSlugInput(): string | undefined;
    private _instanceCount?;
    get instanceCount(): number;
    set instanceCount(value: number);
    resetInstanceCount(): void;
    get instanceCountInput(): number | undefined;
    private _instanceSizeSlug?;
    get instanceSizeSlug(): string;
    set instanceSizeSlug(value: string);
    resetInstanceSizeSlug(): void;
    get instanceSizeSlugInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _runCommand?;
    get runCommand(): string;
    set runCommand(value: string);
    resetRunCommand(): void;
    get runCommandInput(): string | undefined;
    private _sourceDir?;
    get sourceDir(): string;
    set sourceDir(value: string);
    resetSourceDir(): void;
    get sourceDirInput(): string | undefined;
    private _alert;
    get alert(): AppSpecJobAlertList;
    putAlert(value: AppSpecJobAlert[] | cdktn.IResolvable): void;
    resetAlert(): void;
    get alertInput(): cdktn.IResolvable | AppSpecJobAlert[] | undefined;
    private _bitbucket;
    get bitbucket(): AppSpecJobBitbucketOutputReference;
    putBitbucket(value: AppSpecJobBitbucket): void;
    resetBitbucket(): void;
    get bitbucketInput(): AppSpecJobBitbucket | undefined;
    private _env;
    get env(): AppSpecJobEnvList;
    putEnv(value: AppSpecJobEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | AppSpecJobEnv[] | undefined;
    private _git;
    get git(): AppSpecJobGitOutputReference;
    putGit(value: AppSpecJobGit): void;
    resetGit(): void;
    get gitInput(): AppSpecJobGit | undefined;
    private _github;
    get github(): AppSpecJobGithubOutputReference;
    putGithub(value: AppSpecJobGithub): void;
    resetGithub(): void;
    get githubInput(): AppSpecJobGithub | undefined;
    private _gitlab;
    get gitlab(): AppSpecJobGitlabOutputReference;
    putGitlab(value: AppSpecJobGitlab): void;
    resetGitlab(): void;
    get gitlabInput(): AppSpecJobGitlab | undefined;
    private _image;
    get image(): AppSpecJobImageOutputReference;
    putImage(value: AppSpecJobImage): void;
    resetImage(): void;
    get imageInput(): AppSpecJobImage | undefined;
    private _logDestination;
    get logDestination(): AppSpecJobLogDestinationList;
    putLogDestination(value: AppSpecJobLogDestination[] | cdktn.IResolvable): void;
    resetLogDestination(): void;
    get logDestinationInput(): cdktn.IResolvable | AppSpecJobLogDestination[] | undefined;
    private _termination;
    get termination(): AppSpecJobTerminationOutputReference;
    putTermination(value: AppSpecJobTermination): void;
    resetTermination(): void;
    get terminationInput(): AppSpecJobTermination | undefined;
}
export declare class AppSpecJobList extends cdktn.ComplexList {
    internalValue?: AppSpecJob[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecJobOutputReference;
}
export interface AppSpecMaintenance {
    /**
    * Indicates whether the app should be archived. Setting this to true implies that enabled is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#archive App#archive}
    */
    readonly archive?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether maintenance mode should be enabled for the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#enabled App#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * A custom offline page to display when maintenance mode is enabled or the app is archived.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#offline_page_url App#offline_page_url}
    */
    readonly offlinePageUrl?: string;
}
export declare function appSpecMaintenanceToTerraform(struct?: AppSpecMaintenanceOutputReference | AppSpecMaintenance): any;
export declare function appSpecMaintenanceToHclTerraform(struct?: AppSpecMaintenanceOutputReference | AppSpecMaintenance): any;
export declare class AppSpecMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecMaintenance | undefined;
    set internalValue(value: AppSpecMaintenance | undefined);
    private _archive?;
    get archive(): boolean | cdktn.IResolvable;
    set archive(value: boolean | cdktn.IResolvable);
    resetArchive(): void;
    get archiveInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _offlinePageUrl?;
    get offlinePageUrl(): string;
    set offlinePageUrl(value: string);
    resetOfflinePageUrl(): void;
    get offlinePageUrlInput(): string | undefined;
}
export interface AppSpecServiceAlertDestinationsSlackWebhooks {
    /**
    * The Slack channel to send notifications to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#channel App#channel}
    */
    readonly channel: string;
    /**
    * The Slack webhook URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appSpecServiceAlertDestinationsSlackWebhooksToTerraform(struct?: AppSpecServiceAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare function appSpecServiceAlertDestinationsSlackWebhooksToHclTerraform(struct?: AppSpecServiceAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare class AppSpecServiceAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecServiceAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecServiceAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AppSpecServiceAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    internalValue?: AppSpecServiceAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceAlertDestinationsSlackWebhooksOutputReference;
}
export interface AppSpecServiceAlertDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#emails App#emails}
    */
    readonly emails?: string[];
    /**
    * slack_webhooks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#slack_webhooks App#slack_webhooks}
    */
    readonly slackWebhooks?: AppSpecServiceAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
}
export declare function appSpecServiceAlertDestinationsToTerraform(struct?: AppSpecServiceAlertDestinationsOutputReference | AppSpecServiceAlertDestinations): any;
export declare function appSpecServiceAlertDestinationsToHclTerraform(struct?: AppSpecServiceAlertDestinationsOutputReference | AppSpecServiceAlertDestinations): any;
export declare class AppSpecServiceAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceAlertDestinations | undefined;
    set internalValue(value: AppSpecServiceAlertDestinations | undefined);
    private _emails?;
    get emails(): string[];
    set emails(value: string[]);
    resetEmails(): void;
    get emailsInput(): string[] | undefined;
    private _slackWebhooks;
    get slackWebhooks(): AppSpecServiceAlertDestinationsSlackWebhooksList;
    putSlackWebhooks(value: AppSpecServiceAlertDestinationsSlackWebhooks[] | cdktn.IResolvable): void;
    resetSlackWebhooks(): void;
    get slackWebhooksInput(): cdktn.IResolvable | AppSpecServiceAlertDestinationsSlackWebhooks[] | undefined;
}
export interface AppSpecServiceAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disabled App#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#operator App#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rule App#rule}
    */
    readonly rule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#window App#window}
    */
    readonly window: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#destinations App#destinations}
    */
    readonly destinations?: AppSpecServiceAlertDestinations;
}
export declare function appSpecServiceAlertToTerraform(struct?: AppSpecServiceAlert | cdktn.IResolvable): any;
export declare function appSpecServiceAlertToHclTerraform(struct?: AppSpecServiceAlert | cdktn.IResolvable): any;
export declare class AppSpecServiceAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecServiceAlert | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecServiceAlert | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
    private _window?;
    get window(): string;
    set window(value: string);
    get windowInput(): string | undefined;
    private _destinations;
    get destinations(): AppSpecServiceAlertDestinationsOutputReference;
    putDestinations(value: AppSpecServiceAlertDestinations): void;
    resetDestinations(): void;
    get destinationsInput(): AppSpecServiceAlertDestinations | undefined;
}
export declare class AppSpecServiceAlertList extends cdktn.ComplexList {
    internalValue?: AppSpecServiceAlert[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceAlertOutputReference;
}
export interface AppSpecServiceAutoscalingMetricsCpu {
    /**
    * The average target CPU utilization for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#percent App#percent}
    */
    readonly percent: number;
}
export declare function appSpecServiceAutoscalingMetricsCpuToTerraform(struct?: AppSpecServiceAutoscalingMetricsCpuOutputReference | AppSpecServiceAutoscalingMetricsCpu): any;
export declare function appSpecServiceAutoscalingMetricsCpuToHclTerraform(struct?: AppSpecServiceAutoscalingMetricsCpuOutputReference | AppSpecServiceAutoscalingMetricsCpu): any;
export declare class AppSpecServiceAutoscalingMetricsCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceAutoscalingMetricsCpu | undefined;
    set internalValue(value: AppSpecServiceAutoscalingMetricsCpu | undefined);
    private _percent?;
    get percent(): number;
    set percent(value: number);
    get percentInput(): number | undefined;
}
export interface AppSpecServiceAutoscalingMetrics {
    /**
    * cpu block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cpu App#cpu}
    */
    readonly cpu?: AppSpecServiceAutoscalingMetricsCpu;
}
export declare function appSpecServiceAutoscalingMetricsToTerraform(struct?: AppSpecServiceAutoscalingMetricsOutputReference | AppSpecServiceAutoscalingMetrics): any;
export declare function appSpecServiceAutoscalingMetricsToHclTerraform(struct?: AppSpecServiceAutoscalingMetricsOutputReference | AppSpecServiceAutoscalingMetrics): any;
export declare class AppSpecServiceAutoscalingMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceAutoscalingMetrics | undefined;
    set internalValue(value: AppSpecServiceAutoscalingMetrics | undefined);
    private _cpu;
    get cpu(): AppSpecServiceAutoscalingMetricsCpuOutputReference;
    putCpu(value: AppSpecServiceAutoscalingMetricsCpu): void;
    resetCpu(): void;
    get cpuInput(): AppSpecServiceAutoscalingMetricsCpu | undefined;
}
export interface AppSpecServiceAutoscaling {
    /**
    * The maximum amount of instances for this component. Must be more than min_instance_count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#max_instance_count App#max_instance_count}
    */
    readonly maxInstanceCount: number;
    /**
    * The minimum amount of instances for this component. Must be less than max_instance_count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#min_instance_count App#min_instance_count}
    */
    readonly minInstanceCount: number;
    /**
    * metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#metrics App#metrics}
    */
    readonly metrics: AppSpecServiceAutoscalingMetrics;
}
export declare function appSpecServiceAutoscalingToTerraform(struct?: AppSpecServiceAutoscalingOutputReference | AppSpecServiceAutoscaling): any;
export declare function appSpecServiceAutoscalingToHclTerraform(struct?: AppSpecServiceAutoscalingOutputReference | AppSpecServiceAutoscaling): any;
export declare class AppSpecServiceAutoscalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceAutoscaling | undefined;
    set internalValue(value: AppSpecServiceAutoscaling | undefined);
    private _maxInstanceCount?;
    get maxInstanceCount(): number;
    set maxInstanceCount(value: number);
    get maxInstanceCountInput(): number | undefined;
    private _minInstanceCount?;
    get minInstanceCount(): number;
    set minInstanceCount(value: number);
    get minInstanceCountInput(): number | undefined;
    private _metrics;
    get metrics(): AppSpecServiceAutoscalingMetricsOutputReference;
    putMetrics(value: AppSpecServiceAutoscalingMetrics): void;
    get metricsInput(): AppSpecServiceAutoscalingMetrics | undefined;
}
export interface AppSpecServiceBitbucket {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecServiceBitbucketToTerraform(struct?: AppSpecServiceBitbucketOutputReference | AppSpecServiceBitbucket): any;
export declare function appSpecServiceBitbucketToHclTerraform(struct?: AppSpecServiceBitbucketOutputReference | AppSpecServiceBitbucket): any;
export declare class AppSpecServiceBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceBitbucket | undefined;
    set internalValue(value: AppSpecServiceBitbucket | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecServiceCorsAllowOrigins {
    /**
    * Exact string match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#exact App#exact}
    */
    readonly exact?: string;
    /**
    * Prefix-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#prefix App#prefix}
    */
    readonly prefix?: string;
    /**
    * RE2 style regex-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#regex App#regex}
    */
    readonly regex?: string;
}
export declare function appSpecServiceCorsAllowOriginsToTerraform(struct?: AppSpecServiceCorsAllowOriginsOutputReference | AppSpecServiceCorsAllowOrigins): any;
export declare function appSpecServiceCorsAllowOriginsToHclTerraform(struct?: AppSpecServiceCorsAllowOriginsOutputReference | AppSpecServiceCorsAllowOrigins): any;
export declare class AppSpecServiceCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceCorsAllowOrigins | undefined;
    set internalValue(value: AppSpecServiceCorsAllowOrigins | undefined);
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
}
export interface AppSpecServiceCors {
    /**
    * Whether browsers should expose the response to the client-side JavaScript code when the request’s credentials mode is `include`. This configures the Access-Control-Allow-Credentials header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_credentials App#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * The set of allowed HTTP request headers. This configures the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_headers App#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * The set of allowed HTTP methods. This configures the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_methods App#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * The set of HTTP response headers that browsers are allowed to access. This configures the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#expose_headers App#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * An optional duration specifying how long browsers can cache the results of a preflight request. This configures the Access-Control-Max-Age header. Example: `5h30m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#max_age App#max_age}
    */
    readonly maxAge?: string;
    /**
    * allow_origins block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_origins App#allow_origins}
    */
    readonly allowOrigins?: AppSpecServiceCorsAllowOrigins;
}
export declare function appSpecServiceCorsToTerraform(struct?: AppSpecServiceCorsOutputReference | AppSpecServiceCors): any;
export declare function appSpecServiceCorsToHclTerraform(struct?: AppSpecServiceCorsOutputReference | AppSpecServiceCors): any;
export declare class AppSpecServiceCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceCors | undefined;
    set internalValue(value: AppSpecServiceCors | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): string;
    set maxAge(value: string);
    resetMaxAge(): void;
    get maxAgeInput(): string | undefined;
    private _allowOrigins;
    get allowOrigins(): AppSpecServiceCorsAllowOriginsOutputReference;
    putAllowOrigins(value: AppSpecServiceCorsAllowOrigins): void;
    resetAllowOrigins(): void;
    get allowOriginsInput(): AppSpecServiceCorsAllowOrigins | undefined;
}
export interface AppSpecServiceEnv {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * The visibility scope of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scope App#scope}
    */
    readonly scope?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecServiceEnvToTerraform(struct?: AppSpecServiceEnv | cdktn.IResolvable): any;
export declare function appSpecServiceEnvToHclTerraform(struct?: AppSpecServiceEnv | cdktn.IResolvable): any;
export declare class AppSpecServiceEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecServiceEnv | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecServiceEnv | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppSpecServiceEnvList extends cdktn.ComplexList {
    internalValue?: AppSpecServiceEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceEnvOutputReference;
}
export interface AppSpecServiceGit {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * The clone URL of the repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo_clone_url App#repo_clone_url}
    */
    readonly repoCloneUrl?: string;
}
export declare function appSpecServiceGitToTerraform(struct?: AppSpecServiceGitOutputReference | AppSpecServiceGit): any;
export declare function appSpecServiceGitToHclTerraform(struct?: AppSpecServiceGitOutputReference | AppSpecServiceGit): any;
export declare class AppSpecServiceGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceGit | undefined;
    set internalValue(value: AppSpecServiceGit | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _repoCloneUrl?;
    get repoCloneUrl(): string;
    set repoCloneUrl(value: string);
    resetRepoCloneUrl(): void;
    get repoCloneUrlInput(): string | undefined;
}
export interface AppSpecServiceGithub {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecServiceGithubToTerraform(struct?: AppSpecServiceGithubOutputReference | AppSpecServiceGithub): any;
export declare function appSpecServiceGithubToHclTerraform(struct?: AppSpecServiceGithubOutputReference | AppSpecServiceGithub): any;
export declare class AppSpecServiceGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceGithub | undefined;
    set internalValue(value: AppSpecServiceGithub | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecServiceGitlab {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecServiceGitlabToTerraform(struct?: AppSpecServiceGitlabOutputReference | AppSpecServiceGitlab): any;
export declare function appSpecServiceGitlabToHclTerraform(struct?: AppSpecServiceGitlabOutputReference | AppSpecServiceGitlab): any;
export declare class AppSpecServiceGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceGitlab | undefined;
    set internalValue(value: AppSpecServiceGitlab | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecServiceHealthCheck {
    /**
    * The number of failed health checks before considered unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#failure_threshold App#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * The route path used for the HTTP health check ping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#http_path App#http_path}
    */
    readonly httpPath?: string;
    /**
    * The number of seconds to wait before beginning health checks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#initial_delay_seconds App#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * The number of seconds to wait between health checks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#period_seconds App#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * The port on which the health check will be performed. If not set, the health check will be performed on the component's http_port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#port App#port}
    */
    readonly port?: number;
    /**
    * The number of successful health checks before considered healthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#success_threshold App#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * The number of seconds after which the check times out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#timeout_seconds App#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
}
export declare function appSpecServiceHealthCheckToTerraform(struct?: AppSpecServiceHealthCheckOutputReference | AppSpecServiceHealthCheck): any;
export declare function appSpecServiceHealthCheckToHclTerraform(struct?: AppSpecServiceHealthCheckOutputReference | AppSpecServiceHealthCheck): any;
export declare class AppSpecServiceHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceHealthCheck | undefined;
    set internalValue(value: AppSpecServiceHealthCheck | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _httpPath?;
    get httpPath(): string;
    set httpPath(value: string);
    resetHttpPath(): void;
    get httpPathInput(): string | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
}
export interface AppSpecServiceImageDeployOnPush {
    /**
    * Whether to automatically deploy images pushed to DOCR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#enabled App#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function appSpecServiceImageDeployOnPushToTerraform(struct?: AppSpecServiceImageDeployOnPush | cdktn.IResolvable): any;
export declare function appSpecServiceImageDeployOnPushToHclTerraform(struct?: AppSpecServiceImageDeployOnPush | cdktn.IResolvable): any;
export declare class AppSpecServiceImageDeployOnPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecServiceImageDeployOnPush | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecServiceImageDeployOnPush | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppSpecServiceImageDeployOnPushList extends cdktn.ComplexList {
    internalValue?: AppSpecServiceImageDeployOnPush[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceImageDeployOnPushOutputReference;
}
export interface AppSpecServiceImage {
    /**
    * The image digest. Cannot be specified if tag is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#digest App#digest}
    */
    readonly digest?: string;
    /**
    * The registry name. Must be left empty for the DOCR registry type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry App#registry}
    */
    readonly registry?: string;
    /**
    * Access credentials for third-party registries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry_credentials App#registry_credentials}
    */
    readonly registryCredentials?: string;
    /**
    * The registry type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry_type App#registry_type}
    */
    readonly registryType: string;
    /**
    * The repository name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repository App#repository}
    */
    readonly repository: string;
    /**
    * The repository tag. Defaults to latest if not provided. Cannot be specified if digest is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#tag App#tag}
    */
    readonly tag?: string;
    /**
    * deploy_on_push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: AppSpecServiceImageDeployOnPush[] | cdktn.IResolvable;
}
export declare function appSpecServiceImageToTerraform(struct?: AppSpecServiceImageOutputReference | AppSpecServiceImage): any;
export declare function appSpecServiceImageToHclTerraform(struct?: AppSpecServiceImageOutputReference | AppSpecServiceImage): any;
export declare class AppSpecServiceImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceImage | undefined;
    set internalValue(value: AppSpecServiceImage | undefined);
    private _digest?;
    get digest(): string;
    set digest(value: string);
    resetDigest(): void;
    get digestInput(): string | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    resetRegistry(): void;
    get registryInput(): string | undefined;
    private _registryCredentials?;
    get registryCredentials(): string;
    set registryCredentials(value: string);
    resetRegistryCredentials(): void;
    get registryCredentialsInput(): string | undefined;
    private _registryType?;
    get registryType(): string;
    set registryType(value: string);
    get registryTypeInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _deployOnPush;
    get deployOnPush(): AppSpecServiceImageDeployOnPushList;
    putDeployOnPush(value: AppSpecServiceImageDeployOnPush[] | cdktn.IResolvable): void;
    resetDeployOnPush(): void;
    get deployOnPushInput(): cdktn.IResolvable | AppSpecServiceImageDeployOnPush[] | undefined;
}
export interface AppSpecServiceLogDestinationDatadog {
    /**
    * Datadog API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#api_key App#api_key}
    */
    readonly apiKey: string;
    /**
    * Datadog HTTP log intake endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appSpecServiceLogDestinationDatadogToTerraform(struct?: AppSpecServiceLogDestinationDatadogOutputReference | AppSpecServiceLogDestinationDatadog): any;
export declare function appSpecServiceLogDestinationDatadogToHclTerraform(struct?: AppSpecServiceLogDestinationDatadogOutputReference | AppSpecServiceLogDestinationDatadog): any;
export declare class AppSpecServiceLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceLogDestinationDatadog | undefined;
    set internalValue(value: AppSpecServiceLogDestinationDatadog | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppSpecServiceLogDestinationLogtail {
    /**
    * Logtail token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#token App#token}
    */
    readonly token: string;
}
export declare function appSpecServiceLogDestinationLogtailToTerraform(struct?: AppSpecServiceLogDestinationLogtailOutputReference | AppSpecServiceLogDestinationLogtail): any;
export declare function appSpecServiceLogDestinationLogtailToHclTerraform(struct?: AppSpecServiceLogDestinationLogtailOutputReference | AppSpecServiceLogDestinationLogtail): any;
export declare class AppSpecServiceLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceLogDestinationLogtail | undefined;
    set internalValue(value: AppSpecServiceLogDestinationLogtail | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface AppSpecServiceLogDestinationOpenSearchBasicAuth {
    /**
    * Password for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#password App#password}
    */
    readonly password?: string;
    /**
    * user for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#user App#user}
    */
    readonly user?: string;
}
export declare function appSpecServiceLogDestinationOpenSearchBasicAuthToTerraform(struct?: AppSpecServiceLogDestinationOpenSearchBasicAuthOutputReference | AppSpecServiceLogDestinationOpenSearchBasicAuth): any;
export declare function appSpecServiceLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: AppSpecServiceLogDestinationOpenSearchBasicAuthOutputReference | AppSpecServiceLogDestinationOpenSearchBasicAuth): any;
export declare class AppSpecServiceLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: AppSpecServiceLogDestinationOpenSearchBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface AppSpecServiceLogDestinationOpenSearch {
    /**
    * OpenSearch cluster name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cluster_name App#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * OpenSearch endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
    /**
    * OpenSearch index name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#index_name App#index_name}
    */
    readonly indexName?: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#basic_auth App#basic_auth}
    */
    readonly basicAuth: AppSpecServiceLogDestinationOpenSearchBasicAuth;
}
export declare function appSpecServiceLogDestinationOpenSearchToTerraform(struct?: AppSpecServiceLogDestinationOpenSearchOutputReference | AppSpecServiceLogDestinationOpenSearch): any;
export declare function appSpecServiceLogDestinationOpenSearchToHclTerraform(struct?: AppSpecServiceLogDestinationOpenSearchOutputReference | AppSpecServiceLogDestinationOpenSearch): any;
export declare class AppSpecServiceLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceLogDestinationOpenSearch | undefined;
    set internalValue(value: AppSpecServiceLogDestinationOpenSearch | undefined);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    resetIndexName(): void;
    get indexNameInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): AppSpecServiceLogDestinationOpenSearchBasicAuthOutputReference;
    putBasicAuth(value: AppSpecServiceLogDestinationOpenSearchBasicAuth): void;
    get basicAuthInput(): AppSpecServiceLogDestinationOpenSearchBasicAuth | undefined;
}
export interface AppSpecServiceLogDestinationPapertrail {
    /**
    * Papertrail syslog endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint: string;
}
export declare function appSpecServiceLogDestinationPapertrailToTerraform(struct?: AppSpecServiceLogDestinationPapertrailOutputReference | AppSpecServiceLogDestinationPapertrail): any;
export declare function appSpecServiceLogDestinationPapertrailToHclTerraform(struct?: AppSpecServiceLogDestinationPapertrailOutputReference | AppSpecServiceLogDestinationPapertrail): any;
export declare class AppSpecServiceLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceLogDestinationPapertrail | undefined;
    set internalValue(value: AppSpecServiceLogDestinationPapertrail | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
}
export interface AppSpecServiceLogDestination {
    /**
    * Name of the log destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#datadog App#datadog}
    */
    readonly datadog?: AppSpecServiceLogDestinationDatadog;
    /**
    * logtail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#logtail App#logtail}
    */
    readonly logtail?: AppSpecServiceLogDestinationLogtail;
    /**
    * open_search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#open_search App#open_search}
    */
    readonly openSearch?: AppSpecServiceLogDestinationOpenSearch;
    /**
    * papertrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#papertrail App#papertrail}
    */
    readonly papertrail?: AppSpecServiceLogDestinationPapertrail;
}
export declare function appSpecServiceLogDestinationToTerraform(struct?: AppSpecServiceLogDestination | cdktn.IResolvable): any;
export declare function appSpecServiceLogDestinationToHclTerraform(struct?: AppSpecServiceLogDestination | cdktn.IResolvable): any;
export declare class AppSpecServiceLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecServiceLogDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecServiceLogDestination | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _datadog;
    get datadog(): AppSpecServiceLogDestinationDatadogOutputReference;
    putDatadog(value: AppSpecServiceLogDestinationDatadog): void;
    resetDatadog(): void;
    get datadogInput(): AppSpecServiceLogDestinationDatadog | undefined;
    private _logtail;
    get logtail(): AppSpecServiceLogDestinationLogtailOutputReference;
    putLogtail(value: AppSpecServiceLogDestinationLogtail): void;
    resetLogtail(): void;
    get logtailInput(): AppSpecServiceLogDestinationLogtail | undefined;
    private _openSearch;
    get openSearch(): AppSpecServiceLogDestinationOpenSearchOutputReference;
    putOpenSearch(value: AppSpecServiceLogDestinationOpenSearch): void;
    resetOpenSearch(): void;
    get openSearchInput(): AppSpecServiceLogDestinationOpenSearch | undefined;
    private _papertrail;
    get papertrail(): AppSpecServiceLogDestinationPapertrailOutputReference;
    putPapertrail(value: AppSpecServiceLogDestinationPapertrail): void;
    resetPapertrail(): void;
    get papertrailInput(): AppSpecServiceLogDestinationPapertrail | undefined;
}
export declare class AppSpecServiceLogDestinationList extends cdktn.ComplexList {
    internalValue?: AppSpecServiceLogDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceLogDestinationOutputReference;
}
export interface AppSpecServiceRoutes {
    /**
    * Path specifies an route by HTTP path prefix. Paths must start with / and must be unique within the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#path App#path}
    */
    readonly path?: string;
    /**
    *  An optional flag to preserve the path that is forwarded to the backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#preserve_path_prefix App#preserve_path_prefix}
    */
    readonly preservePathPrefix?: boolean | cdktn.IResolvable;
}
export declare function appSpecServiceRoutesToTerraform(struct?: AppSpecServiceRoutes | cdktn.IResolvable): any;
export declare function appSpecServiceRoutesToHclTerraform(struct?: AppSpecServiceRoutes | cdktn.IResolvable): any;
export declare class AppSpecServiceRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecServiceRoutes | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecServiceRoutes | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _preservePathPrefix?;
    get preservePathPrefix(): boolean | cdktn.IResolvable;
    set preservePathPrefix(value: boolean | cdktn.IResolvable);
    resetPreservePathPrefix(): void;
    get preservePathPrefixInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppSpecServiceRoutesList extends cdktn.ComplexList {
    internalValue?: AppSpecServiceRoutes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceRoutesOutputReference;
}
export interface AppSpecServiceTermination {
    /**
    * The number of seconds to wait between selecting a container instance for termination and issuing the TERM signal. Selecting a container instance for termination begins an asynchronous drain of new requests on upstream load-balancers. Default: 15 seconds, Minimum 1, Maximum 110.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#drain_seconds App#drain_seconds}
    */
    readonly drainSeconds?: number;
    /**
    * The number of seconds to wait between sending a TERM signal to a container and issuing a KILL which causes immediate shutdown. Default: 120, Minimum 1, Maximum 600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#grace_period_seconds App#grace_period_seconds}
    */
    readonly gracePeriodSeconds?: number;
}
export declare function appSpecServiceTerminationToTerraform(struct?: AppSpecServiceTerminationOutputReference | AppSpecServiceTermination): any;
export declare function appSpecServiceTerminationToHclTerraform(struct?: AppSpecServiceTerminationOutputReference | AppSpecServiceTermination): any;
export declare class AppSpecServiceTerminationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecServiceTermination | undefined;
    set internalValue(value: AppSpecServiceTermination | undefined);
    private _drainSeconds?;
    get drainSeconds(): number;
    set drainSeconds(value: number);
    resetDrainSeconds(): void;
    get drainSecondsInput(): number | undefined;
    private _gracePeriodSeconds?;
    get gracePeriodSeconds(): number;
    set gracePeriodSeconds(value: number);
    resetGracePeriodSeconds(): void;
    get gracePeriodSecondsInput(): number | undefined;
}
export interface AppSpecService {
    /**
    * An optional build command to run while building this component from source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#build_command App#build_command}
    */
    readonly buildCommand?: string;
    /**
    * The path to a Dockerfile relative to the root of the repo. If set, overrides usage of buildpacks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#dockerfile_path App#dockerfile_path}
    */
    readonly dockerfilePath?: string;
    /**
    * An environment slug describing the type of this app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#environment_slug App#environment_slug}
    */
    readonly environmentSlug?: string;
    /**
    * The internal port on which this service's run command will listen.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#http_port App#http_port}
    */
    readonly httpPort?: number;
    /**
    * The amount of instances that this component should be scaled to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#instance_count App#instance_count}
    */
    readonly instanceCount?: number;
    /**
    * The instance size to use for this component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#instance_size_slug App#instance_size_slug}
    */
    readonly instanceSizeSlug?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#internal_ports App#internal_ports}
    */
    readonly internalPorts?: number[];
    /**
    * The name of the component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * An optional run command to override the component's default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#run_command App#run_command}
    */
    readonly runCommand?: string;
    /**
    * An optional path to the working directory to use for the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#source_dir App#source_dir}
    */
    readonly sourceDir?: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#alert App#alert}
    */
    readonly alert?: AppSpecServiceAlert[] | cdktn.IResolvable;
    /**
    * autoscaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#autoscaling App#autoscaling}
    */
    readonly autoscaling?: AppSpecServiceAutoscaling;
    /**
    * bitbucket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#bitbucket App#bitbucket}
    */
    readonly bitbucket?: AppSpecServiceBitbucket;
    /**
    * cors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cors App#cors}
    */
    readonly cors?: AppSpecServiceCors;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#env App#env}
    */
    readonly env?: AppSpecServiceEnv[] | cdktn.IResolvable;
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#git App#git}
    */
    readonly git?: AppSpecServiceGit;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#github App#github}
    */
    readonly github?: AppSpecServiceGithub;
    /**
    * gitlab block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#gitlab App#gitlab}
    */
    readonly gitlab?: AppSpecServiceGitlab;
    /**
    * health_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#health_check App#health_check}
    */
    readonly healthCheck?: AppSpecServiceHealthCheck;
    /**
    * image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#image App#image}
    */
    readonly image?: AppSpecServiceImage;
    /**
    * log_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#log_destination App#log_destination}
    */
    readonly logDestination?: AppSpecServiceLogDestination[] | cdktn.IResolvable;
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#routes App#routes}
    */
    readonly routes?: AppSpecServiceRoutes[] | cdktn.IResolvable;
    /**
    * termination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#termination App#termination}
    */
    readonly termination?: AppSpecServiceTermination;
}
export declare function appSpecServiceToTerraform(struct?: AppSpecService | cdktn.IResolvable): any;
export declare function appSpecServiceToHclTerraform(struct?: AppSpecService | cdktn.IResolvable): any;
export declare class AppSpecServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecService | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecService | cdktn.IResolvable | undefined);
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _dockerfilePath?;
    get dockerfilePath(): string;
    set dockerfilePath(value: string);
    resetDockerfilePath(): void;
    get dockerfilePathInput(): string | undefined;
    private _environmentSlug?;
    get environmentSlug(): string;
    set environmentSlug(value: string);
    resetEnvironmentSlug(): void;
    get environmentSlugInput(): string | undefined;
    private _httpPort?;
    get httpPort(): number;
    set httpPort(value: number);
    resetHttpPort(): void;
    get httpPortInput(): number | undefined;
    private _instanceCount?;
    get instanceCount(): number;
    set instanceCount(value: number);
    resetInstanceCount(): void;
    get instanceCountInput(): number | undefined;
    private _instanceSizeSlug?;
    get instanceSizeSlug(): string;
    set instanceSizeSlug(value: string);
    resetInstanceSizeSlug(): void;
    get instanceSizeSlugInput(): string | undefined;
    private _internalPorts?;
    get internalPorts(): number[];
    set internalPorts(value: number[]);
    resetInternalPorts(): void;
    get internalPortsInput(): number[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _runCommand?;
    get runCommand(): string;
    set runCommand(value: string);
    resetRunCommand(): void;
    get runCommandInput(): string | undefined;
    private _sourceDir?;
    get sourceDir(): string;
    set sourceDir(value: string);
    resetSourceDir(): void;
    get sourceDirInput(): string | undefined;
    private _alert;
    get alert(): AppSpecServiceAlertList;
    putAlert(value: AppSpecServiceAlert[] | cdktn.IResolvable): void;
    resetAlert(): void;
    get alertInput(): cdktn.IResolvable | AppSpecServiceAlert[] | undefined;
    private _autoscaling;
    get autoscaling(): AppSpecServiceAutoscalingOutputReference;
    putAutoscaling(value: AppSpecServiceAutoscaling): void;
    resetAutoscaling(): void;
    get autoscalingInput(): AppSpecServiceAutoscaling | undefined;
    private _bitbucket;
    get bitbucket(): AppSpecServiceBitbucketOutputReference;
    putBitbucket(value: AppSpecServiceBitbucket): void;
    resetBitbucket(): void;
    get bitbucketInput(): AppSpecServiceBitbucket | undefined;
    private _cors;
    get cors(): AppSpecServiceCorsOutputReference;
    putCors(value: AppSpecServiceCors): void;
    resetCors(): void;
    get corsInput(): AppSpecServiceCors | undefined;
    private _env;
    get env(): AppSpecServiceEnvList;
    putEnv(value: AppSpecServiceEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | AppSpecServiceEnv[] | undefined;
    private _git;
    get git(): AppSpecServiceGitOutputReference;
    putGit(value: AppSpecServiceGit): void;
    resetGit(): void;
    get gitInput(): AppSpecServiceGit | undefined;
    private _github;
    get github(): AppSpecServiceGithubOutputReference;
    putGithub(value: AppSpecServiceGithub): void;
    resetGithub(): void;
    get githubInput(): AppSpecServiceGithub | undefined;
    private _gitlab;
    get gitlab(): AppSpecServiceGitlabOutputReference;
    putGitlab(value: AppSpecServiceGitlab): void;
    resetGitlab(): void;
    get gitlabInput(): AppSpecServiceGitlab | undefined;
    private _healthCheck;
    get healthCheck(): AppSpecServiceHealthCheckOutputReference;
    putHealthCheck(value: AppSpecServiceHealthCheck): void;
    resetHealthCheck(): void;
    get healthCheckInput(): AppSpecServiceHealthCheck | undefined;
    private _image;
    get image(): AppSpecServiceImageOutputReference;
    putImage(value: AppSpecServiceImage): void;
    resetImage(): void;
    get imageInput(): AppSpecServiceImage | undefined;
    private _logDestination;
    get logDestination(): AppSpecServiceLogDestinationList;
    putLogDestination(value: AppSpecServiceLogDestination[] | cdktn.IResolvable): void;
    resetLogDestination(): void;
    get logDestinationInput(): cdktn.IResolvable | AppSpecServiceLogDestination[] | undefined;
    private _routes;
    get routes(): AppSpecServiceRoutesList;
    putRoutes(value: AppSpecServiceRoutes[] | cdktn.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktn.IResolvable | AppSpecServiceRoutes[] | undefined;
    private _termination;
    get termination(): AppSpecServiceTerminationOutputReference;
    putTermination(value: AppSpecServiceTermination): void;
    resetTermination(): void;
    get terminationInput(): AppSpecServiceTermination | undefined;
}
export declare class AppSpecServiceList extends cdktn.ComplexList {
    internalValue?: AppSpecService[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecServiceOutputReference;
}
export interface AppSpecStaticSiteBitbucket {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecStaticSiteBitbucketToTerraform(struct?: AppSpecStaticSiteBitbucketOutputReference | AppSpecStaticSiteBitbucket): any;
export declare function appSpecStaticSiteBitbucketToHclTerraform(struct?: AppSpecStaticSiteBitbucketOutputReference | AppSpecStaticSiteBitbucket): any;
export declare class AppSpecStaticSiteBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecStaticSiteBitbucket | undefined;
    set internalValue(value: AppSpecStaticSiteBitbucket | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecStaticSiteCorsAllowOrigins {
    /**
    * Exact string match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#exact App#exact}
    */
    readonly exact?: string;
    /**
    * Prefix-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#prefix App#prefix}
    */
    readonly prefix?: string;
    /**
    * RE2 style regex-based match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#regex App#regex}
    */
    readonly regex?: string;
}
export declare function appSpecStaticSiteCorsAllowOriginsToTerraform(struct?: AppSpecStaticSiteCorsAllowOriginsOutputReference | AppSpecStaticSiteCorsAllowOrigins): any;
export declare function appSpecStaticSiteCorsAllowOriginsToHclTerraform(struct?: AppSpecStaticSiteCorsAllowOriginsOutputReference | AppSpecStaticSiteCorsAllowOrigins): any;
export declare class AppSpecStaticSiteCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecStaticSiteCorsAllowOrigins | undefined;
    set internalValue(value: AppSpecStaticSiteCorsAllowOrigins | undefined);
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
}
export interface AppSpecStaticSiteCors {
    /**
    * Whether browsers should expose the response to the client-side JavaScript code when the request’s credentials mode is `include`. This configures the Access-Control-Allow-Credentials header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_credentials App#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * The set of allowed HTTP request headers. This configures the Access-Control-Allow-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_headers App#allow_headers}
    */
    readonly allowHeaders?: string[];
    /**
    * The set of allowed HTTP methods. This configures the Access-Control-Allow-Methods header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_methods App#allow_methods}
    */
    readonly allowMethods?: string[];
    /**
    * The set of HTTP response headers that browsers are allowed to access. This configures the Access-Control-Expose-Headers header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#expose_headers App#expose_headers}
    */
    readonly exposeHeaders?: string[];
    /**
    * An optional duration specifying how long browsers can cache the results of a preflight request. This configures the Access-Control-Max-Age header. Example: `5h30m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#max_age App#max_age}
    */
    readonly maxAge?: string;
    /**
    * allow_origins block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#allow_origins App#allow_origins}
    */
    readonly allowOrigins?: AppSpecStaticSiteCorsAllowOrigins;
}
export declare function appSpecStaticSiteCorsToTerraform(struct?: AppSpecStaticSiteCorsOutputReference | AppSpecStaticSiteCors): any;
export declare function appSpecStaticSiteCorsToHclTerraform(struct?: AppSpecStaticSiteCorsOutputReference | AppSpecStaticSiteCors): any;
export declare class AppSpecStaticSiteCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecStaticSiteCors | undefined;
    set internalValue(value: AppSpecStaticSiteCors | undefined);
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowHeaders?;
    get allowHeaders(): string[];
    set allowHeaders(value: string[]);
    resetAllowHeaders(): void;
    get allowHeadersInput(): string[] | undefined;
    private _allowMethods?;
    get allowMethods(): string[];
    set allowMethods(value: string[]);
    resetAllowMethods(): void;
    get allowMethodsInput(): string[] | undefined;
    private _exposeHeaders?;
    get exposeHeaders(): string[];
    set exposeHeaders(value: string[]);
    resetExposeHeaders(): void;
    get exposeHeadersInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): string;
    set maxAge(value: string);
    resetMaxAge(): void;
    get maxAgeInput(): string | undefined;
    private _allowOrigins;
    get allowOrigins(): AppSpecStaticSiteCorsAllowOriginsOutputReference;
    putAllowOrigins(value: AppSpecStaticSiteCorsAllowOrigins): void;
    resetAllowOrigins(): void;
    get allowOriginsInput(): AppSpecStaticSiteCorsAllowOrigins | undefined;
}
export interface AppSpecStaticSiteEnv {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * The visibility scope of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scope App#scope}
    */
    readonly scope?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecStaticSiteEnvToTerraform(struct?: AppSpecStaticSiteEnv | cdktn.IResolvable): any;
export declare function appSpecStaticSiteEnvToHclTerraform(struct?: AppSpecStaticSiteEnv | cdktn.IResolvable): any;
export declare class AppSpecStaticSiteEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecStaticSiteEnv | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecStaticSiteEnv | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppSpecStaticSiteEnvList extends cdktn.ComplexList {
    internalValue?: AppSpecStaticSiteEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecStaticSiteEnvOutputReference;
}
export interface AppSpecStaticSiteGit {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * The clone URL of the repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo_clone_url App#repo_clone_url}
    */
    readonly repoCloneUrl?: string;
}
export declare function appSpecStaticSiteGitToTerraform(struct?: AppSpecStaticSiteGitOutputReference | AppSpecStaticSiteGit): any;
export declare function appSpecStaticSiteGitToHclTerraform(struct?: AppSpecStaticSiteGitOutputReference | AppSpecStaticSiteGit): any;
export declare class AppSpecStaticSiteGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecStaticSiteGit | undefined;
    set internalValue(value: AppSpecStaticSiteGit | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _repoCloneUrl?;
    get repoCloneUrl(): string;
    set repoCloneUrl(value: string);
    resetRepoCloneUrl(): void;
    get repoCloneUrlInput(): string | undefined;
}
export interface AppSpecStaticSiteGithub {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecStaticSiteGithubToTerraform(struct?: AppSpecStaticSiteGithubOutputReference | AppSpecStaticSiteGithub): any;
export declare function appSpecStaticSiteGithubToHclTerraform(struct?: AppSpecStaticSiteGithubOutputReference | AppSpecStaticSiteGithub): any;
export declare class AppSpecStaticSiteGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecStaticSiteGithub | undefined;
    set internalValue(value: AppSpecStaticSiteGithub | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecStaticSiteGitlab {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecStaticSiteGitlabToTerraform(struct?: AppSpecStaticSiteGitlabOutputReference | AppSpecStaticSiteGitlab): any;
export declare function appSpecStaticSiteGitlabToHclTerraform(struct?: AppSpecStaticSiteGitlabOutputReference | AppSpecStaticSiteGitlab): any;
export declare class AppSpecStaticSiteGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecStaticSiteGitlab | undefined;
    set internalValue(value: AppSpecStaticSiteGitlab | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecStaticSiteRoutes {
    /**
    * Path specifies an route by HTTP path prefix. Paths must start with / and must be unique within the app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#path App#path}
    */
    readonly path?: string;
    /**
    *  An optional flag to preserve the path that is forwarded to the backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#preserve_path_prefix App#preserve_path_prefix}
    */
    readonly preservePathPrefix?: boolean | cdktn.IResolvable;
}
export declare function appSpecStaticSiteRoutesToTerraform(struct?: AppSpecStaticSiteRoutes | cdktn.IResolvable): any;
export declare function appSpecStaticSiteRoutesToHclTerraform(struct?: AppSpecStaticSiteRoutes | cdktn.IResolvable): any;
export declare class AppSpecStaticSiteRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecStaticSiteRoutes | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecStaticSiteRoutes | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _preservePathPrefix?;
    get preservePathPrefix(): boolean | cdktn.IResolvable;
    set preservePathPrefix(value: boolean | cdktn.IResolvable);
    resetPreservePathPrefix(): void;
    get preservePathPrefixInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppSpecStaticSiteRoutesList extends cdktn.ComplexList {
    internalValue?: AppSpecStaticSiteRoutes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecStaticSiteRoutesOutputReference;
}
export interface AppSpecStaticSite {
    /**
    * An optional build command to run while building this component from source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#build_command App#build_command}
    */
    readonly buildCommand?: string;
    /**
    * The name of the document to use as the fallback for any requests to documents that are not found when serving this static site.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#catchall_document App#catchall_document}
    */
    readonly catchallDocument?: string;
    /**
    * The path to a Dockerfile relative to the root of the repo. If set, overrides usage of buildpacks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#dockerfile_path App#dockerfile_path}
    */
    readonly dockerfilePath?: string;
    /**
    * An environment slug describing the type of this app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#environment_slug App#environment_slug}
    */
    readonly environmentSlug?: string;
    /**
    * The name of the error document to use when serving this static site.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#error_document App#error_document}
    */
    readonly errorDocument?: string;
    /**
    * The name of the index document to use when serving this static site.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#index_document App#index_document}
    */
    readonly indexDocument?: string;
    /**
    * The name of the component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * An optional path to where the built assets will be located, relative to the build context. If not set, App Platform will automatically scan for these directory names: `_static`, `dist`, `public`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#output_dir App#output_dir}
    */
    readonly outputDir?: string;
    /**
    * An optional path to the working directory to use for the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#source_dir App#source_dir}
    */
    readonly sourceDir?: string;
    /**
    * bitbucket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#bitbucket App#bitbucket}
    */
    readonly bitbucket?: AppSpecStaticSiteBitbucket;
    /**
    * cors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cors App#cors}
    */
    readonly cors?: AppSpecStaticSiteCors;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#env App#env}
    */
    readonly env?: AppSpecStaticSiteEnv[] | cdktn.IResolvable;
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#git App#git}
    */
    readonly git?: AppSpecStaticSiteGit;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#github App#github}
    */
    readonly github?: AppSpecStaticSiteGithub;
    /**
    * gitlab block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#gitlab App#gitlab}
    */
    readonly gitlab?: AppSpecStaticSiteGitlab;
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#routes App#routes}
    */
    readonly routes?: AppSpecStaticSiteRoutes[] | cdktn.IResolvable;
}
export declare function appSpecStaticSiteToTerraform(struct?: AppSpecStaticSite | cdktn.IResolvable): any;
export declare function appSpecStaticSiteToHclTerraform(struct?: AppSpecStaticSite | cdktn.IResolvable): any;
export declare class AppSpecStaticSiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecStaticSite | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecStaticSite | cdktn.IResolvable | undefined);
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _catchallDocument?;
    get catchallDocument(): string;
    set catchallDocument(value: string);
    resetCatchallDocument(): void;
    get catchallDocumentInput(): string | undefined;
    private _dockerfilePath?;
    get dockerfilePath(): string;
    set dockerfilePath(value: string);
    resetDockerfilePath(): void;
    get dockerfilePathInput(): string | undefined;
    private _environmentSlug?;
    get environmentSlug(): string;
    set environmentSlug(value: string);
    resetEnvironmentSlug(): void;
    get environmentSlugInput(): string | undefined;
    private _errorDocument?;
    get errorDocument(): string;
    set errorDocument(value: string);
    resetErrorDocument(): void;
    get errorDocumentInput(): string | undefined;
    private _indexDocument?;
    get indexDocument(): string;
    set indexDocument(value: string);
    resetIndexDocument(): void;
    get indexDocumentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputDir?;
    get outputDir(): string;
    set outputDir(value: string);
    resetOutputDir(): void;
    get outputDirInput(): string | undefined;
    private _sourceDir?;
    get sourceDir(): string;
    set sourceDir(value: string);
    resetSourceDir(): void;
    get sourceDirInput(): string | undefined;
    private _bitbucket;
    get bitbucket(): AppSpecStaticSiteBitbucketOutputReference;
    putBitbucket(value: AppSpecStaticSiteBitbucket): void;
    resetBitbucket(): void;
    get bitbucketInput(): AppSpecStaticSiteBitbucket | undefined;
    private _cors;
    get cors(): AppSpecStaticSiteCorsOutputReference;
    putCors(value: AppSpecStaticSiteCors): void;
    resetCors(): void;
    get corsInput(): AppSpecStaticSiteCors | undefined;
    private _env;
    get env(): AppSpecStaticSiteEnvList;
    putEnv(value: AppSpecStaticSiteEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | AppSpecStaticSiteEnv[] | undefined;
    private _git;
    get git(): AppSpecStaticSiteGitOutputReference;
    putGit(value: AppSpecStaticSiteGit): void;
    resetGit(): void;
    get gitInput(): AppSpecStaticSiteGit | undefined;
    private _github;
    get github(): AppSpecStaticSiteGithubOutputReference;
    putGithub(value: AppSpecStaticSiteGithub): void;
    resetGithub(): void;
    get githubInput(): AppSpecStaticSiteGithub | undefined;
    private _gitlab;
    get gitlab(): AppSpecStaticSiteGitlabOutputReference;
    putGitlab(value: AppSpecStaticSiteGitlab): void;
    resetGitlab(): void;
    get gitlabInput(): AppSpecStaticSiteGitlab | undefined;
    private _routes;
    get routes(): AppSpecStaticSiteRoutesList;
    putRoutes(value: AppSpecStaticSiteRoutes[] | cdktn.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktn.IResolvable | AppSpecStaticSiteRoutes[] | undefined;
}
export declare class AppSpecStaticSiteList extends cdktn.ComplexList {
    internalValue?: AppSpecStaticSite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecStaticSiteOutputReference;
}
export interface AppSpecVpc {
    /**
    * The ID of the VPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#id App#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function appSpecVpcToTerraform(struct?: AppSpecVpc | cdktn.IResolvable): any;
export declare function appSpecVpcToHclTerraform(struct?: AppSpecVpc | cdktn.IResolvable): any;
export declare class AppSpecVpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecVpc | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecVpc | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class AppSpecVpcList extends cdktn.ComplexList {
    internalValue?: AppSpecVpc[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecVpcOutputReference;
}
export interface AppSpecWorkerAlertDestinationsSlackWebhooks {
    /**
    * The Slack channel to send notifications to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#channel App#channel}
    */
    readonly channel: string;
    /**
    * The Slack webhook URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appSpecWorkerAlertDestinationsSlackWebhooksToTerraform(struct?: AppSpecWorkerAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare function appSpecWorkerAlertDestinationsSlackWebhooksToHclTerraform(struct?: AppSpecWorkerAlertDestinationsSlackWebhooks | cdktn.IResolvable): any;
export declare class AppSpecWorkerAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecWorkerAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecWorkerAlertDestinationsSlackWebhooks | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AppSpecWorkerAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    internalValue?: AppSpecWorkerAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecWorkerAlertDestinationsSlackWebhooksOutputReference;
}
export interface AppSpecWorkerAlertDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#emails App#emails}
    */
    readonly emails?: string[];
    /**
    * slack_webhooks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#slack_webhooks App#slack_webhooks}
    */
    readonly slackWebhooks?: AppSpecWorkerAlertDestinationsSlackWebhooks[] | cdktn.IResolvable;
}
export declare function appSpecWorkerAlertDestinationsToTerraform(struct?: AppSpecWorkerAlertDestinationsOutputReference | AppSpecWorkerAlertDestinations): any;
export declare function appSpecWorkerAlertDestinationsToHclTerraform(struct?: AppSpecWorkerAlertDestinationsOutputReference | AppSpecWorkerAlertDestinations): any;
export declare class AppSpecWorkerAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerAlertDestinations | undefined;
    set internalValue(value: AppSpecWorkerAlertDestinations | undefined);
    private _emails?;
    get emails(): string[];
    set emails(value: string[]);
    resetEmails(): void;
    get emailsInput(): string[] | undefined;
    private _slackWebhooks;
    get slackWebhooks(): AppSpecWorkerAlertDestinationsSlackWebhooksList;
    putSlackWebhooks(value: AppSpecWorkerAlertDestinationsSlackWebhooks[] | cdktn.IResolvable): void;
    resetSlackWebhooks(): void;
    get slackWebhooksInput(): cdktn.IResolvable | AppSpecWorkerAlertDestinationsSlackWebhooks[] | undefined;
}
export interface AppSpecWorkerAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disabled App#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#operator App#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#rule App#rule}
    */
    readonly rule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#window App#window}
    */
    readonly window: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#destinations App#destinations}
    */
    readonly destinations?: AppSpecWorkerAlertDestinations;
}
export declare function appSpecWorkerAlertToTerraform(struct?: AppSpecWorkerAlert | cdktn.IResolvable): any;
export declare function appSpecWorkerAlertToHclTerraform(struct?: AppSpecWorkerAlert | cdktn.IResolvable): any;
export declare class AppSpecWorkerAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecWorkerAlert | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecWorkerAlert | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
    private _window?;
    get window(): string;
    set window(value: string);
    get windowInput(): string | undefined;
    private _destinations;
    get destinations(): AppSpecWorkerAlertDestinationsOutputReference;
    putDestinations(value: AppSpecWorkerAlertDestinations): void;
    resetDestinations(): void;
    get destinationsInput(): AppSpecWorkerAlertDestinations | undefined;
}
export declare class AppSpecWorkerAlertList extends cdktn.ComplexList {
    internalValue?: AppSpecWorkerAlert[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecWorkerAlertOutputReference;
}
export interface AppSpecWorkerAutoscalingMetricsCpu {
    /**
    * The average target CPU utilization for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#percent App#percent}
    */
    readonly percent: number;
}
export declare function appSpecWorkerAutoscalingMetricsCpuToTerraform(struct?: AppSpecWorkerAutoscalingMetricsCpuOutputReference | AppSpecWorkerAutoscalingMetricsCpu): any;
export declare function appSpecWorkerAutoscalingMetricsCpuToHclTerraform(struct?: AppSpecWorkerAutoscalingMetricsCpuOutputReference | AppSpecWorkerAutoscalingMetricsCpu): any;
export declare class AppSpecWorkerAutoscalingMetricsCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerAutoscalingMetricsCpu | undefined;
    set internalValue(value: AppSpecWorkerAutoscalingMetricsCpu | undefined);
    private _percent?;
    get percent(): number;
    set percent(value: number);
    get percentInput(): number | undefined;
}
export interface AppSpecWorkerAutoscalingMetrics {
    /**
    * cpu block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cpu App#cpu}
    */
    readonly cpu?: AppSpecWorkerAutoscalingMetricsCpu;
}
export declare function appSpecWorkerAutoscalingMetricsToTerraform(struct?: AppSpecWorkerAutoscalingMetricsOutputReference | AppSpecWorkerAutoscalingMetrics): any;
export declare function appSpecWorkerAutoscalingMetricsToHclTerraform(struct?: AppSpecWorkerAutoscalingMetricsOutputReference | AppSpecWorkerAutoscalingMetrics): any;
export declare class AppSpecWorkerAutoscalingMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerAutoscalingMetrics | undefined;
    set internalValue(value: AppSpecWorkerAutoscalingMetrics | undefined);
    private _cpu;
    get cpu(): AppSpecWorkerAutoscalingMetricsCpuOutputReference;
    putCpu(value: AppSpecWorkerAutoscalingMetricsCpu): void;
    resetCpu(): void;
    get cpuInput(): AppSpecWorkerAutoscalingMetricsCpu | undefined;
}
export interface AppSpecWorkerAutoscaling {
    /**
    * The maximum amount of instances for this component. Must be more than min_instance_count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#max_instance_count App#max_instance_count}
    */
    readonly maxInstanceCount: number;
    /**
    * The minimum amount of instances for this component. Must be less than max_instance_count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#min_instance_count App#min_instance_count}
    */
    readonly minInstanceCount: number;
    /**
    * metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#metrics App#metrics}
    */
    readonly metrics: AppSpecWorkerAutoscalingMetrics;
}
export declare function appSpecWorkerAutoscalingToTerraform(struct?: AppSpecWorkerAutoscalingOutputReference | AppSpecWorkerAutoscaling): any;
export declare function appSpecWorkerAutoscalingToHclTerraform(struct?: AppSpecWorkerAutoscalingOutputReference | AppSpecWorkerAutoscaling): any;
export declare class AppSpecWorkerAutoscalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerAutoscaling | undefined;
    set internalValue(value: AppSpecWorkerAutoscaling | undefined);
    private _maxInstanceCount?;
    get maxInstanceCount(): number;
    set maxInstanceCount(value: number);
    get maxInstanceCountInput(): number | undefined;
    private _minInstanceCount?;
    get minInstanceCount(): number;
    set minInstanceCount(value: number);
    get minInstanceCountInput(): number | undefined;
    private _metrics;
    get metrics(): AppSpecWorkerAutoscalingMetricsOutputReference;
    putMetrics(value: AppSpecWorkerAutoscalingMetrics): void;
    get metricsInput(): AppSpecWorkerAutoscalingMetrics | undefined;
}
export interface AppSpecWorkerBitbucket {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecWorkerBitbucketToTerraform(struct?: AppSpecWorkerBitbucketOutputReference | AppSpecWorkerBitbucket): any;
export declare function appSpecWorkerBitbucketToHclTerraform(struct?: AppSpecWorkerBitbucketOutputReference | AppSpecWorkerBitbucket): any;
export declare class AppSpecWorkerBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerBitbucket | undefined;
    set internalValue(value: AppSpecWorkerBitbucket | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecWorkerEnv {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#key App#key}
    */
    readonly key?: string;
    /**
    * The visibility scope of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#scope App#scope}
    */
    readonly scope?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#type App#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
}
export declare function appSpecWorkerEnvToTerraform(struct?: AppSpecWorkerEnv | cdktn.IResolvable): any;
export declare function appSpecWorkerEnvToHclTerraform(struct?: AppSpecWorkerEnv | cdktn.IResolvable): any;
export declare class AppSpecWorkerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecWorkerEnv | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecWorkerEnv | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppSpecWorkerEnvList extends cdktn.ComplexList {
    internalValue?: AppSpecWorkerEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecWorkerEnvOutputReference;
}
export interface AppSpecWorkerGit {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * The clone URL of the repo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo_clone_url App#repo_clone_url}
    */
    readonly repoCloneUrl?: string;
}
export declare function appSpecWorkerGitToTerraform(struct?: AppSpecWorkerGitOutputReference | AppSpecWorkerGit): any;
export declare function appSpecWorkerGitToHclTerraform(struct?: AppSpecWorkerGitOutputReference | AppSpecWorkerGit): any;
export declare class AppSpecWorkerGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerGit | undefined;
    set internalValue(value: AppSpecWorkerGit | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _repoCloneUrl?;
    get repoCloneUrl(): string;
    set repoCloneUrl(value: string);
    resetRepoCloneUrl(): void;
    get repoCloneUrlInput(): string | undefined;
}
export interface AppSpecWorkerGithub {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecWorkerGithubToTerraform(struct?: AppSpecWorkerGithubOutputReference | AppSpecWorkerGithub): any;
export declare function appSpecWorkerGithubToHclTerraform(struct?: AppSpecWorkerGithubOutputReference | AppSpecWorkerGithub): any;
export declare class AppSpecWorkerGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerGithub | undefined;
    set internalValue(value: AppSpecWorkerGithub | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecWorkerGitlab {
    /**
    * The name of the branch to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Whether to automatically deploy new commits made to the repo
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: boolean | cdktn.IResolvable;
    /**
    * The name of the repo in the format `owner/repo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repo App#repo}
    */
    readonly repo?: string;
}
export declare function appSpecWorkerGitlabToTerraform(struct?: AppSpecWorkerGitlabOutputReference | AppSpecWorkerGitlab): any;
export declare function appSpecWorkerGitlabToHclTerraform(struct?: AppSpecWorkerGitlabOutputReference | AppSpecWorkerGitlab): any;
export declare class AppSpecWorkerGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerGitlab | undefined;
    set internalValue(value: AppSpecWorkerGitlab | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _deployOnPush?;
    get deployOnPush(): boolean | cdktn.IResolvable;
    set deployOnPush(value: boolean | cdktn.IResolvable);
    resetDeployOnPush(): void;
    get deployOnPushInput(): boolean | cdktn.IResolvable | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface AppSpecWorkerImageDeployOnPush {
    /**
    * Whether to automatically deploy images pushed to DOCR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#enabled App#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function appSpecWorkerImageDeployOnPushToTerraform(struct?: AppSpecWorkerImageDeployOnPush | cdktn.IResolvable): any;
export declare function appSpecWorkerImageDeployOnPushToHclTerraform(struct?: AppSpecWorkerImageDeployOnPush | cdktn.IResolvable): any;
export declare class AppSpecWorkerImageDeployOnPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecWorkerImageDeployOnPush | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecWorkerImageDeployOnPush | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppSpecWorkerImageDeployOnPushList extends cdktn.ComplexList {
    internalValue?: AppSpecWorkerImageDeployOnPush[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecWorkerImageDeployOnPushOutputReference;
}
export interface AppSpecWorkerImage {
    /**
    * The image digest. Cannot be specified if tag is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#digest App#digest}
    */
    readonly digest?: string;
    /**
    * The registry name. Must be left empty for the DOCR registry type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry App#registry}
    */
    readonly registry?: string;
    /**
    * Access credentials for third-party registries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry_credentials App#registry_credentials}
    */
    readonly registryCredentials?: string;
    /**
    * The registry type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#registry_type App#registry_type}
    */
    readonly registryType: string;
    /**
    * The repository name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#repository App#repository}
    */
    readonly repository: string;
    /**
    * The repository tag. Defaults to latest if not provided. Cannot be specified if digest is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#tag App#tag}
    */
    readonly tag?: string;
    /**
    * deploy_on_push block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#deploy_on_push App#deploy_on_push}
    */
    readonly deployOnPush?: AppSpecWorkerImageDeployOnPush[] | cdktn.IResolvable;
}
export declare function appSpecWorkerImageToTerraform(struct?: AppSpecWorkerImageOutputReference | AppSpecWorkerImage): any;
export declare function appSpecWorkerImageToHclTerraform(struct?: AppSpecWorkerImageOutputReference | AppSpecWorkerImage): any;
export declare class AppSpecWorkerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerImage | undefined;
    set internalValue(value: AppSpecWorkerImage | undefined);
    private _digest?;
    get digest(): string;
    set digest(value: string);
    resetDigest(): void;
    get digestInput(): string | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    resetRegistry(): void;
    get registryInput(): string | undefined;
    private _registryCredentials?;
    get registryCredentials(): string;
    set registryCredentials(value: string);
    resetRegistryCredentials(): void;
    get registryCredentialsInput(): string | undefined;
    private _registryType?;
    get registryType(): string;
    set registryType(value: string);
    get registryTypeInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _deployOnPush;
    get deployOnPush(): AppSpecWorkerImageDeployOnPushList;
    putDeployOnPush(value: AppSpecWorkerImageDeployOnPush[] | cdktn.IResolvable): void;
    resetDeployOnPush(): void;
    get deployOnPushInput(): cdktn.IResolvable | AppSpecWorkerImageDeployOnPush[] | undefined;
}
export interface AppSpecWorkerLogDestinationDatadog {
    /**
    * Datadog API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#api_key App#api_key}
    */
    readonly apiKey: string;
    /**
    * Datadog HTTP log intake endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appSpecWorkerLogDestinationDatadogToTerraform(struct?: AppSpecWorkerLogDestinationDatadogOutputReference | AppSpecWorkerLogDestinationDatadog): any;
export declare function appSpecWorkerLogDestinationDatadogToHclTerraform(struct?: AppSpecWorkerLogDestinationDatadogOutputReference | AppSpecWorkerLogDestinationDatadog): any;
export declare class AppSpecWorkerLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerLogDestinationDatadog | undefined;
    set internalValue(value: AppSpecWorkerLogDestinationDatadog | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppSpecWorkerLogDestinationLogtail {
    /**
    * Logtail token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#token App#token}
    */
    readonly token: string;
}
export declare function appSpecWorkerLogDestinationLogtailToTerraform(struct?: AppSpecWorkerLogDestinationLogtailOutputReference | AppSpecWorkerLogDestinationLogtail): any;
export declare function appSpecWorkerLogDestinationLogtailToHclTerraform(struct?: AppSpecWorkerLogDestinationLogtailOutputReference | AppSpecWorkerLogDestinationLogtail): any;
export declare class AppSpecWorkerLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerLogDestinationLogtail | undefined;
    set internalValue(value: AppSpecWorkerLogDestinationLogtail | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface AppSpecWorkerLogDestinationOpenSearchBasicAuth {
    /**
    * Password for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#password App#password}
    */
    readonly password?: string;
    /**
    * user for basic authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#user App#user}
    */
    readonly user?: string;
}
export declare function appSpecWorkerLogDestinationOpenSearchBasicAuthToTerraform(struct?: AppSpecWorkerLogDestinationOpenSearchBasicAuthOutputReference | AppSpecWorkerLogDestinationOpenSearchBasicAuth): any;
export declare function appSpecWorkerLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: AppSpecWorkerLogDestinationOpenSearchBasicAuthOutputReference | AppSpecWorkerLogDestinationOpenSearchBasicAuth): any;
export declare class AppSpecWorkerLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: AppSpecWorkerLogDestinationOpenSearchBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface AppSpecWorkerLogDestinationOpenSearch {
    /**
    * OpenSearch cluster name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#cluster_name App#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * OpenSearch endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint?: string;
    /**
    * OpenSearch index name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#index_name App#index_name}
    */
    readonly indexName?: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#basic_auth App#basic_auth}
    */
    readonly basicAuth: AppSpecWorkerLogDestinationOpenSearchBasicAuth;
}
export declare function appSpecWorkerLogDestinationOpenSearchToTerraform(struct?: AppSpecWorkerLogDestinationOpenSearchOutputReference | AppSpecWorkerLogDestinationOpenSearch): any;
export declare function appSpecWorkerLogDestinationOpenSearchToHclTerraform(struct?: AppSpecWorkerLogDestinationOpenSearchOutputReference | AppSpecWorkerLogDestinationOpenSearch): any;
export declare class AppSpecWorkerLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerLogDestinationOpenSearch | undefined;
    set internalValue(value: AppSpecWorkerLogDestinationOpenSearch | undefined);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    resetIndexName(): void;
    get indexNameInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): AppSpecWorkerLogDestinationOpenSearchBasicAuthOutputReference;
    putBasicAuth(value: AppSpecWorkerLogDestinationOpenSearchBasicAuth): void;
    get basicAuthInput(): AppSpecWorkerLogDestinationOpenSearchBasicAuth | undefined;
}
export interface AppSpecWorkerLogDestinationPapertrail {
    /**
    * Papertrail syslog endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#endpoint App#endpoint}
    */
    readonly endpoint: string;
}
export declare function appSpecWorkerLogDestinationPapertrailToTerraform(struct?: AppSpecWorkerLogDestinationPapertrailOutputReference | AppSpecWorkerLogDestinationPapertrail): any;
export declare function appSpecWorkerLogDestinationPapertrailToHclTerraform(struct?: AppSpecWorkerLogDestinationPapertrailOutputReference | AppSpecWorkerLogDestinationPapertrail): any;
export declare class AppSpecWorkerLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerLogDestinationPapertrail | undefined;
    set internalValue(value: AppSpecWorkerLogDestinationPapertrail | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
}
export interface AppSpecWorkerLogDestination {
    /**
    * Name of the log destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#datadog App#datadog}
    */
    readonly datadog?: AppSpecWorkerLogDestinationDatadog;
    /**
    * logtail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#logtail App#logtail}
    */
    readonly logtail?: AppSpecWorkerLogDestinationLogtail;
    /**
    * open_search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#open_search App#open_search}
    */
    readonly openSearch?: AppSpecWorkerLogDestinationOpenSearch;
    /**
    * papertrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#papertrail App#papertrail}
    */
    readonly papertrail?: AppSpecWorkerLogDestinationPapertrail;
}
export declare function appSpecWorkerLogDestinationToTerraform(struct?: AppSpecWorkerLogDestination | cdktn.IResolvable): any;
export declare function appSpecWorkerLogDestinationToHclTerraform(struct?: AppSpecWorkerLogDestination | cdktn.IResolvable): any;
export declare class AppSpecWorkerLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecWorkerLogDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecWorkerLogDestination | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _datadog;
    get datadog(): AppSpecWorkerLogDestinationDatadogOutputReference;
    putDatadog(value: AppSpecWorkerLogDestinationDatadog): void;
    resetDatadog(): void;
    get datadogInput(): AppSpecWorkerLogDestinationDatadog | undefined;
    private _logtail;
    get logtail(): AppSpecWorkerLogDestinationLogtailOutputReference;
    putLogtail(value: AppSpecWorkerLogDestinationLogtail): void;
    resetLogtail(): void;
    get logtailInput(): AppSpecWorkerLogDestinationLogtail | undefined;
    private _openSearch;
    get openSearch(): AppSpecWorkerLogDestinationOpenSearchOutputReference;
    putOpenSearch(value: AppSpecWorkerLogDestinationOpenSearch): void;
    resetOpenSearch(): void;
    get openSearchInput(): AppSpecWorkerLogDestinationOpenSearch | undefined;
    private _papertrail;
    get papertrail(): AppSpecWorkerLogDestinationPapertrailOutputReference;
    putPapertrail(value: AppSpecWorkerLogDestinationPapertrail): void;
    resetPapertrail(): void;
    get papertrailInput(): AppSpecWorkerLogDestinationPapertrail | undefined;
}
export declare class AppSpecWorkerLogDestinationList extends cdktn.ComplexList {
    internalValue?: AppSpecWorkerLogDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecWorkerLogDestinationOutputReference;
}
export interface AppSpecWorkerTermination {
    /**
    * The number of seconds to wait between sending a TERM signal to a container and issuing a KILL which causes immediate shutdown. Default: 120, Minimum 1, Maximum 600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#grace_period_seconds App#grace_period_seconds}
    */
    readonly gracePeriodSeconds?: number;
}
export declare function appSpecWorkerTerminationToTerraform(struct?: AppSpecWorkerTerminationOutputReference | AppSpecWorkerTermination): any;
export declare function appSpecWorkerTerminationToHclTerraform(struct?: AppSpecWorkerTerminationOutputReference | AppSpecWorkerTermination): any;
export declare class AppSpecWorkerTerminationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpecWorkerTermination | undefined;
    set internalValue(value: AppSpecWorkerTermination | undefined);
    private _gracePeriodSeconds?;
    get gracePeriodSeconds(): number;
    set gracePeriodSeconds(value: number);
    resetGracePeriodSeconds(): void;
    get gracePeriodSecondsInput(): number | undefined;
}
export interface AppSpecWorker {
    /**
    * An optional build command to run while building this component from source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#build_command App#build_command}
    */
    readonly buildCommand?: string;
    /**
    * The path to a Dockerfile relative to the root of the repo. If set, overrides usage of buildpacks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#dockerfile_path App#dockerfile_path}
    */
    readonly dockerfilePath?: string;
    /**
    * An environment slug describing the type of this app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#environment_slug App#environment_slug}
    */
    readonly environmentSlug?: string;
    /**
    * The amount of instances that this component should be scaled to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#instance_count App#instance_count}
    */
    readonly instanceCount?: number;
    /**
    * The instance size to use for this component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#instance_size_slug App#instance_size_slug}
    */
    readonly instanceSizeSlug?: string;
    /**
    * The name of the component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * An optional run command to override the component's default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#run_command App#run_command}
    */
    readonly runCommand?: string;
    /**
    * An optional path to the working directory to use for the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#source_dir App#source_dir}
    */
    readonly sourceDir?: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#alert App#alert}
    */
    readonly alert?: AppSpecWorkerAlert[] | cdktn.IResolvable;
    /**
    * autoscaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#autoscaling App#autoscaling}
    */
    readonly autoscaling?: AppSpecWorkerAutoscaling;
    /**
    * bitbucket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#bitbucket App#bitbucket}
    */
    readonly bitbucket?: AppSpecWorkerBitbucket;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#env App#env}
    */
    readonly env?: AppSpecWorkerEnv[] | cdktn.IResolvable;
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#git App#git}
    */
    readonly git?: AppSpecWorkerGit;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#github App#github}
    */
    readonly github?: AppSpecWorkerGithub;
    /**
    * gitlab block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#gitlab App#gitlab}
    */
    readonly gitlab?: AppSpecWorkerGitlab;
    /**
    * image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#image App#image}
    */
    readonly image?: AppSpecWorkerImage;
    /**
    * log_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#log_destination App#log_destination}
    */
    readonly logDestination?: AppSpecWorkerLogDestination[] | cdktn.IResolvable;
    /**
    * termination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#termination App#termination}
    */
    readonly termination?: AppSpecWorkerTermination;
}
export declare function appSpecWorkerToTerraform(struct?: AppSpecWorker | cdktn.IResolvable): any;
export declare function appSpecWorkerToHclTerraform(struct?: AppSpecWorker | cdktn.IResolvable): any;
export declare class AppSpecWorkerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpecWorker | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpecWorker | cdktn.IResolvable | undefined);
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _dockerfilePath?;
    get dockerfilePath(): string;
    set dockerfilePath(value: string);
    resetDockerfilePath(): void;
    get dockerfilePathInput(): string | undefined;
    private _environmentSlug?;
    get environmentSlug(): string;
    set environmentSlug(value: string);
    resetEnvironmentSlug(): void;
    get environmentSlugInput(): string | undefined;
    private _instanceCount?;
    get instanceCount(): number;
    set instanceCount(value: number);
    resetInstanceCount(): void;
    get instanceCountInput(): number | undefined;
    private _instanceSizeSlug?;
    get instanceSizeSlug(): string;
    set instanceSizeSlug(value: string);
    resetInstanceSizeSlug(): void;
    get instanceSizeSlugInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _runCommand?;
    get runCommand(): string;
    set runCommand(value: string);
    resetRunCommand(): void;
    get runCommandInput(): string | undefined;
    private _sourceDir?;
    get sourceDir(): string;
    set sourceDir(value: string);
    resetSourceDir(): void;
    get sourceDirInput(): string | undefined;
    private _alert;
    get alert(): AppSpecWorkerAlertList;
    putAlert(value: AppSpecWorkerAlert[] | cdktn.IResolvable): void;
    resetAlert(): void;
    get alertInput(): cdktn.IResolvable | AppSpecWorkerAlert[] | undefined;
    private _autoscaling;
    get autoscaling(): AppSpecWorkerAutoscalingOutputReference;
    putAutoscaling(value: AppSpecWorkerAutoscaling): void;
    resetAutoscaling(): void;
    get autoscalingInput(): AppSpecWorkerAutoscaling | undefined;
    private _bitbucket;
    get bitbucket(): AppSpecWorkerBitbucketOutputReference;
    putBitbucket(value: AppSpecWorkerBitbucket): void;
    resetBitbucket(): void;
    get bitbucketInput(): AppSpecWorkerBitbucket | undefined;
    private _env;
    get env(): AppSpecWorkerEnvList;
    putEnv(value: AppSpecWorkerEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | AppSpecWorkerEnv[] | undefined;
    private _git;
    get git(): AppSpecWorkerGitOutputReference;
    putGit(value: AppSpecWorkerGit): void;
    resetGit(): void;
    get gitInput(): AppSpecWorkerGit | undefined;
    private _github;
    get github(): AppSpecWorkerGithubOutputReference;
    putGithub(value: AppSpecWorkerGithub): void;
    resetGithub(): void;
    get githubInput(): AppSpecWorkerGithub | undefined;
    private _gitlab;
    get gitlab(): AppSpecWorkerGitlabOutputReference;
    putGitlab(value: AppSpecWorkerGitlab): void;
    resetGitlab(): void;
    get gitlabInput(): AppSpecWorkerGitlab | undefined;
    private _image;
    get image(): AppSpecWorkerImageOutputReference;
    putImage(value: AppSpecWorkerImage): void;
    resetImage(): void;
    get imageInput(): AppSpecWorkerImage | undefined;
    private _logDestination;
    get logDestination(): AppSpecWorkerLogDestinationList;
    putLogDestination(value: AppSpecWorkerLogDestination[] | cdktn.IResolvable): void;
    resetLogDestination(): void;
    get logDestinationInput(): cdktn.IResolvable | AppSpecWorkerLogDestination[] | undefined;
    private _termination;
    get termination(): AppSpecWorkerTerminationOutputReference;
    putTermination(value: AppSpecWorkerTermination): void;
    resetTermination(): void;
    get terminationInput(): AppSpecWorkerTermination | undefined;
}
export declare class AppSpecWorkerList extends cdktn.ComplexList {
    internalValue?: AppSpecWorker[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpecWorkerOutputReference;
}
export interface AppSpec {
    /**
    * Whether to disable the edge cache for the app. Default is false, which enables the edge cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disable_edge_cache App#disable_edge_cache}
    */
    readonly disableEdgeCache?: boolean | cdktn.IResolvable;
    /**
    * Email obfuscation configuration for the app. Default is false, which keeps the email obfuscated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#disable_email_obfuscation App#disable_email_obfuscation}
    */
    readonly disableEmailObfuscation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#domains App#domains}
    */
    readonly domains?: string[];
    /**
    * Whether to enable enhanced threat control for the app. Default is false. Set to true to enable enhanced threat control, putting additional security measures for Layer 7 DDoS attacks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#enhanced_threat_control_enabled App#enhanced_threat_control_enabled}
    */
    readonly enhancedThreatControlEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of features which is applied to the app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#features App#features}
    */
    readonly features?: string[];
    /**
    * The name of the app. Must be unique across all apps in the same account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * The slug for the DigitalOcean data center region hosting the app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#region App#region}
    */
    readonly region?: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#alert App#alert}
    */
    readonly alert?: AppSpecAlert[] | cdktn.IResolvable;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#database App#database}
    */
    readonly database?: AppSpecDatabase[] | cdktn.IResolvable;
    /**
    * domain block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#domain App#domain}
    */
    readonly domain?: AppSpecDomain[] | cdktn.IResolvable;
    /**
    * egress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#egress App#egress}
    */
    readonly egress?: AppSpecEgress[] | cdktn.IResolvable;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#env App#env}
    */
    readonly env?: AppSpecEnv[] | cdktn.IResolvable;
    /**
    * function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#function App#function}
    */
    readonly function?: AppSpecFunction[] | cdktn.IResolvable;
    /**
    * ingress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#ingress App#ingress}
    */
    readonly ingress?: AppSpecIngress;
    /**
    * job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#job App#job}
    */
    readonly job?: AppSpecJob[] | cdktn.IResolvable;
    /**
    * maintenance block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#maintenance App#maintenance}
    */
    readonly maintenance?: AppSpecMaintenance;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#service App#service}
    */
    readonly service?: AppSpecService[] | cdktn.IResolvable;
    /**
    * static_site block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#static_site App#static_site}
    */
    readonly staticSite?: AppSpecStaticSite[] | cdktn.IResolvable;
    /**
    * vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#vpc App#vpc}
    */
    readonly vpc?: AppSpecVpc[] | cdktn.IResolvable;
    /**
    * worker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#worker App#worker}
    */
    readonly worker?: AppSpecWorker[] | cdktn.IResolvable;
}
export declare function appSpecToTerraform(struct?: AppSpecOutputReference | AppSpec): any;
export declare function appSpecToHclTerraform(struct?: AppSpecOutputReference | AppSpec): any;
export declare class AppSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpec | undefined;
    set internalValue(value: AppSpec | undefined);
    private _disableEdgeCache?;
    get disableEdgeCache(): boolean | cdktn.IResolvable;
    set disableEdgeCache(value: boolean | cdktn.IResolvable);
    resetDisableEdgeCache(): void;
    get disableEdgeCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _disableEmailObfuscation?;
    get disableEmailObfuscation(): boolean | cdktn.IResolvable;
    set disableEmailObfuscation(value: boolean | cdktn.IResolvable);
    resetDisableEmailObfuscation(): void;
    get disableEmailObfuscationInput(): boolean | cdktn.IResolvable | undefined;
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    resetDomains(): void;
    get domainsInput(): string[] | undefined;
    private _enhancedThreatControlEnabled?;
    get enhancedThreatControlEnabled(): boolean | cdktn.IResolvable;
    set enhancedThreatControlEnabled(value: boolean | cdktn.IResolvable);
    resetEnhancedThreatControlEnabled(): void;
    get enhancedThreatControlEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _features?;
    get features(): string[];
    set features(value: string[]);
    resetFeatures(): void;
    get featuresInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _alert;
    get alert(): AppSpecAlertList;
    putAlert(value: AppSpecAlert[] | cdktn.IResolvable): void;
    resetAlert(): void;
    get alertInput(): cdktn.IResolvable | AppSpecAlert[] | undefined;
    private _database;
    get database(): AppSpecDatabaseList;
    putDatabase(value: AppSpecDatabase[] | cdktn.IResolvable): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | AppSpecDatabase[] | undefined;
    private _domain;
    get domain(): AppSpecDomainList;
    putDomain(value: AppSpecDomain[] | cdktn.IResolvable): void;
    resetDomain(): void;
    get domainInput(): cdktn.IResolvable | AppSpecDomain[] | undefined;
    private _egress;
    get egress(): AppSpecEgressList;
    putEgress(value: AppSpecEgress[] | cdktn.IResolvable): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | AppSpecEgress[] | undefined;
    private _env;
    get env(): AppSpecEnvList;
    putEnv(value: AppSpecEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | AppSpecEnv[] | undefined;
    private _function;
    get function(): AppSpecFunctionList;
    putFunction(value: AppSpecFunction[] | cdktn.IResolvable): void;
    resetFunction(): void;
    get functionInput(): cdktn.IResolvable | AppSpecFunction[] | undefined;
    private _ingress;
    get ingress(): AppSpecIngressOutputReference;
    putIngress(value: AppSpecIngress): void;
    resetIngress(): void;
    get ingressInput(): AppSpecIngress | undefined;
    private _job;
    get job(): AppSpecJobList;
    putJob(value: AppSpecJob[] | cdktn.IResolvable): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | AppSpecJob[] | undefined;
    private _maintenance;
    get maintenance(): AppSpecMaintenanceOutputReference;
    putMaintenance(value: AppSpecMaintenance): void;
    resetMaintenance(): void;
    get maintenanceInput(): AppSpecMaintenance | undefined;
    private _service;
    get service(): AppSpecServiceList;
    putService(value: AppSpecService[] | cdktn.IResolvable): void;
    resetService(): void;
    get serviceInput(): cdktn.IResolvable | AppSpecService[] | undefined;
    private _staticSite;
    get staticSite(): AppSpecStaticSiteList;
    putStaticSite(value: AppSpecStaticSite[] | cdktn.IResolvable): void;
    resetStaticSite(): void;
    get staticSiteInput(): cdktn.IResolvable | AppSpecStaticSite[] | undefined;
    private _vpc;
    get vpc(): AppSpecVpcList;
    putVpc(value: AppSpecVpc[] | cdktn.IResolvable): void;
    resetVpc(): void;
    get vpcInput(): cdktn.IResolvable | AppSpecVpc[] | undefined;
    private _worker;
    get worker(): AppSpecWorkerList;
    putWorker(value: AppSpecWorker[] | cdktn.IResolvable): void;
    resetWorker(): void;
    get workerInput(): cdktn.IResolvable | AppSpecWorker[] | undefined;
}
export interface AppTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#create App#create}
    */
    readonly create?: string;
}
export declare function appTimeoutsToTerraform(struct?: AppTimeouts | cdktn.IResolvable): any;
export declare function appTimeoutsToHclTerraform(struct?: AppTimeouts | cdktn.IResolvable): any;
export declare class AppTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app digitalocean_app}
*/
export declare class App extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_app";
    /**
    * Generates CDKTN code for importing a App resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the App to import
    * @param importFromId The id of the existing App that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the App to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/app digitalocean_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AppConfig);
    get activeDeploymentId(): string;
    get createdAt(): string;
    get defaultIngress(): string;
    private _deploymentPerPage?;
    get deploymentPerPage(): number;
    set deploymentPerPage(value: number);
    resetDeploymentPerPage(): void;
    get deploymentPerPageInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get liveDomain(): string;
    get liveUrl(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get updatedAt(): string;
    get urn(): string;
    private _dedicatedIps;
    get dedicatedIps(): AppDedicatedIpsList;
    putDedicatedIps(value: AppDedicatedIps[] | cdktn.IResolvable): void;
    resetDedicatedIps(): void;
    get dedicatedIpsInput(): cdktn.IResolvable | AppDedicatedIps[] | undefined;
    private _spec;
    get spec(): AppSpecOutputReference;
    putSpec(value: AppSpec): void;
    resetSpec(): void;
    get specInput(): AppSpec | undefined;
    private _timeouts;
    get timeouts(): AppTimeoutsOutputReference;
    putTimeouts(value: AppTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
