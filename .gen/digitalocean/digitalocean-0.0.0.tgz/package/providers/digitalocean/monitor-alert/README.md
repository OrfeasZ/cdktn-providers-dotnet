# `digitalocean_monitor_alert`

Refer to the Terraform Registry for docs: [`digitalocean_monitor_alert`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/monitor_alert).
