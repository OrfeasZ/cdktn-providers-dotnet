# `data_digitalocean_dedicated_inference`

Refer to the Terraform Registry for docs: [`data_digitalocean_dedicated_inference`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/dedicated_inference).
