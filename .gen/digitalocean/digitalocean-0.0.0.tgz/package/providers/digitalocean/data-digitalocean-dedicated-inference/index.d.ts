import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDedicatedInferenceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the dedicated inference endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference#id DataDigitaloceanDedicatedInference#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataDigitaloceanDedicatedInferenceModelDeploymentsAccelerators {
}
export declare function dataDigitaloceanDedicatedInferenceModelDeploymentsAcceleratorsToTerraform(struct?: DataDigitaloceanDedicatedInferenceModelDeploymentsAccelerators): any;
export declare function dataDigitaloceanDedicatedInferenceModelDeploymentsAcceleratorsToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceModelDeploymentsAccelerators): any;
export declare class DataDigitaloceanDedicatedInferenceModelDeploymentsAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceModelDeploymentsAccelerators | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceModelDeploymentsAccelerators | undefined);
    get acceleratorSlug(): string;
    get scale(): number;
    get type(): string;
}
export declare class DataDigitaloceanDedicatedInferenceModelDeploymentsAcceleratorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceModelDeploymentsAcceleratorsOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceModelDeployments {
}
export declare function dataDigitaloceanDedicatedInferenceModelDeploymentsToTerraform(struct?: DataDigitaloceanDedicatedInferenceModelDeployments): any;
export declare function dataDigitaloceanDedicatedInferenceModelDeploymentsToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceModelDeployments): any;
export declare class DataDigitaloceanDedicatedInferenceModelDeploymentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceModelDeployments | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceModelDeployments | undefined);
    private _accelerators;
    get accelerators(): DataDigitaloceanDedicatedInferenceModelDeploymentsAcceleratorsList;
    get modelId(): string;
    get modelProvider(): string;
    get modelSlug(): string;
    get providerModelId(): string;
}
export declare class DataDigitaloceanDedicatedInferenceModelDeploymentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceModelDeploymentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference digitalocean_dedicated_inference}
*/
export declare class DataDigitaloceanDedicatedInference extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_dedicated_inference";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDedicatedInference resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDedicatedInference to import
    * @param importFromId The id of the existing DataDigitaloceanDedicatedInference that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDedicatedInference to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference digitalocean_dedicated_inference} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDedicatedInferenceConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanDedicatedInferenceConfig);
    get createdAt(): string;
    get enablePublicEndpoint(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _modelDeployments;
    get modelDeployments(): DataDigitaloceanDedicatedInferenceModelDeploymentsList;
    get name(): string;
    get privateEndpointFqdn(): string;
    get publicEndpointFqdn(): string;
    get region(): string;
    get status(): string;
    get updatedAt(): string;
    get vpcUuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
