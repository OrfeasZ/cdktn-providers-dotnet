# `data_digitalocean_gradientai_models`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_models`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models).
