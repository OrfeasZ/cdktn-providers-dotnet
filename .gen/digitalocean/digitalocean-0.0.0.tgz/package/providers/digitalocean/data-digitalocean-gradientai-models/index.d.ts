import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiModelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#id DataDigitaloceanGradientaiModels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#filter DataDigitaloceanGradientaiModels#filter}
    */
    readonly filter?: DataDigitaloceanGradientaiModelsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#sort DataDigitaloceanGradientaiModels#sort}
    */
    readonly sort?: DataDigitaloceanGradientaiModelsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiModelsModelsAgreement {
}
export declare function dataDigitaloceanGradientaiModelsModelsAgreementToTerraform(struct?: DataDigitaloceanGradientaiModelsModelsAgreement): any;
export declare function dataDigitaloceanGradientaiModelsModelsAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiModelsModelsAgreement): any;
export declare class DataDigitaloceanGradientaiModelsModelsAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiModelsModelsAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiModelsModelsAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiModelsModelsAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiModelsModelsAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiModelsModelsVersion {
}
export declare function dataDigitaloceanGradientaiModelsModelsVersionToTerraform(struct?: DataDigitaloceanGradientaiModelsModelsVersion): any;
export declare function dataDigitaloceanGradientaiModelsModelsVersionToHclTerraform(struct?: DataDigitaloceanGradientaiModelsModelsVersion): any;
export declare class DataDigitaloceanGradientaiModelsModelsVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiModelsModelsVersion | undefined;
    set internalValue(value: DataDigitaloceanGradientaiModelsModelsVersion | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiModelsModelsVersionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiModelsModelsVersionOutputReference;
}
export interface DataDigitaloceanGradientaiModelsModels {
}
export declare function dataDigitaloceanGradientaiModelsModelsToTerraform(struct?: DataDigitaloceanGradientaiModelsModels): any;
export declare function dataDigitaloceanGradientaiModelsModelsToHclTerraform(struct?: DataDigitaloceanGradientaiModelsModels): any;
export declare class DataDigitaloceanGradientaiModelsModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiModelsModels | undefined;
    set internalValue(value: DataDigitaloceanGradientaiModelsModels | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiModelsModelsAgreementList;
    get createdAt(): string;
    get id(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get uuid(): string;
    private _version;
    get version(): DataDigitaloceanGradientaiModelsModelsVersionList;
}
export declare class DataDigitaloceanGradientaiModelsModelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiModelsModelsOutputReference;
}
export interface DataDigitaloceanGradientaiModelsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#all DataDigitaloceanGradientaiModels#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#key DataDigitaloceanGradientaiModels#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#match_by DataDigitaloceanGradientaiModels#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#values DataDigitaloceanGradientaiModels#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGradientaiModelsFilterToTerraform(struct?: DataDigitaloceanGradientaiModelsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiModelsFilterToHclTerraform(struct?: DataDigitaloceanGradientaiModelsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiModelsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiModelsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiModelsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGradientaiModelsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiModelsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiModelsFilterOutputReference;
}
export interface DataDigitaloceanGradientaiModelsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#direction DataDigitaloceanGradientaiModels#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#key DataDigitaloceanGradientaiModels#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGradientaiModelsSortToTerraform(struct?: DataDigitaloceanGradientaiModelsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiModelsSortToHclTerraform(struct?: DataDigitaloceanGradientaiModelsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiModelsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiModelsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiModelsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiModelsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiModelsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiModelsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models digitalocean_gradientai_models}
*/
export declare class DataDigitaloceanGradientaiModels extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_models";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiModels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiModels to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiModels that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiModels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_models digitalocean_gradientai_models} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiModelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGradientaiModelsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _models;
    get models(): DataDigitaloceanGradientaiModelsModelsList;
    private _filter;
    get filter(): DataDigitaloceanGradientaiModelsFilterList;
    putFilter(value: DataDigitaloceanGradientaiModelsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanGradientaiModelsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGradientaiModelsSortList;
    putSort(value: DataDigitaloceanGradientaiModelsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanGradientaiModelsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
