import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiIndexingJobDataSourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job_data_sources#id DataDigitaloceanGradientaiIndexingJobDataSources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job_data_sources#indexing_job_uuid DataDigitaloceanGradientaiIndexingJobDataSources#indexing_job_uuid}
    */
    readonly indexingJobUuid: string;
}
export interface DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSources {
}
export declare function dataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSourcesToTerraform(struct?: DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSources): any;
export declare function dataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSourcesToHclTerraform(struct?: DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSources): any;
export declare class DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSources | undefined;
    set internalValue(value: DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSources | undefined);
    get completedAt(): string;
    get dataSourceUuid(): string;
    get errorDetails(): string;
    get errorMsg(): string;
    get failedItemCount(): string;
    get indexedFileCount(): string;
    get indexedItemCount(): string;
    get removedItemCount(): string;
    get skippedItemCount(): string;
    get startedAt(): string;
    get status(): string;
    get totalBytes(): string;
    get totalBytesIndexed(): string;
    get totalFileCount(): string;
}
export declare class DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job_data_sources digitalocean_gradientai_indexing_job_data_sources}
*/
export declare class DataDigitaloceanGradientaiIndexingJobDataSources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_indexing_job_data_sources";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiIndexingJobDataSources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiIndexingJobDataSources to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiIndexingJobDataSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job_data_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiIndexingJobDataSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_indexing_job_data_sources digitalocean_gradientai_indexing_job_data_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiIndexingJobDataSourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiIndexingJobDataSourcesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexedDataSources;
    get indexedDataSources(): DataDigitaloceanGradientaiIndexingJobDataSourcesIndexedDataSourcesList;
    private _indexingJobUuid?;
    get indexingJobUuid(): string;
    set indexingJobUuid(value: string);
    get indexingJobUuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
