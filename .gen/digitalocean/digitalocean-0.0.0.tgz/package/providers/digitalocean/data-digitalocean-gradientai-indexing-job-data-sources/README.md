# `data_digitalocean_gradientai_indexing_job_data_sources`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_indexing_job_data_sources`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_indexing_job_data_sources).
