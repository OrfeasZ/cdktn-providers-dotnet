# `digitalocean_database_user`

Refer to the Terraform Registry for docs: [`digitalocean_database_user`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_user).
