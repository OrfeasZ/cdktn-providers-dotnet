import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#cluster_id DatabaseUser#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#id DatabaseUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#mysql_auth_plugin DatabaseUser#mysql_auth_plugin}
    */
    readonly mysqlAuthPlugin?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#name DatabaseUser#name}
    */
    readonly name: string;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#settings DatabaseUser#settings}
    */
    readonly settings?: DatabaseUserSettings[] | cdktn.IResolvable;
}
export interface DatabaseUserSettingsAcl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#permission DatabaseUser#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#topic DatabaseUser#topic}
    */
    readonly topic: string;
}
export declare function databaseUserSettingsAclToTerraform(struct?: DatabaseUserSettingsAcl | cdktn.IResolvable): any;
export declare function databaseUserSettingsAclToHclTerraform(struct?: DatabaseUserSettingsAcl | cdktn.IResolvable): any;
export declare class DatabaseUserSettingsAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseUserSettingsAcl | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseUserSettingsAcl | cdktn.IResolvable | undefined);
    get id(): string;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
}
export declare class DatabaseUserSettingsAclList extends cdktn.ComplexList {
    internalValue?: DatabaseUserSettingsAcl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseUserSettingsAclOutputReference;
}
export interface DatabaseUserSettingsOpensearchAcl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#index DatabaseUser#index}
    */
    readonly index: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#permission DatabaseUser#permission}
    */
    readonly permission: string;
}
export declare function databaseUserSettingsOpensearchAclToTerraform(struct?: DatabaseUserSettingsOpensearchAcl | cdktn.IResolvable): any;
export declare function databaseUserSettingsOpensearchAclToHclTerraform(struct?: DatabaseUserSettingsOpensearchAcl | cdktn.IResolvable): any;
export declare class DatabaseUserSettingsOpensearchAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseUserSettingsOpensearchAcl | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseUserSettingsOpensearchAcl | cdktn.IResolvable | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export declare class DatabaseUserSettingsOpensearchAclList extends cdktn.ComplexList {
    internalValue?: DatabaseUserSettingsOpensearchAcl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseUserSettingsOpensearchAclOutputReference;
}
export interface DatabaseUserSettings {
    /**
    * acl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#acl DatabaseUser#acl}
    */
    readonly acl?: DatabaseUserSettingsAcl[] | cdktn.IResolvable;
    /**
    * opensearch_acl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#opensearch_acl DatabaseUser#opensearch_acl}
    */
    readonly opensearchAcl?: DatabaseUserSettingsOpensearchAcl[] | cdktn.IResolvable;
}
export declare function databaseUserSettingsToTerraform(struct?: DatabaseUserSettings | cdktn.IResolvable): any;
export declare function databaseUserSettingsToHclTerraform(struct?: DatabaseUserSettings | cdktn.IResolvable): any;
export declare class DatabaseUserSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseUserSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseUserSettings | cdktn.IResolvable | undefined);
    private _acl;
    get acl(): DatabaseUserSettingsAclList;
    putAcl(value: DatabaseUserSettingsAcl[] | cdktn.IResolvable): void;
    resetAcl(): void;
    get aclInput(): cdktn.IResolvable | DatabaseUserSettingsAcl[] | undefined;
    private _opensearchAcl;
    get opensearchAcl(): DatabaseUserSettingsOpensearchAclList;
    putOpensearchAcl(value: DatabaseUserSettingsOpensearchAcl[] | cdktn.IResolvable): void;
    resetOpensearchAcl(): void;
    get opensearchAclInput(): cdktn.IResolvable | DatabaseUserSettingsOpensearchAcl[] | undefined;
}
export declare class DatabaseUserSettingsList extends cdktn.ComplexList {
    internalValue?: DatabaseUserSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseUserSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user digitalocean_database_user}
*/
export declare class DatabaseUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_user";
    /**
    * Generates CDKTN code for importing a DatabaseUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseUser to import
    * @param importFromId The id of the existing DatabaseUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_user digitalocean_database_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseUserConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseUserConfig);
    get accessCert(): string;
    get accessKey(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mysqlAuthPlugin?;
    get mysqlAuthPlugin(): string;
    set mysqlAuthPlugin(value: string);
    resetMysqlAuthPlugin(): void;
    get mysqlAuthPluginInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get password(): string;
    get role(): string;
    private _settings;
    get settings(): DatabaseUserSettingsList;
    putSettings(value: DatabaseUserSettings[] | cdktn.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | DatabaseUserSettings[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
