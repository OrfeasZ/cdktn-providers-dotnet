import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agents_by_openai_api_key#id DataDigitaloceanGradientaiAgentsByOpenaiApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The UUID of the OpenAI API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agents_by_openai_api_key#uuid DataDigitaloceanGradientaiAgentsByOpenaiApiKey#uuid}
    */
    readonly uuid: string;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrail {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrailToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrail): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrailToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrail): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrail | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrail | undefined);
    get agentUuid(): string;
    get createdAt(): string;
    get defaultResponse(): string;
    get description(): string;
    get guardrailUuid(): string;
    get isAttached(): cdktn.IResolvable;
    get isDefault(): cdktn.IResolvable;
    get name(): string;
    get priority(): number;
    get type(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrailOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgents {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgents): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgents): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctions {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctionsToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctions): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctions): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctions | undefined);
    get apiKey(): string;
    get createdAt(): string;
    get description(): string;
    get faasname(): string;
    get faasnamespace(): string;
    get guardrailUuid(): string;
    get name(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBases {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBases): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBases): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktn.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreement {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreementToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreement): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreement): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersions {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersions): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersions): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModel {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModel): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModel): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModel | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelVersionsList;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgents {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgents): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgents): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktn.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModel {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModel): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModel): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModel | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsList;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplate {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplate): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplate): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplate | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplate | undefined);
    get createdAt(): string;
    get description(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateModelList;
    get name(): string;
    get temperature(): number;
    get topP(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateOutputReference;
}
export interface DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgents {
}
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgents): any;
export declare function dataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgents): any;
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgents | undefined);
    private _agentGuardrail;
    get agentGuardrail(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAgentGuardrailList;
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersList;
    private _childAgents;
    get childAgents(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsChildAgentsList;
    get createdAt(): string;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsDeploymentList;
    get description(): string;
    private _functions;
    get functions(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsFunctionsList;
    get ifCase(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsModelList;
    get modelUuid(): string;
    get name(): string;
    private _openAiApiKey;
    get openAiApiKey(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyList;
    private _parentAgents;
    get parentAgents(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsParentAgentsList;
    get projectId(): string;
    get region(): string;
    get retrievalMethod(): string;
    get routeCreatedAt(): string;
    get routeCreatedBy(): string;
    get routeName(): string;
    get routeUuid(): string;
    get tags(): string[];
    get temperature(): number;
    private _template;
    get template(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsTemplateList;
    get topP(): number;
    get updatedAt(): string;
    get url(): string;
    get userId(): string;
}
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agents_by_openai_api_key digitalocean_gradientai_agents_by_openai_api_key}
*/
export declare class DataDigitaloceanGradientaiAgentsByOpenaiApiKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_agents_by_openai_api_key";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiAgentsByOpenaiApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiAgentsByOpenaiApiKey to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiAgentsByOpenaiApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agents_by_openai_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiAgentsByOpenaiApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agents_by_openai_api_key digitalocean_gradientai_agents_by_openai_api_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiAgentsByOpenaiApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiAgentsByOpenaiApiKeyConfig);
    private _agents;
    get agents(): DataDigitaloceanGradientaiAgentsByOpenaiApiKeyAgentsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
