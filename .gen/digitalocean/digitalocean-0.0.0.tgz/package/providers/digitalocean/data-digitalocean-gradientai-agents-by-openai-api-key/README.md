# `data_digitalocean_gradientai_agents_by_openai_api_key`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_agents_by_openai_api_key`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agents_by_openai_api_key).
