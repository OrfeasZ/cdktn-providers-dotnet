import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanSizesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#id DataDigitaloceanSizes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#filter DataDigitaloceanSizes#filter}
    */
    readonly filter?: DataDigitaloceanSizesFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#sort DataDigitaloceanSizes#sort}
    */
    readonly sort?: DataDigitaloceanSizesSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanSizesSizes {
}
export declare function dataDigitaloceanSizesSizesToTerraform(struct?: DataDigitaloceanSizesSizes): any;
export declare function dataDigitaloceanSizesSizesToHclTerraform(struct?: DataDigitaloceanSizesSizes): any;
export declare class DataDigitaloceanSizesSizesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSizesSizes | undefined;
    set internalValue(value: DataDigitaloceanSizesSizes | undefined);
    get available(): cdktn.IResolvable;
    get disk(): number;
    get memory(): number;
    get priceHourly(): number;
    get priceMonthly(): number;
    get regions(): string[];
    get slug(): string;
    get transfer(): number;
    get vcpus(): number;
}
export declare class DataDigitaloceanSizesSizesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSizesSizesOutputReference;
}
export interface DataDigitaloceanSizesFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#all DataDigitaloceanSizes#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#key DataDigitaloceanSizes#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#match_by DataDigitaloceanSizes#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#values DataDigitaloceanSizes#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanSizesFilterToTerraform(struct?: DataDigitaloceanSizesFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanSizesFilterToHclTerraform(struct?: DataDigitaloceanSizesFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanSizesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSizesFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanSizesFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanSizesFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanSizesFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSizesFilterOutputReference;
}
export interface DataDigitaloceanSizesSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#direction DataDigitaloceanSizes#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#key DataDigitaloceanSizes#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanSizesSortToTerraform(struct?: DataDigitaloceanSizesSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanSizesSortToHclTerraform(struct?: DataDigitaloceanSizesSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanSizesSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSizesSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanSizesSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanSizesSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanSizesSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSizesSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes digitalocean_sizes}
*/
export declare class DataDigitaloceanSizes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_sizes";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanSizes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanSizes to import
    * @param importFromId The id of the existing DataDigitaloceanSizes that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanSizes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes digitalocean_sizes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanSizesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanSizesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _sizes;
    get sizes(): DataDigitaloceanSizesSizesList;
    private _filter;
    get filter(): DataDigitaloceanSizesFilterList;
    putFilter(value: DataDigitaloceanSizesFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanSizesFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanSizesSortList;
    putSort(value: DataDigitaloceanSizesSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanSizesSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
