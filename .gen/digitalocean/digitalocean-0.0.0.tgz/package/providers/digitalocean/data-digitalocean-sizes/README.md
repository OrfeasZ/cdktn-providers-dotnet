# `data_digitalocean_sizes`

Refer to the Terraform Registry for docs: [`data_digitalocean_sizes`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/sizes).
