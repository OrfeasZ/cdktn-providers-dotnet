import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UptimeAlertConfig extends cdktn.TerraformMetaArguments {
    /**
    * A unique identifier for a check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#check_id UptimeAlert#check_id}
    */
    readonly checkId: string;
    /**
    * The comparison operator used against the alert's threshold. Enum: 'greater_than' 'less_than
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#comparison UptimeAlert#comparison}
    */
    readonly comparison?: string;
    /**
    * A human-friendly display name for the alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#name UptimeAlert#name}
    */
    readonly name: string;
    /**
    * Period of time the threshold must be exceeded to trigger the alert. Enum '2m' '3m' '5m' '10m' '15m' '30m' '1h'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#period UptimeAlert#period}
    */
    readonly period?: string;
    /**
    * The threshold at which the alert will enter a trigger state. The specific threshold is dependent on the alert type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#threshold UptimeAlert#threshold}
    */
    readonly threshold?: number;
    /**
    * The type of health check to perform. Enum: 'latency' 'down' 'down_global' 'ssl_expiry'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#type UptimeAlert#type}
    */
    readonly type: string;
    /**
    * notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#notifications UptimeAlert#notifications}
    */
    readonly notifications: UptimeAlertNotifications[] | cdktn.IResolvable;
}
export interface UptimeAlertNotificationsSlack {
    /**
    * The Slack channel to send alerts to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#channel UptimeAlert#channel}
    */
    readonly channel: string;
    /**
    * The webhook URL for Slack
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#url UptimeAlert#url}
    */
    readonly url: string;
}
export declare function uptimeAlertNotificationsSlackToTerraform(struct?: UptimeAlertNotificationsSlack | cdktn.IResolvable): any;
export declare function uptimeAlertNotificationsSlackToHclTerraform(struct?: UptimeAlertNotificationsSlack | cdktn.IResolvable): any;
export declare class UptimeAlertNotificationsSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): UptimeAlertNotificationsSlack | cdktn.IResolvable | undefined;
    set internalValue(value: UptimeAlertNotificationsSlack | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class UptimeAlertNotificationsSlackList extends cdktn.ComplexList {
    internalValue?: UptimeAlertNotificationsSlack[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): UptimeAlertNotificationsSlackOutputReference;
}
export interface UptimeAlertNotifications {
    /**
    * List of email addresses to sent notifications to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#email UptimeAlert#email}
    */
    readonly email?: string[];
    /**
    * slack block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#slack UptimeAlert#slack}
    */
    readonly slack?: UptimeAlertNotificationsSlack[] | cdktn.IResolvable;
}
export declare function uptimeAlertNotificationsToTerraform(struct?: UptimeAlertNotifications | cdktn.IResolvable): any;
export declare function uptimeAlertNotificationsToHclTerraform(struct?: UptimeAlertNotifications | cdktn.IResolvable): any;
export declare class UptimeAlertNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): UptimeAlertNotifications | cdktn.IResolvable | undefined;
    set internalValue(value: UptimeAlertNotifications | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _slack;
    get slack(): UptimeAlertNotificationsSlackList;
    putSlack(value: UptimeAlertNotificationsSlack[] | cdktn.IResolvable): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | UptimeAlertNotificationsSlack[] | undefined;
}
export declare class UptimeAlertNotificationsList extends cdktn.ComplexList {
    internalValue?: UptimeAlertNotifications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): UptimeAlertNotificationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert digitalocean_uptime_alert}
*/
export declare class UptimeAlert extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_uptime_alert";
    /**
    * Generates CDKTN code for importing a UptimeAlert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UptimeAlert to import
    * @param importFromId The id of the existing UptimeAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UptimeAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/uptime_alert digitalocean_uptime_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UptimeAlertConfig
    */
    constructor(scope: Construct, id: string, config: UptimeAlertConfig);
    private _checkId?;
    get checkId(): string;
    set checkId(value: string);
    get checkIdInput(): string | undefined;
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _notifications;
    get notifications(): UptimeAlertNotificationsList;
    putNotifications(value: UptimeAlertNotifications[] | cdktn.IResolvable): void;
    get notificationsInput(): cdktn.IResolvable | UptimeAlertNotifications[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
