import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanVpcNatGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the VPC NAT Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/vpc_nat_gateway#id DataDigitaloceanVpcNatGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the VPC NAT Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/vpc_nat_gateway#name DataDigitaloceanVpcNatGateway#name}
    */
    readonly name?: string;
}
export interface DataDigitaloceanVpcNatGatewayEgressesPublicGateways {
}
export declare function dataDigitaloceanVpcNatGatewayEgressesPublicGatewaysToTerraform(struct?: DataDigitaloceanVpcNatGatewayEgressesPublicGateways): any;
export declare function dataDigitaloceanVpcNatGatewayEgressesPublicGatewaysToHclTerraform(struct?: DataDigitaloceanVpcNatGatewayEgressesPublicGateways): any;
export declare class DataDigitaloceanVpcNatGatewayEgressesPublicGatewaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanVpcNatGatewayEgressesPublicGateways | undefined;
    set internalValue(value: DataDigitaloceanVpcNatGatewayEgressesPublicGateways | undefined);
    get ipv4(): string;
}
export declare class DataDigitaloceanVpcNatGatewayEgressesPublicGatewaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanVpcNatGatewayEgressesPublicGatewaysOutputReference;
}
export interface DataDigitaloceanVpcNatGatewayEgresses {
}
export declare function dataDigitaloceanVpcNatGatewayEgressesToTerraform(struct?: DataDigitaloceanVpcNatGatewayEgresses): any;
export declare function dataDigitaloceanVpcNatGatewayEgressesToHclTerraform(struct?: DataDigitaloceanVpcNatGatewayEgresses): any;
export declare class DataDigitaloceanVpcNatGatewayEgressesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanVpcNatGatewayEgresses | undefined;
    set internalValue(value: DataDigitaloceanVpcNatGatewayEgresses | undefined);
    private _publicGateways;
    get publicGateways(): DataDigitaloceanVpcNatGatewayEgressesPublicGatewaysList;
}
export declare class DataDigitaloceanVpcNatGatewayEgressesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanVpcNatGatewayEgressesOutputReference;
}
export interface DataDigitaloceanVpcNatGatewayVpcs {
}
export declare function dataDigitaloceanVpcNatGatewayVpcsToTerraform(struct?: DataDigitaloceanVpcNatGatewayVpcs): any;
export declare function dataDigitaloceanVpcNatGatewayVpcsToHclTerraform(struct?: DataDigitaloceanVpcNatGatewayVpcs): any;
export declare class DataDigitaloceanVpcNatGatewayVpcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanVpcNatGatewayVpcs | undefined;
    set internalValue(value: DataDigitaloceanVpcNatGatewayVpcs | undefined);
    get defaultGateway(): cdktn.IResolvable;
    get gatewayIp(): string;
    get vpcUuid(): string;
}
export declare class DataDigitaloceanVpcNatGatewayVpcsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanVpcNatGatewayVpcsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/vpc_nat_gateway digitalocean_vpc_nat_gateway}
*/
export declare class DataDigitaloceanVpcNatGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_vpc_nat_gateway";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanVpcNatGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanVpcNatGateway to import
    * @param importFromId The id of the existing DataDigitaloceanVpcNatGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/vpc_nat_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanVpcNatGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/vpc_nat_gateway digitalocean_vpc_nat_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanVpcNatGatewayConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanVpcNatGatewayConfig);
    get createdAt(): string;
    private _egresses;
    get egresses(): DataDigitaloceanVpcNatGatewayEgressesList;
    get icmpTimeoutSeconds(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get projectId(): string;
    get region(): string;
    get size(): number;
    get state(): string;
    get tcpTimeoutSeconds(): number;
    get type(): string;
    get udpTimeoutSeconds(): number;
    get updatedAt(): string;
    private _vpcs;
    get vpcs(): DataDigitaloceanVpcNatGatewayVpcsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
