import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseRedisConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#acl_channels_default DatabaseRedisConfig#acl_channels_default}
    */
    readonly aclChannelsDefault?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#cluster_id DatabaseRedisConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#id DatabaseRedisConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#io_threads DatabaseRedisConfig#io_threads}
    */
    readonly ioThreads?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#lfu_decay_time DatabaseRedisConfig#lfu_decay_time}
    */
    readonly lfuDecayTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#lfu_log_factor DatabaseRedisConfig#lfu_log_factor}
    */
    readonly lfuLogFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#maxmemory_policy DatabaseRedisConfig#maxmemory_policy}
    */
    readonly maxmemoryPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#notify_keyspace_events DatabaseRedisConfig#notify_keyspace_events}
    */
    readonly notifyKeyspaceEvents?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#number_of_databases DatabaseRedisConfig#number_of_databases}
    */
    readonly numberOfDatabases?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#persistence DatabaseRedisConfig#persistence}
    */
    readonly persistence?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#pubsub_client_output_buffer_limit DatabaseRedisConfig#pubsub_client_output_buffer_limit}
    */
    readonly pubsubClientOutputBufferLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#ssl DatabaseRedisConfig#ssl}
    */
    readonly ssl?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#timeout DatabaseRedisConfig#timeout}
    */
    readonly timeout?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config digitalocean_database_redis_config}
*/
export declare class DatabaseRedisConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_redis_config";
    /**
    * Generates CDKTN code for importing a DatabaseRedisConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseRedisConfig to import
    * @param importFromId The id of the existing DatabaseRedisConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseRedisConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_redis_config digitalocean_database_redis_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseRedisConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseRedisConfigConfig);
    private _aclChannelsDefault?;
    get aclChannelsDefault(): string;
    set aclChannelsDefault(value: string);
    resetAclChannelsDefault(): void;
    get aclChannelsDefaultInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ioThreads?;
    get ioThreads(): number;
    set ioThreads(value: number);
    resetIoThreads(): void;
    get ioThreadsInput(): number | undefined;
    private _lfuDecayTime?;
    get lfuDecayTime(): number;
    set lfuDecayTime(value: number);
    resetLfuDecayTime(): void;
    get lfuDecayTimeInput(): number | undefined;
    private _lfuLogFactor?;
    get lfuLogFactor(): number;
    set lfuLogFactor(value: number);
    resetLfuLogFactor(): void;
    get lfuLogFactorInput(): number | undefined;
    private _maxmemoryPolicy?;
    get maxmemoryPolicy(): string;
    set maxmemoryPolicy(value: string);
    resetMaxmemoryPolicy(): void;
    get maxmemoryPolicyInput(): string | undefined;
    private _notifyKeyspaceEvents?;
    get notifyKeyspaceEvents(): string;
    set notifyKeyspaceEvents(value: string);
    resetNotifyKeyspaceEvents(): void;
    get notifyKeyspaceEventsInput(): string | undefined;
    private _numberOfDatabases?;
    get numberOfDatabases(): number;
    set numberOfDatabases(value: number);
    resetNumberOfDatabases(): void;
    get numberOfDatabasesInput(): number | undefined;
    private _persistence?;
    get persistence(): string;
    set persistence(value: string);
    resetPersistence(): void;
    get persistenceInput(): string | undefined;
    private _pubsubClientOutputBufferLimit?;
    get pubsubClientOutputBufferLimit(): number;
    set pubsubClientOutputBufferLimit(value: number);
    resetPubsubClientOutputBufferLimit(): void;
    get pubsubClientOutputBufferLimitInput(): number | undefined;
    private _ssl?;
    get ssl(): boolean | cdktn.IResolvable;
    set ssl(value: boolean | cdktn.IResolvable);
    resetSsl(): void;
    get sslInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
