# `digitalocean_project`

Refer to the Terraform Registry for docs: [`digitalocean_project`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/project).
