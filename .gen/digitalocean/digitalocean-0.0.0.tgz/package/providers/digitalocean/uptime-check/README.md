# `digitalocean_uptime_check`

Refer to the Terraform Registry for docs: [`digitalocean_uptime_check`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check).
