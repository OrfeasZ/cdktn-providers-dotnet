import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UptimeCheckConfig extends cdktn.TerraformMetaArguments {
    /**
    * A boolean value indicating whether the check is enabled/disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check#enabled UptimeCheck#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * A human-friendly display name for the check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check#name UptimeCheck#name}
    */
    readonly name: string;
    /**
    * An array containing the selected regions to perform healthchecks from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check#regions UptimeCheck#regions}
    */
    readonly regions?: string[];
    /**
    * The endpoint to perform healthchecks on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check#target UptimeCheck#target}
    */
    readonly target: string;
    /**
    * The type of health check to perform. Enum: 'ping' 'http' 'https'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check#type UptimeCheck#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check digitalocean_uptime_check}
*/
export declare class UptimeCheck extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_uptime_check";
    /**
    * Generates CDKTN code for importing a UptimeCheck resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UptimeCheck to import
    * @param importFromId The id of the existing UptimeCheck that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UptimeCheck to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/uptime_check digitalocean_uptime_check} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UptimeCheckConfig
    */
    constructor(scope: Construct, id: string, config: UptimeCheckConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
