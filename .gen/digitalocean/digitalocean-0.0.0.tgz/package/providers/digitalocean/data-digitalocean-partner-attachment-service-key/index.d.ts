import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanPartnerAttachmentServiceKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Partner Attachment for which to retrieve the service key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment_service_key#attachment_id DataDigitaloceanPartnerAttachmentServiceKey#attachment_id}
    */
    readonly attachmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment_service_key#id DataDigitaloceanPartnerAttachmentServiceKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment_service_key digitalocean_partner_attachment_service_key}
*/
export declare class DataDigitaloceanPartnerAttachmentServiceKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_partner_attachment_service_key";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanPartnerAttachmentServiceKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanPartnerAttachmentServiceKey to import
    * @param importFromId The id of the existing DataDigitaloceanPartnerAttachmentServiceKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment_service_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanPartnerAttachmentServiceKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/partner_attachment_service_key digitalocean_partner_attachment_service_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanPartnerAttachmentServiceKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanPartnerAttachmentServiceKeyConfig);
    private _attachmentId?;
    get attachmentId(): string;
    set attachmentId(value: string);
    get attachmentIdInput(): string | undefined;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get state(): string;
    get value(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
