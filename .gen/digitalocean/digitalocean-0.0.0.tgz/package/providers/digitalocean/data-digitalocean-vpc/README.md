# `data_digitalocean_vpc`

Refer to the Terraform Registry for docs: [`data_digitalocean_vpc`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/vpc).
