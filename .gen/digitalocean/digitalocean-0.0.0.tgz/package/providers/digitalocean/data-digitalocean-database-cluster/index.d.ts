import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDatabaseClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_cluster#id DataDigitaloceanDatabaseCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_cluster#name DataDigitaloceanDatabaseCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_cluster#tags DataDigitaloceanDatabaseCluster#tags}
    */
    readonly tags?: string[];
}
export interface DataDigitaloceanDatabaseClusterMaintenanceWindow {
}
export declare function dataDigitaloceanDatabaseClusterMaintenanceWindowToTerraform(struct?: DataDigitaloceanDatabaseClusterMaintenanceWindow): any;
export declare function dataDigitaloceanDatabaseClusterMaintenanceWindowToHclTerraform(struct?: DataDigitaloceanDatabaseClusterMaintenanceWindow): any;
export declare class DataDigitaloceanDatabaseClusterMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDatabaseClusterMaintenanceWindow | undefined;
    set internalValue(value: DataDigitaloceanDatabaseClusterMaintenanceWindow | undefined);
    get day(): string;
    get hour(): string;
}
export declare class DataDigitaloceanDatabaseClusterMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDatabaseClusterMaintenanceWindowOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_cluster digitalocean_database_cluster}
*/
export declare class DataDigitaloceanDatabaseCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_database_cluster";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDatabaseCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDatabaseCluster to import
    * @param importFromId The id of the existing DataDigitaloceanDatabaseCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDatabaseCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_cluster digitalocean_database_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDatabaseClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanDatabaseClusterConfig);
    get database(): string;
    get engine(): string;
    get host(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDigitaloceanDatabaseClusterMaintenanceWindowList;
    get metricsEndpoints(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeCount(): number;
    get password(): string;
    get port(): number;
    get privateHost(): string;
    get privateNetworkUuid(): string;
    get privateUri(): string;
    get projectId(): string;
    get region(): string;
    get size(): string;
    get storageSizeMib(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get uiDatabase(): string;
    get uiHost(): string;
    get uiPassword(): string;
    get uiPort(): number;
    get uiUri(): string;
    get uiUser(): string;
    get uri(): string;
    get urn(): string;
    get user(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
