# `digitalocean_volume_attachment`

Refer to the Terraform Registry for docs: [`digitalocean_volume_attachment`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/volume_attachment).
