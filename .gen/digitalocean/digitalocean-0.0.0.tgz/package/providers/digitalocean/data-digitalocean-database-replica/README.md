# `data_digitalocean_database_replica`

Refer to the Terraform Registry for docs: [`data_digitalocean_database_replica`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/database_replica).
