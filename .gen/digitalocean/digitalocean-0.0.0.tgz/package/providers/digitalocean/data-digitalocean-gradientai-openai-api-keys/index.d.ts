import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiOpenaiApiKeysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#id DataDigitaloceanGradientaiOpenaiApiKeys#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#filter DataDigitaloceanGradientaiOpenaiApiKeys#filter}
    */
    readonly filter?: DataDigitaloceanGradientaiOpenaiApiKeysFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#sort DataDigitaloceanGradientaiOpenaiApiKeys#sort}
    */
    readonly sort?: DataDigitaloceanGradientaiOpenaiApiKeysSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreement {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreementToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreement): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreement): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreement | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersions {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersionsToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersions): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersions): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersions | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModels {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModels): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModels): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModels | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModels | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktn.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktn.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsVersionsList;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeys {
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeys): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeys): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeys | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    private _models;
    get models(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysModelsList;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeysFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#all DataDigitaloceanGradientaiOpenaiApiKeys#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#key DataDigitaloceanGradientaiOpenaiApiKeys#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#match_by DataDigitaloceanGradientaiOpenaiApiKeys#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#values DataDigitaloceanGradientaiOpenaiApiKeys#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeysFilterToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeysFilterToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeysFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeysFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeysFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeysFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiOpenaiApiKeysFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeysFilterOutputReference;
}
export interface DataDigitaloceanGradientaiOpenaiApiKeysSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#direction DataDigitaloceanGradientaiOpenaiApiKeys#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#key DataDigitaloceanGradientaiOpenaiApiKeys#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGradientaiOpenaiApiKeysSortToTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiOpenaiApiKeysSortToHclTerraform(struct?: DataDigitaloceanGradientaiOpenaiApiKeysSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiOpenaiApiKeysSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiOpenaiApiKeysSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiOpenaiApiKeysSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiOpenaiApiKeysSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiOpenaiApiKeysSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiOpenaiApiKeysSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys digitalocean_gradientai_openai_api_keys}
*/
export declare class DataDigitaloceanGradientaiOpenaiApiKeys extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_openai_api_keys";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiOpenaiApiKeys resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiOpenaiApiKeys to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiOpenaiApiKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiOpenaiApiKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys digitalocean_gradientai_openai_api_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiOpenaiApiKeysConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGradientaiOpenaiApiKeysConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _openaiApiKeys;
    get openaiApiKeys(): DataDigitaloceanGradientaiOpenaiApiKeysOpenaiApiKeysList;
    private _filter;
    get filter(): DataDigitaloceanGradientaiOpenaiApiKeysFilterList;
    putFilter(value: DataDigitaloceanGradientaiOpenaiApiKeysFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanGradientaiOpenaiApiKeysFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGradientaiOpenaiApiKeysSortList;
    putSort(value: DataDigitaloceanGradientaiOpenaiApiKeysSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanGradientaiOpenaiApiKeysSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
