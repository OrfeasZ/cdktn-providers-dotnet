# `data_digitalocean_gradientai_openai_api_keys`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_openai_api_keys`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_openai_api_keys).
