# `data_digitalocean_gradientai_openai_api_keys`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_openai_api_keys`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/gradientai_openai_api_keys).
