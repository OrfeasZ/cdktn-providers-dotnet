import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDedicatedInferenceGpuModelConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/dedicated_inference_gpu_model_config#id DataDigitaloceanDedicatedInferenceGpuModelConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigs {
}
export declare function dataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigsToTerraform(struct?: DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigs): any;
export declare function dataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigsToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigs): any;
export declare class DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigs | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigs | undefined);
    get gpuSlugs(): string[];
    get isModelGated(): cdktn.IResolvable;
    get modelName(): string;
    get modelSlug(): string;
}
export declare class DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/dedicated_inference_gpu_model_config digitalocean_dedicated_inference_gpu_model_config}
*/
export declare class DataDigitaloceanDedicatedInferenceGpuModelConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_dedicated_inference_gpu_model_config";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDedicatedInferenceGpuModelConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDedicatedInferenceGpuModelConfig to import
    * @param importFromId The id of the existing DataDigitaloceanDedicatedInferenceGpuModelConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/dedicated_inference_gpu_model_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDedicatedInferenceGpuModelConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/dedicated_inference_gpu_model_config digitalocean_dedicated_inference_gpu_model_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDedicatedInferenceGpuModelConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDedicatedInferenceGpuModelConfigConfig);
    private _gpuModelConfigs;
    get gpuModelConfigs(): DataDigitaloceanDedicatedInferenceGpuModelConfigGpuModelConfigsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
