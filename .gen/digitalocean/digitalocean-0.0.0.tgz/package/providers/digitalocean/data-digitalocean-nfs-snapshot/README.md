# `data_digitalocean_nfs_snapshot`

Refer to the Terraform Registry for docs: [`data_digitalocean_nfs_snapshot`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/nfs_snapshot).
