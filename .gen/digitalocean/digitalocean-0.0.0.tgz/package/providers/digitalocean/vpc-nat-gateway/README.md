# `digitalocean_vpc_nat_gateway`

Refer to the Terraform Registry for docs: [`digitalocean_vpc_nat_gateway`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/vpc_nat_gateway).
