import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanImagesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#id DataDigitaloceanImages#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#filter DataDigitaloceanImages#filter}
    */
    readonly filter?: DataDigitaloceanImagesFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#sort DataDigitaloceanImages#sort}
    */
    readonly sort?: DataDigitaloceanImagesSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanImagesImages {
}
export declare function dataDigitaloceanImagesImagesToTerraform(struct?: DataDigitaloceanImagesImages): any;
export declare function dataDigitaloceanImagesImagesToHclTerraform(struct?: DataDigitaloceanImagesImages): any;
export declare class DataDigitaloceanImagesImagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanImagesImages | undefined;
    set internalValue(value: DataDigitaloceanImagesImages | undefined);
    get created(): string;
    get description(): string;
    get distribution(): string;
    get errorMessage(): string;
    get id(): number;
    get image(): string;
    get minDiskSize(): number;
    get name(): string;
    get private(): cdktn.IResolvable;
    get regions(): string[];
    get sizeGigabytes(): number;
    get slug(): string;
    get status(): string;
    get tags(): string[];
    get type(): string;
}
export declare class DataDigitaloceanImagesImagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanImagesImagesOutputReference;
}
export interface DataDigitaloceanImagesFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#all DataDigitaloceanImages#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#key DataDigitaloceanImages#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#match_by DataDigitaloceanImages#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#values DataDigitaloceanImages#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanImagesFilterToTerraform(struct?: DataDigitaloceanImagesFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanImagesFilterToHclTerraform(struct?: DataDigitaloceanImagesFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanImagesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanImagesFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanImagesFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanImagesFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanImagesFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanImagesFilterOutputReference;
}
export interface DataDigitaloceanImagesSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#direction DataDigitaloceanImages#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#key DataDigitaloceanImages#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanImagesSortToTerraform(struct?: DataDigitaloceanImagesSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanImagesSortToHclTerraform(struct?: DataDigitaloceanImagesSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanImagesSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanImagesSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanImagesSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanImagesSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanImagesSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanImagesSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images digitalocean_images}
*/
export declare class DataDigitaloceanImages extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_images";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanImages resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanImages to import
    * @param importFromId The id of the existing DataDigitaloceanImages that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanImages to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/images digitalocean_images} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanImagesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanImagesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _images;
    get images(): DataDigitaloceanImagesImagesList;
    private _filter;
    get filter(): DataDigitaloceanImagesFilterList;
    putFilter(value: DataDigitaloceanImagesFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanImagesFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanImagesSortList;
    putSort(value: DataDigitaloceanImagesSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanImagesSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
