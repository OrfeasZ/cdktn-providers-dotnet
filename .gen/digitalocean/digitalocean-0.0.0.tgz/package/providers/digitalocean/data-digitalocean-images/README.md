# `data_digitalocean_images`

Refer to the Terraform Registry for docs: [`data_digitalocean_images`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/images).
