import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseKafkaConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#auto_create_topics_enable DatabaseKafkaConfig#auto_create_topics_enable}
    */
    readonly autoCreateTopicsEnable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#cluster_id DatabaseKafkaConfig#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#group_initial_rebalance_delay_ms DatabaseKafkaConfig#group_initial_rebalance_delay_ms}
    */
    readonly groupInitialRebalanceDelayMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#group_max_session_timeout_ms DatabaseKafkaConfig#group_max_session_timeout_ms}
    */
    readonly groupMaxSessionTimeoutMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#group_min_session_timeout_ms DatabaseKafkaConfig#group_min_session_timeout_ms}
    */
    readonly groupMinSessionTimeoutMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#id DatabaseKafkaConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_cleaner_delete_retention_ms DatabaseKafkaConfig#log_cleaner_delete_retention_ms}
    */
    readonly logCleanerDeleteRetentionMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_cleaner_min_compaction_lag_ms DatabaseKafkaConfig#log_cleaner_min_compaction_lag_ms}
    */
    readonly logCleanerMinCompactionLagMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_flush_interval_ms DatabaseKafkaConfig#log_flush_interval_ms}
    */
    readonly logFlushIntervalMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_index_interval_bytes DatabaseKafkaConfig#log_index_interval_bytes}
    */
    readonly logIndexIntervalBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_message_downconversion_enable DatabaseKafkaConfig#log_message_downconversion_enable}
    */
    readonly logMessageDownconversionEnable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_message_timestamp_difference_max_ms DatabaseKafkaConfig#log_message_timestamp_difference_max_ms}
    */
    readonly logMessageTimestampDifferenceMaxMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_preallocate DatabaseKafkaConfig#log_preallocate}
    */
    readonly logPreallocate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_retention_bytes DatabaseKafkaConfig#log_retention_bytes}
    */
    readonly logRetentionBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_retention_hours DatabaseKafkaConfig#log_retention_hours}
    */
    readonly logRetentionHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_retention_ms DatabaseKafkaConfig#log_retention_ms}
    */
    readonly logRetentionMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_roll_jitter_ms DatabaseKafkaConfig#log_roll_jitter_ms}
    */
    readonly logRollJitterMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#log_segment_delete_delay_ms DatabaseKafkaConfig#log_segment_delete_delay_ms}
    */
    readonly logSegmentDeleteDelayMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#message_max_bytes DatabaseKafkaConfig#message_max_bytes}
    */
    readonly messageMaxBytes?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config digitalocean_database_kafka_config}
*/
export declare class DatabaseKafkaConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_kafka_config";
    /**
    * Generates CDKTN code for importing a DatabaseKafkaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseKafkaConfig to import
    * @param importFromId The id of the existing DatabaseKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseKafkaConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config digitalocean_database_kafka_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseKafkaConfigConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseKafkaConfigConfig);
    private _autoCreateTopicsEnable?;
    get autoCreateTopicsEnable(): boolean | cdktn.IResolvable;
    set autoCreateTopicsEnable(value: boolean | cdktn.IResolvable);
    resetAutoCreateTopicsEnable(): void;
    get autoCreateTopicsEnableInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _groupInitialRebalanceDelayMs?;
    get groupInitialRebalanceDelayMs(): number;
    set groupInitialRebalanceDelayMs(value: number);
    resetGroupInitialRebalanceDelayMs(): void;
    get groupInitialRebalanceDelayMsInput(): number | undefined;
    private _groupMaxSessionTimeoutMs?;
    get groupMaxSessionTimeoutMs(): number;
    set groupMaxSessionTimeoutMs(value: number);
    resetGroupMaxSessionTimeoutMs(): void;
    get groupMaxSessionTimeoutMsInput(): number | undefined;
    private _groupMinSessionTimeoutMs?;
    get groupMinSessionTimeoutMs(): number;
    set groupMinSessionTimeoutMs(value: number);
    resetGroupMinSessionTimeoutMs(): void;
    get groupMinSessionTimeoutMsInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCleanerDeleteRetentionMs?;
    get logCleanerDeleteRetentionMs(): number;
    set logCleanerDeleteRetentionMs(value: number);
    resetLogCleanerDeleteRetentionMs(): void;
    get logCleanerDeleteRetentionMsInput(): number | undefined;
    private _logCleanerMinCompactionLagMs?;
    get logCleanerMinCompactionLagMs(): string;
    set logCleanerMinCompactionLagMs(value: string);
    resetLogCleanerMinCompactionLagMs(): void;
    get logCleanerMinCompactionLagMsInput(): string | undefined;
    private _logFlushIntervalMs?;
    get logFlushIntervalMs(): string;
    set logFlushIntervalMs(value: string);
    resetLogFlushIntervalMs(): void;
    get logFlushIntervalMsInput(): string | undefined;
    private _logIndexIntervalBytes?;
    get logIndexIntervalBytes(): number;
    set logIndexIntervalBytes(value: number);
    resetLogIndexIntervalBytes(): void;
    get logIndexIntervalBytesInput(): number | undefined;
    private _logMessageDownconversionEnable?;
    get logMessageDownconversionEnable(): boolean | cdktn.IResolvable;
    set logMessageDownconversionEnable(value: boolean | cdktn.IResolvable);
    resetLogMessageDownconversionEnable(): void;
    get logMessageDownconversionEnableInput(): boolean | cdktn.IResolvable | undefined;
    private _logMessageTimestampDifferenceMaxMs?;
    get logMessageTimestampDifferenceMaxMs(): string;
    set logMessageTimestampDifferenceMaxMs(value: string);
    resetLogMessageTimestampDifferenceMaxMs(): void;
    get logMessageTimestampDifferenceMaxMsInput(): string | undefined;
    private _logPreallocate?;
    get logPreallocate(): boolean | cdktn.IResolvable;
    set logPreallocate(value: boolean | cdktn.IResolvable);
    resetLogPreallocate(): void;
    get logPreallocateInput(): boolean | cdktn.IResolvable | undefined;
    private _logRetentionBytes?;
    get logRetentionBytes(): string;
    set logRetentionBytes(value: string);
    resetLogRetentionBytes(): void;
    get logRetentionBytesInput(): string | undefined;
    private _logRetentionHours?;
    get logRetentionHours(): number;
    set logRetentionHours(value: number);
    resetLogRetentionHours(): void;
    get logRetentionHoursInput(): number | undefined;
    private _logRetentionMs?;
    get logRetentionMs(): string;
    set logRetentionMs(value: string);
    resetLogRetentionMs(): void;
    get logRetentionMsInput(): string | undefined;
    private _logRollJitterMs?;
    get logRollJitterMs(): string;
    set logRollJitterMs(value: string);
    resetLogRollJitterMs(): void;
    get logRollJitterMsInput(): string | undefined;
    private _logSegmentDeleteDelayMs?;
    get logSegmentDeleteDelayMs(): number;
    set logSegmentDeleteDelayMs(value: number);
    resetLogSegmentDeleteDelayMs(): void;
    get logSegmentDeleteDelayMsInput(): number | undefined;
    private _messageMaxBytes?;
    get messageMaxBytes(): number;
    set messageMaxBytes(value: number);
    resetMessageMaxBytes(): void;
    get messageMaxBytesInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
