"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseKafkaConfig = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const cdktn = require("cdktn");
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config digitalocean_database_kafka_config}
*/
class DatabaseKafkaConfig extends cdktn.TerraformResource {
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a DatabaseKafkaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseKafkaConfig to import
    * @param importFromId The id of the existing DatabaseKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseKafkaConfig to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "digitalocean_database_kafka_config", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_kafka_config digitalocean_database_kafka_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseKafkaConfigConfig
    */
    constructor(scope, id, config) {
        super(scope, id, {
            terraformResourceType: 'digitalocean_database_kafka_config',
            terraformGeneratorMetadata: {
                providerName: 'digitalocean',
                providerVersion: '2.87.0',
                providerVersionConstraint: '2.87.0'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._autoCreateTopicsEnable = config.autoCreateTopicsEnable;
        this._clusterId = config.clusterId;
        this._groupInitialRebalanceDelayMs = config.groupInitialRebalanceDelayMs;
        this._groupMaxSessionTimeoutMs = config.groupMaxSessionTimeoutMs;
        this._groupMinSessionTimeoutMs = config.groupMinSessionTimeoutMs;
        this._id = config.id;
        this._logCleanerDeleteRetentionMs = config.logCleanerDeleteRetentionMs;
        this._logCleanerMinCompactionLagMs = config.logCleanerMinCompactionLagMs;
        this._logFlushIntervalMs = config.logFlushIntervalMs;
        this._logIndexIntervalBytes = config.logIndexIntervalBytes;
        this._logMessageDownconversionEnable = config.logMessageDownconversionEnable;
        this._logMessageTimestampDifferenceMaxMs = config.logMessageTimestampDifferenceMaxMs;
        this._logPreallocate = config.logPreallocate;
        this._logRetentionBytes = config.logRetentionBytes;
        this._logRetentionHours = config.logRetentionHours;
        this._logRetentionMs = config.logRetentionMs;
        this._logRollJitterMs = config.logRollJitterMs;
        this._logSegmentDeleteDelayMs = config.logSegmentDeleteDelayMs;
        this._messageMaxBytes = config.messageMaxBytes;
    }
    get autoCreateTopicsEnable() {
        return this.getBooleanAttribute('auto_create_topics_enable');
    }
    set autoCreateTopicsEnable(value) {
        this._autoCreateTopicsEnable = value;
    }
    resetAutoCreateTopicsEnable() {
        this._autoCreateTopicsEnable = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get autoCreateTopicsEnableInput() {
        return this._autoCreateTopicsEnable;
    }
    get clusterId() {
        return this.getStringAttribute('cluster_id');
    }
    set clusterId(value) {
        this._clusterId = value;
    }
    // Temporarily expose input value. Use with caution.
    get clusterIdInput() {
        return this._clusterId;
    }
    get groupInitialRebalanceDelayMs() {
        return this.getNumberAttribute('group_initial_rebalance_delay_ms');
    }
    set groupInitialRebalanceDelayMs(value) {
        this._groupInitialRebalanceDelayMs = value;
    }
    resetGroupInitialRebalanceDelayMs() {
        this._groupInitialRebalanceDelayMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupInitialRebalanceDelayMsInput() {
        return this._groupInitialRebalanceDelayMs;
    }
    get groupMaxSessionTimeoutMs() {
        return this.getNumberAttribute('group_max_session_timeout_ms');
    }
    set groupMaxSessionTimeoutMs(value) {
        this._groupMaxSessionTimeoutMs = value;
    }
    resetGroupMaxSessionTimeoutMs() {
        this._groupMaxSessionTimeoutMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupMaxSessionTimeoutMsInput() {
        return this._groupMaxSessionTimeoutMs;
    }
    get groupMinSessionTimeoutMs() {
        return this.getNumberAttribute('group_min_session_timeout_ms');
    }
    set groupMinSessionTimeoutMs(value) {
        this._groupMinSessionTimeoutMs = value;
    }
    resetGroupMinSessionTimeoutMs() {
        this._groupMinSessionTimeoutMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get groupMinSessionTimeoutMsInput() {
        return this._groupMinSessionTimeoutMs;
    }
    get id() {
        return this.getStringAttribute('id');
    }
    set id(value) {
        this._id = value;
    }
    resetId() {
        this._id = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get idInput() {
        return this._id;
    }
    get logCleanerDeleteRetentionMs() {
        return this.getNumberAttribute('log_cleaner_delete_retention_ms');
    }
    set logCleanerDeleteRetentionMs(value) {
        this._logCleanerDeleteRetentionMs = value;
    }
    resetLogCleanerDeleteRetentionMs() {
        this._logCleanerDeleteRetentionMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logCleanerDeleteRetentionMsInput() {
        return this._logCleanerDeleteRetentionMs;
    }
    get logCleanerMinCompactionLagMs() {
        return this.getStringAttribute('log_cleaner_min_compaction_lag_ms');
    }
    set logCleanerMinCompactionLagMs(value) {
        this._logCleanerMinCompactionLagMs = value;
    }
    resetLogCleanerMinCompactionLagMs() {
        this._logCleanerMinCompactionLagMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logCleanerMinCompactionLagMsInput() {
        return this._logCleanerMinCompactionLagMs;
    }
    get logFlushIntervalMs() {
        return this.getStringAttribute('log_flush_interval_ms');
    }
    set logFlushIntervalMs(value) {
        this._logFlushIntervalMs = value;
    }
    resetLogFlushIntervalMs() {
        this._logFlushIntervalMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logFlushIntervalMsInput() {
        return this._logFlushIntervalMs;
    }
    get logIndexIntervalBytes() {
        return this.getNumberAttribute('log_index_interval_bytes');
    }
    set logIndexIntervalBytes(value) {
        this._logIndexIntervalBytes = value;
    }
    resetLogIndexIntervalBytes() {
        this._logIndexIntervalBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logIndexIntervalBytesInput() {
        return this._logIndexIntervalBytes;
    }
    get logMessageDownconversionEnable() {
        return this.getBooleanAttribute('log_message_downconversion_enable');
    }
    set logMessageDownconversionEnable(value) {
        this._logMessageDownconversionEnable = value;
    }
    resetLogMessageDownconversionEnable() {
        this._logMessageDownconversionEnable = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logMessageDownconversionEnableInput() {
        return this._logMessageDownconversionEnable;
    }
    get logMessageTimestampDifferenceMaxMs() {
        return this.getStringAttribute('log_message_timestamp_difference_max_ms');
    }
    set logMessageTimestampDifferenceMaxMs(value) {
        this._logMessageTimestampDifferenceMaxMs = value;
    }
    resetLogMessageTimestampDifferenceMaxMs() {
        this._logMessageTimestampDifferenceMaxMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logMessageTimestampDifferenceMaxMsInput() {
        return this._logMessageTimestampDifferenceMaxMs;
    }
    get logPreallocate() {
        return this.getBooleanAttribute('log_preallocate');
    }
    set logPreallocate(value) {
        this._logPreallocate = value;
    }
    resetLogPreallocate() {
        this._logPreallocate = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logPreallocateInput() {
        return this._logPreallocate;
    }
    get logRetentionBytes() {
        return this.getStringAttribute('log_retention_bytes');
    }
    set logRetentionBytes(value) {
        this._logRetentionBytes = value;
    }
    resetLogRetentionBytes() {
        this._logRetentionBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRetentionBytesInput() {
        return this._logRetentionBytes;
    }
    get logRetentionHours() {
        return this.getNumberAttribute('log_retention_hours');
    }
    set logRetentionHours(value) {
        this._logRetentionHours = value;
    }
    resetLogRetentionHours() {
        this._logRetentionHours = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRetentionHoursInput() {
        return this._logRetentionHours;
    }
    get logRetentionMs() {
        return this.getStringAttribute('log_retention_ms');
    }
    set logRetentionMs(value) {
        this._logRetentionMs = value;
    }
    resetLogRetentionMs() {
        this._logRetentionMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRetentionMsInput() {
        return this._logRetentionMs;
    }
    get logRollJitterMs() {
        return this.getStringAttribute('log_roll_jitter_ms');
    }
    set logRollJitterMs(value) {
        this._logRollJitterMs = value;
    }
    resetLogRollJitterMs() {
        this._logRollJitterMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logRollJitterMsInput() {
        return this._logRollJitterMs;
    }
    get logSegmentDeleteDelayMs() {
        return this.getNumberAttribute('log_segment_delete_delay_ms');
    }
    set logSegmentDeleteDelayMs(value) {
        this._logSegmentDeleteDelayMs = value;
    }
    resetLogSegmentDeleteDelayMs() {
        this._logSegmentDeleteDelayMs = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get logSegmentDeleteDelayMsInput() {
        return this._logSegmentDeleteDelayMs;
    }
    get messageMaxBytes() {
        return this.getNumberAttribute('message_max_bytes');
    }
    set messageMaxBytes(value) {
        this._messageMaxBytes = value;
    }
    resetMessageMaxBytes() {
        this._messageMaxBytes = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get messageMaxBytesInput() {
        return this._messageMaxBytes;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            auto_create_topics_enable: cdktn.booleanToTerraform(this._autoCreateTopicsEnable),
            cluster_id: cdktn.stringToTerraform(this._clusterId),
            group_initial_rebalance_delay_ms: cdktn.numberToTerraform(this._groupInitialRebalanceDelayMs),
            group_max_session_timeout_ms: cdktn.numberToTerraform(this._groupMaxSessionTimeoutMs),
            group_min_session_timeout_ms: cdktn.numberToTerraform(this._groupMinSessionTimeoutMs),
            id: cdktn.stringToTerraform(this._id),
            log_cleaner_delete_retention_ms: cdktn.numberToTerraform(this._logCleanerDeleteRetentionMs),
            log_cleaner_min_compaction_lag_ms: cdktn.stringToTerraform(this._logCleanerMinCompactionLagMs),
            log_flush_interval_ms: cdktn.stringToTerraform(this._logFlushIntervalMs),
            log_index_interval_bytes: cdktn.numberToTerraform(this._logIndexIntervalBytes),
            log_message_downconversion_enable: cdktn.booleanToTerraform(this._logMessageDownconversionEnable),
            log_message_timestamp_difference_max_ms: cdktn.stringToTerraform(this._logMessageTimestampDifferenceMaxMs),
            log_preallocate: cdktn.booleanToTerraform(this._logPreallocate),
            log_retention_bytes: cdktn.stringToTerraform(this._logRetentionBytes),
            log_retention_hours: cdktn.numberToTerraform(this._logRetentionHours),
            log_retention_ms: cdktn.stringToTerraform(this._logRetentionMs),
            log_roll_jitter_ms: cdktn.stringToTerraform(this._logRollJitterMs),
            log_segment_delete_delay_ms: cdktn.numberToTerraform(this._logSegmentDeleteDelayMs),
            message_max_bytes: cdktn.numberToTerraform(this._messageMaxBytes),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            auto_create_topics_enable: {
                value: cdktn.booleanToHclTerraform(this._autoCreateTopicsEnable),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            cluster_id: {
                value: cdktn.stringToHclTerraform(this._clusterId),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            group_initial_rebalance_delay_ms: {
                value: cdktn.numberToHclTerraform(this._groupInitialRebalanceDelayMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            group_max_session_timeout_ms: {
                value: cdktn.numberToHclTerraform(this._groupMaxSessionTimeoutMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            group_min_session_timeout_ms: {
                value: cdktn.numberToHclTerraform(this._groupMinSessionTimeoutMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            id: {
                value: cdktn.stringToHclTerraform(this._id),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_cleaner_delete_retention_ms: {
                value: cdktn.numberToHclTerraform(this._logCleanerDeleteRetentionMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_cleaner_min_compaction_lag_ms: {
                value: cdktn.stringToHclTerraform(this._logCleanerMinCompactionLagMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_flush_interval_ms: {
                value: cdktn.stringToHclTerraform(this._logFlushIntervalMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_index_interval_bytes: {
                value: cdktn.numberToHclTerraform(this._logIndexIntervalBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_message_downconversion_enable: {
                value: cdktn.booleanToHclTerraform(this._logMessageDownconversionEnable),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            log_message_timestamp_difference_max_ms: {
                value: cdktn.stringToHclTerraform(this._logMessageTimestampDifferenceMaxMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_preallocate: {
                value: cdktn.booleanToHclTerraform(this._logPreallocate),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            log_retention_bytes: {
                value: cdktn.stringToHclTerraform(this._logRetentionBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_retention_hours: {
                value: cdktn.numberToHclTerraform(this._logRetentionHours),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            log_retention_ms: {
                value: cdktn.stringToHclTerraform(this._logRetentionMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_roll_jitter_ms: {
                value: cdktn.stringToHclTerraform(this._logRollJitterMs),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            log_segment_delete_delay_ms: {
                value: cdktn.numberToHclTerraform(this._logSegmentDeleteDelayMs),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            message_max_bytes: {
                value: cdktn.numberToHclTerraform(this._messageMaxBytes),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.DatabaseKafkaConfig = DatabaseKafkaConfig;
_a = JSII_RTTI_SYMBOL_1;
DatabaseKafkaConfig[_a] = { fqn: "digitalocean.databaseKafkaConfig.DatabaseKafkaConfig", version: "0.0.0" };
// =================
// STATIC PROPERTIES
// =================
DatabaseKafkaConfig.tfResourceType = "digitalocean_database_kafka_config";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUlBLCtCQUErQjtBQXNGL0I7O0VBRUU7QUFDRixNQUFhLG1CQUFvQixTQUFRLEtBQUssQ0FBQyxpQkFBaUI7SUFPOUQsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLG9DQUFvQyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM1SixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBaUM7UUFDaEYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixxQkFBcUIsRUFBRSxvQ0FBb0M7WUFDM0QsMEJBQTBCLEVBQUU7Z0JBQzFCLFlBQVksRUFBRSxjQUFjO2dCQUM1QixlQUFlLEVBQUUsUUFBUTtnQkFDekIseUJBQXlCLEVBQUUsUUFBUTthQUNwQztZQUNELFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsdUJBQXVCLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDO1FBQzdELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxNQUFNLENBQUMsd0JBQXdCLENBQUM7UUFDakUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQztRQUNqRSxJQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQztRQUN2RSxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLDRCQUE0QixDQUFDO1FBQ3pFLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDckQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLENBQUMsK0JBQStCLEdBQUcsTUFBTSxDQUFDLDhCQUE4QixDQUFDO1FBQzdFLElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxNQUFNLENBQUMsa0NBQWtDLENBQUM7UUFDckYsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1FBQzdDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7UUFDN0MsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7UUFDL0MsSUFBSSxDQUFDLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztRQUMvRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQztJQUNqRCxDQUFDO0lBUUQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFrQztRQUNsRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFDTSwyQkFBMkI7UUFDaEMsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFNBQVMsQ0FBQztJQUMzQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsMkJBQTJCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLENBQUM7SUFJRCxJQUFXLFNBQVM7UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUNELElBQVcsU0FBUyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGNBQWM7UUFDdkIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFJRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFDRCxJQUFXLDRCQUE0QixDQUFDLEtBQWE7UUFDbkQsSUFBSSxDQUFDLDZCQUE2QixHQUFHLEtBQUssQ0FBQztJQUM3QyxDQUFDO0lBQ00saUNBQWlDO1FBQ3RDLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxTQUFTLENBQUM7SUFDakQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLGlDQUFpQztRQUMxQyxPQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztJQUM1QyxDQUFDO0lBSUQsSUFBVyx3QkFBd0I7UUFDakMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBQ0QsSUFBVyx3QkFBd0IsQ0FBQyxLQUFhO1FBQy9DLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxLQUFLLENBQUM7SUFDekMsQ0FBQztJQUNNLDZCQUE2QjtRQUNsQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsU0FBUyxDQUFDO0lBQzdDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyw2QkFBNkI7UUFDdEMsT0FBTyxJQUFJLENBQUMseUJBQXlCLENBQUM7SUFDeEMsQ0FBQztJQUlELElBQVcsd0JBQXdCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNELElBQVcsd0JBQXdCLENBQUMsS0FBYTtRQUMvQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO0lBQ3pDLENBQUM7SUFDTSw2QkFBNkI7UUFDbEMsSUFBSSxDQUFDLHlCQUF5QixHQUFHLFNBQVMsQ0FBQztJQUM3QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNkJBQTZCO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixDQUFDO0lBQ3hDLENBQUM7SUFJRCxJQUFXLEVBQUU7UUFDWCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBQ0QsSUFBVyxFQUFFLENBQUMsS0FBYTtRQUN6QixJQUFJLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQztJQUNuQixDQUFDO0lBQ00sT0FBTztRQUNaLElBQUksQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFDO0lBQ3ZCLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxPQUFPO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNsQixDQUFDO0lBSUQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBQ0QsSUFBVywyQkFBMkIsQ0FBQyxLQUFhO1FBQ2xELElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUlELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUNELElBQVcsNEJBQTRCLENBQUMsS0FBYTtRQUNuRCxJQUFJLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxDQUFDO0lBQzdDLENBQUM7SUFDTSxpQ0FBaUM7UUFDdEMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLFNBQVMsQ0FBQztJQUNqRCxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUNBQWlDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDO0lBQzVDLENBQUM7SUFJRCxJQUFXLGtCQUFrQjtRQUMzQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFDRCxJQUFXLGtCQUFrQixDQUFDLEtBQWE7UUFDekMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUNuQyxDQUFDO0lBQ00sdUJBQXVCO1FBQzVCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxTQUFTLENBQUM7SUFDdkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHVCQUF1QjtRQUNoQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUNsQyxDQUFDO0lBSUQsSUFBVyxxQkFBcUI7UUFDOUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxxQkFBcUIsQ0FBQyxLQUFhO1FBQzVDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDdEMsQ0FBQztJQUNNLDBCQUEwQjtRQUMvQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO0lBQzFDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQkFBMEI7UUFDbkMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUM7SUFDckMsQ0FBQztJQUlELElBQVcsOEJBQThCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUNELElBQVcsOEJBQThCLENBQUMsS0FBa0M7UUFDMUUsSUFBSSxDQUFDLCtCQUErQixHQUFHLEtBQUssQ0FBQztJQUMvQyxDQUFDO0lBQ00sbUNBQW1DO1FBQ3hDLElBQUksQ0FBQywrQkFBK0IsR0FBRyxTQUFTLENBQUM7SUFDbkQsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1DQUFtQztRQUM1QyxPQUFPLElBQUksQ0FBQywrQkFBK0IsQ0FBQztJQUM5QyxDQUFDO0lBSUQsSUFBVyxrQ0FBa0M7UUFDM0MsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBQ0QsSUFBVyxrQ0FBa0MsQ0FBQyxLQUFhO1FBQ3pELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUM7SUFDbkQsQ0FBQztJQUNNLHVDQUF1QztRQUM1QyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsU0FBUyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyx1Q0FBdUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsbUNBQW1DLENBQUM7SUFDbEQsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFrQztRQUMxRCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBQ00sbUJBQW1CO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDO0lBQ25DLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxtQkFBbUI7UUFDNUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFJRCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBQ00sc0JBQXNCO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHNCQUFzQjtRQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNqQyxDQUFDO0lBSUQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUlELElBQVcsY0FBYztRQUN2QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDRCxJQUFXLGNBQWMsQ0FBQyxLQUFhO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7SUFDTSxtQkFBbUI7UUFDeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLG1CQUFtQjtRQUM1QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUlELElBQVcsZUFBZTtRQUN4QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxJQUFXLGVBQWUsQ0FBQyxLQUFhO1FBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7SUFDaEMsQ0FBQztJQUNNLG9CQUFvQjtRQUN6QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsU0FBUyxDQUFDO0lBQ3BDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxvQkFBb0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7SUFDL0IsQ0FBQztJQUlELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLDZCQUE2QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBYTtRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7SUFDTSw0QkFBNEI7UUFDakMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLFNBQVMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsNEJBQTRCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZDLENBQUM7SUFJRCxJQUFXLGVBQWU7UUFDeEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0QsSUFBVyxlQUFlLENBQUMsS0FBYTtRQUN0QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQ2hDLENBQUM7SUFDTSxvQkFBb0I7UUFDekIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFNBQVMsQ0FBQztJQUNwQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7SUFFRCxZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFFRixvQkFBb0I7UUFDNUIsT0FBTztZQUNMLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDakYsVUFBVSxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3BELGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7WUFDN0YsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUNyRiw0QkFBNEIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1lBQ3JGLEVBQUUsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNyQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO1lBQzNGLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7WUFDOUYscUJBQXFCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUN4RSx3QkFBd0IsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1lBQzlFLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7WUFDakcsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQ0FBbUMsQ0FBQztZQUMxRyxlQUFlLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDL0QsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNyRSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ3JFLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1lBQy9ELGtCQUFrQixFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDbEUsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNuRixpQkFBaUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1NBQ2xFLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCO1FBQy9CLE1BQU0sS0FBSyxHQUFHO1lBQ1oseUJBQXlCLEVBQUU7Z0JBQ3pCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUNoRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGdDQUFnQyxFQUFFO2dCQUNoQyxLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztnQkFDckUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDakUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDRCQUE0QixFQUFFO2dCQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztnQkFDakUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELEVBQUUsRUFBRTtnQkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwrQkFBK0IsRUFBRTtnQkFDL0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7Z0JBQ3BFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQ0FBaUMsRUFBRTtnQkFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUM7Z0JBQ3JFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCx3QkFBd0IsRUFBRTtnQkFDeEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxpQ0FBaUMsRUFBRTtnQkFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUM7Z0JBQ3hFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCx1Q0FBdUMsRUFBRTtnQkFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsbUNBQW1DLENBQUM7Z0JBQzNFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxlQUFlLEVBQUU7Z0JBQ2YsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUN4RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1lBQ0QsZ0JBQWdCLEVBQUU7Z0JBQ2hCLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztnQkFDdkQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDeEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELDJCQUEyQixFQUFFO2dCQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztnQkFDaEUsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtZQUNELGlCQUFpQixFQUFFO2dCQUNqQixLQUFLLEVBQUUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDeEQsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsZ0JBQWdCLEVBQUUsUUFBUTthQUMzQjtTQUNGLENBQUM7UUFFRiw4QkFBOEI7UUFDOUIsT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUUsQ0FBQyxDQUFBO0lBQzVILENBQUM7O0FBMWdCSCxrREEyZ0JDOzs7QUF6Z0JDLG9CQUFvQjtBQUNwQixvQkFBb0I7QUFDcEIsb0JBQW9CO0FBQ0csa0NBQWMsR0FBRyxvQ0FBb0MsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWdcbi8vIGdlbmVyYXRlZCBmcm9tIHRlcnJhZm9ybSByZXNvdXJjZSBzY2hlbWFcblxuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBjZGt0biBmcm9tICdjZGt0bic7XG5cbi8vIENvbmZpZ3VyYXRpb25cblxuZXhwb3J0IGludGVyZmFjZSBEYXRhYmFzZUthZmthQ29uZmlnQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtTWV0YUFyZ3VtZW50cyB7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNhdXRvX2NyZWF0ZV90b3BpY3NfZW5hYmxlIERhdGFiYXNlS2Fma2FDb25maWcjYXV0b19jcmVhdGVfdG9waWNzX2VuYWJsZX1cbiAgKi9cbiAgcmVhZG9ubHkgYXV0b0NyZWF0ZVRvcGljc0VuYWJsZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2NsdXN0ZXJfaWQgRGF0YWJhc2VLYWZrYUNvbmZpZyNjbHVzdGVyX2lkfVxuICAqL1xuICByZWFkb25seSBjbHVzdGVySWQ6IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2dyb3VwX2luaXRpYWxfcmViYWxhbmNlX2RlbGF5X21zIERhdGFiYXNlS2Fma2FDb25maWcjZ3JvdXBfaW5pdGlhbF9yZWJhbGFuY2VfZGVsYXlfbXN9XG4gICovXG4gIHJlYWRvbmx5IGdyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXM/OiBudW1iZXI7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNncm91cF9tYXhfc2Vzc2lvbl90aW1lb3V0X21zIERhdGFiYXNlS2Fma2FDb25maWcjZ3JvdXBfbWF4X3Nlc3Npb25fdGltZW91dF9tc31cbiAgKi9cbiAgcmVhZG9ubHkgZ3JvdXBNYXhTZXNzaW9uVGltZW91dE1zPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjZ3JvdXBfbWluX3Nlc3Npb25fdGltZW91dF9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2dyb3VwX21pbl9zZXNzaW9uX3RpbWVvdXRfbXN9XG4gICovXG4gIHJlYWRvbmx5IGdyb3VwTWluU2Vzc2lvblRpbWVvdXRNcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2lkIERhdGFiYXNlS2Fma2FDb25maWcjaWR9XG4gICpcbiAgKiBQbGVhc2UgYmUgYXdhcmUgdGhhdCB0aGUgaWQgZmllbGQgaXMgYXV0b21hdGljYWxseSBhZGRlZCB0byBhbGwgcmVzb3VyY2VzIGluIFRlcnJhZm9ybSBwcm92aWRlcnMgdXNpbmcgYSBUZXJyYWZvcm0gcHJvdmlkZXIgU0RLIHZlcnNpb24gYmVsb3cgMi5cbiAgKiBJZiB5b3UgZXhwZXJpZW5jZSBwcm9ibGVtcyBzZXR0aW5nIHRoaXMgdmFsdWUgaXQgbWlnaHQgbm90IGJlIHNldHRhYmxlLiBQbGVhc2UgdGFrZSBhIGxvb2sgYXQgdGhlIHByb3ZpZGVyIGRvY3VtZW50YXRpb24gdG8gZW5zdXJlIGl0IHNob3VsZCBiZSBzZXR0YWJsZS5cbiAgKi9cbiAgcmVhZG9ubHkgaWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfY2xlYW5lcl9kZWxldGVfcmV0ZW50aW9uX21zIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX2NsZWFuZXJfZGVsZXRlX3JldGVudGlvbl9tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zPzogbnVtYmVyO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX2NsZWFuZXJfbWluX2NvbXBhY3Rpb25fbGFnX21zIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX2NsZWFuZXJfbWluX2NvbXBhY3Rpb25fbGFnX21zfVxuICAqL1xuICByZWFkb25seSBsb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX2ZsdXNoX2ludGVydmFsX21zIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX2ZsdXNoX2ludGVydmFsX21zfVxuICAqL1xuICByZWFkb25seSBsb2dGbHVzaEludGVydmFsTXM/OiBzdHJpbmc7XG4gIC8qKlxuICAqIERvY3MgYXQgVGVycmFmb3JtIFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyNsb2dfaW5kZXhfaW50ZXJ2YWxfYnl0ZXMgRGF0YWJhc2VLYWZrYUNvbmZpZyNsb2dfaW5kZXhfaW50ZXJ2YWxfYnl0ZXN9XG4gICovXG4gIHJlYWRvbmx5IGxvZ0luZGV4SW50ZXJ2YWxCeXRlcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19tZXNzYWdlX2Rvd25jb252ZXJzaW9uX2VuYWJsZSBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19tZXNzYWdlX2Rvd25jb252ZXJzaW9uX2VuYWJsZX1cbiAgKi9cbiAgcmVhZG9ubHkgbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX21lc3NhZ2VfdGltZXN0YW1wX2RpZmZlcmVuY2VfbWF4X21zIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX21lc3NhZ2VfdGltZXN0YW1wX2RpZmZlcmVuY2VfbWF4X21zfVxuICAqL1xuICByZWFkb25seSBsb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX3ByZWFsbG9jYXRlIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX3ByZWFsbG9jYXRlfVxuICAqL1xuICByZWFkb25seSBsb2dQcmVhbGxvY2F0ZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19yZXRlbnRpb25fYnl0ZXMgRGF0YWJhc2VLYWZrYUNvbmZpZyNsb2dfcmV0ZW50aW9uX2J5dGVzfVxuICAqL1xuICByZWFkb25seSBsb2dSZXRlbnRpb25CeXRlcz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19yZXRlbnRpb25faG91cnMgRGF0YWJhc2VLYWZrYUNvbmZpZyNsb2dfcmV0ZW50aW9uX2hvdXJzfVxuICAqL1xuICByZWFkb25seSBsb2dSZXRlbnRpb25Ib3Vycz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19yZXRlbnRpb25fbXMgRGF0YWJhc2VLYWZrYUNvbmZpZyNsb2dfcmV0ZW50aW9uX21zfVxuICAqL1xuICByZWFkb25seSBsb2dSZXRlbnRpb25Ncz86IHN0cmluZztcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI2xvZ19yb2xsX2ppdHRlcl9tcyBEYXRhYmFzZUthZmthQ29uZmlnI2xvZ19yb2xsX2ppdHRlcl9tc31cbiAgKi9cbiAgcmVhZG9ubHkgbG9nUm9sbEppdHRlck1zPzogc3RyaW5nO1xuICAvKipcbiAgKiBEb2NzIGF0IFRlcnJhZm9ybSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjbG9nX3NlZ21lbnRfZGVsZXRlX2RlbGF5X21zIERhdGFiYXNlS2Fma2FDb25maWcjbG9nX3NlZ21lbnRfZGVsZXRlX2RlbGF5X21zfVxuICAqL1xuICByZWFkb25seSBsb2dTZWdtZW50RGVsZXRlRGVsYXlNcz86IG51bWJlcjtcbiAgLyoqXG4gICogRG9jcyBhdCBUZXJyYWZvcm0gUmVnaXN0cnk6IHtAbGluayBodHRwczovL3JlZ2lzdHJ5LnRlcnJhZm9ybS5pby9wcm92aWRlcnMvZGlnaXRhbG9jZWFuL2RpZ2l0YWxvY2Vhbi8yLjg3LjAvZG9jcy9yZXNvdXJjZXMvZGF0YWJhc2Vfa2Fma2FfY29uZmlnI21lc3NhZ2VfbWF4X2J5dGVzIERhdGFiYXNlS2Fma2FDb25maWcjbWVzc2FnZV9tYXhfYnl0ZXN9XG4gICovXG4gIHJlYWRvbmx5IG1lc3NhZ2VNYXhCeXRlcz86IG51bWJlcjtcbn1cblxuLyoqXG4qIFJlcHJlc2VudHMgYSB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfa2Fma2FfY29uZmlnfVxuKi9cbmV4cG9ydCBjbGFzcyBEYXRhYmFzZUthZmthQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtUmVzb3VyY2Uge1xuXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIC8vIFNUQVRJQyBQUk9QRVJUSUVTXG4gIC8vID09PT09PT09PT09PT09PT09XG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgdGZSZXNvdXJjZVR5cGUgPSBcImRpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9rYWZrYV9jb25maWdcIjtcblxuICAvLyA9PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgTWV0aG9kc1xuICAvLyA9PT09PT09PT09PT09PVxuICAvKipcbiAgKiBHZW5lcmF0ZXMgQ0RLVE4gY29kZSBmb3IgaW1wb3J0aW5nIGEgRGF0YWJhc2VLYWZrYUNvbmZpZyByZXNvdXJjZSB1cG9uIHJ1bm5pbmcgXCJjZGt0biBwbGFuIDxzdGFjay1uYW1lPlwiXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaW1wb3J0VG9JZCBUaGUgY29uc3RydWN0IGlkIHVzZWQgaW4gdGhlIGdlbmVyYXRlZCBjb25maWcgZm9yIHRoZSBEYXRhYmFzZUthZmthQ29uZmlnIHRvIGltcG9ydFxuICAqIEBwYXJhbSBpbXBvcnRGcm9tSWQgVGhlIGlkIG9mIHRoZSBleGlzdGluZyBEYXRhYmFzZUthZmthQ29uZmlnIHRoYXQgc2hvdWxkIGJlIGltcG9ydGVkLiBSZWZlciB0byB0aGUge0BsaW5rIGh0dHBzOi8vcmVnaXN0cnkudGVycmFmb3JtLmlvL3Byb3ZpZGVycy9kaWdpdGFsb2NlYW4vZGlnaXRhbG9jZWFuLzIuODcuMC9kb2NzL3Jlc291cmNlcy9kYXRhYmFzZV9rYWZrYV9jb25maWcjaW1wb3J0IGltcG9ydCBzZWN0aW9ufSBpbiB0aGUgZG9jdW1lbnRhdGlvbiBvZiB0aGlzIHJlc291cmNlIGZvciB0aGUgaWQgdG8gdXNlXG4gICogQHBhcmFtIHByb3ZpZGVyPyBPcHRpb25hbCBpbnN0YW5jZSBvZiB0aGUgcHJvdmlkZXIgd2hlcmUgdGhlIERhdGFiYXNlS2Fma2FDb25maWcgdG8gaW1wb3J0IGlzIGZvdW5kXG4gICovXG4gIHB1YmxpYyBzdGF0aWMgZ2VuZXJhdGVDb25maWdGb3JJbXBvcnQoc2NvcGU6IENvbnN0cnVjdCwgaW1wb3J0VG9JZDogc3RyaW5nLCBpbXBvcnRGcm9tSWQ6IHN0cmluZywgcHJvdmlkZXI/OiBjZGt0bi5UZXJyYWZvcm1Qcm92aWRlcikge1xuICAgICAgICByZXR1cm4gbmV3IGNka3RuLkltcG9ydGFibGVSZXNvdXJjZShzY29wZSwgaW1wb3J0VG9JZCwgeyB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6IFwiZGlnaXRhbG9jZWFuX2RhdGFiYXNlX2thZmthX2NvbmZpZ1wiLCBpbXBvcnRJZDogaW1wb3J0RnJvbUlkLCBwcm92aWRlciB9KTtcbiAgICAgIH1cblxuICAvLyA9PT09PT09PT09PVxuICAvLyBJTklUSUFMSVpFUlxuICAvLyA9PT09PT09PT09PVxuXG4gIC8qKlxuICAqIENyZWF0ZSBhIG5ldyB7QGxpbmsgaHR0cHM6Ly9yZWdpc3RyeS50ZXJyYWZvcm0uaW8vcHJvdmlkZXJzL2RpZ2l0YWxvY2Vhbi9kaWdpdGFsb2NlYW4vMi44Ny4wL2RvY3MvcmVzb3VyY2VzL2RhdGFiYXNlX2thZmthX2NvbmZpZyBkaWdpdGFsb2NlYW5fZGF0YWJhc2Vfa2Fma2FfY29uZmlnfSBSZXNvdXJjZVxuICAqXG4gICogQHBhcmFtIHNjb3BlIFRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBjb25zdHJ1Y3RcbiAgKiBAcGFyYW0gaWQgVGhlIHNjb3BlZCBjb25zdHJ1Y3QgSUQuIE11c3QgYmUgdW5pcXVlIGFtb25nc3Qgc2libGluZ3MgaW4gdGhlIHNhbWUgc2NvcGVcbiAgKiBAcGFyYW0gb3B0aW9ucyBEYXRhYmFzZUthZmthQ29uZmlnQ29uZmlnXG4gICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBjb25maWc6IERhdGFiYXNlS2Fma2FDb25maWdDb25maWcpIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIHRlcnJhZm9ybVJlc291cmNlVHlwZTogJ2RpZ2l0YWxvY2Vhbl9kYXRhYmFzZV9rYWZrYV9jb25maWcnLFxuICAgICAgdGVycmFmb3JtR2VuZXJhdG9yTWV0YWRhdGE6IHtcbiAgICAgICAgcHJvdmlkZXJOYW1lOiAnZGlnaXRhbG9jZWFuJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uOiAnMi44Ny4wJyxcbiAgICAgICAgcHJvdmlkZXJWZXJzaW9uQ29uc3RyYWludDogJzIuODcuMCdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcjogY29uZmlnLnByb3ZpZGVyLFxuICAgICAgZGVwZW5kc09uOiBjb25maWcuZGVwZW5kc09uLFxuICAgICAgY291bnQ6IGNvbmZpZy5jb3VudCxcbiAgICAgIGxpZmVjeWNsZTogY29uZmlnLmxpZmVjeWNsZSxcbiAgICAgIHByb3Zpc2lvbmVyczogY29uZmlnLnByb3Zpc2lvbmVycyxcbiAgICAgIGNvbm5lY3Rpb246IGNvbmZpZy5jb25uZWN0aW9uLFxuICAgICAgZm9yRWFjaDogY29uZmlnLmZvckVhY2hcbiAgICB9KTtcbiAgICB0aGlzLl9hdXRvQ3JlYXRlVG9waWNzRW5hYmxlID0gY29uZmlnLmF1dG9DcmVhdGVUb3BpY3NFbmFibGU7XG4gICAgdGhpcy5fY2x1c3RlcklkID0gY29uZmlnLmNsdXN0ZXJJZDtcbiAgICB0aGlzLl9ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zID0gY29uZmlnLmdyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXM7XG4gICAgdGhpcy5fZ3JvdXBNYXhTZXNzaW9uVGltZW91dE1zID0gY29uZmlnLmdyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcztcbiAgICB0aGlzLl9ncm91cE1pblNlc3Npb25UaW1lb3V0TXMgPSBjb25maWcuZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zO1xuICAgIHRoaXMuX2lkID0gY29uZmlnLmlkO1xuICAgIHRoaXMuX2xvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcyA9IGNvbmZpZy5sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXM7XG4gICAgdGhpcy5fbG9nQ2xlYW5lck1pbkNvbXBhY3Rpb25MYWdNcyA9IGNvbmZpZy5sb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zO1xuICAgIHRoaXMuX2xvZ0ZsdXNoSW50ZXJ2YWxNcyA9IGNvbmZpZy5sb2dGbHVzaEludGVydmFsTXM7XG4gICAgdGhpcy5fbG9nSW5kZXhJbnRlcnZhbEJ5dGVzID0gY29uZmlnLmxvZ0luZGV4SW50ZXJ2YWxCeXRlcztcbiAgICB0aGlzLl9sb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGUgPSBjb25maWcubG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlO1xuICAgIHRoaXMuX2xvZ01lc3NhZ2VUaW1lc3RhbXBEaWZmZXJlbmNlTWF4TXMgPSBjb25maWcubG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcztcbiAgICB0aGlzLl9sb2dQcmVhbGxvY2F0ZSA9IGNvbmZpZy5sb2dQcmVhbGxvY2F0ZTtcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25CeXRlcyA9IGNvbmZpZy5sb2dSZXRlbnRpb25CeXRlcztcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25Ib3VycyA9IGNvbmZpZy5sb2dSZXRlbnRpb25Ib3VycztcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25NcyA9IGNvbmZpZy5sb2dSZXRlbnRpb25NcztcbiAgICB0aGlzLl9sb2dSb2xsSml0dGVyTXMgPSBjb25maWcubG9nUm9sbEppdHRlck1zO1xuICAgIHRoaXMuX2xvZ1NlZ21lbnREZWxldGVEZWxheU1zID0gY29uZmlnLmxvZ1NlZ21lbnREZWxldGVEZWxheU1zO1xuICAgIHRoaXMuX21lc3NhZ2VNYXhCeXRlcyA9IGNvbmZpZy5tZXNzYWdlTWF4Qnl0ZXM7XG4gIH1cblxuICAvLyA9PT09PT09PT09XG4gIC8vIEFUVFJJQlVURVNcbiAgLy8gPT09PT09PT09PVxuXG4gIC8vIGF1dG9fY3JlYXRlX3RvcGljc19lbmFibGUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hdXRvQ3JlYXRlVG9waWNzRW5hYmxlPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBhdXRvQ3JlYXRlVG9waWNzRW5hYmxlKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2F1dG9fY3JlYXRlX3RvcGljc19lbmFibGUnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGF1dG9DcmVhdGVUb3BpY3NFbmFibGUodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2F1dG9DcmVhdGVUb3BpY3NFbmFibGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRBdXRvQ3JlYXRlVG9waWNzRW5hYmxlKCkge1xuICAgIHRoaXMuX2F1dG9DcmVhdGVUb3BpY3NFbmFibGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGF1dG9DcmVhdGVUb3BpY3NFbmFibGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b0NyZWF0ZVRvcGljc0VuYWJsZTtcbiAgfVxuXG4gIC8vIGNsdXN0ZXJfaWQgLSBjb21wdXRlZDogZmFsc2UsIG9wdGlvbmFsOiBmYWxzZSwgcmVxdWlyZWQ6IHRydWVcbiAgcHJpdmF0ZSBfY2x1c3RlcklkPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBjbHVzdGVySWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdjbHVzdGVyX2lkJyk7XG4gIH1cbiAgcHVibGljIHNldCBjbHVzdGVySWQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2NsdXN0ZXJJZCA9IHZhbHVlO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBjbHVzdGVySWRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2x1c3RlcklkO1xuICB9XG5cbiAgLy8gZ3JvdXBfaW5pdGlhbF9yZWJhbGFuY2VfZGVsYXlfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnZ3JvdXBfaW5pdGlhbF9yZWJhbGFuY2VfZGVsYXlfbXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGdyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXModmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuX2dyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRHcm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zKCkge1xuICAgIHRoaXMuX2dyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGdyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZ3JvdXBJbml0aWFsUmViYWxhbmNlRGVsYXlNcztcbiAgfVxuXG4gIC8vIGdyb3VwX21heF9zZXNzaW9uX3RpbWVvdXRfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9ncm91cE1heFNlc3Npb25UaW1lb3V0TXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGdyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2dyb3VwX21heF9zZXNzaW9uX3RpbWVvdXRfbXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGdyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fZ3JvdXBNYXhTZXNzaW9uVGltZW91dE1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0R3JvdXBNYXhTZXNzaW9uVGltZW91dE1zKCkge1xuICAgIHRoaXMuX2dyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgZ3JvdXBNYXhTZXNzaW9uVGltZW91dE1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2dyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcztcbiAgfVxuXG4gIC8vIGdyb3VwX21pbl9zZXNzaW9uX3RpbWVvdXRfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9ncm91cE1pblNlc3Npb25UaW1lb3V0TXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGdyb3VwTWluU2Vzc2lvblRpbWVvdXRNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2dyb3VwX21pbl9zZXNzaW9uX3RpbWVvdXRfbXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGdyb3VwTWluU2Vzc2lvblRpbWVvdXRNcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0R3JvdXBNaW5TZXNzaW9uVGltZW91dE1zKCkge1xuICAgIHRoaXMuX2dyb3VwTWluU2Vzc2lvblRpbWVvdXRNcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgZ3JvdXBNaW5TZXNzaW9uVGltZW91dE1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2dyb3VwTWluU2Vzc2lvblRpbWVvdXRNcztcbiAgfVxuXG4gIC8vIGlkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfaWQ/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGlkKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnaWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGlkKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9pZCA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldElkKCkge1xuICAgIHRoaXMuX2lkID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBpZElucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9pZDtcbiAgfVxuXG4gIC8vIGxvZ19jbGVhbmVyX2RlbGV0ZV9yZXRlbnRpb25fbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGxvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xvZ19jbGVhbmVyX2RlbGV0ZV9yZXRlbnRpb25fbXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25Ncyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zKCkge1xuICAgIHRoaXMuX2xvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nQ2xlYW5lckRlbGV0ZVJldGVudGlvbk1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcztcbiAgfVxuXG4gIC8vIGxvZ19jbGVhbmVyX21pbl9jb21wYWN0aW9uX2xhZ19tcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXM/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGxvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdsb2dfY2xlYW5lcl9taW5fY29tcGFjdGlvbl9sYWdfbXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXModmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dDbGVhbmVyTWluQ29tcGFjdGlvbkxhZ01zKCkge1xuICAgIHRoaXMuX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nQ2xlYW5lck1pbkNvbXBhY3Rpb25MYWdNcztcbiAgfVxuXG4gIC8vIGxvZ19mbHVzaF9pbnRlcnZhbF9tcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ0ZsdXNoSW50ZXJ2YWxNcz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgbG9nRmx1c2hJbnRlcnZhbE1zKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX2ZsdXNoX2ludGVydmFsX21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dGbHVzaEludGVydmFsTXModmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2xvZ0ZsdXNoSW50ZXJ2YWxNcyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ0ZsdXNoSW50ZXJ2YWxNcygpIHtcbiAgICB0aGlzLl9sb2dGbHVzaEludGVydmFsTXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ0ZsdXNoSW50ZXJ2YWxNc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dGbHVzaEludGVydmFsTXM7XG4gIH1cblxuICAvLyBsb2dfaW5kZXhfaW50ZXJ2YWxfYnl0ZXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dJbmRleEludGVydmFsQnl0ZXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGxvZ0luZGV4SW50ZXJ2YWxCeXRlcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xvZ19pbmRleF9pbnRlcnZhbF9ieXRlcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nSW5kZXhJbnRlcnZhbEJ5dGVzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9sb2dJbmRleEludGVydmFsQnl0ZXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dJbmRleEludGVydmFsQnl0ZXMoKSB7XG4gICAgdGhpcy5fbG9nSW5kZXhJbnRlcnZhbEJ5dGVzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dJbmRleEludGVydmFsQnl0ZXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nSW5kZXhJbnRlcnZhbEJ5dGVzO1xuICB9XG5cbiAgLy8gbG9nX21lc3NhZ2VfZG93bmNvbnZlcnNpb25fZW5hYmxlIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCBsb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnbG9nX21lc3NhZ2VfZG93bmNvbnZlcnNpb25fZW5hYmxlJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGUodmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2xvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZSA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZSgpIHtcbiAgICB0aGlzLl9sb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGUgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ01lc3NhZ2VEb3duY29udmVyc2lvbkVuYWJsZUlucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dNZXNzYWdlRG93bmNvbnZlcnNpb25FbmFibGU7XG4gIH1cblxuICAvLyBsb2dfbWVzc2FnZV90aW1lc3RhbXBfZGlmZmVyZW5jZV9tYXhfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zPzogc3RyaW5nOyBcbiAgcHVibGljIGdldCBsb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX21lc3NhZ2VfdGltZXN0YW1wX2RpZmZlcmVuY2VfbWF4X21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9sb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcygpIHtcbiAgICB0aGlzLl9sb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dNZXNzYWdlVGltZXN0YW1wRGlmZmVyZW5jZU1heE1zSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ01lc3NhZ2VUaW1lc3RhbXBEaWZmZXJlbmNlTWF4TXM7XG4gIH1cblxuICAvLyBsb2dfcHJlYWxsb2NhdGUgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dQcmVhbGxvY2F0ZT86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgbG9nUHJlYWxsb2NhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnbG9nX3ByZWFsbG9jYXRlJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dQcmVhbGxvY2F0ZSh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fbG9nUHJlYWxsb2NhdGUgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dQcmVhbGxvY2F0ZSgpIHtcbiAgICB0aGlzLl9sb2dQcmVhbGxvY2F0ZSA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nUHJlYWxsb2NhdGVJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nUHJlYWxsb2NhdGU7XG4gIH1cblxuICAvLyBsb2dfcmV0ZW50aW9uX2J5dGVzIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nUmV0ZW50aW9uQnl0ZXM/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGxvZ1JldGVudGlvbkJ5dGVzKCkge1xuICAgIHJldHVybiB0aGlzLmdldFN0cmluZ0F0dHJpYnV0ZSgnbG9nX3JldGVudGlvbl9ieXRlcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nUmV0ZW50aW9uQnl0ZXModmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX2xvZ1JldGVudGlvbkJ5dGVzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TG9nUmV0ZW50aW9uQnl0ZXMoKSB7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uQnl0ZXMgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGxvZ1JldGVudGlvbkJ5dGVzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZ1JldGVudGlvbkJ5dGVzO1xuICB9XG5cbiAgLy8gbG9nX3JldGVudGlvbl9ob3VycyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2xvZ1JldGVudGlvbkhvdXJzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBsb2dSZXRlbnRpb25Ib3VycygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXROdW1iZXJBdHRyaWJ1dGUoJ2xvZ19yZXRlbnRpb25faG91cnMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGxvZ1JldGVudGlvbkhvdXJzKHZhbHVlOiBudW1iZXIpIHtcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25Ib3VycyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldExvZ1JldGVudGlvbkhvdXJzKCkge1xuICAgIHRoaXMuX2xvZ1JldGVudGlvbkhvdXJzID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dSZXRlbnRpb25Ib3Vyc0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9sb2dSZXRlbnRpb25Ib3VycztcbiAgfVxuXG4gIC8vIGxvZ19yZXRlbnRpb25fbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dSZXRlbnRpb25Ncz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgbG9nUmV0ZW50aW9uTXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdsb2dfcmV0ZW50aW9uX21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dSZXRlbnRpb25Ncyh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fbG9nUmV0ZW50aW9uTXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dSZXRlbnRpb25NcygpIHtcbiAgICB0aGlzLl9sb2dSZXRlbnRpb25NcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nUmV0ZW50aW9uTXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nUmV0ZW50aW9uTXM7XG4gIH1cblxuICAvLyBsb2dfcm9sbF9qaXR0ZXJfbXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9sb2dSb2xsSml0dGVyTXM/OiBzdHJpbmc7IFxuICBwdWJsaWMgZ2V0IGxvZ1JvbGxKaXR0ZXJNcygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2xvZ19yb2xsX2ppdHRlcl9tcycpO1xuICB9XG4gIHB1YmxpYyBzZXQgbG9nUm9sbEppdHRlck1zKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9sb2dSb2xsSml0dGVyTXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dSb2xsSml0dGVyTXMoKSB7XG4gICAgdGhpcy5fbG9nUm9sbEppdHRlck1zID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBsb2dSb2xsSml0dGVyTXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nUm9sbEppdHRlck1zO1xuICB9XG5cbiAgLy8gbG9nX3NlZ21lbnRfZGVsZXRlX2RlbGF5X21zIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfbG9nU2VnbWVudERlbGV0ZURlbGF5TXM/OiBudW1iZXI7IFxuICBwdWJsaWMgZ2V0IGxvZ1NlZ21lbnREZWxldGVEZWxheU1zKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbG9nX3NlZ21lbnRfZGVsZXRlX2RlbGF5X21zJyk7XG4gIH1cbiAgcHVibGljIHNldCBsb2dTZWdtZW50RGVsZXRlRGVsYXlNcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbG9nU2VnbWVudERlbGV0ZURlbGF5TXMgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRMb2dTZWdtZW50RGVsZXRlRGVsYXlNcygpIHtcbiAgICB0aGlzLl9sb2dTZWdtZW50RGVsZXRlRGVsYXlNcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbG9nU2VnbWVudERlbGV0ZURlbGF5TXNJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nU2VnbWVudERlbGV0ZURlbGF5TXM7XG4gIH1cblxuICAvLyBtZXNzYWdlX21heF9ieXRlcyAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX21lc3NhZ2VNYXhCeXRlcz86IG51bWJlcjsgXG4gIHB1YmxpYyBnZXQgbWVzc2FnZU1heEJ5dGVzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnbWVzc2FnZV9tYXhfYnl0ZXMnKTtcbiAgfVxuICBwdWJsaWMgc2V0IG1lc3NhZ2VNYXhCeXRlcyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fbWVzc2FnZU1heEJ5dGVzID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0TWVzc2FnZU1heEJ5dGVzKCkge1xuICAgIHRoaXMuX21lc3NhZ2VNYXhCeXRlcyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgbWVzc2FnZU1heEJ5dGVzSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX21lc3NhZ2VNYXhCeXRlcztcbiAgfVxuXG4gIC8vID09PT09PT09PVxuICAvLyBTWU5USEVTSVNcbiAgLy8gPT09PT09PT09XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICByZXR1cm4ge1xuICAgICAgYXV0b19jcmVhdGVfdG9waWNzX2VuYWJsZTogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2F1dG9DcmVhdGVUb3BpY3NFbmFibGUpLFxuICAgICAgY2x1c3Rlcl9pZDogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgIGdyb3VwX2luaXRpYWxfcmViYWxhbmNlX2RlbGF5X21zOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9ncm91cEluaXRpYWxSZWJhbGFuY2VEZWxheU1zKSxcbiAgICAgIGdyb3VwX21heF9zZXNzaW9uX3RpbWVvdXRfbXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2dyb3VwTWF4U2Vzc2lvblRpbWVvdXRNcyksXG4gICAgICBncm91cF9taW5fc2Vzc2lvbl90aW1lb3V0X21zOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9ncm91cE1pblNlc3Npb25UaW1lb3V0TXMpLFxuICAgICAgaWQ6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2lkKSxcbiAgICAgIGxvZ19jbGVhbmVyX2RlbGV0ZV9yZXRlbnRpb25fbXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2xvZ0NsZWFuZXJEZWxldGVSZXRlbnRpb25NcyksXG4gICAgICBsb2dfY2xlYW5lcl9taW5fY29tcGFjdGlvbl9sYWdfbXM6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXMpLFxuICAgICAgbG9nX2ZsdXNoX2ludGVydmFsX21zOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9sb2dGbHVzaEludGVydmFsTXMpLFxuICAgICAgbG9nX2luZGV4X2ludGVydmFsX2J5dGVzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9sb2dJbmRleEludGVydmFsQnl0ZXMpLFxuICAgICAgbG9nX21lc3NhZ2VfZG93bmNvbnZlcnNpb25fZW5hYmxlOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlKSxcbiAgICAgIGxvZ19tZXNzYWdlX3RpbWVzdGFtcF9kaWZmZXJlbmNlX21heF9tczogY2RrdG4uc3RyaW5nVG9UZXJyYWZvcm0odGhpcy5fbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcyksXG4gICAgICBsb2dfcHJlYWxsb2NhdGU6IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9sb2dQcmVhbGxvY2F0ZSksXG4gICAgICBsb2dfcmV0ZW50aW9uX2J5dGVzOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9sb2dSZXRlbnRpb25CeXRlcyksXG4gICAgICBsb2dfcmV0ZW50aW9uX2hvdXJzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9sb2dSZXRlbnRpb25Ib3VycyksXG4gICAgICBsb2dfcmV0ZW50aW9uX21zOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9sb2dSZXRlbnRpb25NcyksXG4gICAgICBsb2dfcm9sbF9qaXR0ZXJfbXM6IGNka3RuLnN0cmluZ1RvVGVycmFmb3JtKHRoaXMuX2xvZ1JvbGxKaXR0ZXJNcyksXG4gICAgICBsb2dfc2VnbWVudF9kZWxldGVfZGVsYXlfbXM6IGNka3RuLm51bWJlclRvVGVycmFmb3JtKHRoaXMuX2xvZ1NlZ21lbnREZWxldGVEZWxheU1zKSxcbiAgICAgIG1lc3NhZ2VfbWF4X2J5dGVzOiBjZGt0bi5udW1iZXJUb1RlcnJhZm9ybSh0aGlzLl9tZXNzYWdlTWF4Qnl0ZXMpLFxuICAgIH07XG4gIH1cblxuICBwcm90ZWN0ZWQgc3ludGhlc2l6ZUhjbEF0dHJpYnV0ZXMoKTogeyBbbmFtZTogc3RyaW5nXTogYW55IH0ge1xuICAgIGNvbnN0IGF0dHJzID0ge1xuICAgICAgYXV0b19jcmVhdGVfdG9waWNzX2VuYWJsZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2F1dG9DcmVhdGVUb3BpY3NFbmFibGUpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgY2x1c3Rlcl9pZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fY2x1c3RlcklkKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgZ3JvdXBfaW5pdGlhbF9yZWJhbGFuY2VfZGVsYXlfbXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLm51bWJlclRvSGNsVGVycmFmb3JtKHRoaXMuX2dyb3VwSW5pdGlhbFJlYmFsYW5jZURlbGF5TXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBncm91cF9tYXhfc2Vzc2lvbl90aW1lb3V0X21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9ncm91cE1heFNlc3Npb25UaW1lb3V0TXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBncm91cF9taW5fc2Vzc2lvbl90aW1lb3V0X21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9ncm91cE1pblNlc3Npb25UaW1lb3V0TXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBpZDoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5faWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBsb2dfY2xlYW5lcl9kZWxldGVfcmV0ZW50aW9uX21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dDbGVhbmVyRGVsZXRlUmV0ZW50aW9uTXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBsb2dfY2xlYW5lcl9taW5fY29tcGFjdGlvbl9sYWdfbXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ0NsZWFuZXJNaW5Db21wYWN0aW9uTGFnTXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgICBsb2dfZmx1c2hfaW50ZXJ2YWxfbXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ0ZsdXNoSW50ZXJ2YWxNcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19pbmRleF9pbnRlcnZhbF9ieXRlczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nSW5kZXhJbnRlcnZhbEJ5dGVzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwibnVtYmVyXCIsXG4gICAgICB9LFxuICAgICAgbG9nX21lc3NhZ2VfZG93bmNvbnZlcnNpb25fZW5hYmxlOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nTWVzc2FnZURvd25jb252ZXJzaW9uRW5hYmxlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGxvZ19tZXNzYWdlX3RpbWVzdGFtcF9kaWZmZXJlbmNlX21heF9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nTWVzc2FnZVRpbWVzdGFtcERpZmZlcmVuY2VNYXhNcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19wcmVhbGxvY2F0ZToge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ1ByZWFsbG9jYXRlKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGxvZ19yZXRlbnRpb25fYnl0ZXM6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX2xvZ1JldGVudGlvbkJ5dGVzKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9nX3JldGVudGlvbl9ob3Vyczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nUmV0ZW50aW9uSG91cnMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgICBsb2dfcmV0ZW50aW9uX21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5zdHJpbmdUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dSZXRlbnRpb25NcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGxvZ19yb2xsX2ppdHRlcl9tczoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fbG9nUm9sbEppdHRlck1zKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwic3RyaW5nXCIsXG4gICAgICB9LFxuICAgICAgbG9nX3NlZ21lbnRfZGVsZXRlX2RlbGF5X21zOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9sb2dTZWdtZW50RGVsZXRlRGVsYXlNcyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIG1lc3NhZ2VfbWF4X2J5dGVzOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5udW1iZXJUb0hjbFRlcnJhZm9ybSh0aGlzLl9tZXNzYWdlTWF4Qnl0ZXMpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJudW1iZXJcIixcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIC8vIHJlbW92ZSB1bmRlZmluZWQgYXR0cmlidXRlc1xuICAgIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoYXR0cnMpLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS52YWx1ZSAhPT0gdW5kZWZpbmVkICkpXG4gIH1cbn1cbiJdfQ==