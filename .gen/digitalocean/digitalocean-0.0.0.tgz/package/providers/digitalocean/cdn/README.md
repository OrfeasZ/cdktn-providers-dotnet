# `digitalocean_cdn`

Refer to the Terraform Registry for docs: [`digitalocean_cdn`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/cdn).
