import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CdnConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of a DigitalOcean managed TLS certificate for use with custom domains
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#certificate_id Cdn#certificate_id}
    */
    readonly certificateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#certificate_name Cdn#certificate_name}
    */
    readonly certificateName?: string;
    /**
    * fully qualified domain name (FQDN) for custom subdomain, (requires certificate_id)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#custom_domain Cdn#custom_domain}
    */
    readonly customDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#id Cdn#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * fully qualified domain name (FQDN) for the origin server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#origin Cdn#origin}
    */
    readonly origin: string;
    /**
    * The amount of time the content is cached in the CDN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#ttl Cdn#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn digitalocean_cdn}
*/
export declare class Cdn extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_cdn";
    /**
    * Generates CDKTN code for importing a Cdn resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Cdn to import
    * @param importFromId The id of the existing Cdn that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Cdn to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/cdn digitalocean_cdn} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnConfig
    */
    constructor(scope: Construct, id: string, config: CdnConfig);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    resetCertificateId(): void;
    get certificateIdInput(): string | undefined;
    private _certificateName?;
    get certificateName(): string;
    set certificateName(value: string);
    resetCertificateName(): void;
    get certificateNameInput(): string | undefined;
    get createdAt(): string;
    private _customDomain?;
    get customDomain(): string;
    set customDomain(value: string);
    resetCustomDomain(): void;
    get customDomainInput(): string | undefined;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _origin?;
    get origin(): string;
    set origin(value: string);
    get originInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
