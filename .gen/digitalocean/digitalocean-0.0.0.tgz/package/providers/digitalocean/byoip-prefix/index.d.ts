import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ByoipPrefixConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix#advertised ByoipPrefix#advertised}
    */
    readonly advertised?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix#id ByoipPrefix#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix#prefix ByoipPrefix#prefix}
    */
    readonly prefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix#region ByoipPrefix#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix#signature ByoipPrefix#signature}
    */
    readonly signature?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix digitalocean_byoip_prefix}
*/
export declare class ByoipPrefix extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_byoip_prefix";
    /**
    * Generates CDKTN code for importing a ByoipPrefix resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ByoipPrefix to import
    * @param importFromId The id of the existing ByoipPrefix that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ByoipPrefix to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/byoip_prefix digitalocean_byoip_prefix} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ByoipPrefixConfig
    */
    constructor(scope: Construct, id: string, config: ByoipPrefixConfig);
    private _advertised?;
    get advertised(): boolean | cdktn.IResolvable;
    set advertised(value: boolean | cdktn.IResolvable);
    resetAdvertised(): void;
    get advertisedInput(): boolean | cdktn.IResolvable | undefined;
    get failureReason(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _signature?;
    get signature(): string;
    set signature(value: string);
    resetSignature(): void;
    get signatureInput(): string | undefined;
    get status(): string;
    get uuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
