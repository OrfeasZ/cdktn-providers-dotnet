import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanByoipPrefixConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/byoip_prefix#id DataDigitaloceanByoipPrefix#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the BYOIP prefix
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/byoip_prefix#uuid DataDigitaloceanByoipPrefix#uuid}
    */
    readonly uuid: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/byoip_prefix digitalocean_byoip_prefix}
*/
export declare class DataDigitaloceanByoipPrefix extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_byoip_prefix";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanByoipPrefix resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanByoipPrefix to import
    * @param importFromId The id of the existing DataDigitaloceanByoipPrefix that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/byoip_prefix#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanByoipPrefix to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/byoip_prefix digitalocean_byoip_prefix} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanByoipPrefixConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanByoipPrefixConfig);
    get advertised(): cdktn.IResolvable;
    get failureReason(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get prefix(): string;
    get region(): string;
    get status(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
