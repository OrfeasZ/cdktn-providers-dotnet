# `data_digitalocean_byoip_prefix`

Refer to the Terraform Registry for docs: [`data_digitalocean_byoip_prefix`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/byoip_prefix).
