import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#id DataDigitaloceanTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#filter DataDigitaloceanTags#filter}
    */
    readonly filter?: DataDigitaloceanTagsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#sort DataDigitaloceanTags#sort}
    */
    readonly sort?: DataDigitaloceanTagsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanTagsTags {
}
export declare function dataDigitaloceanTagsTagsToTerraform(struct?: DataDigitaloceanTagsTags): any;
export declare function dataDigitaloceanTagsTagsToHclTerraform(struct?: DataDigitaloceanTagsTags): any;
export declare class DataDigitaloceanTagsTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanTagsTags | undefined;
    set internalValue(value: DataDigitaloceanTagsTags | undefined);
    get databasesCount(): number;
    get dropletsCount(): number;
    get imagesCount(): number;
    get name(): string;
    get totalResourceCount(): number;
    get volumeSnapshotsCount(): number;
    get volumesCount(): number;
}
export declare class DataDigitaloceanTagsTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanTagsTagsOutputReference;
}
export interface DataDigitaloceanTagsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#all DataDigitaloceanTags#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#key DataDigitaloceanTags#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#match_by DataDigitaloceanTags#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#values DataDigitaloceanTags#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanTagsFilterToTerraform(struct?: DataDigitaloceanTagsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanTagsFilterToHclTerraform(struct?: DataDigitaloceanTagsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanTagsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanTagsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanTagsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanTagsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanTagsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanTagsFilterOutputReference;
}
export interface DataDigitaloceanTagsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#direction DataDigitaloceanTags#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#key DataDigitaloceanTags#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanTagsSortToTerraform(struct?: DataDigitaloceanTagsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanTagsSortToHclTerraform(struct?: DataDigitaloceanTagsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanTagsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanTagsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanTagsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanTagsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanTagsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanTagsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags digitalocean_tags}
*/
export declare class DataDigitaloceanTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_tags";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanTags to import
    * @param importFromId The id of the existing DataDigitaloceanTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/tags digitalocean_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanTagsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanTagsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tags;
    get tags(): DataDigitaloceanTagsTagsList;
    private _filter;
    get filter(): DataDigitaloceanTagsFilterList;
    putFilter(value: DataDigitaloceanTagsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanTagsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanTagsSortList;
    putSort(value: DataDigitaloceanTagsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanTagsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
