import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall#cluster_id DatabaseFirewall#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall#id DatabaseFirewall#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall#rule DatabaseFirewall#rule}
    */
    readonly rule: DatabaseFirewallRule[] | cdktn.IResolvable;
}
export interface DatabaseFirewallRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall#type DatabaseFirewall#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall#value DatabaseFirewall#value}
    */
    readonly value: string;
}
export declare function databaseFirewallRuleToTerraform(struct?: DatabaseFirewallRule | cdktn.IResolvable): any;
export declare function databaseFirewallRuleToHclTerraform(struct?: DatabaseFirewallRule | cdktn.IResolvable): any;
export declare class DatabaseFirewallRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseFirewallRule | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseFirewallRule | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get uuid(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DatabaseFirewallRuleList extends cdktn.ComplexList {
    internalValue?: DatabaseFirewallRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseFirewallRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall digitalocean_database_firewall}
*/
export declare class DatabaseFirewall extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_firewall";
    /**
    * Generates CDKTN code for importing a DatabaseFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseFirewall to import
    * @param importFromId The id of the existing DatabaseFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_firewall digitalocean_database_firewall} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseFirewallConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseFirewallConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _rule;
    get rule(): DatabaseFirewallRuleList;
    putRule(value: DatabaseFirewallRule[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | DatabaseFirewallRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
