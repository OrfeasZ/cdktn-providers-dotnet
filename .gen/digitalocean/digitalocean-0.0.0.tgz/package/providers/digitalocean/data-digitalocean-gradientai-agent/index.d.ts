import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Agent to retrieve
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#agent_id DataDigitaloceanGradientaiAgent#agent_id}
    */
    readonly agentId: string;
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#description DataDigitaloceanGradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#id DataDigitaloceanGradientaiAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If case condition
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#if_case DataDigitaloceanGradientaiAgent#if_case}
    */
    readonly ifCase?: string;
    /**
    * K value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#k DataDigitaloceanGradientaiAgent#k}
    */
    readonly k?: number;
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#max_tokens DataDigitaloceanGradientaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Retrieval method used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#retrieval_method DataDigitaloceanGradientaiAgent#retrieval_method}
    */
    readonly retrievalMethod?: string;
    /**
    * User who created the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#route_created_by DataDigitaloceanGradientaiAgent#route_created_by}
    */
    readonly routeCreatedBy?: string;
    /**
    * Route name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#route_name DataDigitaloceanGradientaiAgent#route_name}
    */
    readonly routeName?: string;
    /**
    * Route UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#route_uuid DataDigitaloceanGradientaiAgent#route_uuid}
    */
    readonly routeUuid?: string;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#tags DataDigitaloceanGradientaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#temperature DataDigitaloceanGradientaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#top_p DataDigitaloceanGradientaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * URL for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * User ID linked with the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#user_id DataDigitaloceanGradientaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * agent_guardrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#agent_guardrail DataDigitaloceanGradientaiAgent#agent_guardrail}
    */
    readonly agentGuardrail?: DataDigitaloceanGradientaiAgentAgentGuardrail[] | cdktn.IResolvable;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#anthropic_api_key DataDigitaloceanGradientaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: DataDigitaloceanGradientaiAgentAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#api_key_infos DataDigitaloceanGradientaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: DataDigitaloceanGradientaiAgentApiKeyInfos[] | cdktn.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#api_keys DataDigitaloceanGradientaiAgent#api_keys}
    */
    readonly apiKeys?: DataDigitaloceanGradientaiAgentApiKeys[] | cdktn.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#chatbot DataDigitaloceanGradientaiAgent#chatbot}
    */
    readonly chatbot?: DataDigitaloceanGradientaiAgentChatbot[] | cdktn.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#chatbot_identifiers DataDigitaloceanGradientaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: DataDigitaloceanGradientaiAgentChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#deployment DataDigitaloceanGradientaiAgent#deployment}
    */
    readonly deployment?: DataDigitaloceanGradientaiAgentDeployment[] | cdktn.IResolvable;
    /**
    * functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#functions DataDigitaloceanGradientaiAgent#functions}
    */
    readonly functions?: DataDigitaloceanGradientaiAgentFunctions[] | cdktn.IResolvable;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#knowledge_bases DataDigitaloceanGradientaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: DataDigitaloceanGradientaiAgentKnowledgeBases[] | cdktn.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#model DataDigitaloceanGradientaiAgent#model}
    */
    readonly model?: DataDigitaloceanGradientaiAgentModel[] | cdktn.IResolvable;
    /**
    * open_ai_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#open_ai_api_key DataDigitaloceanGradientaiAgent#open_ai_api_key}
    */
    readonly openAiApiKey?: DataDigitaloceanGradientaiAgentOpenAiApiKey[] | cdktn.IResolvable;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#template DataDigitaloceanGradientaiAgent#template}
    */
    readonly template?: DataDigitaloceanGradientaiAgentTemplate[] | cdktn.IResolvable;
}
export interface DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChildAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChildAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChildAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChildAgents {
}
export declare function dataDigitaloceanGradientaiAgentChildAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgents): any;
export declare function dataDigitaloceanGradientaiAgentChildAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChildAgents): any;
export declare class DataDigitaloceanGradientaiAgentChildAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChildAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentChildAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentChildAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentChildAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentChildAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentChildAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentChildAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiAgentChildAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChildAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgentsApiKeys {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsApiKeys): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsApiKeys): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsApiKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgentsChatbot {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsChatbot): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsChatbot): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsChatbotList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgentsDeployment {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsDeployment): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgentsDeployment): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentParentAgents {
}
export declare function dataDigitaloceanGradientaiAgentParentAgentsToTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgents): any;
export declare function dataDigitaloceanGradientaiAgentParentAgentsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentParentAgents): any;
export declare class DataDigitaloceanGradientaiAgentParentAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentParentAgents | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentParentAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentParentAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentParentAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentParentAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentParentAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentParentAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentParentAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGradientaiAgentParentAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentParentAgentsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentAgentGuardrail {
    /**
    * Agent UUID for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#agent_uuid DataDigitaloceanGradientaiAgent#agent_uuid}
    */
    readonly agentUuid?: string;
    /**
    * Default response for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#default_response DataDigitaloceanGradientaiAgent#default_response}
    */
    readonly defaultResponse?: string;
    /**
    * Description of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#description DataDigitaloceanGradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#guardrail_uuid DataDigitaloceanGradientaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Indicates if the Guardrail is default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#is_default DataDigitaloceanGradientaiAgent#is_default}
    */
    readonly isDefault?: boolean | cdktn.IResolvable;
    /**
    * Name of Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Priority of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#priority DataDigitaloceanGradientaiAgent#priority}
    */
    readonly priority?: number;
    /**
    * Type of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#type DataDigitaloceanGradientaiAgent#type}
    */
    readonly type?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentAgentGuardrailToTerraform(struct?: DataDigitaloceanGradientaiAgentAgentGuardrail | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentAgentGuardrailToHclTerraform(struct?: DataDigitaloceanGradientaiAgentAgentGuardrail | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentAgentGuardrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentAgentGuardrail | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentAgentGuardrail | cdktn.IResolvable | undefined);
    private _agentUuid?;
    get agentUuid(): string;
    set agentUuid(value: string);
    resetAgentUuid(): void;
    get agentUuidInput(): string | undefined;
    get createdAt(): string;
    private _defaultResponse?;
    get defaultResponse(): string;
    set defaultResponse(value: string);
    resetDefaultResponse(): void;
    get defaultResponseInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    get isAttached(): cdktn.IResolvable;
    private _isDefault?;
    get isDefault(): boolean | cdktn.IResolvable;
    set isDefault(value: boolean | cdktn.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentAgentGuardrailList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentAgentGuardrail[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentAgentGuardrailOutputReference;
}
export interface DataDigitaloceanGradientaiAgentAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#created_by DataDigitaloceanGradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentAnthropicApiKey | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentAnthropicApiKey | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentAnthropicApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentAnthropicApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentAnthropicApiKey | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentAnthropicApiKeyList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentAnthropicApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#created_by DataDigitaloceanGradientaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#secret_key DataDigitaloceanGradientaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentApiKeyInfosToTerraform(struct?: DataDigitaloceanGradientaiAgentApiKeyInfos | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGradientaiAgentApiKeyInfos | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentApiKeyInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentApiKeyInfos | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentApiKeyInfos | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentApiKeyInfosList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentApiKeyInfos[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGradientaiAgentApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#api_key DataDigitaloceanGradientaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function dataDigitaloceanGradientaiAgentApiKeysToTerraform(struct?: DataDigitaloceanGradientaiAgentApiKeys | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentApiKeysToHclTerraform(struct?: DataDigitaloceanGradientaiAgentApiKeys | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentApiKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentApiKeys | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentApiKeys | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentApiKeysList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentApiKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentApiKeysOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#button_background_color DataDigitaloceanGradientaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#logo DataDigitaloceanGradientaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#primary_color DataDigitaloceanGradientaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#secondary_color DataDigitaloceanGradientaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#starting_message DataDigitaloceanGradientaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function dataDigitaloceanGradientaiAgentChatbotToTerraform(struct?: DataDigitaloceanGradientaiAgentChatbot | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentChatbotToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChatbot | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentChatbotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChatbot | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChatbot | cdktn.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentChatbotList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentChatbot[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChatbotOutputReference;
}
export interface DataDigitaloceanGradientaiAgentChatbotIdentifiers {
    /**
    * Chatbot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#chatbot_id DataDigitaloceanGradientaiAgent#chatbot_id}
    */
    readonly chatbotId?: string;
}
export declare function dataDigitaloceanGradientaiAgentChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGradientaiAgentChatbotIdentifiers | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGradientaiAgentChatbotIdentifiers | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentChatbotIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentChatbotIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentChatbotIdentifiers | cdktn.IResolvable | undefined);
    private _chatbotId?;
    get chatbotId(): string;
    set chatbotId(value: string);
    resetChatbotId(): void;
    get chatbotIdInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentChatbotIdentifiersList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentChatbotIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGradientaiAgentDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#status DataDigitaloceanGradientaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#visibility DataDigitaloceanGradientaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function dataDigitaloceanGradientaiAgentDeploymentToTerraform(struct?: DataDigitaloceanGradientaiAgentDeployment | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentDeploymentToHclTerraform(struct?: DataDigitaloceanGradientaiAgentDeployment | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentDeployment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentDeployment | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentDeploymentList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentDeployment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentDeploymentOutputReference;
}
export interface DataDigitaloceanGradientaiAgentFunctions {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#api_key DataDigitaloceanGradientaiAgent#api_key}
    */
    readonly apiKey?: string;
    /**
    * Description of the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#description DataDigitaloceanGradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#faasname DataDigitaloceanGradientaiAgent#faasname}
    */
    readonly faasname?: string;
    /**
    * Namespace of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#faasnamespace DataDigitaloceanGradientaiAgent#faasnamespace}
    */
    readonly faasnamespace?: string;
    /**
    * Guardrail UUID for the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#guardrail_uuid DataDigitaloceanGradientaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentFunctionsToTerraform(struct?: DataDigitaloceanGradientaiAgentFunctions | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentFunctionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentFunctions | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentFunctions | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _faasname?;
    get faasname(): string;
    set faasname(value: string);
    resetFaasname(): void;
    get faasnameInput(): string | undefined;
    private _faasnamespace?;
    get faasnamespace(): string;
    set faasnamespace(value: string);
    resetFaasnamespace(): void;
    get faasnamespaceInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentFunctionsList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentFunctionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#completed_datasources DataDigitaloceanGradientaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#data_source_uuids DataDigitaloceanGradientaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#phase DataDigitaloceanGradientaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#tokens DataDigitaloceanGradientaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#total_datasources DataDigitaloceanGradientaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface DataDigitaloceanGradientaiAgentKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#database_id DataDigitaloceanGradientaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#embedding_model_uuid DataDigitaloceanGradientaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#is_public DataDigitaloceanGradientaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#project_id DataDigitaloceanGradientaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#region DataDigitaloceanGradientaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#tags DataDigitaloceanGradientaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#user_id DataDigitaloceanGradientaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#last_indexing_job DataDigitaloceanGradientaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob;
}
export declare function dataDigitaloceanGradientaiAgentKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentKnowledgeBases | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentKnowledgeBases | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentKnowledgeBases | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentKnowledgeBases | cdktn.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktn.IResolvable;
    set isPublic(value: boolean | cdktn.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): DataDigitaloceanGradientaiAgentKnowledgeBasesLastIndexingJob | undefined;
}
export declare class DataDigitaloceanGradientaiAgentKnowledgeBasesList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentKnowledgeBases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#description DataDigitaloceanGradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentModelAgreementToTerraform(struct?: DataDigitaloceanGradientaiAgentModelAgreement | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentModelAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiAgentModelAgreement | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentModelAgreement | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentModelAgreement | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentModelAgreementList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentModelAgreement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentModelAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiAgentModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#major DataDigitaloceanGradientaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#minor DataDigitaloceanGradientaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#patch DataDigitaloceanGradientaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function dataDigitaloceanGradientaiAgentModelVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentModelVersions | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentModelVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentModelVersions | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentModelVersions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentModelVersions | cdktn.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class DataDigitaloceanGradientaiAgentModelVersionsList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentModelVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentModelVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#inference_name DataDigitaloceanGradientaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#inference_version DataDigitaloceanGradientaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#is_foundational DataDigitaloceanGradientaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#parent_uuid DataDigitaloceanGradientaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#provider DataDigitaloceanGradientaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#upload_complete DataDigitaloceanGradientaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktn.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#usecases DataDigitaloceanGradientaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#agreement DataDigitaloceanGradientaiAgent#agreement}
    */
    readonly agreement?: DataDigitaloceanGradientaiAgentModelAgreement[] | cdktn.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#versions DataDigitaloceanGradientaiAgent#versions}
    */
    readonly versions?: DataDigitaloceanGradientaiAgentModelVersions[] | cdktn.IResolvable;
}
export declare function dataDigitaloceanGradientaiAgentModelToTerraform(struct?: DataDigitaloceanGradientaiAgentModel | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentModelToHclTerraform(struct?: DataDigitaloceanGradientaiAgentModel | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentModel | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentModel | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktn.IResolvable;
    set isFoundational(value: boolean | cdktn.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktn.IResolvable;
    set uploadComplete(value: boolean | cdktn.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiAgentModelAgreementList;
    putAgreement(value: DataDigitaloceanGradientaiAgentModelAgreement[] | cdktn.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentModelAgreement[] | undefined;
    private _versions;
    get versions(): DataDigitaloceanGradientaiAgentModelVersionsList;
    putVersions(value: DataDigitaloceanGradientaiAgentModelVersions[] | cdktn.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentModelVersions[] | undefined;
}
export declare class DataDigitaloceanGradientaiAgentModelList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentModelOutputReference;
}
export interface DataDigitaloceanGradientaiAgentOpenAiApiKey {
    /**
    * OpenAI API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#api_key DataDigitaloceanGradientaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function dataDigitaloceanGradientaiAgentOpenAiApiKeyToTerraform(struct?: DataDigitaloceanGradientaiAgentOpenAiApiKey | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentOpenAiApiKeyToHclTerraform(struct?: DataDigitaloceanGradientaiAgentOpenAiApiKey | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentOpenAiApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentOpenAiApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentOpenAiApiKey | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentOpenAiApiKeyList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentOpenAiApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentOpenAiApiKeyOutputReference;
}
export interface DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#completed_datasources DataDigitaloceanGradientaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#data_source_uuids DataDigitaloceanGradientaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#phase DataDigitaloceanGradientaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#tokens DataDigitaloceanGradientaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#total_datasources DataDigitaloceanGradientaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface DataDigitaloceanGradientaiAgentTemplateKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#database_id DataDigitaloceanGradientaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#embedding_model_uuid DataDigitaloceanGradientaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#is_public DataDigitaloceanGradientaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#project_id DataDigitaloceanGradientaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#region DataDigitaloceanGradientaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#tags DataDigitaloceanGradientaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#user_id DataDigitaloceanGradientaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#last_indexing_job DataDigitaloceanGradientaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob;
}
export declare function dataDigitaloceanGradientaiAgentTemplateKnowledgeBasesToTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentTemplateKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentTemplateKnowledgeBases | cdktn.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktn.IResolvable;
    set isPublic(value: boolean | cdktn.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
}
export declare class DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGradientaiAgentTemplateModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#description DataDigitaloceanGradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGradientaiAgentTemplateModelAgreementToTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateModelAgreement | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentTemplateModelAgreementToHclTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateModelAgreement | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentTemplateModelAgreementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentTemplateModelAgreement | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentTemplateModelAgreement | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGradientaiAgentTemplateModelAgreementList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentTemplateModelAgreement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentTemplateModelAgreementOutputReference;
}
export interface DataDigitaloceanGradientaiAgentTemplateModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#major DataDigitaloceanGradientaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#minor DataDigitaloceanGradientaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#patch DataDigitaloceanGradientaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function dataDigitaloceanGradientaiAgentTemplateModelVersionsToTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateModelVersions | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentTemplateModelVersionsToHclTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateModelVersions | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentTemplateModelVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentTemplateModelVersions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentTemplateModelVersions | cdktn.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class DataDigitaloceanGradientaiAgentTemplateModelVersionsList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentTemplateModelVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentTemplateModelVersionsOutputReference;
}
export interface DataDigitaloceanGradientaiAgentTemplateModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#inference_name DataDigitaloceanGradientaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#inference_version DataDigitaloceanGradientaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#is_foundational DataDigitaloceanGradientaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktn.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#parent_uuid DataDigitaloceanGradientaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#provider DataDigitaloceanGradientaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#upload_complete DataDigitaloceanGradientaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktn.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#url DataDigitaloceanGradientaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#usecases DataDigitaloceanGradientaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#agreement DataDigitaloceanGradientaiAgent#agreement}
    */
    readonly agreement?: DataDigitaloceanGradientaiAgentTemplateModelAgreement[] | cdktn.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#versions DataDigitaloceanGradientaiAgent#versions}
    */
    readonly versions?: DataDigitaloceanGradientaiAgentTemplateModelVersions[] | cdktn.IResolvable;
}
export declare function dataDigitaloceanGradientaiAgentTemplateModelToTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateModel | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentTemplateModelToHclTerraform(struct?: DataDigitaloceanGradientaiAgentTemplateModel | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentTemplateModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentTemplateModel | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentTemplateModel | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktn.IResolvable;
    set isFoundational(value: boolean | cdktn.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktn.IResolvable;
    set uploadComplete(value: boolean | cdktn.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): DataDigitaloceanGradientaiAgentTemplateModelAgreementList;
    putAgreement(value: DataDigitaloceanGradientaiAgentTemplateModelAgreement[] | cdktn.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentTemplateModelAgreement[] | undefined;
    private _versions;
    get versions(): DataDigitaloceanGradientaiAgentTemplateModelVersionsList;
    putVersions(value: DataDigitaloceanGradientaiAgentTemplateModelVersions[] | cdktn.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentTemplateModelVersions[] | undefined;
}
export declare class DataDigitaloceanGradientaiAgentTemplateModelList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentTemplateModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentTemplateModelOutputReference;
}
export interface DataDigitaloceanGradientaiAgentTemplate {
    /**
    * Description of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#description DataDigitaloceanGradientaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#instruction DataDigitaloceanGradientaiAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * K value for the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#k DataDigitaloceanGradientaiAgent#k}
    */
    readonly k?: number;
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#max_tokens DataDigitaloceanGradientaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Name of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#name DataDigitaloceanGradientaiAgent#name}
    */
    readonly name?: string;
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#temperature DataDigitaloceanGradientaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#top_p DataDigitaloceanGradientaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * uuid of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#uuid DataDigitaloceanGradientaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#knowledge_bases DataDigitaloceanGradientaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: DataDigitaloceanGradientaiAgentTemplateKnowledgeBases[] | cdktn.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#model DataDigitaloceanGradientaiAgent#model}
    */
    readonly model?: DataDigitaloceanGradientaiAgentTemplateModel[] | cdktn.IResolvable;
}
export declare function dataDigitaloceanGradientaiAgentTemplateToTerraform(struct?: DataDigitaloceanGradientaiAgentTemplate | cdktn.IResolvable): any;
export declare function dataDigitaloceanGradientaiAgentTemplateToHclTerraform(struct?: DataDigitaloceanGradientaiAgentTemplate | cdktn.IResolvable): any;
export declare class DataDigitaloceanGradientaiAgentTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiAgentTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGradientaiAgentTemplate | cdktn.IResolvable | undefined);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiAgentTemplateKnowledgeBasesList;
    putKnowledgeBases(value: DataDigitaloceanGradientaiAgentTemplateKnowledgeBases[] | cdktn.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentTemplateKnowledgeBases[] | undefined;
    private _model;
    get model(): DataDigitaloceanGradientaiAgentTemplateModelList;
    putModel(value: DataDigitaloceanGradientaiAgentTemplateModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentTemplateModel[] | undefined;
}
export declare class DataDigitaloceanGradientaiAgentTemplateList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanGradientaiAgentTemplate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiAgentTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent digitalocean_gradientai_agent}
*/
export declare class DataDigitaloceanGradientaiAgent extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_agent";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiAgent to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_agent digitalocean_gradientai_agent} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiAgentConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiAgentConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _childAgents;
    get childAgents(): DataDigitaloceanGradientaiAgentChildAgentsList;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifCase?;
    get ifCase(): string;
    set ifCase(value: string);
    resetIfCase(): void;
    get ifCaseInput(): string | undefined;
    get instruction(): string;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    get modelUuid(): string;
    get name(): string;
    private _parentAgents;
    get parentAgents(): DataDigitaloceanGradientaiAgentParentAgentsList;
    get projectId(): string;
    get region(): string;
    private _retrievalMethod?;
    get retrievalMethod(): string;
    set retrievalMethod(value: string);
    resetRetrievalMethod(): void;
    get retrievalMethodInput(): string | undefined;
    get routeCreatedAt(): string;
    private _routeCreatedBy?;
    get routeCreatedBy(): string;
    set routeCreatedBy(value: string);
    resetRouteCreatedBy(): void;
    get routeCreatedByInput(): string | undefined;
    private _routeName?;
    get routeName(): string;
    set routeName(value: string);
    resetRouteName(): void;
    get routeNameInput(): string | undefined;
    private _routeUuid?;
    get routeUuid(): string;
    set routeUuid(value: string);
    resetRouteUuid(): void;
    get routeUuidInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _agentGuardrail;
    get agentGuardrail(): DataDigitaloceanGradientaiAgentAgentGuardrailList;
    putAgentGuardrail(value: DataDigitaloceanGradientaiAgentAgentGuardrail[] | cdktn.IResolvable): void;
    resetAgentGuardrail(): void;
    get agentGuardrailInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentAgentGuardrail[] | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGradientaiAgentAnthropicApiKeyList;
    putAnthropicApiKey(value: DataDigitaloceanGradientaiAgentAnthropicApiKey[] | cdktn.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGradientaiAgentApiKeyInfosList;
    putApiKeyInfos(value: DataDigitaloceanGradientaiAgentApiKeyInfos[] | cdktn.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGradientaiAgentApiKeysList;
    putApiKeys(value: DataDigitaloceanGradientaiAgentApiKeys[] | cdktn.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): DataDigitaloceanGradientaiAgentChatbotList;
    putChatbot(value: DataDigitaloceanGradientaiAgentChatbot[] | cdktn.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGradientaiAgentChatbotIdentifiersList;
    putChatbotIdentifiers(value: DataDigitaloceanGradientaiAgentChatbotIdentifiers[] | cdktn.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentChatbotIdentifiers[] | undefined;
    private _deployment;
    get deployment(): DataDigitaloceanGradientaiAgentDeploymentList;
    putDeployment(value: DataDigitaloceanGradientaiAgentDeployment[] | cdktn.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentDeployment[] | undefined;
    private _functions;
    get functions(): DataDigitaloceanGradientaiAgentFunctionsList;
    putFunctions(value: DataDigitaloceanGradientaiAgentFunctions[] | cdktn.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentFunctions[] | undefined;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGradientaiAgentKnowledgeBasesList;
    putKnowledgeBases(value: DataDigitaloceanGradientaiAgentKnowledgeBases[] | cdktn.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentKnowledgeBases[] | undefined;
    private _model;
    get model(): DataDigitaloceanGradientaiAgentModelList;
    putModel(value: DataDigitaloceanGradientaiAgentModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentModel[] | undefined;
    private _openAiApiKey;
    get openAiApiKey(): DataDigitaloceanGradientaiAgentOpenAiApiKeyList;
    putOpenAiApiKey(value: DataDigitaloceanGradientaiAgentOpenAiApiKey[] | cdktn.IResolvable): void;
    resetOpenAiApiKey(): void;
    get openAiApiKeyInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentOpenAiApiKey[] | undefined;
    private _template;
    get template(): DataDigitaloceanGradientaiAgentTemplateList;
    putTemplate(value: DataDigitaloceanGradientaiAgentTemplate[] | cdktn.IResolvable): void;
    resetTemplate(): void;
    get templateInput(): cdktn.IResolvable | DataDigitaloceanGradientaiAgentTemplate[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
