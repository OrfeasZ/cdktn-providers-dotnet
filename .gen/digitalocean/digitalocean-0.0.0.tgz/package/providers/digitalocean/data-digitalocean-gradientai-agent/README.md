# `data_digitalocean_gradientai_agent`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_agent`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_agent).
