import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReservedIpv6AssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/reserved_ipv6_assignment#droplet_id ReservedIpv6Assignment#droplet_id}
    */
    readonly dropletId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/reserved_ipv6_assignment#id ReservedIpv6Assignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/reserved_ipv6_assignment#ip ReservedIpv6Assignment#ip}
    */
    readonly ip: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/reserved_ipv6_assignment digitalocean_reserved_ipv6_assignment}
*/
export declare class ReservedIpv6Assignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_reserved_ipv6_assignment";
    /**
    * Generates CDKTN code for importing a ReservedIpv6Assignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ReservedIpv6Assignment to import
    * @param importFromId The id of the existing ReservedIpv6Assignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/reserved_ipv6_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ReservedIpv6Assignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/reserved_ipv6_assignment digitalocean_reserved_ipv6_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReservedIpv6AssignmentConfig
    */
    constructor(scope: Construct, id: string, config: ReservedIpv6AssignmentConfig);
    private _dropletId?;
    get dropletId(): number;
    set dropletId(value: number);
    get dropletIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
