import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GradientaiAgentKnowledgeBaseAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * A unique identifier for an agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_knowledge_base_attachment#agent_uuid GradientaiAgentKnowledgeBaseAttachment#agent_uuid}
    */
    readonly agentUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_knowledge_base_attachment#id GradientaiAgentKnowledgeBaseAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A unique identifier for a knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_knowledge_base_attachment#knowledge_base_uuid GradientaiAgentKnowledgeBaseAttachment#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_knowledge_base_attachment digitalocean_gradientai_agent_knowledge_base_attachment}
*/
export declare class GradientaiAgentKnowledgeBaseAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_gradientai_agent_knowledge_base_attachment";
    /**
    * Generates CDKTN code for importing a GradientaiAgentKnowledgeBaseAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GradientaiAgentKnowledgeBaseAttachment to import
    * @param importFromId The id of the existing GradientaiAgentKnowledgeBaseAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_knowledge_base_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GradientaiAgentKnowledgeBaseAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/gradientai_agent_knowledge_base_attachment digitalocean_gradientai_agent_knowledge_base_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GradientaiAgentKnowledgeBaseAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: GradientaiAgentKnowledgeBaseAttachmentConfig);
    private _agentUuid?;
    get agentUuid(): string;
    set agentUuid(value: string);
    get agentUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
