# `digitalocean_gradientai_agent_knowledge_base_attachment`

Refer to the Terraform Registry for docs: [`digitalocean_gradientai_agent_knowledge_base_attachment`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/gradientai_agent_knowledge_base_attachment).
