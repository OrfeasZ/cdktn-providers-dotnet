# `data_digitalocean_domains`

Refer to the Terraform Registry for docs: [`data_digitalocean_domains`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/domains).
