import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#id DataDigitaloceanDomains#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#filter DataDigitaloceanDomains#filter}
    */
    readonly filter?: DataDigitaloceanDomainsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#sort DataDigitaloceanDomains#sort}
    */
    readonly sort?: DataDigitaloceanDomainsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanDomainsDomains {
}
export declare function dataDigitaloceanDomainsDomainsToTerraform(struct?: DataDigitaloceanDomainsDomains): any;
export declare function dataDigitaloceanDomainsDomainsToHclTerraform(struct?: DataDigitaloceanDomainsDomains): any;
export declare class DataDigitaloceanDomainsDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDomainsDomains | undefined;
    set internalValue(value: DataDigitaloceanDomainsDomains | undefined);
    get name(): string;
    get ttl(): number;
    get urn(): string;
}
export declare class DataDigitaloceanDomainsDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDomainsDomainsOutputReference;
}
export interface DataDigitaloceanDomainsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#all DataDigitaloceanDomains#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#key DataDigitaloceanDomains#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#match_by DataDigitaloceanDomains#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#values DataDigitaloceanDomains#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanDomainsFilterToTerraform(struct?: DataDigitaloceanDomainsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanDomainsFilterToHclTerraform(struct?: DataDigitaloceanDomainsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanDomainsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDomainsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDomainsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanDomainsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDomainsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDomainsFilterOutputReference;
}
export interface DataDigitaloceanDomainsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#direction DataDigitaloceanDomains#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#key DataDigitaloceanDomains#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanDomainsSortToTerraform(struct?: DataDigitaloceanDomainsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanDomainsSortToHclTerraform(struct?: DataDigitaloceanDomainsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanDomainsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDomainsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanDomainsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanDomainsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanDomainsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDomainsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains digitalocean_domains}
*/
export declare class DataDigitaloceanDomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_domains";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDomains to import
    * @param importFromId The id of the existing DataDigitaloceanDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/domains digitalocean_domains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDomainsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDomainsConfig);
    private _domains;
    get domains(): DataDigitaloceanDomainsDomainsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanDomainsFilterList;
    putFilter(value: DataDigitaloceanDomainsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanDomainsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanDomainsSortList;
    putSort(value: DataDigitaloceanDomainsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanDomainsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
