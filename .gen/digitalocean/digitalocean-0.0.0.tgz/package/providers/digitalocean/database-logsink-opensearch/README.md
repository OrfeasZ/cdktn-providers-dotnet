# `digitalocean_database_logsink_opensearch`

Refer to the Terraform Registry for docs: [`digitalocean_database_logsink_opensearch`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_logsink_opensearch).
