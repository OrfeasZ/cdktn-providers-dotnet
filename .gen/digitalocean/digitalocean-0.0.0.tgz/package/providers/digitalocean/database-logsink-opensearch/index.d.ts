import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseLogsinkOpensearchConfig extends cdktn.TerraformMetaArguments {
    /**
    * CA certificate for TLS verification (PEM format)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#ca_cert DatabaseLogsinkOpensearch#ca_cert}
    */
    readonly caCert?: string;
    /**
    * UUID of the source database cluster that will forward logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#cluster_id DatabaseLogsinkOpensearch#cluster_id}
    */
    readonly clusterId: string;
    /**
    * HTTPS URL to OpenSearch (https://host:port)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#endpoint DatabaseLogsinkOpensearch#endpoint}
    */
    readonly endpoint: string;
    /**
    * Maximum number of days to retain indices (>= 1)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#index_days_max DatabaseLogsinkOpensearch#index_days_max}
    */
    readonly indexDaysMax?: number;
    /**
    * Prefix for OpenSearch indices
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#index_prefix DatabaseLogsinkOpensearch#index_prefix}
    */
    readonly indexPrefix: string;
    /**
    * Display name for the logsink
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#name DatabaseLogsinkOpensearch#name}
    */
    readonly name: string;
    /**
    * Request timeout for log deliveries in seconds (>= 1)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#timeout_seconds DatabaseLogsinkOpensearch#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch digitalocean_database_logsink_opensearch}
*/
export declare class DatabaseLogsinkOpensearch extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_logsink_opensearch";
    /**
    * Generates CDKTN code for importing a DatabaseLogsinkOpensearch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseLogsinkOpensearch to import
    * @param importFromId The id of the existing DatabaseLogsinkOpensearch that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseLogsinkOpensearch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/resources/database_logsink_opensearch digitalocean_database_logsink_opensearch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseLogsinkOpensearchConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseLogsinkOpensearchConfig);
    private _caCert?;
    get caCert(): string;
    set caCert(value: string);
    resetCaCert(): void;
    get caCertInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    get id(): string;
    private _indexDaysMax?;
    get indexDaysMax(): number;
    set indexDaysMax(value: number);
    resetIndexDaysMax(): void;
    get indexDaysMaxInput(): number | undefined;
    private _indexPrefix?;
    get indexPrefix(): string;
    set indexPrefix(value: string);
    get indexPrefixInput(): string | undefined;
    get logsinkId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
