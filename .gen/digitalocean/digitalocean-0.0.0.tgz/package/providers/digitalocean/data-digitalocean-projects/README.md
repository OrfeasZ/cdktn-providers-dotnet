# `data_digitalocean_projects`

Refer to the Terraform Registry for docs: [`data_digitalocean_projects`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects).
