import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanProjectsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#id DataDigitaloceanProjects#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#filter DataDigitaloceanProjects#filter}
    */
    readonly filter?: DataDigitaloceanProjectsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#sort DataDigitaloceanProjects#sort}
    */
    readonly sort?: DataDigitaloceanProjectsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanProjectsProjects {
}
export declare function dataDigitaloceanProjectsProjectsToTerraform(struct?: DataDigitaloceanProjectsProjects): any;
export declare function dataDigitaloceanProjectsProjectsToHclTerraform(struct?: DataDigitaloceanProjectsProjects): any;
export declare class DataDigitaloceanProjectsProjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanProjectsProjects | undefined;
    set internalValue(value: DataDigitaloceanProjectsProjects | undefined);
    get createdAt(): string;
    get description(): string;
    get environment(): string;
    get id(): string;
    get isDefault(): cdktn.IResolvable;
    get name(): string;
    get ownerId(): number;
    get ownerUuid(): string;
    get purpose(): string;
    get resources(): string[];
    get updatedAt(): string;
}
export declare class DataDigitaloceanProjectsProjectsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanProjectsProjectsOutputReference;
}
export interface DataDigitaloceanProjectsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#all DataDigitaloceanProjects#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#key DataDigitaloceanProjects#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#match_by DataDigitaloceanProjects#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#values DataDigitaloceanProjects#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanProjectsFilterToTerraform(struct?: DataDigitaloceanProjectsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanProjectsFilterToHclTerraform(struct?: DataDigitaloceanProjectsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanProjectsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanProjectsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanProjectsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanProjectsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanProjectsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanProjectsFilterOutputReference;
}
export interface DataDigitaloceanProjectsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#direction DataDigitaloceanProjects#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#key DataDigitaloceanProjects#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanProjectsSortToTerraform(struct?: DataDigitaloceanProjectsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanProjectsSortToHclTerraform(struct?: DataDigitaloceanProjectsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanProjectsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanProjectsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanProjectsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanProjectsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanProjectsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanProjectsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects digitalocean_projects}
*/
export declare class DataDigitaloceanProjects extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_projects";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanProjects resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanProjects to import
    * @param importFromId The id of the existing DataDigitaloceanProjects that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanProjects to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/projects digitalocean_projects} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanProjectsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanProjectsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projects;
    get projects(): DataDigitaloceanProjectsProjectsList;
    private _filter;
    get filter(): DataDigitaloceanProjectsFilterList;
    putFilter(value: DataDigitaloceanProjectsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanProjectsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanProjectsSortList;
    putSort(value: DataDigitaloceanProjectsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanProjectsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
