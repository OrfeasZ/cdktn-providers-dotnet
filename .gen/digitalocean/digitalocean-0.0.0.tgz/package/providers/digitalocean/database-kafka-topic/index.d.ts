import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseKafkaTopicConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#cluster_id DatabaseKafkaTopic#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#id DatabaseKafkaTopic#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#name DatabaseKafkaTopic#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#partition_count DatabaseKafkaTopic#partition_count}
    */
    readonly partitionCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#replication_factor DatabaseKafkaTopic#replication_factor}
    */
    readonly replicationFactor?: number;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#config DatabaseKafkaTopic#config}
    */
    readonly config?: DatabaseKafkaTopicConfigA[] | cdktn.IResolvable;
}
export interface DatabaseKafkaTopicConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#cleanup_policy DatabaseKafkaTopic#cleanup_policy}
    */
    readonly cleanupPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#compression_type DatabaseKafkaTopic#compression_type}
    */
    readonly compressionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#delete_retention_ms DatabaseKafkaTopic#delete_retention_ms}
    */
    readonly deleteRetentionMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#file_delete_delay_ms DatabaseKafkaTopic#file_delete_delay_ms}
    */
    readonly fileDeleteDelayMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#flush_messages DatabaseKafkaTopic#flush_messages}
    */
    readonly flushMessages?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#flush_ms DatabaseKafkaTopic#flush_ms}
    */
    readonly flushMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#index_interval_bytes DatabaseKafkaTopic#index_interval_bytes}
    */
    readonly indexIntervalBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#max_compaction_lag_ms DatabaseKafkaTopic#max_compaction_lag_ms}
    */
    readonly maxCompactionLagMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#max_message_bytes DatabaseKafkaTopic#max_message_bytes}
    */
    readonly maxMessageBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#message_down_conversion_enable DatabaseKafkaTopic#message_down_conversion_enable}
    */
    readonly messageDownConversionEnable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#message_format_version DatabaseKafkaTopic#message_format_version}
    */
    readonly messageFormatVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#message_timestamp_difference_max_ms DatabaseKafkaTopic#message_timestamp_difference_max_ms}
    */
    readonly messageTimestampDifferenceMaxMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#message_timestamp_type DatabaseKafkaTopic#message_timestamp_type}
    */
    readonly messageTimestampType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#min_cleanable_dirty_ratio DatabaseKafkaTopic#min_cleanable_dirty_ratio}
    */
    readonly minCleanableDirtyRatio?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#min_compaction_lag_ms DatabaseKafkaTopic#min_compaction_lag_ms}
    */
    readonly minCompactionLagMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#min_insync_replicas DatabaseKafkaTopic#min_insync_replicas}
    */
    readonly minInsyncReplicas?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#preallocate DatabaseKafkaTopic#preallocate}
    */
    readonly preallocate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#retention_bytes DatabaseKafkaTopic#retention_bytes}
    */
    readonly retentionBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#retention_ms DatabaseKafkaTopic#retention_ms}
    */
    readonly retentionMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#segment_bytes DatabaseKafkaTopic#segment_bytes}
    */
    readonly segmentBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#segment_index_bytes DatabaseKafkaTopic#segment_index_bytes}
    */
    readonly segmentIndexBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#segment_jitter_ms DatabaseKafkaTopic#segment_jitter_ms}
    */
    readonly segmentJitterMs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#segment_ms DatabaseKafkaTopic#segment_ms}
    */
    readonly segmentMs?: string;
}
export declare function databaseKafkaTopicConfigAToTerraform(struct?: DatabaseKafkaTopicConfigA | cdktn.IResolvable): any;
export declare function databaseKafkaTopicConfigAToHclTerraform(struct?: DatabaseKafkaTopicConfigA | cdktn.IResolvable): any;
export declare class DatabaseKafkaTopicConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseKafkaTopicConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseKafkaTopicConfigA | cdktn.IResolvable | undefined);
    private _cleanupPolicy?;
    get cleanupPolicy(): string;
    set cleanupPolicy(value: string);
    resetCleanupPolicy(): void;
    get cleanupPolicyInput(): string | undefined;
    private _compressionType?;
    get compressionType(): string;
    set compressionType(value: string);
    resetCompressionType(): void;
    get compressionTypeInput(): string | undefined;
    private _deleteRetentionMs?;
    get deleteRetentionMs(): string;
    set deleteRetentionMs(value: string);
    resetDeleteRetentionMs(): void;
    get deleteRetentionMsInput(): string | undefined;
    private _fileDeleteDelayMs?;
    get fileDeleteDelayMs(): string;
    set fileDeleteDelayMs(value: string);
    resetFileDeleteDelayMs(): void;
    get fileDeleteDelayMsInput(): string | undefined;
    private _flushMessages?;
    get flushMessages(): string;
    set flushMessages(value: string);
    resetFlushMessages(): void;
    get flushMessagesInput(): string | undefined;
    private _flushMs?;
    get flushMs(): string;
    set flushMs(value: string);
    resetFlushMs(): void;
    get flushMsInput(): string | undefined;
    private _indexIntervalBytes?;
    get indexIntervalBytes(): string;
    set indexIntervalBytes(value: string);
    resetIndexIntervalBytes(): void;
    get indexIntervalBytesInput(): string | undefined;
    private _maxCompactionLagMs?;
    get maxCompactionLagMs(): string;
    set maxCompactionLagMs(value: string);
    resetMaxCompactionLagMs(): void;
    get maxCompactionLagMsInput(): string | undefined;
    private _maxMessageBytes?;
    get maxMessageBytes(): string;
    set maxMessageBytes(value: string);
    resetMaxMessageBytes(): void;
    get maxMessageBytesInput(): string | undefined;
    private _messageDownConversionEnable?;
    get messageDownConversionEnable(): boolean | cdktn.IResolvable;
    set messageDownConversionEnable(value: boolean | cdktn.IResolvable);
    resetMessageDownConversionEnable(): void;
    get messageDownConversionEnableInput(): boolean | cdktn.IResolvable | undefined;
    private _messageFormatVersion?;
    get messageFormatVersion(): string;
    set messageFormatVersion(value: string);
    resetMessageFormatVersion(): void;
    get messageFormatVersionInput(): string | undefined;
    private _messageTimestampDifferenceMaxMs?;
    get messageTimestampDifferenceMaxMs(): string;
    set messageTimestampDifferenceMaxMs(value: string);
    resetMessageTimestampDifferenceMaxMs(): void;
    get messageTimestampDifferenceMaxMsInput(): string | undefined;
    private _messageTimestampType?;
    get messageTimestampType(): string;
    set messageTimestampType(value: string);
    resetMessageTimestampType(): void;
    get messageTimestampTypeInput(): string | undefined;
    private _minCleanableDirtyRatio?;
    get minCleanableDirtyRatio(): number;
    set minCleanableDirtyRatio(value: number);
    resetMinCleanableDirtyRatio(): void;
    get minCleanableDirtyRatioInput(): number | undefined;
    private _minCompactionLagMs?;
    get minCompactionLagMs(): string;
    set minCompactionLagMs(value: string);
    resetMinCompactionLagMs(): void;
    get minCompactionLagMsInput(): string | undefined;
    private _minInsyncReplicas?;
    get minInsyncReplicas(): number;
    set minInsyncReplicas(value: number);
    resetMinInsyncReplicas(): void;
    get minInsyncReplicasInput(): number | undefined;
    private _preallocate?;
    get preallocate(): boolean | cdktn.IResolvable;
    set preallocate(value: boolean | cdktn.IResolvable);
    resetPreallocate(): void;
    get preallocateInput(): boolean | cdktn.IResolvable | undefined;
    private _retentionBytes?;
    get retentionBytes(): string;
    set retentionBytes(value: string);
    resetRetentionBytes(): void;
    get retentionBytesInput(): string | undefined;
    private _retentionMs?;
    get retentionMs(): string;
    set retentionMs(value: string);
    resetRetentionMs(): void;
    get retentionMsInput(): string | undefined;
    private _segmentBytes?;
    get segmentBytes(): string;
    set segmentBytes(value: string);
    resetSegmentBytes(): void;
    get segmentBytesInput(): string | undefined;
    private _segmentIndexBytes?;
    get segmentIndexBytes(): string;
    set segmentIndexBytes(value: string);
    resetSegmentIndexBytes(): void;
    get segmentIndexBytesInput(): string | undefined;
    private _segmentJitterMs?;
    get segmentJitterMs(): string;
    set segmentJitterMs(value: string);
    resetSegmentJitterMs(): void;
    get segmentJitterMsInput(): string | undefined;
    private _segmentMs?;
    get segmentMs(): string;
    set segmentMs(value: string);
    resetSegmentMs(): void;
    get segmentMsInput(): string | undefined;
}
export declare class DatabaseKafkaTopicConfigAList extends cdktn.ComplexList {
    internalValue?: DatabaseKafkaTopicConfigA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseKafkaTopicConfigAOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic digitalocean_database_kafka_topic}
*/
export declare class DatabaseKafkaTopic extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_kafka_topic";
    /**
    * Generates CDKTN code for importing a DatabaseKafkaTopic resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseKafkaTopic to import
    * @param importFromId The id of the existing DatabaseKafkaTopic that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseKafkaTopic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_kafka_topic digitalocean_database_kafka_topic} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseKafkaTopicConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseKafkaTopicConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partitionCount?;
    get partitionCount(): number;
    set partitionCount(value: number);
    resetPartitionCount(): void;
    get partitionCountInput(): number | undefined;
    private _replicationFactor?;
    get replicationFactor(): number;
    set replicationFactor(value: number);
    resetReplicationFactor(): void;
    get replicationFactorInput(): number | undefined;
    get state(): string;
    private _config;
    get config(): DatabaseKafkaTopicConfigAList;
    putConfig(value: DatabaseKafkaTopicConfigA[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | DatabaseKafkaTopicConfigA[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
