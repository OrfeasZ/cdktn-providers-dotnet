# `data_digitalocean_records`

Refer to the Terraform Registry for docs: [`data_digitalocean_records`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records).
