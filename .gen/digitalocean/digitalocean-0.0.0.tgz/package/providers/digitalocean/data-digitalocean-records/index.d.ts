import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanRecordsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#domain DataDigitaloceanRecords#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#id DataDigitaloceanRecords#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#filter DataDigitaloceanRecords#filter}
    */
    readonly filter?: DataDigitaloceanRecordsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#sort DataDigitaloceanRecords#sort}
    */
    readonly sort?: DataDigitaloceanRecordsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanRecordsRecords {
}
export declare function dataDigitaloceanRecordsRecordsToTerraform(struct?: DataDigitaloceanRecordsRecords): any;
export declare function dataDigitaloceanRecordsRecordsToHclTerraform(struct?: DataDigitaloceanRecordsRecords): any;
export declare class DataDigitaloceanRecordsRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanRecordsRecords | undefined;
    set internalValue(value: DataDigitaloceanRecordsRecords | undefined);
    get domain(): string;
    get flags(): number;
    get id(): number;
    get name(): string;
    get port(): number;
    get priority(): number;
    get tag(): string;
    get ttl(): number;
    get type(): string;
    get value(): string;
    get weight(): number;
}
export declare class DataDigitaloceanRecordsRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanRecordsRecordsOutputReference;
}
export interface DataDigitaloceanRecordsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#all DataDigitaloceanRecords#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#key DataDigitaloceanRecords#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#match_by DataDigitaloceanRecords#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#values DataDigitaloceanRecords#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanRecordsFilterToTerraform(struct?: DataDigitaloceanRecordsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanRecordsFilterToHclTerraform(struct?: DataDigitaloceanRecordsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanRecordsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanRecordsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanRecordsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanRecordsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanRecordsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanRecordsFilterOutputReference;
}
export interface DataDigitaloceanRecordsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#direction DataDigitaloceanRecords#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#key DataDigitaloceanRecords#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanRecordsSortToTerraform(struct?: DataDigitaloceanRecordsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanRecordsSortToHclTerraform(struct?: DataDigitaloceanRecordsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanRecordsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanRecordsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanRecordsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanRecordsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanRecordsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanRecordsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records digitalocean_records}
*/
export declare class DataDigitaloceanRecords extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_records";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanRecords resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanRecords to import
    * @param importFromId The id of the existing DataDigitaloceanRecords that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanRecords to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/records digitalocean_records} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanRecordsConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanRecordsConfig);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _records;
    get records(): DataDigitaloceanRecordsRecordsList;
    private _filter;
    get filter(): DataDigitaloceanRecordsFilterList;
    putFilter(value: DataDigitaloceanRecordsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanRecordsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanRecordsSortList;
    putSort(value: DataDigitaloceanRecordsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanRecordsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
