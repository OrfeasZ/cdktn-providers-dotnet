# `provider`

Refer to the Terraform Registry for docs: [`digitalocean`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs).
