import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DigitaloceanProviderConfig {
    /**
    * The URL to use for the DigitalOcean API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#api_endpoint DigitaloceanProvider#api_endpoint}
    */
    readonly apiEndpoint?: string;
    /**
    * The maximum number of retries on a failed API request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#http_retry_max DigitaloceanProvider#http_retry_max}
    */
    readonly httpRetryMax?: number;
    /**
    * The maximum wait time (in seconds) between failed API requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#http_retry_wait_max DigitaloceanProvider#http_retry_wait_max}
    */
    readonly httpRetryWaitMax?: number;
    /**
    * The minimum wait time (in seconds) between failed API requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#http_retry_wait_min DigitaloceanProvider#http_retry_wait_min}
    */
    readonly httpRetryWaitMin?: number;
    /**
    * The rate of requests per second to limit the HTTP client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#requests_per_second DigitaloceanProvider#requests_per_second}
    */
    readonly requestsPerSecond?: number;
    /**
    * The access key ID for Spaces API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#spaces_access_id DigitaloceanProvider#spaces_access_id}
    */
    readonly spacesAccessId?: string;
    /**
    * The URL to use for the DigitalOcean Spaces API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#spaces_endpoint DigitaloceanProvider#spaces_endpoint}
    */
    readonly spacesEndpoint?: string;
    /**
    * The secret access key for Spaces API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#spaces_secret_key DigitaloceanProvider#spaces_secret_key}
    */
    readonly spacesSecretKey?: string;
    /**
    * The token key for API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#token DigitaloceanProvider#token}
    */
    readonly token?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#alias DigitaloceanProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs digitalocean}
*/
export declare class DigitaloceanProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "digitalocean";
    /**
    * Generates CDKTN code for importing a DigitaloceanProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DigitaloceanProvider to import
    * @param importFromId The id of the existing DigitaloceanProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DigitaloceanProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs digitalocean} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DigitaloceanProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DigitaloceanProviderConfig);
    private _apiEndpoint?;
    get apiEndpoint(): string | undefined;
    set apiEndpoint(value: string | undefined);
    resetApiEndpoint(): void;
    get apiEndpointInput(): string | undefined;
    private _httpRetryMax?;
    get httpRetryMax(): number | undefined;
    set httpRetryMax(value: number | undefined);
    resetHttpRetryMax(): void;
    get httpRetryMaxInput(): number | undefined;
    private _httpRetryWaitMax?;
    get httpRetryWaitMax(): number | undefined;
    set httpRetryWaitMax(value: number | undefined);
    resetHttpRetryWaitMax(): void;
    get httpRetryWaitMaxInput(): number | undefined;
    private _httpRetryWaitMin?;
    get httpRetryWaitMin(): number | undefined;
    set httpRetryWaitMin(value: number | undefined);
    resetHttpRetryWaitMin(): void;
    get httpRetryWaitMinInput(): number | undefined;
    private _requestsPerSecond?;
    get requestsPerSecond(): number | undefined;
    set requestsPerSecond(value: number | undefined);
    resetRequestsPerSecond(): void;
    get requestsPerSecondInput(): number | undefined;
    private _spacesAccessId?;
    get spacesAccessId(): string | undefined;
    set spacesAccessId(value: string | undefined);
    resetSpacesAccessId(): void;
    get spacesAccessIdInput(): string | undefined;
    private _spacesEndpoint?;
    get spacesEndpoint(): string | undefined;
    set spacesEndpoint(value: string | undefined);
    resetSpacesEndpoint(): void;
    get spacesEndpointInput(): string | undefined;
    private _spacesSecretKey?;
    get spacesSecretKey(): string | undefined;
    set spacesSecretKey(value: string | undefined);
    resetSpacesSecretKey(): void;
    get spacesSecretKeyInput(): string | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
