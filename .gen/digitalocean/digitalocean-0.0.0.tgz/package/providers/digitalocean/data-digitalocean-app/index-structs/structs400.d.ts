import * as cdktn from 'cdktn';
import { DataDigitaloceanAppSpecWorkerAlertList, DataDigitaloceanAppSpecWorkerAutoscalingList, DataDigitaloceanAppSpecWorkerBitbucketList, DataDigitaloceanAppSpecWorkerEnvList, DataDigitaloceanAppSpecWorkerGitList, DataDigitaloceanAppSpecWorkerGithubList, DataDigitaloceanAppSpecWorkerGitlabList, DataDigitaloceanAppSpecAlertList, DataDigitaloceanAppSpecDatabaseList, DataDigitaloceanAppSpecDomainList, DataDigitaloceanAppSpecEgressList, DataDigitaloceanAppSpecEnvList, DataDigitaloceanAppSpecFunctionList, DataDigitaloceanAppSpecIngressList, DataDigitaloceanAppSpecJobList, DataDigitaloceanAppSpecMaintenanceList, DataDigitaloceanAppSpecServiceList, DataDigitaloceanAppSpecStaticSiteList, DataDigitaloceanAppSpecVpcList } from './structs0';
export interface DataDigitaloceanAppSpecWorkerImageDeployOnPush {
}
export declare function dataDigitaloceanAppSpecWorkerImageDeployOnPushToTerraform(struct?: DataDigitaloceanAppSpecWorkerImageDeployOnPush): any;
export declare function dataDigitaloceanAppSpecWorkerImageDeployOnPushToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerImageDeployOnPush): any;
export declare class DataDigitaloceanAppSpecWorkerImageDeployOnPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerImageDeployOnPush | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerImageDeployOnPush | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataDigitaloceanAppSpecWorkerImageDeployOnPushList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerImageDeployOnPushOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerImage {
}
export declare function dataDigitaloceanAppSpecWorkerImageToTerraform(struct?: DataDigitaloceanAppSpecWorkerImage): any;
export declare function dataDigitaloceanAppSpecWorkerImageToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerImage): any;
export declare class DataDigitaloceanAppSpecWorkerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerImage | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerImage | undefined);
    private _deployOnPush;
    get deployOnPush(): DataDigitaloceanAppSpecWorkerImageDeployOnPushList;
    get digest(): string;
    get registry(): string;
    get registryCredentials(): string;
    get registryType(): string;
    get repository(): string;
    get tag(): string;
}
export declare class DataDigitaloceanAppSpecWorkerImageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerImageOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerLogDestinationDatadog {
}
export declare function dataDigitaloceanAppSpecWorkerLogDestinationDatadogToTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationDatadog): any;
export declare function dataDigitaloceanAppSpecWorkerLogDestinationDatadogToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationDatadog): any;
export declare class DataDigitaloceanAppSpecWorkerLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerLogDestinationDatadog | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerLogDestinationDatadog | undefined);
    get apiKey(): string;
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecWorkerLogDestinationDatadogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerLogDestinationDatadogOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerLogDestinationLogtail {
}
export declare function dataDigitaloceanAppSpecWorkerLogDestinationLogtailToTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationLogtail): any;
export declare function dataDigitaloceanAppSpecWorkerLogDestinationLogtailToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationLogtail): any;
export declare class DataDigitaloceanAppSpecWorkerLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerLogDestinationLogtail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerLogDestinationLogtail | undefined);
    get token(): string;
}
export declare class DataDigitaloceanAppSpecWorkerLogDestinationLogtailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerLogDestinationLogtailOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuth {
}
export declare function dataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuthToTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuth): any;
export declare function dataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuth): any;
export declare class DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuth | undefined);
    get password(): string;
    get user(): string;
}
export declare class DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuthList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuthOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerLogDestinationOpenSearch {
}
export declare function dataDigitaloceanAppSpecWorkerLogDestinationOpenSearchToTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationOpenSearch): any;
export declare function dataDigitaloceanAppSpecWorkerLogDestinationOpenSearchToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationOpenSearch): any;
export declare class DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerLogDestinationOpenSearch | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerLogDestinationOpenSearch | undefined);
    private _basicAuth;
    get basicAuth(): DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchBasicAuthList;
    get clusterName(): string;
    get endpoint(): string;
    get indexName(): string;
}
export declare class DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerLogDestinationPapertrail {
}
export declare function dataDigitaloceanAppSpecWorkerLogDestinationPapertrailToTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationPapertrail): any;
export declare function dataDigitaloceanAppSpecWorkerLogDestinationPapertrailToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestinationPapertrail): any;
export declare class DataDigitaloceanAppSpecWorkerLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerLogDestinationPapertrail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerLogDestinationPapertrail | undefined);
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecWorkerLogDestinationPapertrailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerLogDestinationPapertrailOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerLogDestination {
}
export declare function dataDigitaloceanAppSpecWorkerLogDestinationToTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestination): any;
export declare function dataDigitaloceanAppSpecWorkerLogDestinationToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerLogDestination): any;
export declare class DataDigitaloceanAppSpecWorkerLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerLogDestination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerLogDestination | undefined);
    private _datadog;
    get datadog(): DataDigitaloceanAppSpecWorkerLogDestinationDatadogList;
    private _logtail;
    get logtail(): DataDigitaloceanAppSpecWorkerLogDestinationLogtailList;
    get name(): string;
    private _openSearch;
    get openSearch(): DataDigitaloceanAppSpecWorkerLogDestinationOpenSearchList;
    private _papertrail;
    get papertrail(): DataDigitaloceanAppSpecWorkerLogDestinationPapertrailList;
}
export declare class DataDigitaloceanAppSpecWorkerLogDestinationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerLogDestinationOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerTermination {
}
export declare function dataDigitaloceanAppSpecWorkerTerminationToTerraform(struct?: DataDigitaloceanAppSpecWorkerTermination): any;
export declare function dataDigitaloceanAppSpecWorkerTerminationToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerTermination): any;
export declare class DataDigitaloceanAppSpecWorkerTerminationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerTermination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerTermination | undefined);
    get gracePeriodSeconds(): number;
}
export declare class DataDigitaloceanAppSpecWorkerTerminationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerTerminationOutputReference;
}
export interface DataDigitaloceanAppSpecWorker {
}
export declare function dataDigitaloceanAppSpecWorkerToTerraform(struct?: DataDigitaloceanAppSpecWorker): any;
export declare function dataDigitaloceanAppSpecWorkerToHclTerraform(struct?: DataDigitaloceanAppSpecWorker): any;
export declare class DataDigitaloceanAppSpecWorkerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorker | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorker | undefined);
    private _alert;
    get alert(): DataDigitaloceanAppSpecWorkerAlertList;
    private _autoscaling;
    get autoscaling(): DataDigitaloceanAppSpecWorkerAutoscalingList;
    private _bitbucket;
    get bitbucket(): DataDigitaloceanAppSpecWorkerBitbucketList;
    get buildCommand(): string;
    get dockerfilePath(): string;
    private _env;
    get env(): DataDigitaloceanAppSpecWorkerEnvList;
    get environmentSlug(): string;
    private _git;
    get git(): DataDigitaloceanAppSpecWorkerGitList;
    private _github;
    get github(): DataDigitaloceanAppSpecWorkerGithubList;
    private _gitlab;
    get gitlab(): DataDigitaloceanAppSpecWorkerGitlabList;
    private _image;
    get image(): DataDigitaloceanAppSpecWorkerImageList;
    get instanceCount(): number;
    get instanceSizeSlug(): string;
    private _logDestination;
    get logDestination(): DataDigitaloceanAppSpecWorkerLogDestinationList;
    get name(): string;
    get runCommand(): string;
    get sourceDir(): string;
    private _termination;
    get termination(): DataDigitaloceanAppSpecWorkerTerminationList;
}
export declare class DataDigitaloceanAppSpecWorkerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerOutputReference;
}
export interface DataDigitaloceanAppSpec {
}
export declare function dataDigitaloceanAppSpecToTerraform(struct?: DataDigitaloceanAppSpec): any;
export declare function dataDigitaloceanAppSpecToHclTerraform(struct?: DataDigitaloceanAppSpec): any;
export declare class DataDigitaloceanAppSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpec | undefined;
    set internalValue(value: DataDigitaloceanAppSpec | undefined);
    private _alert;
    get alert(): DataDigitaloceanAppSpecAlertList;
    private _database;
    get database(): DataDigitaloceanAppSpecDatabaseList;
    get disableEdgeCache(): cdktn.IResolvable;
    get disableEmailObfuscation(): cdktn.IResolvable;
    private _domain;
    get domain(): DataDigitaloceanAppSpecDomainList;
    get domains(): string[];
    private _egress;
    get egress(): DataDigitaloceanAppSpecEgressList;
    get enhancedThreatControlEnabled(): cdktn.IResolvable;
    private _env;
    get env(): DataDigitaloceanAppSpecEnvList;
    get features(): string[];
    private _function;
    get function(): DataDigitaloceanAppSpecFunctionList;
    private _ingress;
    get ingress(): DataDigitaloceanAppSpecIngressList;
    private _job;
    get job(): DataDigitaloceanAppSpecJobList;
    private _maintenance;
    get maintenance(): DataDigitaloceanAppSpecMaintenanceList;
    get name(): string;
    get region(): string;
    private _service;
    get service(): DataDigitaloceanAppSpecServiceList;
    private _staticSite;
    get staticSite(): DataDigitaloceanAppSpecStaticSiteList;
    private _vpc;
    get vpc(): DataDigitaloceanAppSpecVpcList;
    private _worker;
    get worker(): DataDigitaloceanAppSpecWorkerList;
}
export declare class DataDigitaloceanAppSpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecOutputReference;
}
export interface DataDigitaloceanAppDedicatedIps {
    /**
    * The ID of the dedicated egress IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#id DataDigitaloceanApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IP address of the dedicated egress IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#ip DataDigitaloceanApp#ip}
    */
    readonly ip?: string;
    /**
    * The status of the dedicated egress IP: 'UNKNOWN', 'ASSIGNING', 'ASSIGNED', or 'REMOVED'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#status DataDigitaloceanApp#status}
    */
    readonly status?: string;
}
export declare function dataDigitaloceanAppDedicatedIpsToTerraform(struct?: DataDigitaloceanAppDedicatedIps | cdktn.IResolvable): any;
export declare function dataDigitaloceanAppDedicatedIpsToHclTerraform(struct?: DataDigitaloceanAppDedicatedIps | cdktn.IResolvable): any;
export declare class DataDigitaloceanAppDedicatedIpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppDedicatedIps | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanAppDedicatedIps | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class DataDigitaloceanAppDedicatedIpsList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanAppDedicatedIps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppDedicatedIpsOutputReference;
}
