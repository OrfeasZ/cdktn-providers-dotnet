import * as cdktn from 'cdktn';
export interface DataDigitaloceanAppSpecAlertDestinationsSlackWebhooks {
}
export declare function dataDigitaloceanAppSpecAlertDestinationsSlackWebhooksToTerraform(struct?: DataDigitaloceanAppSpecAlertDestinationsSlackWebhooks): any;
export declare function dataDigitaloceanAppSpecAlertDestinationsSlackWebhooksToHclTerraform(struct?: DataDigitaloceanAppSpecAlertDestinationsSlackWebhooks): any;
export declare class DataDigitaloceanAppSpecAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecAlertDestinationsSlackWebhooks | undefined;
    set internalValue(value: DataDigitaloceanAppSpecAlertDestinationsSlackWebhooks | undefined);
    get channel(): string;
    get url(): string;
}
export declare class DataDigitaloceanAppSpecAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecAlertDestinationsSlackWebhooksOutputReference;
}
export interface DataDigitaloceanAppSpecAlertDestinations {
}
export declare function dataDigitaloceanAppSpecAlertDestinationsToTerraform(struct?: DataDigitaloceanAppSpecAlertDestinations): any;
export declare function dataDigitaloceanAppSpecAlertDestinationsToHclTerraform(struct?: DataDigitaloceanAppSpecAlertDestinations): any;
export declare class DataDigitaloceanAppSpecAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecAlertDestinations | undefined;
    set internalValue(value: DataDigitaloceanAppSpecAlertDestinations | undefined);
    get emails(): string[];
    private _slackWebhooks;
    get slackWebhooks(): DataDigitaloceanAppSpecAlertDestinationsSlackWebhooksList;
}
export declare class DataDigitaloceanAppSpecAlertDestinationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecAlertDestinationsOutputReference;
}
export interface DataDigitaloceanAppSpecAlert {
}
export declare function dataDigitaloceanAppSpecAlertToTerraform(struct?: DataDigitaloceanAppSpecAlert): any;
export declare function dataDigitaloceanAppSpecAlertToHclTerraform(struct?: DataDigitaloceanAppSpecAlert): any;
export declare class DataDigitaloceanAppSpecAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecAlert | undefined;
    set internalValue(value: DataDigitaloceanAppSpecAlert | undefined);
    private _destinations;
    get destinations(): DataDigitaloceanAppSpecAlertDestinationsList;
    get disabled(): cdktn.IResolvable;
    get rule(): string;
}
export declare class DataDigitaloceanAppSpecAlertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecAlertOutputReference;
}
export interface DataDigitaloceanAppSpecDatabase {
}
export declare function dataDigitaloceanAppSpecDatabaseToTerraform(struct?: DataDigitaloceanAppSpecDatabase): any;
export declare function dataDigitaloceanAppSpecDatabaseToHclTerraform(struct?: DataDigitaloceanAppSpecDatabase): any;
export declare class DataDigitaloceanAppSpecDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecDatabase | undefined;
    set internalValue(value: DataDigitaloceanAppSpecDatabase | undefined);
    get clusterName(): string;
    get dbName(): string;
    get dbUser(): string;
    get engine(): string;
    get name(): string;
    get production(): cdktn.IResolvable;
    get version(): string;
}
export declare class DataDigitaloceanAppSpecDatabaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecDatabaseOutputReference;
}
export interface DataDigitaloceanAppSpecDomain {
}
export declare function dataDigitaloceanAppSpecDomainToTerraform(struct?: DataDigitaloceanAppSpecDomain): any;
export declare function dataDigitaloceanAppSpecDomainToHclTerraform(struct?: DataDigitaloceanAppSpecDomain): any;
export declare class DataDigitaloceanAppSpecDomainOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecDomain | undefined;
    set internalValue(value: DataDigitaloceanAppSpecDomain | undefined);
    get name(): string;
    get type(): string;
    get wildcard(): cdktn.IResolvable;
    get zone(): string;
}
export declare class DataDigitaloceanAppSpecDomainList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecDomainOutputReference;
}
export interface DataDigitaloceanAppSpecEgress {
}
export declare function dataDigitaloceanAppSpecEgressToTerraform(struct?: DataDigitaloceanAppSpecEgress): any;
export declare function dataDigitaloceanAppSpecEgressToHclTerraform(struct?: DataDigitaloceanAppSpecEgress): any;
export declare class DataDigitaloceanAppSpecEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecEgress | undefined;
    set internalValue(value: DataDigitaloceanAppSpecEgress | undefined);
    get type(): string;
}
export declare class DataDigitaloceanAppSpecEgressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecEgressOutputReference;
}
export interface DataDigitaloceanAppSpecEnv {
}
export declare function dataDigitaloceanAppSpecEnvToTerraform(struct?: DataDigitaloceanAppSpecEnv): any;
export declare function dataDigitaloceanAppSpecEnvToHclTerraform(struct?: DataDigitaloceanAppSpecEnv): any;
export declare class DataDigitaloceanAppSpecEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecEnv | undefined;
    set internalValue(value: DataDigitaloceanAppSpecEnv | undefined);
    get key(): string;
    get scope(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecEnvOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooks {
}
export declare function dataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooksToTerraform(struct?: DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooks): any;
export declare function dataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooksToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooks): any;
export declare class DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooks | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooks | undefined);
    get channel(): string;
    get url(): string;
}
export declare class DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooksOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionAlertDestinations {
}
export declare function dataDigitaloceanAppSpecFunctionAlertDestinationsToTerraform(struct?: DataDigitaloceanAppSpecFunctionAlertDestinations): any;
export declare function dataDigitaloceanAppSpecFunctionAlertDestinationsToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionAlertDestinations): any;
export declare class DataDigitaloceanAppSpecFunctionAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionAlertDestinations | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionAlertDestinations | undefined);
    get emails(): string[];
    private _slackWebhooks;
    get slackWebhooks(): DataDigitaloceanAppSpecFunctionAlertDestinationsSlackWebhooksList;
}
export declare class DataDigitaloceanAppSpecFunctionAlertDestinationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionAlertDestinationsOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionAlert {
}
export declare function dataDigitaloceanAppSpecFunctionAlertToTerraform(struct?: DataDigitaloceanAppSpecFunctionAlert): any;
export declare function dataDigitaloceanAppSpecFunctionAlertToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionAlert): any;
export declare class DataDigitaloceanAppSpecFunctionAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionAlert | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionAlert | undefined);
    private _destinations;
    get destinations(): DataDigitaloceanAppSpecFunctionAlertDestinationsList;
    get disabled(): cdktn.IResolvable;
    get operator(): string;
    get rule(): string;
    get value(): number;
    get window(): string;
}
export declare class DataDigitaloceanAppSpecFunctionAlertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionAlertOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionBitbucket {
}
export declare function dataDigitaloceanAppSpecFunctionBitbucketToTerraform(struct?: DataDigitaloceanAppSpecFunctionBitbucket): any;
export declare function dataDigitaloceanAppSpecFunctionBitbucketToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionBitbucket): any;
export declare class DataDigitaloceanAppSpecFunctionBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionBitbucket | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionBitbucket | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecFunctionBitbucketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionBitbucketOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionCorsAllowOrigins {
}
export declare function dataDigitaloceanAppSpecFunctionCorsAllowOriginsToTerraform(struct?: DataDigitaloceanAppSpecFunctionCorsAllowOrigins): any;
export declare function dataDigitaloceanAppSpecFunctionCorsAllowOriginsToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionCorsAllowOrigins): any;
export declare class DataDigitaloceanAppSpecFunctionCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionCorsAllowOrigins | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionCorsAllowOrigins | undefined);
    get exact(): string;
    get prefix(): string;
    get regex(): string;
}
export declare class DataDigitaloceanAppSpecFunctionCorsAllowOriginsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionCorsAllowOriginsOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionCors {
}
export declare function dataDigitaloceanAppSpecFunctionCorsToTerraform(struct?: DataDigitaloceanAppSpecFunctionCors): any;
export declare function dataDigitaloceanAppSpecFunctionCorsToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionCors): any;
export declare class DataDigitaloceanAppSpecFunctionCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionCors | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionCors | undefined);
    get allowCredentials(): cdktn.IResolvable;
    get allowHeaders(): string[];
    get allowMethods(): string[];
    private _allowOrigins;
    get allowOrigins(): DataDigitaloceanAppSpecFunctionCorsAllowOriginsList;
    get exposeHeaders(): string[];
    get maxAge(): string;
}
export declare class DataDigitaloceanAppSpecFunctionCorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionCorsOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionEnv {
}
export declare function dataDigitaloceanAppSpecFunctionEnvToTerraform(struct?: DataDigitaloceanAppSpecFunctionEnv): any;
export declare function dataDigitaloceanAppSpecFunctionEnvToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionEnv): any;
export declare class DataDigitaloceanAppSpecFunctionEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionEnv | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionEnv | undefined);
    get key(): string;
    get scope(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecFunctionEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionEnvOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionGit {
}
export declare function dataDigitaloceanAppSpecFunctionGitToTerraform(struct?: DataDigitaloceanAppSpecFunctionGit): any;
export declare function dataDigitaloceanAppSpecFunctionGitToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionGit): any;
export declare class DataDigitaloceanAppSpecFunctionGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionGit | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionGit | undefined);
    get branch(): string;
    get repoCloneUrl(): string;
}
export declare class DataDigitaloceanAppSpecFunctionGitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionGitOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionGithub {
}
export declare function dataDigitaloceanAppSpecFunctionGithubToTerraform(struct?: DataDigitaloceanAppSpecFunctionGithub): any;
export declare function dataDigitaloceanAppSpecFunctionGithubToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionGithub): any;
export declare class DataDigitaloceanAppSpecFunctionGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionGithub | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionGithub | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecFunctionGithubList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionGithubOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionGitlab {
}
export declare function dataDigitaloceanAppSpecFunctionGitlabToTerraform(struct?: DataDigitaloceanAppSpecFunctionGitlab): any;
export declare function dataDigitaloceanAppSpecFunctionGitlabToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionGitlab): any;
export declare class DataDigitaloceanAppSpecFunctionGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionGitlab | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionGitlab | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecFunctionGitlabList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionGitlabOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionLogDestinationDatadog {
}
export declare function dataDigitaloceanAppSpecFunctionLogDestinationDatadogToTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationDatadog): any;
export declare function dataDigitaloceanAppSpecFunctionLogDestinationDatadogToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationDatadog): any;
export declare class DataDigitaloceanAppSpecFunctionLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionLogDestinationDatadog | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionLogDestinationDatadog | undefined);
    get apiKey(): string;
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecFunctionLogDestinationDatadogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionLogDestinationDatadogOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionLogDestinationLogtail {
}
export declare function dataDigitaloceanAppSpecFunctionLogDestinationLogtailToTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationLogtail): any;
export declare function dataDigitaloceanAppSpecFunctionLogDestinationLogtailToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationLogtail): any;
export declare class DataDigitaloceanAppSpecFunctionLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionLogDestinationLogtail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionLogDestinationLogtail | undefined);
    get token(): string;
}
export declare class DataDigitaloceanAppSpecFunctionLogDestinationLogtailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionLogDestinationLogtailOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuth {
}
export declare function dataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuthToTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuth): any;
export declare function dataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuth): any;
export declare class DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuth | undefined);
    get password(): string;
    get user(): string;
}
export declare class DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuthList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuthOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionLogDestinationOpenSearch {
}
export declare function dataDigitaloceanAppSpecFunctionLogDestinationOpenSearchToTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationOpenSearch): any;
export declare function dataDigitaloceanAppSpecFunctionLogDestinationOpenSearchToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationOpenSearch): any;
export declare class DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionLogDestinationOpenSearch | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionLogDestinationOpenSearch | undefined);
    private _basicAuth;
    get basicAuth(): DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchBasicAuthList;
    get clusterName(): string;
    get endpoint(): string;
    get indexName(): string;
}
export declare class DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionLogDestinationPapertrail {
}
export declare function dataDigitaloceanAppSpecFunctionLogDestinationPapertrailToTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationPapertrail): any;
export declare function dataDigitaloceanAppSpecFunctionLogDestinationPapertrailToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestinationPapertrail): any;
export declare class DataDigitaloceanAppSpecFunctionLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionLogDestinationPapertrail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionLogDestinationPapertrail | undefined);
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecFunctionLogDestinationPapertrailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionLogDestinationPapertrailOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionLogDestination {
}
export declare function dataDigitaloceanAppSpecFunctionLogDestinationToTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestination): any;
export declare function dataDigitaloceanAppSpecFunctionLogDestinationToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionLogDestination): any;
export declare class DataDigitaloceanAppSpecFunctionLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionLogDestination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionLogDestination | undefined);
    private _datadog;
    get datadog(): DataDigitaloceanAppSpecFunctionLogDestinationDatadogList;
    private _logtail;
    get logtail(): DataDigitaloceanAppSpecFunctionLogDestinationLogtailList;
    get name(): string;
    private _openSearch;
    get openSearch(): DataDigitaloceanAppSpecFunctionLogDestinationOpenSearchList;
    private _papertrail;
    get papertrail(): DataDigitaloceanAppSpecFunctionLogDestinationPapertrailList;
}
export declare class DataDigitaloceanAppSpecFunctionLogDestinationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionLogDestinationOutputReference;
}
export interface DataDigitaloceanAppSpecFunctionRoutes {
}
export declare function dataDigitaloceanAppSpecFunctionRoutesToTerraform(struct?: DataDigitaloceanAppSpecFunctionRoutes): any;
export declare function dataDigitaloceanAppSpecFunctionRoutesToHclTerraform(struct?: DataDigitaloceanAppSpecFunctionRoutes): any;
export declare class DataDigitaloceanAppSpecFunctionRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunctionRoutes | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunctionRoutes | undefined);
    get path(): string;
    get preservePathPrefix(): cdktn.IResolvable;
}
export declare class DataDigitaloceanAppSpecFunctionRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionRoutesOutputReference;
}
export interface DataDigitaloceanAppSpecFunction {
}
export declare function dataDigitaloceanAppSpecFunctionToTerraform(struct?: DataDigitaloceanAppSpecFunction): any;
export declare function dataDigitaloceanAppSpecFunctionToHclTerraform(struct?: DataDigitaloceanAppSpecFunction): any;
export declare class DataDigitaloceanAppSpecFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecFunction | undefined;
    set internalValue(value: DataDigitaloceanAppSpecFunction | undefined);
    private _alert;
    get alert(): DataDigitaloceanAppSpecFunctionAlertList;
    private _bitbucket;
    get bitbucket(): DataDigitaloceanAppSpecFunctionBitbucketList;
    private _cors;
    get cors(): DataDigitaloceanAppSpecFunctionCorsList;
    private _env;
    get env(): DataDigitaloceanAppSpecFunctionEnvList;
    private _git;
    get git(): DataDigitaloceanAppSpecFunctionGitList;
    private _github;
    get github(): DataDigitaloceanAppSpecFunctionGithubList;
    private _gitlab;
    get gitlab(): DataDigitaloceanAppSpecFunctionGitlabList;
    private _logDestination;
    get logDestination(): DataDigitaloceanAppSpecFunctionLogDestinationList;
    get name(): string;
    private _routes;
    get routes(): DataDigitaloceanAppSpecFunctionRoutesList;
    get sourceDir(): string;
}
export declare class DataDigitaloceanAppSpecFunctionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecFunctionOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleComponent {
}
export declare function dataDigitaloceanAppSpecIngressRuleComponentToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleComponent): any;
export declare function dataDigitaloceanAppSpecIngressRuleComponentToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleComponent): any;
export declare class DataDigitaloceanAppSpecIngressRuleComponentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleComponent | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleComponent | undefined);
    get name(): string;
    get preservePathPrefix(): cdktn.IResolvable;
    get rewrite(): string;
}
export declare class DataDigitaloceanAppSpecIngressRuleComponentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleComponentOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleCorsAllowOrigins {
}
export declare function dataDigitaloceanAppSpecIngressRuleCorsAllowOriginsToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleCorsAllowOrigins): any;
export declare function dataDigitaloceanAppSpecIngressRuleCorsAllowOriginsToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleCorsAllowOrigins): any;
export declare class DataDigitaloceanAppSpecIngressRuleCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleCorsAllowOrigins | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleCorsAllowOrigins | undefined);
    get exact(): string;
    get prefix(): string;
    get regex(): string;
}
export declare class DataDigitaloceanAppSpecIngressRuleCorsAllowOriginsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleCorsAllowOriginsOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleCors {
}
export declare function dataDigitaloceanAppSpecIngressRuleCorsToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleCors): any;
export declare function dataDigitaloceanAppSpecIngressRuleCorsToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleCors): any;
export declare class DataDigitaloceanAppSpecIngressRuleCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleCors | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleCors | undefined);
    get allowCredentials(): cdktn.IResolvable;
    get allowHeaders(): string[];
    get allowMethods(): string[];
    private _allowOrigins;
    get allowOrigins(): DataDigitaloceanAppSpecIngressRuleCorsAllowOriginsList;
    get exposeHeaders(): string[];
    get maxAge(): string;
}
export declare class DataDigitaloceanAppSpecIngressRuleCorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleCorsOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleMatchAuthority {
}
export declare function dataDigitaloceanAppSpecIngressRuleMatchAuthorityToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleMatchAuthority): any;
export declare function dataDigitaloceanAppSpecIngressRuleMatchAuthorityToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleMatchAuthority): any;
export declare class DataDigitaloceanAppSpecIngressRuleMatchAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleMatchAuthority | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleMatchAuthority | undefined);
    get exact(): string;
}
export declare class DataDigitaloceanAppSpecIngressRuleMatchAuthorityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleMatchAuthorityOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleMatchPath {
}
export declare function dataDigitaloceanAppSpecIngressRuleMatchPathToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleMatchPath): any;
export declare function dataDigitaloceanAppSpecIngressRuleMatchPathToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleMatchPath): any;
export declare class DataDigitaloceanAppSpecIngressRuleMatchPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleMatchPath | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleMatchPath | undefined);
    get prefix(): string;
}
export declare class DataDigitaloceanAppSpecIngressRuleMatchPathList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleMatchPathOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleMatch {
}
export declare function dataDigitaloceanAppSpecIngressRuleMatchToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleMatch): any;
export declare function dataDigitaloceanAppSpecIngressRuleMatchToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleMatch): any;
export declare class DataDigitaloceanAppSpecIngressRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleMatch | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleMatch | undefined);
    private _authority;
    get authority(): DataDigitaloceanAppSpecIngressRuleMatchAuthorityList;
    private _path;
    get path(): DataDigitaloceanAppSpecIngressRuleMatchPathList;
}
export declare class DataDigitaloceanAppSpecIngressRuleMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleMatchOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRuleRedirect {
}
export declare function dataDigitaloceanAppSpecIngressRuleRedirectToTerraform(struct?: DataDigitaloceanAppSpecIngressRuleRedirect): any;
export declare function dataDigitaloceanAppSpecIngressRuleRedirectToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRuleRedirect): any;
export declare class DataDigitaloceanAppSpecIngressRuleRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRuleRedirect | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRuleRedirect | undefined);
    get authority(): string;
    get port(): number;
    get redirectCode(): number;
    get scheme(): string;
    get uri(): string;
}
export declare class DataDigitaloceanAppSpecIngressRuleRedirectList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleRedirectOutputReference;
}
export interface DataDigitaloceanAppSpecIngressRule {
}
export declare function dataDigitaloceanAppSpecIngressRuleToTerraform(struct?: DataDigitaloceanAppSpecIngressRule): any;
export declare function dataDigitaloceanAppSpecIngressRuleToHclTerraform(struct?: DataDigitaloceanAppSpecIngressRule): any;
export declare class DataDigitaloceanAppSpecIngressRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressRule | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressRule | undefined);
    private _component;
    get component(): DataDigitaloceanAppSpecIngressRuleComponentList;
    private _cors;
    get cors(): DataDigitaloceanAppSpecIngressRuleCorsList;
    private _match;
    get match(): DataDigitaloceanAppSpecIngressRuleMatchList;
    private _redirect;
    get redirect(): DataDigitaloceanAppSpecIngressRuleRedirectList;
}
export declare class DataDigitaloceanAppSpecIngressRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressRuleOutputReference;
}
export interface DataDigitaloceanAppSpecIngressSecureHeader {
}
export declare function dataDigitaloceanAppSpecIngressSecureHeaderToTerraform(struct?: DataDigitaloceanAppSpecIngressSecureHeader): any;
export declare function dataDigitaloceanAppSpecIngressSecureHeaderToHclTerraform(struct?: DataDigitaloceanAppSpecIngressSecureHeader): any;
export declare class DataDigitaloceanAppSpecIngressSecureHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngressSecureHeader | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngressSecureHeader | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecIngressSecureHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressSecureHeaderOutputReference;
}
export interface DataDigitaloceanAppSpecIngress {
}
export declare function dataDigitaloceanAppSpecIngressToTerraform(struct?: DataDigitaloceanAppSpecIngress): any;
export declare function dataDigitaloceanAppSpecIngressToHclTerraform(struct?: DataDigitaloceanAppSpecIngress): any;
export declare class DataDigitaloceanAppSpecIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecIngress | undefined;
    set internalValue(value: DataDigitaloceanAppSpecIngress | undefined);
    private _rule;
    get rule(): DataDigitaloceanAppSpecIngressRuleList;
    private _secureHeader;
    get secureHeader(): DataDigitaloceanAppSpecIngressSecureHeaderList;
}
export declare class DataDigitaloceanAppSpecIngressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecIngressOutputReference;
}
export interface DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooks {
}
export declare function dataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooksToTerraform(struct?: DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooks): any;
export declare function dataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooksToHclTerraform(struct?: DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooks): any;
export declare class DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooks | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooks | undefined);
    get channel(): string;
    get url(): string;
}
export declare class DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooksOutputReference;
}
export interface DataDigitaloceanAppSpecJobAlertDestinations {
}
export declare function dataDigitaloceanAppSpecJobAlertDestinationsToTerraform(struct?: DataDigitaloceanAppSpecJobAlertDestinations): any;
export declare function dataDigitaloceanAppSpecJobAlertDestinationsToHclTerraform(struct?: DataDigitaloceanAppSpecJobAlertDestinations): any;
export declare class DataDigitaloceanAppSpecJobAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobAlertDestinations | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobAlertDestinations | undefined);
    get emails(): string[];
    private _slackWebhooks;
    get slackWebhooks(): DataDigitaloceanAppSpecJobAlertDestinationsSlackWebhooksList;
}
export declare class DataDigitaloceanAppSpecJobAlertDestinationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobAlertDestinationsOutputReference;
}
export interface DataDigitaloceanAppSpecJobAlert {
}
export declare function dataDigitaloceanAppSpecJobAlertToTerraform(struct?: DataDigitaloceanAppSpecJobAlert): any;
export declare function dataDigitaloceanAppSpecJobAlertToHclTerraform(struct?: DataDigitaloceanAppSpecJobAlert): any;
export declare class DataDigitaloceanAppSpecJobAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobAlert | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobAlert | undefined);
    private _destinations;
    get destinations(): DataDigitaloceanAppSpecJobAlertDestinationsList;
    get disabled(): cdktn.IResolvable;
    get operator(): string;
    get rule(): string;
    get value(): number;
    get window(): string;
}
export declare class DataDigitaloceanAppSpecJobAlertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobAlertOutputReference;
}
export interface DataDigitaloceanAppSpecJobBitbucket {
}
export declare function dataDigitaloceanAppSpecJobBitbucketToTerraform(struct?: DataDigitaloceanAppSpecJobBitbucket): any;
export declare function dataDigitaloceanAppSpecJobBitbucketToHclTerraform(struct?: DataDigitaloceanAppSpecJobBitbucket): any;
export declare class DataDigitaloceanAppSpecJobBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobBitbucket | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobBitbucket | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecJobBitbucketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobBitbucketOutputReference;
}
export interface DataDigitaloceanAppSpecJobEnv {
}
export declare function dataDigitaloceanAppSpecJobEnvToTerraform(struct?: DataDigitaloceanAppSpecJobEnv): any;
export declare function dataDigitaloceanAppSpecJobEnvToHclTerraform(struct?: DataDigitaloceanAppSpecJobEnv): any;
export declare class DataDigitaloceanAppSpecJobEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobEnv | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobEnv | undefined);
    get key(): string;
    get scope(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecJobEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobEnvOutputReference;
}
export interface DataDigitaloceanAppSpecJobGit {
}
export declare function dataDigitaloceanAppSpecJobGitToTerraform(struct?: DataDigitaloceanAppSpecJobGit): any;
export declare function dataDigitaloceanAppSpecJobGitToHclTerraform(struct?: DataDigitaloceanAppSpecJobGit): any;
export declare class DataDigitaloceanAppSpecJobGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobGit | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobGit | undefined);
    get branch(): string;
    get repoCloneUrl(): string;
}
export declare class DataDigitaloceanAppSpecJobGitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobGitOutputReference;
}
export interface DataDigitaloceanAppSpecJobGithub {
}
export declare function dataDigitaloceanAppSpecJobGithubToTerraform(struct?: DataDigitaloceanAppSpecJobGithub): any;
export declare function dataDigitaloceanAppSpecJobGithubToHclTerraform(struct?: DataDigitaloceanAppSpecJobGithub): any;
export declare class DataDigitaloceanAppSpecJobGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobGithub | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobGithub | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecJobGithubList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobGithubOutputReference;
}
export interface DataDigitaloceanAppSpecJobGitlab {
}
export declare function dataDigitaloceanAppSpecJobGitlabToTerraform(struct?: DataDigitaloceanAppSpecJobGitlab): any;
export declare function dataDigitaloceanAppSpecJobGitlabToHclTerraform(struct?: DataDigitaloceanAppSpecJobGitlab): any;
export declare class DataDigitaloceanAppSpecJobGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobGitlab | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobGitlab | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecJobGitlabList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobGitlabOutputReference;
}
export interface DataDigitaloceanAppSpecJobImageDeployOnPush {
}
export declare function dataDigitaloceanAppSpecJobImageDeployOnPushToTerraform(struct?: DataDigitaloceanAppSpecJobImageDeployOnPush): any;
export declare function dataDigitaloceanAppSpecJobImageDeployOnPushToHclTerraform(struct?: DataDigitaloceanAppSpecJobImageDeployOnPush): any;
export declare class DataDigitaloceanAppSpecJobImageDeployOnPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobImageDeployOnPush | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobImageDeployOnPush | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataDigitaloceanAppSpecJobImageDeployOnPushList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobImageDeployOnPushOutputReference;
}
export interface DataDigitaloceanAppSpecJobImage {
}
export declare function dataDigitaloceanAppSpecJobImageToTerraform(struct?: DataDigitaloceanAppSpecJobImage): any;
export declare function dataDigitaloceanAppSpecJobImageToHclTerraform(struct?: DataDigitaloceanAppSpecJobImage): any;
export declare class DataDigitaloceanAppSpecJobImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobImage | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobImage | undefined);
    private _deployOnPush;
    get deployOnPush(): DataDigitaloceanAppSpecJobImageDeployOnPushList;
    get digest(): string;
    get registry(): string;
    get registryCredentials(): string;
    get registryType(): string;
    get repository(): string;
    get tag(): string;
}
export declare class DataDigitaloceanAppSpecJobImageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobImageOutputReference;
}
export interface DataDigitaloceanAppSpecJobLogDestinationDatadog {
}
export declare function dataDigitaloceanAppSpecJobLogDestinationDatadogToTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationDatadog): any;
export declare function dataDigitaloceanAppSpecJobLogDestinationDatadogToHclTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationDatadog): any;
export declare class DataDigitaloceanAppSpecJobLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobLogDestinationDatadog | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobLogDestinationDatadog | undefined);
    get apiKey(): string;
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecJobLogDestinationDatadogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobLogDestinationDatadogOutputReference;
}
export interface DataDigitaloceanAppSpecJobLogDestinationLogtail {
}
export declare function dataDigitaloceanAppSpecJobLogDestinationLogtailToTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationLogtail): any;
export declare function dataDigitaloceanAppSpecJobLogDestinationLogtailToHclTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationLogtail): any;
export declare class DataDigitaloceanAppSpecJobLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobLogDestinationLogtail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobLogDestinationLogtail | undefined);
    get token(): string;
}
export declare class DataDigitaloceanAppSpecJobLogDestinationLogtailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobLogDestinationLogtailOutputReference;
}
export interface DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuth {
}
export declare function dataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuthToTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuth): any;
export declare function dataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuth): any;
export declare class DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuth | undefined);
    get password(): string;
    get user(): string;
}
export declare class DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuthList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuthOutputReference;
}
export interface DataDigitaloceanAppSpecJobLogDestinationOpenSearch {
}
export declare function dataDigitaloceanAppSpecJobLogDestinationOpenSearchToTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationOpenSearch): any;
export declare function dataDigitaloceanAppSpecJobLogDestinationOpenSearchToHclTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationOpenSearch): any;
export declare class DataDigitaloceanAppSpecJobLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobLogDestinationOpenSearch | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobLogDestinationOpenSearch | undefined);
    private _basicAuth;
    get basicAuth(): DataDigitaloceanAppSpecJobLogDestinationOpenSearchBasicAuthList;
    get clusterName(): string;
    get endpoint(): string;
    get indexName(): string;
}
export declare class DataDigitaloceanAppSpecJobLogDestinationOpenSearchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobLogDestinationOpenSearchOutputReference;
}
export interface DataDigitaloceanAppSpecJobLogDestinationPapertrail {
}
export declare function dataDigitaloceanAppSpecJobLogDestinationPapertrailToTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationPapertrail): any;
export declare function dataDigitaloceanAppSpecJobLogDestinationPapertrailToHclTerraform(struct?: DataDigitaloceanAppSpecJobLogDestinationPapertrail): any;
export declare class DataDigitaloceanAppSpecJobLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobLogDestinationPapertrail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobLogDestinationPapertrail | undefined);
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecJobLogDestinationPapertrailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobLogDestinationPapertrailOutputReference;
}
export interface DataDigitaloceanAppSpecJobLogDestination {
}
export declare function dataDigitaloceanAppSpecJobLogDestinationToTerraform(struct?: DataDigitaloceanAppSpecJobLogDestination): any;
export declare function dataDigitaloceanAppSpecJobLogDestinationToHclTerraform(struct?: DataDigitaloceanAppSpecJobLogDestination): any;
export declare class DataDigitaloceanAppSpecJobLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobLogDestination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobLogDestination | undefined);
    private _datadog;
    get datadog(): DataDigitaloceanAppSpecJobLogDestinationDatadogList;
    private _logtail;
    get logtail(): DataDigitaloceanAppSpecJobLogDestinationLogtailList;
    get name(): string;
    private _openSearch;
    get openSearch(): DataDigitaloceanAppSpecJobLogDestinationOpenSearchList;
    private _papertrail;
    get papertrail(): DataDigitaloceanAppSpecJobLogDestinationPapertrailList;
}
export declare class DataDigitaloceanAppSpecJobLogDestinationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobLogDestinationOutputReference;
}
export interface DataDigitaloceanAppSpecJobTermination {
}
export declare function dataDigitaloceanAppSpecJobTerminationToTerraform(struct?: DataDigitaloceanAppSpecJobTermination): any;
export declare function dataDigitaloceanAppSpecJobTerminationToHclTerraform(struct?: DataDigitaloceanAppSpecJobTermination): any;
export declare class DataDigitaloceanAppSpecJobTerminationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJobTermination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJobTermination | undefined);
    get gracePeriodSeconds(): number;
}
export declare class DataDigitaloceanAppSpecJobTerminationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobTerminationOutputReference;
}
export interface DataDigitaloceanAppSpecJob {
}
export declare function dataDigitaloceanAppSpecJobToTerraform(struct?: DataDigitaloceanAppSpecJob): any;
export declare function dataDigitaloceanAppSpecJobToHclTerraform(struct?: DataDigitaloceanAppSpecJob): any;
export declare class DataDigitaloceanAppSpecJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecJob | undefined;
    set internalValue(value: DataDigitaloceanAppSpecJob | undefined);
    private _alert;
    get alert(): DataDigitaloceanAppSpecJobAlertList;
    private _bitbucket;
    get bitbucket(): DataDigitaloceanAppSpecJobBitbucketList;
    get buildCommand(): string;
    get dockerfilePath(): string;
    private _env;
    get env(): DataDigitaloceanAppSpecJobEnvList;
    get environmentSlug(): string;
    private _git;
    get git(): DataDigitaloceanAppSpecJobGitList;
    private _github;
    get github(): DataDigitaloceanAppSpecJobGithubList;
    private _gitlab;
    get gitlab(): DataDigitaloceanAppSpecJobGitlabList;
    private _image;
    get image(): DataDigitaloceanAppSpecJobImageList;
    get instanceCount(): number;
    get instanceSizeSlug(): string;
    get kind(): string;
    private _logDestination;
    get logDestination(): DataDigitaloceanAppSpecJobLogDestinationList;
    get name(): string;
    get runCommand(): string;
    get sourceDir(): string;
    private _termination;
    get termination(): DataDigitaloceanAppSpecJobTerminationList;
}
export declare class DataDigitaloceanAppSpecJobList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecJobOutputReference;
}
export interface DataDigitaloceanAppSpecMaintenance {
}
export declare function dataDigitaloceanAppSpecMaintenanceToTerraform(struct?: DataDigitaloceanAppSpecMaintenance): any;
export declare function dataDigitaloceanAppSpecMaintenanceToHclTerraform(struct?: DataDigitaloceanAppSpecMaintenance): any;
export declare class DataDigitaloceanAppSpecMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecMaintenance | undefined;
    set internalValue(value: DataDigitaloceanAppSpecMaintenance | undefined);
    get archive(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get offlinePageUrl(): string;
}
export declare class DataDigitaloceanAppSpecMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecMaintenanceOutputReference;
}
export interface DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooks {
}
export declare function dataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooksToTerraform(struct?: DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooks): any;
export declare function dataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooksToHclTerraform(struct?: DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooks): any;
export declare class DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooks | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooks | undefined);
    get channel(): string;
    get url(): string;
}
export declare class DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooksOutputReference;
}
export interface DataDigitaloceanAppSpecServiceAlertDestinations {
}
export declare function dataDigitaloceanAppSpecServiceAlertDestinationsToTerraform(struct?: DataDigitaloceanAppSpecServiceAlertDestinations): any;
export declare function dataDigitaloceanAppSpecServiceAlertDestinationsToHclTerraform(struct?: DataDigitaloceanAppSpecServiceAlertDestinations): any;
export declare class DataDigitaloceanAppSpecServiceAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceAlertDestinations | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceAlertDestinations | undefined);
    get emails(): string[];
    private _slackWebhooks;
    get slackWebhooks(): DataDigitaloceanAppSpecServiceAlertDestinationsSlackWebhooksList;
}
export declare class DataDigitaloceanAppSpecServiceAlertDestinationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceAlertDestinationsOutputReference;
}
export interface DataDigitaloceanAppSpecServiceAlert {
}
export declare function dataDigitaloceanAppSpecServiceAlertToTerraform(struct?: DataDigitaloceanAppSpecServiceAlert): any;
export declare function dataDigitaloceanAppSpecServiceAlertToHclTerraform(struct?: DataDigitaloceanAppSpecServiceAlert): any;
export declare class DataDigitaloceanAppSpecServiceAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceAlert | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceAlert | undefined);
    private _destinations;
    get destinations(): DataDigitaloceanAppSpecServiceAlertDestinationsList;
    get disabled(): cdktn.IResolvable;
    get operator(): string;
    get rule(): string;
    get value(): number;
    get window(): string;
}
export declare class DataDigitaloceanAppSpecServiceAlertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceAlertOutputReference;
}
export interface DataDigitaloceanAppSpecServiceAutoscalingMetricsCpu {
}
export declare function dataDigitaloceanAppSpecServiceAutoscalingMetricsCpuToTerraform(struct?: DataDigitaloceanAppSpecServiceAutoscalingMetricsCpu): any;
export declare function dataDigitaloceanAppSpecServiceAutoscalingMetricsCpuToHclTerraform(struct?: DataDigitaloceanAppSpecServiceAutoscalingMetricsCpu): any;
export declare class DataDigitaloceanAppSpecServiceAutoscalingMetricsCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceAutoscalingMetricsCpu | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceAutoscalingMetricsCpu | undefined);
    get percent(): number;
}
export declare class DataDigitaloceanAppSpecServiceAutoscalingMetricsCpuList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceAutoscalingMetricsCpuOutputReference;
}
export interface DataDigitaloceanAppSpecServiceAutoscalingMetrics {
}
export declare function dataDigitaloceanAppSpecServiceAutoscalingMetricsToTerraform(struct?: DataDigitaloceanAppSpecServiceAutoscalingMetrics): any;
export declare function dataDigitaloceanAppSpecServiceAutoscalingMetricsToHclTerraform(struct?: DataDigitaloceanAppSpecServiceAutoscalingMetrics): any;
export declare class DataDigitaloceanAppSpecServiceAutoscalingMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceAutoscalingMetrics | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceAutoscalingMetrics | undefined);
    private _cpu;
    get cpu(): DataDigitaloceanAppSpecServiceAutoscalingMetricsCpuList;
}
export declare class DataDigitaloceanAppSpecServiceAutoscalingMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceAutoscalingMetricsOutputReference;
}
export interface DataDigitaloceanAppSpecServiceAutoscaling {
}
export declare function dataDigitaloceanAppSpecServiceAutoscalingToTerraform(struct?: DataDigitaloceanAppSpecServiceAutoscaling): any;
export declare function dataDigitaloceanAppSpecServiceAutoscalingToHclTerraform(struct?: DataDigitaloceanAppSpecServiceAutoscaling): any;
export declare class DataDigitaloceanAppSpecServiceAutoscalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceAutoscaling | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceAutoscaling | undefined);
    get maxInstanceCount(): number;
    private _metrics;
    get metrics(): DataDigitaloceanAppSpecServiceAutoscalingMetricsList;
    get minInstanceCount(): number;
}
export declare class DataDigitaloceanAppSpecServiceAutoscalingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceAutoscalingOutputReference;
}
export interface DataDigitaloceanAppSpecServiceBitbucket {
}
export declare function dataDigitaloceanAppSpecServiceBitbucketToTerraform(struct?: DataDigitaloceanAppSpecServiceBitbucket): any;
export declare function dataDigitaloceanAppSpecServiceBitbucketToHclTerraform(struct?: DataDigitaloceanAppSpecServiceBitbucket): any;
export declare class DataDigitaloceanAppSpecServiceBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceBitbucket | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceBitbucket | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecServiceBitbucketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceBitbucketOutputReference;
}
export interface DataDigitaloceanAppSpecServiceCorsAllowOrigins {
}
export declare function dataDigitaloceanAppSpecServiceCorsAllowOriginsToTerraform(struct?: DataDigitaloceanAppSpecServiceCorsAllowOrigins): any;
export declare function dataDigitaloceanAppSpecServiceCorsAllowOriginsToHclTerraform(struct?: DataDigitaloceanAppSpecServiceCorsAllowOrigins): any;
export declare class DataDigitaloceanAppSpecServiceCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceCorsAllowOrigins | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceCorsAllowOrigins | undefined);
    get exact(): string;
    get prefix(): string;
    get regex(): string;
}
export declare class DataDigitaloceanAppSpecServiceCorsAllowOriginsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceCorsAllowOriginsOutputReference;
}
export interface DataDigitaloceanAppSpecServiceCors {
}
export declare function dataDigitaloceanAppSpecServiceCorsToTerraform(struct?: DataDigitaloceanAppSpecServiceCors): any;
export declare function dataDigitaloceanAppSpecServiceCorsToHclTerraform(struct?: DataDigitaloceanAppSpecServiceCors): any;
export declare class DataDigitaloceanAppSpecServiceCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceCors | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceCors | undefined);
    get allowCredentials(): cdktn.IResolvable;
    get allowHeaders(): string[];
    get allowMethods(): string[];
    private _allowOrigins;
    get allowOrigins(): DataDigitaloceanAppSpecServiceCorsAllowOriginsList;
    get exposeHeaders(): string[];
    get maxAge(): string;
}
export declare class DataDigitaloceanAppSpecServiceCorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceCorsOutputReference;
}
export interface DataDigitaloceanAppSpecServiceEnv {
}
export declare function dataDigitaloceanAppSpecServiceEnvToTerraform(struct?: DataDigitaloceanAppSpecServiceEnv): any;
export declare function dataDigitaloceanAppSpecServiceEnvToHclTerraform(struct?: DataDigitaloceanAppSpecServiceEnv): any;
export declare class DataDigitaloceanAppSpecServiceEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceEnv | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceEnv | undefined);
    get key(): string;
    get scope(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecServiceEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceEnvOutputReference;
}
export interface DataDigitaloceanAppSpecServiceGit {
}
export declare function dataDigitaloceanAppSpecServiceGitToTerraform(struct?: DataDigitaloceanAppSpecServiceGit): any;
export declare function dataDigitaloceanAppSpecServiceGitToHclTerraform(struct?: DataDigitaloceanAppSpecServiceGit): any;
export declare class DataDigitaloceanAppSpecServiceGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceGit | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceGit | undefined);
    get branch(): string;
    get repoCloneUrl(): string;
}
export declare class DataDigitaloceanAppSpecServiceGitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceGitOutputReference;
}
export interface DataDigitaloceanAppSpecServiceGithub {
}
export declare function dataDigitaloceanAppSpecServiceGithubToTerraform(struct?: DataDigitaloceanAppSpecServiceGithub): any;
export declare function dataDigitaloceanAppSpecServiceGithubToHclTerraform(struct?: DataDigitaloceanAppSpecServiceGithub): any;
export declare class DataDigitaloceanAppSpecServiceGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceGithub | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceGithub | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecServiceGithubList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceGithubOutputReference;
}
export interface DataDigitaloceanAppSpecServiceGitlab {
}
export declare function dataDigitaloceanAppSpecServiceGitlabToTerraform(struct?: DataDigitaloceanAppSpecServiceGitlab): any;
export declare function dataDigitaloceanAppSpecServiceGitlabToHclTerraform(struct?: DataDigitaloceanAppSpecServiceGitlab): any;
export declare class DataDigitaloceanAppSpecServiceGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceGitlab | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceGitlab | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecServiceGitlabList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceGitlabOutputReference;
}
export interface DataDigitaloceanAppSpecServiceHealthCheck {
}
export declare function dataDigitaloceanAppSpecServiceHealthCheckToTerraform(struct?: DataDigitaloceanAppSpecServiceHealthCheck): any;
export declare function dataDigitaloceanAppSpecServiceHealthCheckToHclTerraform(struct?: DataDigitaloceanAppSpecServiceHealthCheck): any;
export declare class DataDigitaloceanAppSpecServiceHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceHealthCheck | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceHealthCheck | undefined);
    get failureThreshold(): number;
    get httpPath(): string;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get port(): number;
    get successThreshold(): number;
    get timeoutSeconds(): number;
}
export declare class DataDigitaloceanAppSpecServiceHealthCheckList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceHealthCheckOutputReference;
}
export interface DataDigitaloceanAppSpecServiceImageDeployOnPush {
}
export declare function dataDigitaloceanAppSpecServiceImageDeployOnPushToTerraform(struct?: DataDigitaloceanAppSpecServiceImageDeployOnPush): any;
export declare function dataDigitaloceanAppSpecServiceImageDeployOnPushToHclTerraform(struct?: DataDigitaloceanAppSpecServiceImageDeployOnPush): any;
export declare class DataDigitaloceanAppSpecServiceImageDeployOnPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceImageDeployOnPush | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceImageDeployOnPush | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataDigitaloceanAppSpecServiceImageDeployOnPushList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceImageDeployOnPushOutputReference;
}
export interface DataDigitaloceanAppSpecServiceImage {
}
export declare function dataDigitaloceanAppSpecServiceImageToTerraform(struct?: DataDigitaloceanAppSpecServiceImage): any;
export declare function dataDigitaloceanAppSpecServiceImageToHclTerraform(struct?: DataDigitaloceanAppSpecServiceImage): any;
export declare class DataDigitaloceanAppSpecServiceImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceImage | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceImage | undefined);
    private _deployOnPush;
    get deployOnPush(): DataDigitaloceanAppSpecServiceImageDeployOnPushList;
    get digest(): string;
    get registry(): string;
    get registryCredentials(): string;
    get registryType(): string;
    get repository(): string;
    get tag(): string;
}
export declare class DataDigitaloceanAppSpecServiceImageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceImageOutputReference;
}
export interface DataDigitaloceanAppSpecServiceLogDestinationDatadog {
}
export declare function dataDigitaloceanAppSpecServiceLogDestinationDatadogToTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationDatadog): any;
export declare function dataDigitaloceanAppSpecServiceLogDestinationDatadogToHclTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationDatadog): any;
export declare class DataDigitaloceanAppSpecServiceLogDestinationDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceLogDestinationDatadog | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceLogDestinationDatadog | undefined);
    get apiKey(): string;
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecServiceLogDestinationDatadogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceLogDestinationDatadogOutputReference;
}
export interface DataDigitaloceanAppSpecServiceLogDestinationLogtail {
}
export declare function dataDigitaloceanAppSpecServiceLogDestinationLogtailToTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationLogtail): any;
export declare function dataDigitaloceanAppSpecServiceLogDestinationLogtailToHclTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationLogtail): any;
export declare class DataDigitaloceanAppSpecServiceLogDestinationLogtailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceLogDestinationLogtail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceLogDestinationLogtail | undefined);
    get token(): string;
}
export declare class DataDigitaloceanAppSpecServiceLogDestinationLogtailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceLogDestinationLogtailOutputReference;
}
export interface DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuth {
}
export declare function dataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuthToTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuth): any;
export declare function dataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuthToHclTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuth): any;
export declare class DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuth | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuth | undefined);
    get password(): string;
    get user(): string;
}
export declare class DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuthList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuthOutputReference;
}
export interface DataDigitaloceanAppSpecServiceLogDestinationOpenSearch {
}
export declare function dataDigitaloceanAppSpecServiceLogDestinationOpenSearchToTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationOpenSearch): any;
export declare function dataDigitaloceanAppSpecServiceLogDestinationOpenSearchToHclTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationOpenSearch): any;
export declare class DataDigitaloceanAppSpecServiceLogDestinationOpenSearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceLogDestinationOpenSearch | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceLogDestinationOpenSearch | undefined);
    private _basicAuth;
    get basicAuth(): DataDigitaloceanAppSpecServiceLogDestinationOpenSearchBasicAuthList;
    get clusterName(): string;
    get endpoint(): string;
    get indexName(): string;
}
export declare class DataDigitaloceanAppSpecServiceLogDestinationOpenSearchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceLogDestinationOpenSearchOutputReference;
}
export interface DataDigitaloceanAppSpecServiceLogDestinationPapertrail {
}
export declare function dataDigitaloceanAppSpecServiceLogDestinationPapertrailToTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationPapertrail): any;
export declare function dataDigitaloceanAppSpecServiceLogDestinationPapertrailToHclTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestinationPapertrail): any;
export declare class DataDigitaloceanAppSpecServiceLogDestinationPapertrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceLogDestinationPapertrail | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceLogDestinationPapertrail | undefined);
    get endpoint(): string;
}
export declare class DataDigitaloceanAppSpecServiceLogDestinationPapertrailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceLogDestinationPapertrailOutputReference;
}
export interface DataDigitaloceanAppSpecServiceLogDestination {
}
export declare function dataDigitaloceanAppSpecServiceLogDestinationToTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestination): any;
export declare function dataDigitaloceanAppSpecServiceLogDestinationToHclTerraform(struct?: DataDigitaloceanAppSpecServiceLogDestination): any;
export declare class DataDigitaloceanAppSpecServiceLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceLogDestination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceLogDestination | undefined);
    private _datadog;
    get datadog(): DataDigitaloceanAppSpecServiceLogDestinationDatadogList;
    private _logtail;
    get logtail(): DataDigitaloceanAppSpecServiceLogDestinationLogtailList;
    get name(): string;
    private _openSearch;
    get openSearch(): DataDigitaloceanAppSpecServiceLogDestinationOpenSearchList;
    private _papertrail;
    get papertrail(): DataDigitaloceanAppSpecServiceLogDestinationPapertrailList;
}
export declare class DataDigitaloceanAppSpecServiceLogDestinationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceLogDestinationOutputReference;
}
export interface DataDigitaloceanAppSpecServiceRoutes {
}
export declare function dataDigitaloceanAppSpecServiceRoutesToTerraform(struct?: DataDigitaloceanAppSpecServiceRoutes): any;
export declare function dataDigitaloceanAppSpecServiceRoutesToHclTerraform(struct?: DataDigitaloceanAppSpecServiceRoutes): any;
export declare class DataDigitaloceanAppSpecServiceRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceRoutes | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceRoutes | undefined);
    get path(): string;
    get preservePathPrefix(): cdktn.IResolvable;
}
export declare class DataDigitaloceanAppSpecServiceRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceRoutesOutputReference;
}
export interface DataDigitaloceanAppSpecServiceTermination {
}
export declare function dataDigitaloceanAppSpecServiceTerminationToTerraform(struct?: DataDigitaloceanAppSpecServiceTermination): any;
export declare function dataDigitaloceanAppSpecServiceTerminationToHclTerraform(struct?: DataDigitaloceanAppSpecServiceTermination): any;
export declare class DataDigitaloceanAppSpecServiceTerminationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecServiceTermination | undefined;
    set internalValue(value: DataDigitaloceanAppSpecServiceTermination | undefined);
    get drainSeconds(): number;
    get gracePeriodSeconds(): number;
}
export declare class DataDigitaloceanAppSpecServiceTerminationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceTerminationOutputReference;
}
export interface DataDigitaloceanAppSpecService {
}
export declare function dataDigitaloceanAppSpecServiceToTerraform(struct?: DataDigitaloceanAppSpecService): any;
export declare function dataDigitaloceanAppSpecServiceToHclTerraform(struct?: DataDigitaloceanAppSpecService): any;
export declare class DataDigitaloceanAppSpecServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecService | undefined;
    set internalValue(value: DataDigitaloceanAppSpecService | undefined);
    private _alert;
    get alert(): DataDigitaloceanAppSpecServiceAlertList;
    private _autoscaling;
    get autoscaling(): DataDigitaloceanAppSpecServiceAutoscalingList;
    private _bitbucket;
    get bitbucket(): DataDigitaloceanAppSpecServiceBitbucketList;
    get buildCommand(): string;
    private _cors;
    get cors(): DataDigitaloceanAppSpecServiceCorsList;
    get dockerfilePath(): string;
    private _env;
    get env(): DataDigitaloceanAppSpecServiceEnvList;
    get environmentSlug(): string;
    private _git;
    get git(): DataDigitaloceanAppSpecServiceGitList;
    private _github;
    get github(): DataDigitaloceanAppSpecServiceGithubList;
    private _gitlab;
    get gitlab(): DataDigitaloceanAppSpecServiceGitlabList;
    private _healthCheck;
    get healthCheck(): DataDigitaloceanAppSpecServiceHealthCheckList;
    get httpPort(): number;
    private _image;
    get image(): DataDigitaloceanAppSpecServiceImageList;
    get instanceCount(): number;
    get instanceSizeSlug(): string;
    get internalPorts(): number[];
    private _logDestination;
    get logDestination(): DataDigitaloceanAppSpecServiceLogDestinationList;
    get name(): string;
    private _routes;
    get routes(): DataDigitaloceanAppSpecServiceRoutesList;
    get runCommand(): string;
    get sourceDir(): string;
    private _termination;
    get termination(): DataDigitaloceanAppSpecServiceTerminationList;
}
export declare class DataDigitaloceanAppSpecServiceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecServiceOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteBitbucket {
}
export declare function dataDigitaloceanAppSpecStaticSiteBitbucketToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteBitbucket): any;
export declare function dataDigitaloceanAppSpecStaticSiteBitbucketToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteBitbucket): any;
export declare class DataDigitaloceanAppSpecStaticSiteBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteBitbucket | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteBitbucket | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteBitbucketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteBitbucketOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteCorsAllowOrigins {
}
export declare function dataDigitaloceanAppSpecStaticSiteCorsAllowOriginsToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteCorsAllowOrigins): any;
export declare function dataDigitaloceanAppSpecStaticSiteCorsAllowOriginsToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteCorsAllowOrigins): any;
export declare class DataDigitaloceanAppSpecStaticSiteCorsAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteCorsAllowOrigins | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteCorsAllowOrigins | undefined);
    get exact(): string;
    get prefix(): string;
    get regex(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteCorsAllowOriginsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteCorsAllowOriginsOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteCors {
}
export declare function dataDigitaloceanAppSpecStaticSiteCorsToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteCors): any;
export declare function dataDigitaloceanAppSpecStaticSiteCorsToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteCors): any;
export declare class DataDigitaloceanAppSpecStaticSiteCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteCors | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteCors | undefined);
    get allowCredentials(): cdktn.IResolvable;
    get allowHeaders(): string[];
    get allowMethods(): string[];
    private _allowOrigins;
    get allowOrigins(): DataDigitaloceanAppSpecStaticSiteCorsAllowOriginsList;
    get exposeHeaders(): string[];
    get maxAge(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteCorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteCorsOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteEnv {
}
export declare function dataDigitaloceanAppSpecStaticSiteEnvToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteEnv): any;
export declare function dataDigitaloceanAppSpecStaticSiteEnvToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteEnv): any;
export declare class DataDigitaloceanAppSpecStaticSiteEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteEnv | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteEnv | undefined);
    get key(): string;
    get scope(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteEnvOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteGit {
}
export declare function dataDigitaloceanAppSpecStaticSiteGitToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteGit): any;
export declare function dataDigitaloceanAppSpecStaticSiteGitToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteGit): any;
export declare class DataDigitaloceanAppSpecStaticSiteGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteGit | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteGit | undefined);
    get branch(): string;
    get repoCloneUrl(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteGitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteGitOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteGithub {
}
export declare function dataDigitaloceanAppSpecStaticSiteGithubToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteGithub): any;
export declare function dataDigitaloceanAppSpecStaticSiteGithubToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteGithub): any;
export declare class DataDigitaloceanAppSpecStaticSiteGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteGithub | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteGithub | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteGithubList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteGithubOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteGitlab {
}
export declare function dataDigitaloceanAppSpecStaticSiteGitlabToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteGitlab): any;
export declare function dataDigitaloceanAppSpecStaticSiteGitlabToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteGitlab): any;
export declare class DataDigitaloceanAppSpecStaticSiteGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteGitlab | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteGitlab | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteGitlabList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteGitlabOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSiteRoutes {
}
export declare function dataDigitaloceanAppSpecStaticSiteRoutesToTerraform(struct?: DataDigitaloceanAppSpecStaticSiteRoutes): any;
export declare function dataDigitaloceanAppSpecStaticSiteRoutesToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSiteRoutes): any;
export declare class DataDigitaloceanAppSpecStaticSiteRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSiteRoutes | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSiteRoutes | undefined);
    get path(): string;
    get preservePathPrefix(): cdktn.IResolvable;
}
export declare class DataDigitaloceanAppSpecStaticSiteRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteRoutesOutputReference;
}
export interface DataDigitaloceanAppSpecStaticSite {
}
export declare function dataDigitaloceanAppSpecStaticSiteToTerraform(struct?: DataDigitaloceanAppSpecStaticSite): any;
export declare function dataDigitaloceanAppSpecStaticSiteToHclTerraform(struct?: DataDigitaloceanAppSpecStaticSite): any;
export declare class DataDigitaloceanAppSpecStaticSiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecStaticSite | undefined;
    set internalValue(value: DataDigitaloceanAppSpecStaticSite | undefined);
    private _bitbucket;
    get bitbucket(): DataDigitaloceanAppSpecStaticSiteBitbucketList;
    get buildCommand(): string;
    get catchallDocument(): string;
    private _cors;
    get cors(): DataDigitaloceanAppSpecStaticSiteCorsList;
    get dockerfilePath(): string;
    private _env;
    get env(): DataDigitaloceanAppSpecStaticSiteEnvList;
    get environmentSlug(): string;
    get errorDocument(): string;
    private _git;
    get git(): DataDigitaloceanAppSpecStaticSiteGitList;
    private _github;
    get github(): DataDigitaloceanAppSpecStaticSiteGithubList;
    private _gitlab;
    get gitlab(): DataDigitaloceanAppSpecStaticSiteGitlabList;
    get indexDocument(): string;
    get name(): string;
    get outputDir(): string;
    private _routes;
    get routes(): DataDigitaloceanAppSpecStaticSiteRoutesList;
    get sourceDir(): string;
}
export declare class DataDigitaloceanAppSpecStaticSiteList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecStaticSiteOutputReference;
}
export interface DataDigitaloceanAppSpecVpc {
}
export declare function dataDigitaloceanAppSpecVpcToTerraform(struct?: DataDigitaloceanAppSpecVpc): any;
export declare function dataDigitaloceanAppSpecVpcToHclTerraform(struct?: DataDigitaloceanAppSpecVpc): any;
export declare class DataDigitaloceanAppSpecVpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecVpc | undefined;
    set internalValue(value: DataDigitaloceanAppSpecVpc | undefined);
    get id(): string;
}
export declare class DataDigitaloceanAppSpecVpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecVpcOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooks {
}
export declare function dataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooksToTerraform(struct?: DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooks): any;
export declare function dataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooksToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooks): any;
export declare class DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooks | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooks | undefined);
    get channel(): string;
    get url(): string;
}
export declare class DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooksOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerAlertDestinations {
}
export declare function dataDigitaloceanAppSpecWorkerAlertDestinationsToTerraform(struct?: DataDigitaloceanAppSpecWorkerAlertDestinations): any;
export declare function dataDigitaloceanAppSpecWorkerAlertDestinationsToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerAlertDestinations): any;
export declare class DataDigitaloceanAppSpecWorkerAlertDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerAlertDestinations | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerAlertDestinations | undefined);
    get emails(): string[];
    private _slackWebhooks;
    get slackWebhooks(): DataDigitaloceanAppSpecWorkerAlertDestinationsSlackWebhooksList;
}
export declare class DataDigitaloceanAppSpecWorkerAlertDestinationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerAlertDestinationsOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerAlert {
}
export declare function dataDigitaloceanAppSpecWorkerAlertToTerraform(struct?: DataDigitaloceanAppSpecWorkerAlert): any;
export declare function dataDigitaloceanAppSpecWorkerAlertToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerAlert): any;
export declare class DataDigitaloceanAppSpecWorkerAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerAlert | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerAlert | undefined);
    private _destinations;
    get destinations(): DataDigitaloceanAppSpecWorkerAlertDestinationsList;
    get disabled(): cdktn.IResolvable;
    get operator(): string;
    get rule(): string;
    get value(): number;
    get window(): string;
}
export declare class DataDigitaloceanAppSpecWorkerAlertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerAlertOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpu {
}
export declare function dataDigitaloceanAppSpecWorkerAutoscalingMetricsCpuToTerraform(struct?: DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpu): any;
export declare function dataDigitaloceanAppSpecWorkerAutoscalingMetricsCpuToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpu): any;
export declare class DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpu | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpu | undefined);
    get percent(): number;
}
export declare class DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpuList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpuOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerAutoscalingMetrics {
}
export declare function dataDigitaloceanAppSpecWorkerAutoscalingMetricsToTerraform(struct?: DataDigitaloceanAppSpecWorkerAutoscalingMetrics): any;
export declare function dataDigitaloceanAppSpecWorkerAutoscalingMetricsToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerAutoscalingMetrics): any;
export declare class DataDigitaloceanAppSpecWorkerAutoscalingMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerAutoscalingMetrics | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerAutoscalingMetrics | undefined);
    private _cpu;
    get cpu(): DataDigitaloceanAppSpecWorkerAutoscalingMetricsCpuList;
}
export declare class DataDigitaloceanAppSpecWorkerAutoscalingMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerAutoscalingMetricsOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerAutoscaling {
}
export declare function dataDigitaloceanAppSpecWorkerAutoscalingToTerraform(struct?: DataDigitaloceanAppSpecWorkerAutoscaling): any;
export declare function dataDigitaloceanAppSpecWorkerAutoscalingToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerAutoscaling): any;
export declare class DataDigitaloceanAppSpecWorkerAutoscalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerAutoscaling | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerAutoscaling | undefined);
    get maxInstanceCount(): number;
    private _metrics;
    get metrics(): DataDigitaloceanAppSpecWorkerAutoscalingMetricsList;
    get minInstanceCount(): number;
}
export declare class DataDigitaloceanAppSpecWorkerAutoscalingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerAutoscalingOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerBitbucket {
}
export declare function dataDigitaloceanAppSpecWorkerBitbucketToTerraform(struct?: DataDigitaloceanAppSpecWorkerBitbucket): any;
export declare function dataDigitaloceanAppSpecWorkerBitbucketToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerBitbucket): any;
export declare class DataDigitaloceanAppSpecWorkerBitbucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerBitbucket | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerBitbucket | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecWorkerBitbucketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerBitbucketOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerEnv {
}
export declare function dataDigitaloceanAppSpecWorkerEnvToTerraform(struct?: DataDigitaloceanAppSpecWorkerEnv): any;
export declare function dataDigitaloceanAppSpecWorkerEnvToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerEnv): any;
export declare class DataDigitaloceanAppSpecWorkerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerEnv | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerEnv | undefined);
    get key(): string;
    get scope(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDigitaloceanAppSpecWorkerEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerEnvOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerGit {
}
export declare function dataDigitaloceanAppSpecWorkerGitToTerraform(struct?: DataDigitaloceanAppSpecWorkerGit): any;
export declare function dataDigitaloceanAppSpecWorkerGitToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerGit): any;
export declare class DataDigitaloceanAppSpecWorkerGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerGit | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerGit | undefined);
    get branch(): string;
    get repoCloneUrl(): string;
}
export declare class DataDigitaloceanAppSpecWorkerGitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerGitOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerGithub {
}
export declare function dataDigitaloceanAppSpecWorkerGithubToTerraform(struct?: DataDigitaloceanAppSpecWorkerGithub): any;
export declare function dataDigitaloceanAppSpecWorkerGithubToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerGithub): any;
export declare class DataDigitaloceanAppSpecWorkerGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerGithub | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerGithub | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecWorkerGithubList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerGithubOutputReference;
}
export interface DataDigitaloceanAppSpecWorkerGitlab {
}
export declare function dataDigitaloceanAppSpecWorkerGitlabToTerraform(struct?: DataDigitaloceanAppSpecWorkerGitlab): any;
export declare function dataDigitaloceanAppSpecWorkerGitlabToHclTerraform(struct?: DataDigitaloceanAppSpecWorkerGitlab): any;
export declare class DataDigitaloceanAppSpecWorkerGitlabOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanAppSpecWorkerGitlab | undefined;
    set internalValue(value: DataDigitaloceanAppSpecWorkerGitlab | undefined);
    get branch(): string;
    get deployOnPush(): cdktn.IResolvable;
    get repo(): string;
}
export declare class DataDigitaloceanAppSpecWorkerGitlabList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanAppSpecWorkerGitlabOutputReference;
}
