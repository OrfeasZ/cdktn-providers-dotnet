import { DataDigitaloceanAppSpecList, DataDigitaloceanAppDedicatedIps, DataDigitaloceanAppDedicatedIpsList } from './index-structs';
export * from './index-structs';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#app_id DataDigitaloceanApp#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#id DataDigitaloceanApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * dedicated_ips block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#dedicated_ips DataDigitaloceanApp#dedicated_ips}
    */
    readonly dedicatedIps?: DataDigitaloceanAppDedicatedIps[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app digitalocean_app}
*/
export declare class DataDigitaloceanApp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_app";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanApp to import
    * @param importFromId The id of the existing DataDigitaloceanApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/app digitalocean_app} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanAppConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanAppConfig);
    get activeDeploymentId(): string;
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get createdAt(): string;
    get defaultIngress(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get liveDomain(): string;
    get liveUrl(): string;
    get projectId(): string;
    private _spec;
    get spec(): DataDigitaloceanAppSpecList;
    get updatedAt(): string;
    get urn(): string;
    private _dedicatedIps;
    get dedicatedIps(): DataDigitaloceanAppDedicatedIpsList;
    putDedicatedIps(value: DataDigitaloceanAppDedicatedIps[] | cdktn.IResolvable): void;
    resetDedicatedIps(): void;
    get dedicatedIpsInput(): cdktn.IResolvable | DataDigitaloceanAppDedicatedIps[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
