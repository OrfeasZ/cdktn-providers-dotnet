# `data_digitalocean_dedicated_inference_sizes`

Refer to the Terraform Registry for docs: [`data_digitalocean_dedicated_inference_sizes`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/dedicated_inference_sizes).
