# `data_digitalocean_dedicated_inference_sizes`

Refer to the Terraform Registry for docs: [`data_digitalocean_dedicated_inference_sizes`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/dedicated_inference_sizes).
