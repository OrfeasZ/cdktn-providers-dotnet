import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDedicatedInferenceSizesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference_sizes#id DataDigitaloceanDedicatedInferenceSizes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDigitaloceanDedicatedInferenceSizesSizesDisks {
}
export declare function dataDigitaloceanDedicatedInferenceSizesSizesDisksToTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizesDisks): any;
export declare function dataDigitaloceanDedicatedInferenceSizesSizesDisksToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizesDisks): any;
export declare class DataDigitaloceanDedicatedInferenceSizesSizesDisksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceSizesSizesDisks | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceSizesSizesDisks | undefined);
    get sizeGb(): number;
    get type(): string;
}
export declare class DataDigitaloceanDedicatedInferenceSizesSizesDisksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceSizesSizesDisksOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceSizesSizesGpu {
}
export declare function dataDigitaloceanDedicatedInferenceSizesSizesGpuToTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizesGpu): any;
export declare function dataDigitaloceanDedicatedInferenceSizesSizesGpuToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizesGpu): any;
export declare class DataDigitaloceanDedicatedInferenceSizesSizesGpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceSizesSizesGpu | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceSizesSizesGpu | undefined);
    get count(): number;
    get slug(): string;
    get vramGb(): number;
}
export declare class DataDigitaloceanDedicatedInferenceSizesSizesGpuList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceSizesSizesGpuOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceSizesSizesSizeCategory {
}
export declare function dataDigitaloceanDedicatedInferenceSizesSizesSizeCategoryToTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizesSizeCategory): any;
export declare function dataDigitaloceanDedicatedInferenceSizesSizesSizeCategoryToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizesSizeCategory): any;
export declare class DataDigitaloceanDedicatedInferenceSizesSizesSizeCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceSizesSizesSizeCategory | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceSizesSizesSizeCategory | undefined);
    get fleetName(): string;
    get name(): string;
}
export declare class DataDigitaloceanDedicatedInferenceSizesSizesSizeCategoryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceSizesSizesSizeCategoryOutputReference;
}
export interface DataDigitaloceanDedicatedInferenceSizesSizes {
}
export declare function dataDigitaloceanDedicatedInferenceSizesSizesToTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizes): any;
export declare function dataDigitaloceanDedicatedInferenceSizesSizesToHclTerraform(struct?: DataDigitaloceanDedicatedInferenceSizesSizes): any;
export declare class DataDigitaloceanDedicatedInferenceSizesSizesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanDedicatedInferenceSizesSizes | undefined;
    set internalValue(value: DataDigitaloceanDedicatedInferenceSizesSizes | undefined);
    get cpu(): number;
    get currency(): string;
    private _disks;
    get disks(): DataDigitaloceanDedicatedInferenceSizesSizesDisksList;
    private _gpu;
    get gpu(): DataDigitaloceanDedicatedInferenceSizesSizesGpuList;
    get gpuSlug(): string;
    get memory(): number;
    get pricePerHour(): string;
    get regions(): string[];
    private _sizeCategory;
    get sizeCategory(): DataDigitaloceanDedicatedInferenceSizesSizesSizeCategoryList;
}
export declare class DataDigitaloceanDedicatedInferenceSizesSizesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanDedicatedInferenceSizesSizesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference_sizes digitalocean_dedicated_inference_sizes}
*/
export declare class DataDigitaloceanDedicatedInferenceSizes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_dedicated_inference_sizes";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDedicatedInferenceSizes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDedicatedInferenceSizes to import
    * @param importFromId The id of the existing DataDigitaloceanDedicatedInferenceSizes that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference_sizes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDedicatedInferenceSizes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/dedicated_inference_sizes digitalocean_dedicated_inference_sizes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDedicatedInferenceSizesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDedicatedInferenceSizesConfig);
    get enabledRegions(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _sizes;
    get sizes(): DataDigitaloceanDedicatedInferenceSizesSizesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
