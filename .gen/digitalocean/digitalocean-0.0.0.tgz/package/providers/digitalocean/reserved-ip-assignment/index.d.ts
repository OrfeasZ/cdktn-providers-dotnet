import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReservedIpAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/reserved_ip_assignment#droplet_id ReservedIpAssignment#droplet_id}
    */
    readonly dropletId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/reserved_ip_assignment#id ReservedIpAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/reserved_ip_assignment#ip_address ReservedIpAssignment#ip_address}
    */
    readonly ipAddress: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/reserved_ip_assignment digitalocean_reserved_ip_assignment}
*/
export declare class ReservedIpAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_reserved_ip_assignment";
    /**
    * Generates CDKTN code for importing a ReservedIpAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ReservedIpAssignment to import
    * @param importFromId The id of the existing ReservedIpAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/reserved_ip_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ReservedIpAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/reserved_ip_assignment digitalocean_reserved_ip_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReservedIpAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: ReservedIpAssignmentConfig);
    private _dropletId?;
    get dropletId(): number;
    set dropletId(value: number);
    get dropletIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    get ipAddressInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
