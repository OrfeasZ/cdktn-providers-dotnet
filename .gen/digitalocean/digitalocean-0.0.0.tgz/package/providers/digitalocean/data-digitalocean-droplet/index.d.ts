import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanDropletConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet#gpu DataDigitaloceanDroplet#gpu}
    */
    readonly gpu?: boolean | cdktn.IResolvable;
    /**
    * id of the Droplet
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet#id DataDigitaloceanDroplet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * name of the Droplet
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet#name DataDigitaloceanDroplet#name}
    */
    readonly name?: string;
    /**
    * unique tag of the Droplet
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet#tag DataDigitaloceanDroplet#tag}
    */
    readonly tag?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet digitalocean_droplet}
*/
export declare class DataDigitaloceanDroplet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_droplet";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanDroplet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanDroplet to import
    * @param importFromId The id of the existing DataDigitaloceanDroplet that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanDroplet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/droplet digitalocean_droplet} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanDropletConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanDropletConfig);
    get backups(): cdktn.IResolvable;
    get createdAt(): string;
    get disk(): number;
    private _gpu?;
    get gpu(): boolean | cdktn.IResolvable;
    set gpu(value: boolean | cdktn.IResolvable);
    resetGpu(): void;
    get gpuInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get image(): string;
    get ipv4Address(): string;
    get ipv4AddressPrivate(): string;
    get ipv6(): cdktn.IResolvable;
    get ipv6Address(): string;
    get ipv6AddressPrivate(): string;
    get locked(): cdktn.IResolvable;
    get memory(): number;
    get monitoring(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get priceHourly(): number;
    get priceMonthly(): number;
    get privateNetworking(): cdktn.IResolvable;
    get region(): string;
    get size(): string;
    get status(): string;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    get tags(): string[];
    get urn(): string;
    get vcpus(): number;
    get volumeIds(): string[];
    get vpcUuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
