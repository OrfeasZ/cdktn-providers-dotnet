# `data_digitalocean_gradientai_knowledge_base_indexing_jobs`

Refer to the Terraform Registry for docs: [`data_digitalocean_gradientai_knowledge_base_indexing_jobs`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/gradientai_knowledge_base_indexing_jobs).
