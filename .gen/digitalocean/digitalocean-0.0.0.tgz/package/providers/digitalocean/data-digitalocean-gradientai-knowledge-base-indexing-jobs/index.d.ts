import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base_indexing_jobs#id DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base_indexing_jobs#knowledge_base_uuid DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobs {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobsToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobs): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobsToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobs): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobs | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobs | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get status(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get totalItemsFailed(): string;
    get totalItemsIndexed(): string;
    get totalItemsSkipped(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobsOutputReference;
}
export interface DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMeta {
}
export declare function dataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMetaToTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMeta): any;
export declare function dataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMetaToHclTerraform(struct?: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMeta): any;
export declare class DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMetaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMeta | undefined;
    set internalValue(value: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMeta | undefined);
    get page(): number;
    get pages(): number;
    get total(): number;
}
export declare class DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMetaList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMetaOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base_indexing_jobs digitalocean_gradientai_knowledge_base_indexing_jobs}
*/
export declare class DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_gradientai_knowledge_base_indexing_jobs";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs to import
    * @param importFromId The id of the existing DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base_indexing_jobs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGradientaiKnowledgeBaseIndexingJobs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/gradientai_knowledge_base_indexing_jobs digitalocean_gradientai_knowledge_base_indexing_jobs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobs;
    get jobs(): DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsJobsList;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    private _meta;
    get meta(): DataDigitaloceanGradientaiKnowledgeBaseIndexingJobsMetaList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
