# `digitalocean_database_cluster`

Refer to the Terraform Registry for docs: [`digitalocean_database_cluster`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_cluster).
