import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#engine DatabaseCluster#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#eviction_policy DatabaseCluster#eviction_policy}
    */
    readonly evictionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#id DatabaseCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#name DatabaseCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#node_count DatabaseCluster#node_count}
    */
    readonly nodeCount: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#private_network_uuid DatabaseCluster#private_network_uuid}
    */
    readonly privateNetworkUuid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#project_id DatabaseCluster#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#region DatabaseCluster#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#size DatabaseCluster#size}
    */
    readonly size: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#sql_mode DatabaseCluster#sql_mode}
    */
    readonly sqlMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#storage_size_mib DatabaseCluster#storage_size_mib}
    */
    readonly storageSizeMib?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#tags DatabaseCluster#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#version DatabaseCluster#version}
    */
    readonly version?: string;
    /**
    * backup_restore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#backup_restore DatabaseCluster#backup_restore}
    */
    readonly backupRestore?: DatabaseClusterBackupRestore;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#maintenance_window DatabaseCluster#maintenance_window}
    */
    readonly maintenanceWindow?: DatabaseClusterMaintenanceWindow[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#timeouts DatabaseCluster#timeouts}
    */
    readonly timeouts?: DatabaseClusterTimeouts;
}
export interface DatabaseClusterBackupRestore {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#backup_created_at DatabaseCluster#backup_created_at}
    */
    readonly backupCreatedAt?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#database_name DatabaseCluster#database_name}
    */
    readonly databaseName: string;
}
export declare function databaseClusterBackupRestoreToTerraform(struct?: DatabaseClusterBackupRestoreOutputReference | DatabaseClusterBackupRestore): any;
export declare function databaseClusterBackupRestoreToHclTerraform(struct?: DatabaseClusterBackupRestoreOutputReference | DatabaseClusterBackupRestore): any;
export declare class DatabaseClusterBackupRestoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseClusterBackupRestore | undefined;
    set internalValue(value: DatabaseClusterBackupRestore | undefined);
    private _backupCreatedAt?;
    get backupCreatedAt(): string;
    set backupCreatedAt(value: string);
    resetBackupCreatedAt(): void;
    get backupCreatedAtInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
}
export interface DatabaseClusterMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#day DatabaseCluster#day}
    */
    readonly day: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#hour DatabaseCluster#hour}
    */
    readonly hour: string;
}
export declare function databaseClusterMaintenanceWindowToTerraform(struct?: DatabaseClusterMaintenanceWindow | cdktn.IResolvable): any;
export declare function databaseClusterMaintenanceWindowToHclTerraform(struct?: DatabaseClusterMaintenanceWindow | cdktn.IResolvable): any;
export declare class DatabaseClusterMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseClusterMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseClusterMaintenanceWindow | cdktn.IResolvable | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    get dayInput(): string | undefined;
    private _hour?;
    get hour(): string;
    set hour(value: string);
    get hourInput(): string | undefined;
}
export declare class DatabaseClusterMaintenanceWindowList extends cdktn.ComplexList {
    internalValue?: DatabaseClusterMaintenanceWindow[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseClusterMaintenanceWindowOutputReference;
}
export interface DatabaseClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#create DatabaseCluster#create}
    */
    readonly create?: string;
}
export declare function databaseClusterTimeoutsToTerraform(struct?: DatabaseClusterTimeouts | cdktn.IResolvable): any;
export declare function databaseClusterTimeoutsToHclTerraform(struct?: DatabaseClusterTimeouts | cdktn.IResolvable): any;
export declare class DatabaseClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster digitalocean_database_cluster}
*/
export declare class DatabaseCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_cluster";
    /**
    * Generates CDKTN code for importing a DatabaseCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseCluster to import
    * @param importFromId The id of the existing DatabaseCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/database_cluster digitalocean_database_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseClusterConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseClusterConfig);
    get database(): string;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _evictionPolicy?;
    get evictionPolicy(): string;
    set evictionPolicy(value: string);
    resetEvictionPolicy(): void;
    get evictionPolicyInput(): string | undefined;
    get host(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get metricsEndpoints(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    get nodeCountInput(): number | undefined;
    get password(): string;
    get port(): number;
    get privateHost(): string;
    private _privateNetworkUuid?;
    get privateNetworkUuid(): string;
    set privateNetworkUuid(value: string);
    resetPrivateNetworkUuid(): void;
    get privateNetworkUuidInput(): string | undefined;
    get privateUri(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
    private _sqlMode?;
    get sqlMode(): string;
    set sqlMode(value: string);
    resetSqlMode(): void;
    get sqlModeInput(): string | undefined;
    private _storageSizeMib?;
    get storageSizeMib(): string;
    set storageSizeMib(value: string);
    resetStorageSizeMib(): void;
    get storageSizeMibInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get uiDatabase(): string;
    get uiHost(): string;
    get uiPassword(): string;
    get uiPort(): number;
    get uiUri(): string;
    get uiUser(): string;
    get uri(): string;
    get urn(): string;
    get user(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _backupRestore;
    get backupRestore(): DatabaseClusterBackupRestoreOutputReference;
    putBackupRestore(value: DatabaseClusterBackupRestore): void;
    resetBackupRestore(): void;
    get backupRestoreInput(): DatabaseClusterBackupRestore | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DatabaseClusterMaintenanceWindowList;
    putMaintenanceWindow(value: DatabaseClusterMaintenanceWindow[] | cdktn.IResolvable): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DatabaseClusterMaintenanceWindow[] | undefined;
    private _timeouts;
    get timeouts(): DatabaseClusterTimeoutsOutputReference;
    putTimeouts(value: DatabaseClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DatabaseClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
