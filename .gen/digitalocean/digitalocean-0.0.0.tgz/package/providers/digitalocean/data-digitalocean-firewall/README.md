# `data_digitalocean_firewall`

Refer to the Terraform Registry for docs: [`data_digitalocean_firewall`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/firewall).
