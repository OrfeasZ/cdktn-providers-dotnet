# `data_digitalocean_database_connection_pool`

Refer to the Terraform Registry for docs: [`data_digitalocean_database_connection_pool`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/database_connection_pool).
