# `digitalocean_volume`

Refer to the Terraform Registry for docs: [`digitalocean_volume`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/volume).
