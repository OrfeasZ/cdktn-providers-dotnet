import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DropletConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#backups Droplet#backups}
    */
    readonly backups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#droplet_agent Droplet#droplet_agent}
    */
    readonly dropletAgent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#graceful_shutdown Droplet#graceful_shutdown}
    */
    readonly gracefulShutdown?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#id Droplet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#image Droplet#image}
    */
    readonly image: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#ipv6 Droplet#ipv6}
    */
    readonly ipv6?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#ipv6_address Droplet#ipv6_address}
    */
    readonly ipv6Address?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#monitoring Droplet#monitoring}
    */
    readonly monitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#name Droplet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#private_networking Droplet#private_networking}
    */
    readonly privateNetworking?: boolean | cdktn.IResolvable;
    /**
    * Enables public networking for the Droplet. By default, this is always enabled on new droplets, but by explicitly setting it to false, you can create a droplet with public networking entirely disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#public_networking Droplet#public_networking}
    */
    readonly publicNetworking?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#region Droplet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#resize_disk Droplet#resize_disk}
    */
    readonly resizeDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#size Droplet#size}
    */
    readonly size: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#ssh_keys Droplet#ssh_keys}
    */
    readonly sshKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#tags Droplet#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#user_data Droplet#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#volume_ids Droplet#volume_ids}
    */
    readonly volumeIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#vpc_uuid Droplet#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * backup_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#backup_policy Droplet#backup_policy}
    */
    readonly backupPolicy?: DropletBackupPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#timeouts Droplet#timeouts}
    */
    readonly timeouts?: DropletTimeouts;
}
export interface DropletBackupPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#hour Droplet#hour}
    */
    readonly hour?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#plan Droplet#plan}
    */
    readonly plan?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#weekday Droplet#weekday}
    */
    readonly weekday?: string;
}
export declare function dropletBackupPolicyToTerraform(struct?: DropletBackupPolicyOutputReference | DropletBackupPolicy): any;
export declare function dropletBackupPolicyToHclTerraform(struct?: DropletBackupPolicyOutputReference | DropletBackupPolicy): any;
export declare class DropletBackupPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DropletBackupPolicy | undefined;
    set internalValue(value: DropletBackupPolicy | undefined);
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
    private _plan?;
    get plan(): string;
    set plan(value: string);
    resetPlan(): void;
    get planInput(): string | undefined;
    private _weekday?;
    get weekday(): string;
    set weekday(value: string);
    resetWeekday(): void;
    get weekdayInput(): string | undefined;
}
export interface DropletTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#create Droplet#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#delete Droplet#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#update Droplet#update}
    */
    readonly update?: string;
}
export declare function dropletTimeoutsToTerraform(struct?: DropletTimeouts | cdktn.IResolvable): any;
export declare function dropletTimeoutsToHclTerraform(struct?: DropletTimeouts | cdktn.IResolvable): any;
export declare class DropletTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DropletTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DropletTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet digitalocean_droplet}
*/
export declare class Droplet extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_droplet";
    /**
    * Generates CDKTN code for importing a Droplet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Droplet to import
    * @param importFromId The id of the existing Droplet that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Droplet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet digitalocean_droplet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DropletConfig
    */
    constructor(scope: Construct, id: string, config: DropletConfig);
    private _backups?;
    get backups(): boolean | cdktn.IResolvable;
    set backups(value: boolean | cdktn.IResolvable);
    resetBackups(): void;
    get backupsInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    get disk(): number;
    private _dropletAgent?;
    get dropletAgent(): boolean | cdktn.IResolvable;
    set dropletAgent(value: boolean | cdktn.IResolvable);
    resetDropletAgent(): void;
    get dropletAgentInput(): boolean | cdktn.IResolvable | undefined;
    private _gracefulShutdown?;
    get gracefulShutdown(): boolean | cdktn.IResolvable;
    set gracefulShutdown(value: boolean | cdktn.IResolvable);
    resetGracefulShutdown(): void;
    get gracefulShutdownInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    get ipv4Address(): string;
    get ipv4AddressPrivate(): string;
    private _ipv6?;
    get ipv6(): boolean | cdktn.IResolvable;
    set ipv6(value: boolean | cdktn.IResolvable);
    resetIpv6(): void;
    get ipv6Input(): boolean | cdktn.IResolvable | undefined;
    private _ipv6Address?;
    get ipv6Address(): string;
    set ipv6Address(value: string);
    resetIpv6Address(): void;
    get ipv6AddressInput(): string | undefined;
    get locked(): cdktn.IResolvable;
    get memory(): number;
    private _monitoring?;
    get monitoring(): boolean | cdktn.IResolvable;
    set monitoring(value: boolean | cdktn.IResolvable);
    resetMonitoring(): void;
    get monitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get priceHourly(): number;
    get priceMonthly(): number;
    private _privateNetworking?;
    get privateNetworking(): boolean | cdktn.IResolvable;
    set privateNetworking(value: boolean | cdktn.IResolvable);
    resetPrivateNetworking(): void;
    get privateNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _publicNetworking?;
    get publicNetworking(): boolean | cdktn.IResolvable;
    set publicNetworking(value: boolean | cdktn.IResolvable);
    resetPublicNetworking(): void;
    get publicNetworkingInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resizeDisk?;
    get resizeDisk(): boolean | cdktn.IResolvable;
    set resizeDisk(value: boolean | cdktn.IResolvable);
    resetResizeDisk(): void;
    get resizeDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
    private _sshKeys?;
    get sshKeys(): string[];
    set sshKeys(value: string[]);
    resetSshKeys(): void;
    get sshKeysInput(): string[] | undefined;
    get status(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get urn(): string;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    get vcpus(): number;
    private _volumeIds?;
    get volumeIds(): string[];
    set volumeIds(value: string[]);
    resetVolumeIds(): void;
    get volumeIdsInput(): string[] | undefined;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _backupPolicy;
    get backupPolicy(): DropletBackupPolicyOutputReference;
    putBackupPolicy(value: DropletBackupPolicy): void;
    resetBackupPolicy(): void;
    get backupPolicyInput(): DropletBackupPolicy | undefined;
    private _timeouts;
    get timeouts(): DropletTimeoutsOutputReference;
    putTimeouts(value: DropletTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DropletTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
