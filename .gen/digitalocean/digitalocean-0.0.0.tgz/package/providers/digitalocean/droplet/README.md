# `digitalocean_droplet`

Refer to the Terraform Registry for docs: [`digitalocean_droplet`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/droplet).
