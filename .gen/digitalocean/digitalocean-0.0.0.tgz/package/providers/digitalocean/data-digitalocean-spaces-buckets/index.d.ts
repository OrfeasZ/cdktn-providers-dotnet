import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanSpacesBucketsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#id DataDigitaloceanSpacesBuckets#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#filter DataDigitaloceanSpacesBuckets#filter}
    */
    readonly filter?: DataDigitaloceanSpacesBucketsFilter[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#sort DataDigitaloceanSpacesBuckets#sort}
    */
    readonly sort?: DataDigitaloceanSpacesBucketsSort[] | cdktn.IResolvable;
}
export interface DataDigitaloceanSpacesBucketsBuckets {
}
export declare function dataDigitaloceanSpacesBucketsBucketsToTerraform(struct?: DataDigitaloceanSpacesBucketsBuckets): any;
export declare function dataDigitaloceanSpacesBucketsBucketsToHclTerraform(struct?: DataDigitaloceanSpacesBucketsBuckets): any;
export declare class DataDigitaloceanSpacesBucketsBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSpacesBucketsBuckets | undefined;
    set internalValue(value: DataDigitaloceanSpacesBucketsBuckets | undefined);
    get bucketDomainName(): string;
    get endpoint(): string;
    get name(): string;
    get region(): string;
    get urn(): string;
}
export declare class DataDigitaloceanSpacesBucketsBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSpacesBucketsBucketsOutputReference;
}
export interface DataDigitaloceanSpacesBucketsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#all DataDigitaloceanSpacesBuckets#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#key DataDigitaloceanSpacesBuckets#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#match_by DataDigitaloceanSpacesBuckets#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#values DataDigitaloceanSpacesBuckets#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanSpacesBucketsFilterToTerraform(struct?: DataDigitaloceanSpacesBucketsFilter | cdktn.IResolvable): any;
export declare function dataDigitaloceanSpacesBucketsFilterToHclTerraform(struct?: DataDigitaloceanSpacesBucketsFilter | cdktn.IResolvable): any;
export declare class DataDigitaloceanSpacesBucketsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSpacesBucketsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanSpacesBucketsFilter | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanSpacesBucketsFilterList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanSpacesBucketsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSpacesBucketsFilterOutputReference;
}
export interface DataDigitaloceanSpacesBucketsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#direction DataDigitaloceanSpacesBuckets#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#key DataDigitaloceanSpacesBuckets#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanSpacesBucketsSortToTerraform(struct?: DataDigitaloceanSpacesBucketsSort | cdktn.IResolvable): any;
export declare function dataDigitaloceanSpacesBucketsSortToHclTerraform(struct?: DataDigitaloceanSpacesBucketsSort | cdktn.IResolvable): any;
export declare class DataDigitaloceanSpacesBucketsSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanSpacesBucketsSort | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanSpacesBucketsSort | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanSpacesBucketsSortList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanSpacesBucketsSort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanSpacesBucketsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets digitalocean_spaces_buckets}
*/
export declare class DataDigitaloceanSpacesBuckets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_spaces_buckets";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanSpacesBuckets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanSpacesBuckets to import
    * @param importFromId The id of the existing DataDigitaloceanSpacesBuckets that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanSpacesBuckets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/spaces_buckets digitalocean_spaces_buckets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanSpacesBucketsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanSpacesBucketsConfig);
    private _buckets;
    get buckets(): DataDigitaloceanSpacesBucketsBucketsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanSpacesBucketsFilterList;
    putFilter(value: DataDigitaloceanSpacesBucketsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataDigitaloceanSpacesBucketsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanSpacesBucketsSortList;
    putSort(value: DataDigitaloceanSpacesBucketsSort[] | cdktn.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktn.IResolvable | DataDigitaloceanSpacesBucketsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
