# `digitalocean_spaces_key`

Refer to the Terraform Registry for docs: [`digitalocean_spaces_key`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/resources/spaces_key).
