import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SpacesKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key#id SpacesKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A name for the key. This is used to identify the key in the DigitalOcean control panel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key#name SpacesKey#name}
    */
    readonly name: string;
    /**
    * grant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key#grant SpacesKey#grant}
    */
    readonly grant?: SpacesKeyGrant[] | cdktn.IResolvable;
}
export interface SpacesKeyGrant {
    /**
    * The name of the bucket to grant the key access to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key#bucket SpacesKey#bucket}
    */
    readonly bucket: string;
    /**
    * The permission to grant the key. Valid values are `read`, `readwrite`, or `fullaccess`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key#permission SpacesKey#permission}
    */
    readonly permission: string;
}
export declare function spacesKeyGrantToTerraform(struct?: SpacesKeyGrant | cdktn.IResolvable): any;
export declare function spacesKeyGrantToHclTerraform(struct?: SpacesKeyGrant | cdktn.IResolvable): any;
export declare class SpacesKeyGrantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SpacesKeyGrant | cdktn.IResolvable | undefined;
    set internalValue(value: SpacesKeyGrant | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export declare class SpacesKeyGrantList extends cdktn.ComplexList {
    internalValue?: SpacesKeyGrant[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SpacesKeyGrantOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key digitalocean_spaces_key}
*/
export declare class SpacesKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_spaces_key";
    /**
    * Generates CDKTN code for importing a SpacesKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SpacesKey to import
    * @param importFromId The id of the existing SpacesKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SpacesKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/spaces_key digitalocean_spaces_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SpacesKeyConfig
    */
    constructor(scope: Construct, id: string, config: SpacesKeyConfig);
    get accessKey(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get secretKey(): string;
    private _grant;
    get grant(): SpacesKeyGrantList;
    putGrant(value: SpacesKeyGrant[] | cdktn.IResolvable): void;
    resetGrant(): void;
    get grantInput(): cdktn.IResolvable | SpacesKeyGrant[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
