import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanKubernetesClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#id DataDigitaloceanKubernetesCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#kubeconfig_expire_seconds DataDigitaloceanKubernetesCluster#kubeconfig_expire_seconds}
    */
    readonly kubeconfigExpireSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#name DataDigitaloceanKubernetesCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#tags DataDigitaloceanKubernetesCluster#tags}
    */
    readonly tags?: string[];
    /**
    * amd_gpu_device_metrics_exporter_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#amd_gpu_device_metrics_exporter_plugin DataDigitaloceanKubernetesCluster#amd_gpu_device_metrics_exporter_plugin}
    */
    readonly amdGpuDeviceMetricsExporterPlugin?: DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin;
    /**
    * amd_gpu_device_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#amd_gpu_device_plugin DataDigitaloceanKubernetesCluster#amd_gpu_device_plugin}
    */
    readonly amdGpuDevicePlugin?: DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin;
    /**
    * cluster_autoscaler_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#cluster_autoscaler_configuration DataDigitaloceanKubernetesCluster#cluster_autoscaler_configuration}
    */
    readonly clusterAutoscalerConfiguration?: DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration[] | cdktn.IResolvable;
    /**
    * nvidia_gpu_device_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#nvidia_gpu_device_plugin DataDigitaloceanKubernetesCluster#nvidia_gpu_device_plugin}
    */
    readonly nvidiaGpuDevicePlugin?: DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin;
    /**
    * rdma_shared_device_plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#rdma_shared_device_plugin DataDigitaloceanKubernetesCluster#rdma_shared_device_plugin}
    */
    readonly rdmaSharedDevicePlugin?: DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin;
    /**
    * routing_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#routing_agent DataDigitaloceanKubernetesCluster#routing_agent}
    */
    readonly routingAgent?: DataDigitaloceanKubernetesClusterRoutingAgent;
    /**
    * sso block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#sso DataDigitaloceanKubernetesCluster#sso}
    */
    readonly sso?: DataDigitaloceanKubernetesClusterSso;
}
export interface DataDigitaloceanKubernetesClusterControlPlaneFirewall {
}
export declare function dataDigitaloceanKubernetesClusterControlPlaneFirewallToTerraform(struct?: DataDigitaloceanKubernetesClusterControlPlaneFirewall): any;
export declare function dataDigitaloceanKubernetesClusterControlPlaneFirewallToHclTerraform(struct?: DataDigitaloceanKubernetesClusterControlPlaneFirewall): any;
export declare class DataDigitaloceanKubernetesClusterControlPlaneFirewallOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterControlPlaneFirewall | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterControlPlaneFirewall | undefined);
    get allowedAddresses(): string[];
    get enabled(): cdktn.IResolvable;
}
export declare class DataDigitaloceanKubernetesClusterControlPlaneFirewallList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterControlPlaneFirewallOutputReference;
}
export interface DataDigitaloceanKubernetesClusterKubeConfig {
}
export declare function dataDigitaloceanKubernetesClusterKubeConfigToTerraform(struct?: DataDigitaloceanKubernetesClusterKubeConfig): any;
export declare function dataDigitaloceanKubernetesClusterKubeConfigToHclTerraform(struct?: DataDigitaloceanKubernetesClusterKubeConfig): any;
export declare class DataDigitaloceanKubernetesClusterKubeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterKubeConfig | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterKubeConfig | undefined);
    get clientCertificate(): string;
    get clientKey(): string;
    get clusterCaCertificate(): string;
    get expiresAt(): string;
    get host(): string;
    get rawConfig(): string;
    get token(): string;
}
export declare class DataDigitaloceanKubernetesClusterKubeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterKubeConfigOutputReference;
}
export interface DataDigitaloceanKubernetesClusterMaintenancePolicy {
}
export declare function dataDigitaloceanKubernetesClusterMaintenancePolicyToTerraform(struct?: DataDigitaloceanKubernetesClusterMaintenancePolicy): any;
export declare function dataDigitaloceanKubernetesClusterMaintenancePolicyToHclTerraform(struct?: DataDigitaloceanKubernetesClusterMaintenancePolicy): any;
export declare class DataDigitaloceanKubernetesClusterMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterMaintenancePolicy | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterMaintenancePolicy | undefined);
    get day(): string;
    get duration(): string;
    get startTime(): string;
}
export declare class DataDigitaloceanKubernetesClusterMaintenancePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterMaintenancePolicyOutputReference;
}
export interface DataDigitaloceanKubernetesClusterNodePoolNodes {
}
export declare function dataDigitaloceanKubernetesClusterNodePoolNodesToTerraform(struct?: DataDigitaloceanKubernetesClusterNodePoolNodes): any;
export declare function dataDigitaloceanKubernetesClusterNodePoolNodesToHclTerraform(struct?: DataDigitaloceanKubernetesClusterNodePoolNodes): any;
export declare class DataDigitaloceanKubernetesClusterNodePoolNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterNodePoolNodes | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterNodePoolNodes | undefined);
    get createdAt(): string;
    get dropletId(): string;
    get id(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
}
export declare class DataDigitaloceanKubernetesClusterNodePoolNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterNodePoolNodesOutputReference;
}
export interface DataDigitaloceanKubernetesClusterNodePoolTaint {
}
export declare function dataDigitaloceanKubernetesClusterNodePoolTaintToTerraform(struct?: DataDigitaloceanKubernetesClusterNodePoolTaint): any;
export declare function dataDigitaloceanKubernetesClusterNodePoolTaintToHclTerraform(struct?: DataDigitaloceanKubernetesClusterNodePoolTaint): any;
export declare class DataDigitaloceanKubernetesClusterNodePoolTaintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterNodePoolTaint | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterNodePoolTaint | undefined);
    get effect(): string;
    get key(): string;
    get value(): string;
}
export declare class DataDigitaloceanKubernetesClusterNodePoolTaintList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterNodePoolTaintOutputReference;
}
export interface DataDigitaloceanKubernetesClusterNodePool {
}
export declare function dataDigitaloceanKubernetesClusterNodePoolToTerraform(struct?: DataDigitaloceanKubernetesClusterNodePool): any;
export declare function dataDigitaloceanKubernetesClusterNodePoolToHclTerraform(struct?: DataDigitaloceanKubernetesClusterNodePool): any;
export declare class DataDigitaloceanKubernetesClusterNodePoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterNodePool | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterNodePool | undefined);
    get actualNodeCount(): number;
    get autoScale(): cdktn.IResolvable;
    get id(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get maxNodes(): number;
    get minNodes(): number;
    get name(): string;
    get nodeCount(): number;
    private _nodes;
    get nodes(): DataDigitaloceanKubernetesClusterNodePoolNodesList;
    get size(): string;
    get tags(): string[];
    private _taint;
    get taint(): DataDigitaloceanKubernetesClusterNodePoolTaintList;
}
export declare class DataDigitaloceanKubernetesClusterNodePoolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterNodePoolOutputReference;
}
export interface DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin {
}
export declare function dataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPluginToTerraform(struct?: DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference | DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin): any;
export declare function dataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPluginToHclTerraform(struct?: DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference | DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin): any;
export declare class DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin {
}
export declare function dataDigitaloceanKubernetesClusterAmdGpuDevicePluginToTerraform(struct?: DataDigitaloceanKubernetesClusterAmdGpuDevicePluginOutputReference | DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin): any;
export declare function dataDigitaloceanKubernetesClusterAmdGpuDevicePluginToHclTerraform(struct?: DataDigitaloceanKubernetesClusterAmdGpuDevicePluginOutputReference | DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin): any;
export declare class DataDigitaloceanKubernetesClusterAmdGpuDevicePluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#expanders DataDigitaloceanKubernetesCluster#expanders}
    */
    readonly expanders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#scale_down_unneeded_time DataDigitaloceanKubernetesCluster#scale_down_unneeded_time}
    */
    readonly scaleDownUnneededTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#scale_down_utilization_threshold DataDigitaloceanKubernetesCluster#scale_down_utilization_threshold}
    */
    readonly scaleDownUtilizationThreshold?: number;
}
export declare function dataDigitaloceanKubernetesClusterClusterAutoscalerConfigurationToTerraform(struct?: DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable): any;
export declare function dataDigitaloceanKubernetesClusterClusterAutoscalerConfigurationToHclTerraform(struct?: DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable): any;
export declare class DataDigitaloceanKubernetesClusterClusterAutoscalerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration | cdktn.IResolvable | undefined);
    private _expanders?;
    get expanders(): string[];
    set expanders(value: string[]);
    resetExpanders(): void;
    get expandersInput(): string[] | undefined;
    private _scaleDownUnneededTime?;
    get scaleDownUnneededTime(): string;
    set scaleDownUnneededTime(value: string);
    resetScaleDownUnneededTime(): void;
    get scaleDownUnneededTimeInput(): string | undefined;
    private _scaleDownUtilizationThreshold?;
    get scaleDownUtilizationThreshold(): number;
    set scaleDownUtilizationThreshold(value: number);
    resetScaleDownUtilizationThreshold(): void;
    get scaleDownUtilizationThresholdInput(): number | undefined;
}
export declare class DataDigitaloceanKubernetesClusterClusterAutoscalerConfigurationList extends cdktn.ComplexList {
    internalValue?: DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanKubernetesClusterClusterAutoscalerConfigurationOutputReference;
}
export interface DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin {
}
export declare function dataDigitaloceanKubernetesClusterNvidiaGpuDevicePluginToTerraform(struct?: DataDigitaloceanKubernetesClusterNvidiaGpuDevicePluginOutputReference | DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin): any;
export declare function dataDigitaloceanKubernetesClusterNvidiaGpuDevicePluginToHclTerraform(struct?: DataDigitaloceanKubernetesClusterNvidiaGpuDevicePluginOutputReference | DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin): any;
export declare class DataDigitaloceanKubernetesClusterNvidiaGpuDevicePluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin {
}
export declare function dataDigitaloceanKubernetesClusterRdmaSharedDevicePluginToTerraform(struct?: DataDigitaloceanKubernetesClusterRdmaSharedDevicePluginOutputReference | DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin): any;
export declare function dataDigitaloceanKubernetesClusterRdmaSharedDevicePluginToHclTerraform(struct?: DataDigitaloceanKubernetesClusterRdmaSharedDevicePluginOutputReference | DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin): any;
export declare class DataDigitaloceanKubernetesClusterRdmaSharedDevicePluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDigitaloceanKubernetesClusterRoutingAgent {
}
export declare function dataDigitaloceanKubernetesClusterRoutingAgentToTerraform(struct?: DataDigitaloceanKubernetesClusterRoutingAgentOutputReference | DataDigitaloceanKubernetesClusterRoutingAgent): any;
export declare function dataDigitaloceanKubernetesClusterRoutingAgentToHclTerraform(struct?: DataDigitaloceanKubernetesClusterRoutingAgentOutputReference | DataDigitaloceanKubernetesClusterRoutingAgent): any;
export declare class DataDigitaloceanKubernetesClusterRoutingAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanKubernetesClusterRoutingAgent | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterRoutingAgent | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDigitaloceanKubernetesClusterSso {
}
export declare function dataDigitaloceanKubernetesClusterSsoToTerraform(struct?: DataDigitaloceanKubernetesClusterSsoOutputReference | DataDigitaloceanKubernetesClusterSso): any;
export declare function dataDigitaloceanKubernetesClusterSsoToHclTerraform(struct?: DataDigitaloceanKubernetesClusterSsoOutputReference | DataDigitaloceanKubernetesClusterSso): any;
export declare class DataDigitaloceanKubernetesClusterSsoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanKubernetesClusterSso | undefined;
    set internalValue(value: DataDigitaloceanKubernetesClusterSso | undefined);
    get clientId(): string;
    get enabled(): cdktn.IResolvable;
    get issuerUrl(): string;
    get required(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster digitalocean_kubernetes_cluster}
*/
export declare class DataDigitaloceanKubernetesCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_kubernetes_cluster";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanKubernetesCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanKubernetesCluster to import
    * @param importFromId The id of the existing DataDigitaloceanKubernetesCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanKubernetesCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.87.0/docs/data-sources/kubernetes_cluster digitalocean_kubernetes_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanKubernetesClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanKubernetesClusterConfig);
    get autoUpgrade(): cdktn.IResolvable;
    get clusterSubnet(): string;
    private _controlPlaneFirewall;
    get controlPlaneFirewall(): DataDigitaloceanKubernetesClusterControlPlaneFirewallList;
    get createdAt(): string;
    get endpoint(): string;
    get ha(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipv4Address(): string;
    private _kubeConfig;
    get kubeConfig(): DataDigitaloceanKubernetesClusterKubeConfigList;
    private _kubeconfigExpireSeconds?;
    get kubeconfigExpireSeconds(): number;
    set kubeconfigExpireSeconds(value: number);
    resetKubeconfigExpireSeconds(): void;
    get kubeconfigExpireSecondsInput(): number | undefined;
    private _maintenancePolicy;
    get maintenancePolicy(): DataDigitaloceanKubernetesClusterMaintenancePolicyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodePool;
    get nodePool(): DataDigitaloceanKubernetesClusterNodePoolList;
    get region(): string;
    get serviceSubnet(): string;
    get status(): string;
    get surgeUpgrade(): cdktn.IResolvable;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    get urn(): string;
    get version(): string;
    get vpcUuid(): string;
    private _amdGpuDeviceMetricsExporterPlugin;
    get amdGpuDeviceMetricsExporterPlugin(): DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPluginOutputReference;
    putAmdGpuDeviceMetricsExporterPlugin(value: DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin): void;
    resetAmdGpuDeviceMetricsExporterPlugin(): void;
    get amdGpuDeviceMetricsExporterPluginInput(): DataDigitaloceanKubernetesClusterAmdGpuDeviceMetricsExporterPlugin | undefined;
    private _amdGpuDevicePlugin;
    get amdGpuDevicePlugin(): DataDigitaloceanKubernetesClusterAmdGpuDevicePluginOutputReference;
    putAmdGpuDevicePlugin(value: DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin): void;
    resetAmdGpuDevicePlugin(): void;
    get amdGpuDevicePluginInput(): DataDigitaloceanKubernetesClusterAmdGpuDevicePlugin | undefined;
    private _clusterAutoscalerConfiguration;
    get clusterAutoscalerConfiguration(): DataDigitaloceanKubernetesClusterClusterAutoscalerConfigurationList;
    putClusterAutoscalerConfiguration(value: DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration[] | cdktn.IResolvable): void;
    resetClusterAutoscalerConfiguration(): void;
    get clusterAutoscalerConfigurationInput(): cdktn.IResolvable | DataDigitaloceanKubernetesClusterClusterAutoscalerConfiguration[] | undefined;
    private _nvidiaGpuDevicePlugin;
    get nvidiaGpuDevicePlugin(): DataDigitaloceanKubernetesClusterNvidiaGpuDevicePluginOutputReference;
    putNvidiaGpuDevicePlugin(value: DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin): void;
    resetNvidiaGpuDevicePlugin(): void;
    get nvidiaGpuDevicePluginInput(): DataDigitaloceanKubernetesClusterNvidiaGpuDevicePlugin | undefined;
    private _rdmaSharedDevicePlugin;
    get rdmaSharedDevicePlugin(): DataDigitaloceanKubernetesClusterRdmaSharedDevicePluginOutputReference;
    putRdmaSharedDevicePlugin(value: DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin): void;
    resetRdmaSharedDevicePlugin(): void;
    get rdmaSharedDevicePluginInput(): DataDigitaloceanKubernetesClusterRdmaSharedDevicePlugin | undefined;
    private _routingAgent;
    get routingAgent(): DataDigitaloceanKubernetesClusterRoutingAgentOutputReference;
    putRoutingAgent(value: DataDigitaloceanKubernetesClusterRoutingAgent): void;
    resetRoutingAgent(): void;
    get routingAgentInput(): DataDigitaloceanKubernetesClusterRoutingAgent | undefined;
    private _sso;
    get sso(): DataDigitaloceanKubernetesClusterSsoOutputReference;
    putSso(value: DataDigitaloceanKubernetesClusterSso): void;
    resetSso(): void;
    get ssoInput(): DataDigitaloceanKubernetesClusterSso | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
