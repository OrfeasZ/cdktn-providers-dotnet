# `data_digitalocean_kubernetes_cluster`

Refer to the Terraform Registry for docs: [`data_digitalocean_kubernetes_cluster`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/kubernetes_cluster).
