# `digitalocean_database_online_migration`

Refer to the Terraform Registry for docs: [`digitalocean_database_online_migration`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration).
