import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseOnlineMigrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#cluster_id DatabaseOnlineMigration#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Disables SSL encryption when connecting to the source database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#disable_ssl DatabaseOnlineMigration#disable_ssl}
    */
    readonly disableSsl?: boolean | cdktn.IResolvable;
    /**
    * The list of databases to be ignored during the migration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#ignore_dbs DatabaseOnlineMigration#ignore_dbs}
    */
    readonly ignoreDbs?: string[];
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#source DatabaseOnlineMigration#source}
    */
    readonly source: DatabaseOnlineMigrationSource;
}
export interface DatabaseOnlineMigrationSource {
    /**
    * The name of the default database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#db_name DatabaseOnlineMigration#db_name}
    */
    readonly dbName: string;
    /**
    * The FQDN pointing to the database cluster's current primary node
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#host DatabaseOnlineMigration#host}
    */
    readonly host: string;
    /**
    * The password of the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#password DatabaseOnlineMigration#password}
    */
    readonly password: string;
    /**
    * The port on which the database cluster is listening
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#port DatabaseOnlineMigration#port}
    */
    readonly port: number;
    /**
    * The default user of the database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#username DatabaseOnlineMigration#username}
    */
    readonly username: string;
}
export declare function databaseOnlineMigrationSourceToTerraform(struct?: DatabaseOnlineMigrationSourceOutputReference | DatabaseOnlineMigrationSource): any;
export declare function databaseOnlineMigrationSourceToHclTerraform(struct?: DatabaseOnlineMigrationSourceOutputReference | DatabaseOnlineMigrationSource): any;
export declare class DatabaseOnlineMigrationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseOnlineMigrationSource | undefined;
    set internalValue(value: DatabaseOnlineMigrationSource | undefined);
    private _dbName?;
    get dbName(): string;
    set dbName(value: string);
    get dbNameInput(): string | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration digitalocean_database_online_migration}
*/
export declare class DatabaseOnlineMigration extends cdktn.TerraformResource {
    static readonly tfResourceType = "digitalocean_database_online_migration";
    /**
    * Generates CDKTN code for importing a DatabaseOnlineMigration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseOnlineMigration to import
    * @param importFromId The id of the existing DatabaseOnlineMigration that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseOnlineMigration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/resources/database_online_migration digitalocean_database_online_migration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseOnlineMigrationConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseOnlineMigrationConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get createdAt(): string;
    private _disableSsl?;
    get disableSsl(): boolean | cdktn.IResolvable;
    set disableSsl(value: boolean | cdktn.IResolvable);
    resetDisableSsl(): void;
    get disableSslInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _ignoreDbs?;
    get ignoreDbs(): string[];
    set ignoreDbs(value: string[]);
    resetIgnoreDbs(): void;
    get ignoreDbsInput(): string[] | undefined;
    get status(): string;
    private _source;
    get source(): DatabaseOnlineMigrationSourceOutputReference;
    putSource(value: DatabaseOnlineMigrationSource): void;
    get sourceInput(): DatabaseOnlineMigrationSource | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
