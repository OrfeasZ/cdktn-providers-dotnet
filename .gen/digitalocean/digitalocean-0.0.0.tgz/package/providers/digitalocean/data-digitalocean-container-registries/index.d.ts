import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanContainerRegistriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/container_registries#id DataDigitaloceanContainerRegistries#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * name of the container registries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/container_registries#name DataDigitaloceanContainerRegistries#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/container_registries digitalocean_container_registries}
*/
export declare class DataDigitaloceanContainerRegistries extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_container_registries";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanContainerRegistries resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanContainerRegistries to import
    * @param importFromId The id of the existing DataDigitaloceanContainerRegistries that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/container_registries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanContainerRegistries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.86.0/docs/data-sources/container_registries digitalocean_container_registries} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanContainerRegistriesConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanContainerRegistriesConfig);
    get createdAt(): string;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get serverUrl(): string;
    get storageUsageBytes(): number;
    get subscriptionTierSlug(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
