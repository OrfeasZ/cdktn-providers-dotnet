# `data_digitalocean_container_registries`

Refer to the Terraform Registry for docs: [`data_digitalocean_container_registries`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/container_registries).
