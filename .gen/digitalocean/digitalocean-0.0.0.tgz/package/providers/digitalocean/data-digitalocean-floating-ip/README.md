# `data_digitalocean_floating_ip`

Refer to the Terraform Registry for docs: [`data_digitalocean_floating_ip`](https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/floating_ip).
