import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDigitaloceanFloatingIpConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/floating_ip#id DataDigitaloceanFloatingIp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * floating ip address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/floating_ip#ip_address DataDigitaloceanFloatingIp#ip_address}
    */
    readonly ipAddress: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/floating_ip digitalocean_floating_ip}
*/
export declare class DataDigitaloceanFloatingIp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_floating_ip";
    /**
    * Generates CDKTN code for importing a DataDigitaloceanFloatingIp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanFloatingIp to import
    * @param importFromId The id of the existing DataDigitaloceanFloatingIp that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/floating_ip#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanFloatingIp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.85.1/docs/data-sources/floating_ip digitalocean_floating_ip} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanFloatingIpConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanFloatingIpConfig);
    get dropletId(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    get ipAddressInput(): string | undefined;
    get region(): string;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
