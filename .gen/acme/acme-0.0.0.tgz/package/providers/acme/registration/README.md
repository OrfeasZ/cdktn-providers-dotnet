# `acme_registration`

Refer to the Terraform Registry for docs: [`acme_registration`](https://registry.terraform.io/providers/vancluever/acme/2.48.1/docs/resources/registration).
