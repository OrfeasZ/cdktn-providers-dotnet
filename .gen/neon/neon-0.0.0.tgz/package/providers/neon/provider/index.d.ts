import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NeonProviderConfig {
    /**
    * API access key. Default is read from the environment variable `NEON_API_KEY`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs#api_key NeonProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs#alias NeonProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs neon}
*/
export declare class NeonProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "neon";
    /**
    * Generates CDKTN code for importing a NeonProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NeonProvider to import
    * @param importFromId The id of the existing NeonProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NeonProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs neon} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NeonProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: NeonProviderConfig);
    private _apiKey?;
    get apiKey(): string | undefined;
    set apiKey(value: string | undefined);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
