# `neon_role`

Refer to the Terraform Registry for docs: [`neon_role`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/role).
