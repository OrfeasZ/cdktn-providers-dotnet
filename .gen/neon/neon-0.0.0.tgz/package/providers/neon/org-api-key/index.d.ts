import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OrgApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the API Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key#name OrgApiKey#name}
    */
    readonly name: string;
    /**
    * The organisation ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key#org_id OrgApiKey#org_id}
    */
    readonly orgId: string;
    /**
    * The project ID to which this key will grant the access to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key#project_id OrgApiKey#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key neon_org_api_key}
*/
export declare class OrgApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_org_api_key";
    /**
    * Generates CDKTN code for importing a OrgApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrgApiKey to import
    * @param importFromId The id of the existing OrgApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrgApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key neon_org_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrgApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: OrgApiKeyConfig);
    get id(): string;
    get key(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
