# `neon_org_api_key`

Refer to the Terraform Registry for docs: [`neon_org_api_key`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/org_api_key).
