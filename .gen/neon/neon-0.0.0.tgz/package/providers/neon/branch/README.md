# `neon_branch`

Refer to the Terraform Registry for docs: [`neon_branch`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch).
