import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BranchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Branch name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#name Branch#name}
    */
    readonly name?: string;
    /**
    * ID of the branch to check out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#parent_id Branch#parent_id}
    */
    readonly parentId?: string;
    /**
    * Log Sequence Number (LSN) horizon for the data to be present in the new branch.
    * See details: https://neon.tech/docs/reference/glossary/#lsn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#parent_lsn Branch#parent_lsn}
    */
    readonly parentLsn?: string;
    /**
    * Timestamp horizon for the data to be present in the new branch.
    * **Note**: it's defined as Unix epoch.'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#parent_timestamp Branch#parent_timestamp}
    */
    readonly parentTimestamp?: number;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#project_id Branch#project_id}
    */
    readonly projectId: string;
    /**
    * Set to 'yes' to activate, 'no' to deactivate explicitly, and omit to keep the default value.
    * Set whether the branch is protected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#protected Branch#protected}
    */
    readonly protected?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch neon_branch}
*/
export declare class Branch extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_branch";
    /**
    * Generates CDKTN code for importing a Branch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Branch to import
    * @param importFromId The id of the existing Branch that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Branch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/branch neon_branch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BranchConfig
    */
    constructor(scope: Construct, id: string, config: BranchConfig);
    get id(): string;
    get logicalSize(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    resetParentId(): void;
    get parentIdInput(): string | undefined;
    private _parentLsn?;
    get parentLsn(): string;
    set parentLsn(value: string);
    resetParentLsn(): void;
    get parentLsnInput(): string | undefined;
    private _parentTimestamp?;
    get parentTimestamp(): number;
    set parentTimestamp(value: number);
    resetParentTimestamp(): void;
    get parentTimestampInput(): number | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _protected?;
    get protected(): string;
    set protected(value: string);
    resetProtected(): void;
    get protectedInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
