# `neon_vpc_endpoint_restriction`

Refer to the Terraform Registry for docs: [`neon_vpc_endpoint_restriction`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction).
