import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VpcEndpointRestrictionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction#id VpcEndpointRestriction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A descriptive label for the VPC endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction#label VpcEndpointRestriction#label}
    */
    readonly label: string;
    /**
    * The Neon project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction#project_id VpcEndpointRestriction#project_id}
    */
    readonly projectId: string;
    /**
    * The VPC endpoint ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction#vpc_endpoint_id VpcEndpointRestriction#vpc_endpoint_id}
    */
    readonly vpcEndpointId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction neon_vpc_endpoint_restriction}
*/
export declare class VpcEndpointRestriction extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_vpc_endpoint_restriction";
    /**
    * Generates CDKTN code for importing a VpcEndpointRestriction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpcEndpointRestriction to import
    * @param importFromId The id of the existing VpcEndpointRestriction that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpcEndpointRestriction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_restriction neon_vpc_endpoint_restriction} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpcEndpointRestrictionConfig
    */
    constructor(scope: Construct, id: string, config: VpcEndpointRestrictionConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    get vpcEndpointIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
