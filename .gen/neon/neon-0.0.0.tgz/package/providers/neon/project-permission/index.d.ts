import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ProjectPermissionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Email of the user whom to grant project permission.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project_permission#grantee ProjectPermission#grantee}
    */
    readonly grantee: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project_permission#project_id ProjectPermission#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project_permission neon_project_permission}
*/
export declare class ProjectPermission extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_project_permission";
    /**
    * Generates CDKTN code for importing a ProjectPermission resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProjectPermission to import
    * @param importFromId The id of the existing ProjectPermission that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project_permission#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProjectPermission to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project_permission neon_project_permission} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectPermissionConfig
    */
    constructor(scope: Construct, id: string, config: ProjectPermissionConfig);
    private _grantee?;
    get grantee(): string;
    set grantee(value: string);
    get granteeInput(): string | undefined;
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
