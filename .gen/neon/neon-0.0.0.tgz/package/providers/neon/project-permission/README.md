# `neon_project_permission`

Refer to the Terraform Registry for docs: [`neon_project_permission`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project_permission).
