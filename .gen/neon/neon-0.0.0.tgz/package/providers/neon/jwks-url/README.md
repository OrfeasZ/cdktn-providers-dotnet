# `neon_jwks_url`

Refer to the Terraform Registry for docs: [`neon_jwks_url`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url).
