import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface JwksUrlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Branch ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#branch_id JwksUrl#branch_id}
    */
    readonly branchId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#id JwksUrl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The URL that lists the JWKS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#jwks_url JwksUrl#jwks_url}
    */
    readonly jwksUrl: string;
    /**
    * The name of the required JWT Audience to be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#jwt_audience JwksUrl#jwt_audience}
    */
    readonly jwtAudience?: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#project_id JwksUrl#project_id}
    */
    readonly projectId: string;
    /**
    * The name of the authentication provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#provider_name JwksUrl#provider_name}
    */
    readonly providerName: string;
    /**
    * The roles the JWKS should be mapped to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#role_names JwksUrl#role_names}
    */
    readonly roleNames: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url neon_jwks_url}
*/
export declare class JwksUrl extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_jwks_url";
    /**
    * Generates CDKTN code for importing a JwksUrl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the JwksUrl to import
    * @param importFromId The id of the existing JwksUrl that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the JwksUrl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/jwks_url neon_jwks_url} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options JwksUrlConfig
    */
    constructor(scope: Construct, id: string, config: JwksUrlConfig);
    private _branchId?;
    get branchId(): string;
    set branchId(value: string);
    resetBranchId(): void;
    get branchIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jwksUrl?;
    get jwksUrl(): string;
    set jwksUrl(value: string);
    get jwksUrlInput(): string | undefined;
    private _jwtAudience?;
    get jwtAudience(): string;
    set jwtAudience(value: string);
    resetJwtAudience(): void;
    get jwtAudienceInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    get providerNameInput(): string | undefined;
    private _roleNames?;
    get roleNames(): string[];
    set roleNames(value: string[]);
    get roleNamesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
