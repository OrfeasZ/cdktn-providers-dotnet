import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of IP addresses that are allowed to connect to the endpoints.
    * Note that the feature is available to the Neon Scale plans only. Details: https://neon.tech/docs/manage/projects#configure-ip-allow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#allowed_ips Project#allowed_ips}
    */
    readonly allowedIps?: string[];
    /**
    * Set to 'yes' to activate, 'no' to deactivate explicitly, and omit to keep the default value.
    * Apply the allow-list to the protected branches only.
    * Note that the feature is available to the Neon Scale plans only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#allowed_ips_protected_branches_only Project#allowed_ips_protected_branches_only}
    */
    readonly allowedIpsProtectedBranchesOnly?: string;
    /**
    * Set to 'yes' to activate, 'no' to deactivate explicitly, and omit to keep the default value.
    * Block connections from public internet. This supersedes the AllowedIPs list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#block_public_connections Project#block_public_connections}
    */
    readonly blockPublicConnections?: string;
    /**
    * Set to 'yes' to activate, 'no' to deactivate explicitly, and omit to keep the default value.
    * Block connections that use VPC endpoints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#block_vpc_connections Project#block_vpc_connections}
    */
    readonly blockVpcConnections?: string;
    /**
    * Provisioner The Neon compute provisioner.
    * Specify the k8s-neonvm provisioner to create a compute endpoint that supports Autoscaling.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#compute_provisioner Project#compute_provisioner}
    */
    readonly computeProvisioner?: string;
    /**
    * Set to 'yes' to activate, 'no' to deactivate explicitly, and omit to keep the default value.
    * Sets wal_level=logical for all compute endpoints in this project.
    * All active endpoints will be suspended. Once enabled, logical replication cannot be disabled.
    * See details: https://neon.tech/docs/introduction/logical-replication
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#enable_logical_replication Project#enable_logical_replication}
    */
    readonly enableLogicalReplication?: string;
    /**
    * The number of seconds to retain the point-in-time restore (PITR) backup history for this project.
    * Default: 1 day, see https://neon.tech/docs/reference/glossary#point-in-time-restore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#history_retention_seconds Project#history_retention_seconds}
    */
    readonly historyRetentionSeconds?: number;
    /**
    * Project name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#name Project#name}
    */
    readonly name?: string;
    /**
    * Identifier of the organisation to which this project belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#org_id Project#org_id}
    */
    readonly orgId?: string;
    /**
    * Postgres version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#pg_version Project#pg_version}
    */
    readonly pgVersion?: number;
    /**
    * Deployment region: https://neon.tech/docs/introduction/regions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#region_id Project#region_id}
    */
    readonly regionId?: string;
    /**
    * Set to 'yes' to activate, 'no' to deactivate explicitly, and omit to keep the default value.
    * Whether or not passwords are stored for roles in the Neon project.
    * Storing passwords facilitates access to Neon features that require authorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#store_password Project#store_password}
    */
    readonly storePassword?: string;
    /**
    * branch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#branch Project#branch}
    */
    readonly branch?: ProjectBranch;
    /**
    * default_endpoint_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#default_endpoint_settings Project#default_endpoint_settings}
    */
    readonly defaultEndpointSettings?: ProjectDefaultEndpointSettings;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#maintenance_window Project#maintenance_window}
    */
    readonly maintenanceWindow?: ProjectMaintenanceWindow;
    /**
    * quota block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#quota Project#quota}
    */
    readonly quota?: ProjectQuota;
}
export interface ProjectBranch {
    /**
    * The name of the default database provisioned upon creation of new project. It's owned by the default role (`role_name`).
    * If not specified, the default database name will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#database_name Project#database_name}
    */
    readonly databaseName?: string;
    /**
    * The name of the default branch provisioned upon creation of new project.
    * If not specified, the default branch name will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#name Project#name}
    */
    readonly name?: string;
    /**
    * The name of the default role provisioned upon creation of new project.
    * If not specified, the default role name will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#role_name Project#role_name}
    */
    readonly roleName?: string;
}
export declare function projectBranchToTerraform(struct?: ProjectBranchOutputReference | ProjectBranch): any;
export declare function projectBranchToHclTerraform(struct?: ProjectBranchOutputReference | ProjectBranch): any;
export declare class ProjectBranchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectBranch | undefined;
    set internalValue(value: ProjectBranch | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    resetRoleName(): void;
    get roleNameInput(): string | undefined;
}
export interface ProjectDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#autoscaling_limit_max_cu Project#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#autoscaling_limit_min_cu Project#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Duration of inactivity in seconds after which the compute endpoint is automatically suspended.
    * The value 0 means use the global default.
    * The value -1 means never suspend. The default value is 300 seconds (5 minutes).
    * The maximum value is 604800 seconds (1 week)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#suspend_timeout_seconds Project#suspend_timeout_seconds}
    */
    readonly suspendTimeoutSeconds?: number;
}
export declare function projectDefaultEndpointSettingsToTerraform(struct?: ProjectDefaultEndpointSettingsOutputReference | ProjectDefaultEndpointSettings): any;
export declare function projectDefaultEndpointSettingsToHclTerraform(struct?: ProjectDefaultEndpointSettingsOutputReference | ProjectDefaultEndpointSettings): any;
export declare class ProjectDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectDefaultEndpointSettings | undefined;
    set internalValue(value: ProjectDefaultEndpointSettings | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    get id(): string;
    private _suspendTimeoutSeconds?;
    get suspendTimeoutSeconds(): number;
    set suspendTimeoutSeconds(value: number);
    resetSuspendTimeoutSeconds(): void;
    get suspendTimeoutSecondsInput(): number | undefined;
}
export interface ProjectMaintenanceWindow {
    /**
    * End time of the maintenance window, in the format of "HH:MM". Uses UTC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#end_time Project#end_time}
    */
    readonly endTime: string;
    /**
    * Start time of the maintenance window, in the format of "HH:MM". Uses UTC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#start_time Project#start_time}
    */
    readonly startTime: string;
    /**
    * A list of weekdays when the maintenance window is active. Encoded as ints, where 1 - Monday, and 7 - Sunday.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#weekdays Project#weekdays}
    */
    readonly weekdays: number[];
}
export declare function projectMaintenanceWindowToTerraform(struct?: ProjectMaintenanceWindowOutputReference | ProjectMaintenanceWindow): any;
export declare function projectMaintenanceWindowToHclTerraform(struct?: ProjectMaintenanceWindowOutputReference | ProjectMaintenanceWindow): any;
export declare class ProjectMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectMaintenanceWindow | undefined;
    set internalValue(value: ProjectMaintenanceWindow | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _weekdays?;
    get weekdays(): number[];
    set weekdays(value: number[]);
    get weekdaysInput(): number[] | undefined;
}
export interface ProjectQuota {
    /**
    * The total amount of wall-clock time allowed to be spent by the project's compute endpoints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#active_time_seconds Project#active_time_seconds}
    */
    readonly activeTimeSeconds?: number;
    /**
    * The total amount of CPU seconds allowed to be spent by the project's compute endpoints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#compute_time_seconds Project#compute_time_seconds}
    */
    readonly computeTimeSeconds?: number;
    /**
    * Total amount of data transferred from all of a project's branches using the proxy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#data_transfer_bytes Project#data_transfer_bytes}
    */
    readonly dataTransferBytes?: number;
    /**
    * Limit on the logical size of every project's branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#logical_size_bytes Project#logical_size_bytes}
    */
    readonly logicalSizeBytes?: number;
    /**
    * Total amount of data written to all of a project's branches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#written_data_bytes Project#written_data_bytes}
    */
    readonly writtenDataBytes?: number;
}
export declare function projectQuotaToTerraform(struct?: ProjectQuotaOutputReference | ProjectQuota): any;
export declare function projectQuotaToHclTerraform(struct?: ProjectQuotaOutputReference | ProjectQuota): any;
export declare class ProjectQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProjectQuota | undefined;
    set internalValue(value: ProjectQuota | undefined);
    private _activeTimeSeconds?;
    get activeTimeSeconds(): number;
    set activeTimeSeconds(value: number);
    resetActiveTimeSeconds(): void;
    get activeTimeSecondsInput(): number | undefined;
    private _computeTimeSeconds?;
    get computeTimeSeconds(): number;
    set computeTimeSeconds(value: number);
    resetComputeTimeSeconds(): void;
    get computeTimeSecondsInput(): number | undefined;
    private _dataTransferBytes?;
    get dataTransferBytes(): number;
    set dataTransferBytes(value: number);
    resetDataTransferBytes(): void;
    get dataTransferBytesInput(): number | undefined;
    private _logicalSizeBytes?;
    get logicalSizeBytes(): number;
    set logicalSizeBytes(value: number);
    resetLogicalSizeBytes(): void;
    get logicalSizeBytesInput(): number | undefined;
    private _writtenDataBytes?;
    get writtenDataBytes(): number;
    set writtenDataBytes(value: number);
    resetWrittenDataBytes(): void;
    get writtenDataBytesInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project neon_project}
*/
export declare class Project extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_project";
    /**
    * Generates CDKTN code for importing a Project resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Project to import
    * @param importFromId The id of the existing Project that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Project to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/project neon_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProjectConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ProjectConfig);
    private _allowedIps?;
    get allowedIps(): string[];
    set allowedIps(value: string[]);
    resetAllowedIps(): void;
    get allowedIpsInput(): string[] | undefined;
    private _allowedIpsProtectedBranchesOnly?;
    get allowedIpsProtectedBranchesOnly(): string;
    set allowedIpsProtectedBranchesOnly(value: string);
    resetAllowedIpsProtectedBranchesOnly(): void;
    get allowedIpsProtectedBranchesOnlyInput(): string | undefined;
    private _blockPublicConnections?;
    get blockPublicConnections(): string;
    set blockPublicConnections(value: string);
    resetBlockPublicConnections(): void;
    get blockPublicConnectionsInput(): string | undefined;
    private _blockVpcConnections?;
    get blockVpcConnections(): string;
    set blockVpcConnections(value: string);
    resetBlockVpcConnections(): void;
    get blockVpcConnectionsInput(): string | undefined;
    private _computeProvisioner?;
    get computeProvisioner(): string;
    set computeProvisioner(value: string);
    resetComputeProvisioner(): void;
    get computeProvisionerInput(): string | undefined;
    get connectionUri(): string;
    get connectionUriPooler(): string;
    get databaseHost(): string;
    get databaseHostPooler(): string;
    get databaseName(): string;
    get databasePassword(): string;
    get databaseUser(): string;
    get defaultBranchId(): string;
    get defaultEndpointId(): string;
    private _enableLogicalReplication?;
    get enableLogicalReplication(): string;
    set enableLogicalReplication(value: string);
    resetEnableLogicalReplication(): void;
    get enableLogicalReplicationInput(): string | undefined;
    private _historyRetentionSeconds?;
    get historyRetentionSeconds(): number;
    set historyRetentionSeconds(value: number);
    resetHistoryRetentionSeconds(): void;
    get historyRetentionSecondsInput(): number | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    resetOrgId(): void;
    get orgIdInput(): string | undefined;
    private _pgVersion?;
    get pgVersion(): number;
    set pgVersion(value: number);
    resetPgVersion(): void;
    get pgVersionInput(): number | undefined;
    private _regionId?;
    get regionId(): string;
    set regionId(value: string);
    resetRegionId(): void;
    get regionIdInput(): string | undefined;
    private _storePassword?;
    get storePassword(): string;
    set storePassword(value: string);
    resetStorePassword(): void;
    get storePasswordInput(): string | undefined;
    private _branch;
    get branch(): ProjectBranchOutputReference;
    putBranch(value: ProjectBranch): void;
    resetBranch(): void;
    get branchInput(): ProjectBranch | undefined;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): ProjectDefaultEndpointSettingsOutputReference;
    putDefaultEndpointSettings(value: ProjectDefaultEndpointSettings): void;
    resetDefaultEndpointSettings(): void;
    get defaultEndpointSettingsInput(): ProjectDefaultEndpointSettings | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): ProjectMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: ProjectMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): ProjectMaintenanceWindow | undefined;
    private _quota;
    get quota(): ProjectQuotaOutputReference;
    putQuota(value: ProjectQuota): void;
    resetQuota(): void;
    get quotaInput(): ProjectQuota | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
