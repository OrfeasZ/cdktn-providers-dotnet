# `data_neon_project`

Refer to the Terraform Registry for docs: [`data_neon_project`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/project).
