import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNeonProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/project#id DataNeonProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/project neon_project}
*/
export declare class DataNeonProject extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "neon_project";
    /**
    * Generates CDKTN code for importing a DataNeonProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNeonProject to import
    * @param importFromId The id of the existing DataNeonProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNeonProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/project neon_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNeonProjectConfig
    */
    constructor(scope: Construct, id: string, config: DataNeonProjectConfig);
    get connectionUri(): string;
    get connectionUriPooler(): string;
    get databaseHost(): string;
    get databaseHostPooler(): string;
    get databaseName(): string;
    get databasePassword(): string;
    get databaseUser(): string;
    get defaultBranchId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
