import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the API Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/api_key#name ApiKey#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/api_key neon_api_key}
*/
export declare class ApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_api_key";
    /**
    * Generates CDKTN code for importing a ApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiKey to import
    * @param importFromId The id of the existing ApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/api_key neon_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: ApiKeyConfig);
    get id(): string;
    get key(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
