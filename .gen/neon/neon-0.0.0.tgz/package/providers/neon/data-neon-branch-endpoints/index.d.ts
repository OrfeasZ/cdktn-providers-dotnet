import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNeonBranchEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Branch ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints#branch_id DataNeonBranchEndpoints#branch_id}
    */
    readonly branchId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints#id DataNeonBranchEndpoints#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints#project_id DataNeonBranchEndpoints#project_id}
    */
    readonly projectId: string;
    /**
    * endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints#endpoints DataNeonBranchEndpoints#endpoints}
    */
    readonly endpoints?: DataNeonBranchEndpointsEndpoints[] | cdktn.IResolvable;
}
export interface DataNeonBranchEndpointsEndpoints {
}
export declare function dataNeonBranchEndpointsEndpointsToTerraform(struct?: DataNeonBranchEndpointsEndpoints | cdktn.IResolvable): any;
export declare function dataNeonBranchEndpointsEndpointsToHclTerraform(struct?: DataNeonBranchEndpointsEndpoints | cdktn.IResolvable): any;
export declare class DataNeonBranchEndpointsEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNeonBranchEndpointsEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataNeonBranchEndpointsEndpoints | cdktn.IResolvable | undefined);
    get host(): string;
    get id(): string;
    get proxyHost(): string;
    get regionId(): string;
    get type(): string;
}
export declare class DataNeonBranchEndpointsEndpointsList extends cdktn.ComplexList {
    internalValue?: DataNeonBranchEndpointsEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNeonBranchEndpointsEndpointsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints neon_branch_endpoints}
*/
export declare class DataNeonBranchEndpoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "neon_branch_endpoints";
    /**
    * Generates CDKTN code for importing a DataNeonBranchEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNeonBranchEndpoints to import
    * @param importFromId The id of the existing DataNeonBranchEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNeonBranchEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints neon_branch_endpoints} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNeonBranchEndpointsConfig
    */
    constructor(scope: Construct, id: string, config: DataNeonBranchEndpointsConfig);
    private _branchId?;
    get branchId(): string;
    set branchId(value: string);
    get branchIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _endpoints;
    get endpoints(): DataNeonBranchEndpointsEndpointsList;
    putEndpoints(value: DataNeonBranchEndpointsEndpoints[] | cdktn.IResolvable): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataNeonBranchEndpointsEndpoints[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
