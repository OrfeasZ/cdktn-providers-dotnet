# `data_neon_branch_endpoints`

Refer to the Terraform Registry for docs: [`data_neon_branch_endpoints`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_endpoints).
