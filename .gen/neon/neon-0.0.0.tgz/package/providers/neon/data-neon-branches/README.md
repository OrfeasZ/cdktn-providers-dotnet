# `data_neon_branches`

Refer to the Terraform Registry for docs: [`data_neon_branches`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branches).
