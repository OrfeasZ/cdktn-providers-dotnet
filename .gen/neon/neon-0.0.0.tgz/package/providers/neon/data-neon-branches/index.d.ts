import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNeonBranchesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branches#id DataNeonBranches#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branches#project_id DataNeonBranches#project_id}
    */
    readonly projectId: string;
}
export interface DataNeonBranchesBranches {
}
export declare function dataNeonBranchesBranchesToTerraform(struct?: DataNeonBranchesBranches): any;
export declare function dataNeonBranchesBranchesToHclTerraform(struct?: DataNeonBranchesBranches): any;
export declare class DataNeonBranchesBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNeonBranchesBranches | undefined;
    set internalValue(value: DataNeonBranchesBranches | undefined);
    get id(): string;
    get logicalSize(): number;
    get name(): string;
    get parentId(): string;
    get primary(): cdktn.IResolvable;
}
export declare class DataNeonBranchesBranchesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNeonBranchesBranchesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branches neon_branches}
*/
export declare class DataNeonBranches extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "neon_branches";
    /**
    * Generates CDKTN code for importing a DataNeonBranches resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNeonBranches to import
    * @param importFromId The id of the existing DataNeonBranches that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branches#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNeonBranches to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branches neon_branches} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNeonBranchesConfig
    */
    constructor(scope: Construct, id: string, config: DataNeonBranchesConfig);
    private _branches;
    get branches(): DataNeonBranchesBranchesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
