# `neon_vpc_endpoint_assignment`

Refer to the Terraform Registry for docs: [`neon_vpc_endpoint_assignment`](https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/vpc_endpoint_assignment).
