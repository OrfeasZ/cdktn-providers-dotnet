import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#autoscaling_limit_max_cu Endpoint#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#autoscaling_limit_min_cu Endpoint#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Branch ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#branch_id Endpoint#branch_id}
    */
    readonly branchId: string;
    /**
    * Provisioner The Neon compute provisioner.
    * Specify the k8s-neonvm provisioner to create a compute endpoint that supports Autoscaling.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#compute_provisioner Endpoint#compute_provisioner}
    */
    readonly computeProvisioner?: string;
    /**
    * Disable the endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#disabled Endpoint#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#pg_settings Endpoint#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Activate connection pooling.
    * See details: https://neon.tech/docs/connect/connection-pooling
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#pooler_enabled Endpoint#pooler_enabled}
    */
    readonly poolerEnabled?: boolean | cdktn.IResolvable;
    /**
    * Mode of connections pooling.
    * See details: https://neon.tech/docs/connect/connection-pooling
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#pooler_mode Endpoint#pooler_mode}
    */
    readonly poolerMode?: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#project_id Endpoint#project_id}
    */
    readonly projectId: string;
    /**
    * Deployment region: https://neon.tech/docs/introduction/regions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#region_id Endpoint#region_id}
    */
    readonly regionId?: string;
    /**
    * Duration of inactivity in seconds after which the compute endpoint is automatically suspended.
    * The value 0 means use the global default.
    * The value -1 means never suspend. The default value is 300 seconds (5 minutes).
    * The maximum value is 604800 seconds (1 week)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#suspend_timeout_seconds Endpoint#suspend_timeout_seconds}
    */
    readonly suspendTimeoutSeconds?: number;
    /**
    * Access type. **Note** that a single branch can have only one "read_write" endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#type Endpoint#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint neon_endpoint}
*/
export declare class Endpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "neon_endpoint";
    /**
    * Generates CDKTN code for importing a Endpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Endpoint to import
    * @param importFromId The id of the existing Endpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Endpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/resources/endpoint neon_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EndpointConfig
    */
    constructor(scope: Construct, id: string, config: EndpointConfig);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _branchId?;
    get branchId(): string;
    set branchId(value: string);
    get branchIdInput(): string | undefined;
    private _computeProvisioner?;
    get computeProvisioner(): string;
    set computeProvisioner(value: string);
    resetComputeProvisioner(): void;
    get computeProvisionerInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get host(): string;
    get id(): string;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _poolerEnabled?;
    get poolerEnabled(): boolean | cdktn.IResolvable;
    set poolerEnabled(value: boolean | cdktn.IResolvable);
    resetPoolerEnabled(): void;
    get poolerEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _poolerMode?;
    get poolerMode(): string;
    set poolerMode(value: string);
    resetPoolerMode(): void;
    get poolerModeInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get proxyHost(): string;
    private _regionId?;
    get regionId(): string;
    set regionId(value: string);
    resetRegionId(): void;
    get regionIdInput(): string | undefined;
    private _suspendTimeoutSeconds?;
    get suspendTimeoutSeconds(): number;
    set suspendTimeoutSeconds(value: number);
    resetSuspendTimeoutSeconds(): void;
    get suspendTimeoutSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
