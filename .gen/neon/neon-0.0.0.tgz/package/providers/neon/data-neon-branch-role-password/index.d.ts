import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNeonBranchRolePasswordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Branch ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password#branch_id DataNeonBranchRolePassword#branch_id}
    */
    readonly branchId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password#id DataNeonBranchRolePassword#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password#project_id DataNeonBranchRolePassword#project_id}
    */
    readonly projectId: string;
    /**
    * Role name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password#role_name DataNeonBranchRolePassword#role_name}
    */
    readonly roleName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password neon_branch_role_password}
*/
export declare class DataNeonBranchRolePassword extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "neon_branch_role_password";
    /**
    * Generates CDKTN code for importing a DataNeonBranchRolePassword resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNeonBranchRolePassword to import
    * @param importFromId The id of the existing DataNeonBranchRolePassword that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNeonBranchRolePassword to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_role_password neon_branch_role_password} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNeonBranchRolePasswordConfig
    */
    constructor(scope: Construct, id: string, config: DataNeonBranchRolePasswordConfig);
    private _branchId?;
    get branchId(): string;
    set branchId(value: string);
    get branchIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get password(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
