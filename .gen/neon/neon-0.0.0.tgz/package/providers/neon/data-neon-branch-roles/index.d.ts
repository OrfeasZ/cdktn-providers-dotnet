import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNeonBranchRolesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Branch ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles#branch_id DataNeonBranchRoles#branch_id}
    */
    readonly branchId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles#id DataNeonBranchRoles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles#project_id DataNeonBranchRoles#project_id}
    */
    readonly projectId: string;
    /**
    * roles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles#roles DataNeonBranchRoles#roles}
    */
    readonly roles?: DataNeonBranchRolesRoles[] | cdktn.IResolvable;
}
export interface DataNeonBranchRolesRoles {
}
export declare function dataNeonBranchRolesRolesToTerraform(struct?: DataNeonBranchRolesRoles | cdktn.IResolvable): any;
export declare function dataNeonBranchRolesRolesToHclTerraform(struct?: DataNeonBranchRolesRoles | cdktn.IResolvable): any;
export declare class DataNeonBranchRolesRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNeonBranchRolesRoles | cdktn.IResolvable | undefined;
    set internalValue(value: DataNeonBranchRolesRoles | cdktn.IResolvable | undefined);
    get name(): string;
    get protected(): cdktn.IResolvable;
}
export declare class DataNeonBranchRolesRolesList extends cdktn.ComplexList {
    internalValue?: DataNeonBranchRolesRoles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNeonBranchRolesRolesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles neon_branch_roles}
*/
export declare class DataNeonBranchRoles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "neon_branch_roles";
    /**
    * Generates CDKTN code for importing a DataNeonBranchRoles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNeonBranchRoles to import
    * @param importFromId The id of the existing DataNeonBranchRoles that should be imported. Refer to the {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNeonBranchRoles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kislerdm/neon/0.13.0/docs/data-sources/branch_roles neon_branch_roles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNeonBranchRolesConfig
    */
    constructor(scope: Construct, id: string, config: DataNeonBranchRolesConfig);
    private _branchId?;
    get branchId(): string;
    set branchId(value: string);
    get branchIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _roles;
    get roles(): DataNeonBranchRolesRolesList;
    putRoles(value: DataNeonBranchRolesRoles[] | cdktn.IResolvable): void;
    resetRoles(): void;
    get rolesInput(): cdktn.IResolvable | DataNeonBranchRolesRoles[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
