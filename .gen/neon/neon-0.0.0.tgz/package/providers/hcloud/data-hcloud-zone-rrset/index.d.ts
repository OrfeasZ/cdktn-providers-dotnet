import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudZoneRrsetConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset#id DataHcloudZoneRrset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset#name DataHcloudZoneRrset#name}
    */
    readonly name?: string;
    /**
    * Type of the Zone RRSet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset#type DataHcloudZoneRrset#type}
    */
    readonly type?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset#with_selector DataHcloudZoneRrset#with_selector}
    */
    readonly withSelector?: string;
    /**
    * ID or Name of the parent Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset#zone DataHcloudZoneRrset#zone}
    */
    readonly zone: string;
}
export interface DataHcloudZoneRrsetRecords {
}
export declare function dataHcloudZoneRrsetRecordsToTerraform(struct?: DataHcloudZoneRrsetRecords): any;
export declare function dataHcloudZoneRrsetRecordsToHclTerraform(struct?: DataHcloudZoneRrsetRecords): any;
export declare class DataHcloudZoneRrsetRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudZoneRrsetRecords | undefined;
    set internalValue(value: DataHcloudZoneRrsetRecords | undefined);
    get comment(): string;
    get value(): string;
}
export declare class DataHcloudZoneRrsetRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudZoneRrsetRecordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset hcloud_zone_rrset}
*/
export declare class DataHcloudZoneRrset extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_zone_rrset";
    /**
    * Generates CDKTN code for importing a DataHcloudZoneRrset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudZoneRrset to import
    * @param importFromId The id of the existing DataHcloudZoneRrset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudZoneRrset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrset hcloud_zone_rrset} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudZoneRrsetConfig
    */
    constructor(scope: Construct, id: string, config: DataHcloudZoneRrsetConfig);
    get changeProtection(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _records;
    get records(): DataHcloudZoneRrsetRecordsList;
    get ttl(): number;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
