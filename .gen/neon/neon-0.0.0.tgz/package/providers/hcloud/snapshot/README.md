# `hcloud_snapshot`

Refer to the Terraform Registry for docs: [`hcloud_snapshot`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/snapshot).
