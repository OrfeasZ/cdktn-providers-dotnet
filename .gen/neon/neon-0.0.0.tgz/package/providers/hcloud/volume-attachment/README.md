# `hcloud_volume_attachment`

Refer to the Terraform Registry for docs: [`hcloud_volume_attachment`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/volume_attachment).
