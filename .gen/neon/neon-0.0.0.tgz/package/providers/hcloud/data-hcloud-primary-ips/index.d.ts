import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudPrimaryIpsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/primary_ips#id DataHcloudPrimaryIps#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/primary_ips#with_selector DataHcloudPrimaryIps#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudPrimaryIpsPrimaryIps {
}
export declare function dataHcloudPrimaryIpsPrimaryIpsToTerraform(struct?: DataHcloudPrimaryIpsPrimaryIps): any;
export declare function dataHcloudPrimaryIpsPrimaryIpsToHclTerraform(struct?: DataHcloudPrimaryIpsPrimaryIps): any;
export declare class DataHcloudPrimaryIpsPrimaryIpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudPrimaryIpsPrimaryIps | undefined;
    set internalValue(value: DataHcloudPrimaryIpsPrimaryIps | undefined);
    get assigneeId(): number;
    get assigneeType(): string;
    get autoDelete(): cdktn.IResolvable;
    get datacenter(): string;
    get deleteProtection(): cdktn.IResolvable;
    get id(): number;
    get ipAddress(): string;
    get ipNetwork(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get type(): string;
}
export declare class DataHcloudPrimaryIpsPrimaryIpsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudPrimaryIpsPrimaryIpsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/primary_ips hcloud_primary_ips}
*/
export declare class DataHcloudPrimaryIps extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_primary_ips";
    /**
    * Generates CDKTN code for importing a DataHcloudPrimaryIps resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudPrimaryIps to import
    * @param importFromId The id of the existing DataHcloudPrimaryIps that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/primary_ips#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudPrimaryIps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/primary_ips hcloud_primary_ips} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudPrimaryIpsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudPrimaryIpsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _primaryIps;
    get primaryIps(): DataHcloudPrimaryIpsPrimaryIpsList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
