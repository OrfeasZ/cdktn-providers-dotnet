import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudFirewallsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewalls#id DataHcloudFirewalls#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewalls#most_recent DataHcloudFirewalls#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewalls#with_selector DataHcloudFirewalls#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudFirewallsFirewallsApplyTo {
}
export declare function dataHcloudFirewallsFirewallsApplyToToTerraform(struct?: DataHcloudFirewallsFirewallsApplyTo): any;
export declare function dataHcloudFirewallsFirewallsApplyToToHclTerraform(struct?: DataHcloudFirewallsFirewallsApplyTo): any;
export declare class DataHcloudFirewallsFirewallsApplyToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudFirewallsFirewallsApplyTo | undefined;
    set internalValue(value: DataHcloudFirewallsFirewallsApplyTo | undefined);
    get labelSelector(): string;
    get server(): number;
}
export declare class DataHcloudFirewallsFirewallsApplyToList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudFirewallsFirewallsApplyToOutputReference;
}
export interface DataHcloudFirewallsFirewallsRule {
}
export declare function dataHcloudFirewallsFirewallsRuleToTerraform(struct?: DataHcloudFirewallsFirewallsRule): any;
export declare function dataHcloudFirewallsFirewallsRuleToHclTerraform(struct?: DataHcloudFirewallsFirewallsRule): any;
export declare class DataHcloudFirewallsFirewallsRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudFirewallsFirewallsRule | undefined;
    set internalValue(value: DataHcloudFirewallsFirewallsRule | undefined);
    get description(): string;
    get destinationIps(): string[];
    get direction(): string;
    get port(): string;
    get protocol(): string;
    get sourceIps(): string[];
}
export declare class DataHcloudFirewallsFirewallsRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudFirewallsFirewallsRuleOutputReference;
}
export interface DataHcloudFirewallsFirewalls {
}
export declare function dataHcloudFirewallsFirewallsToTerraform(struct?: DataHcloudFirewallsFirewalls): any;
export declare function dataHcloudFirewallsFirewallsToHclTerraform(struct?: DataHcloudFirewallsFirewalls): any;
export declare class DataHcloudFirewallsFirewallsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudFirewallsFirewalls | undefined;
    set internalValue(value: DataHcloudFirewallsFirewalls | undefined);
    private _applyTo;
    get applyTo(): DataHcloudFirewallsFirewallsApplyToList;
    get id(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    private _rule;
    get rule(): DataHcloudFirewallsFirewallsRuleList;
}
export declare class DataHcloudFirewallsFirewallsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudFirewallsFirewallsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewalls hcloud_firewalls}
*/
export declare class DataHcloudFirewalls extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_firewalls";
    /**
    * Generates CDKTN code for importing a DataHcloudFirewalls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudFirewalls to import
    * @param importFromId The id of the existing DataHcloudFirewalls that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewalls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudFirewalls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewalls hcloud_firewalls} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudFirewallsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudFirewallsConfig);
    private _firewalls;
    get firewalls(): DataHcloudFirewallsFirewallsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
