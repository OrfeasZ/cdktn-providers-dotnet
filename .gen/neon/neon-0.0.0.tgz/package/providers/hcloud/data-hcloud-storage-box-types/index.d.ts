import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxTypesConfig extends cdktn.TerraformMetaArguments {
}
export interface DataHcloudStorageBoxTypesStorageBoxTypes {
}
export declare function dataHcloudStorageBoxTypesStorageBoxTypesToTerraform(struct?: DataHcloudStorageBoxTypesStorageBoxTypes): any;
export declare function dataHcloudStorageBoxTypesStorageBoxTypesToHclTerraform(struct?: DataHcloudStorageBoxTypesStorageBoxTypes): any;
export declare class DataHcloudStorageBoxTypesStorageBoxTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudStorageBoxTypesStorageBoxTypes | undefined;
    set internalValue(value: DataHcloudStorageBoxTypesStorageBoxTypes | undefined);
    get automaticSnapshotLimit(): number;
    get deprecationAnnounced(): string;
    get description(): string;
    get id(): number;
    get isDeprecated(): cdktn.IResolvable;
    get name(): string;
    get size(): number;
    get snapshotLimit(): number;
    get subaccountsLimit(): number;
    get unavailableAfter(): string;
}
export declare class DataHcloudStorageBoxTypesStorageBoxTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudStorageBoxTypesStorageBoxTypesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_types hcloud_storage_box_types}
*/
export declare class DataHcloudStorageBoxTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box_types";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxTypes to import
    * @param importFromId The id of the existing DataHcloudStorageBoxTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_types hcloud_storage_box_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxTypesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudStorageBoxTypesConfig);
    private _storageBoxTypes;
    get storageBoxTypes(): DataHcloudStorageBoxTypesStorageBoxTypesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
