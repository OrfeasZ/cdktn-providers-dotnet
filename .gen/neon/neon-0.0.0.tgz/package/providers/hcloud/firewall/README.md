# `hcloud_firewall`

Refer to the Terraform Registry for docs: [`hcloud_firewall`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/firewall).
