import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#allow_deprecated_images Server#allow_deprecated_images}
    */
    readonly allowDeprecatedImages?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#backups Server#backups}
    */
    readonly backups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#datacenter Server#datacenter}
    */
    readonly datacenter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#delete_protection Server#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#firewall_ids Server#firewall_ids}
    */
    readonly firewallIds?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#id Server#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ignore_remote_firewall_ids Server#ignore_remote_firewall_ids}
    */
    readonly ignoreRemoteFirewallIds?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#image Server#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#iso Server#iso}
    */
    readonly iso?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#keep_disk Server#keep_disk}
    */
    readonly keepDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#labels Server#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#location Server#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#name Server#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#placement_group_id Server#placement_group_id}
    */
    readonly placementGroupId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#rebuild_protection Server#rebuild_protection}
    */
    readonly rebuildProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#rescue Server#rescue}
    */
    readonly rescue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#server_type Server#server_type}
    */
    readonly serverType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#shutdown_before_deletion Server#shutdown_before_deletion}
    */
    readonly shutdownBeforeDeletion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ssh_keys Server#ssh_keys}
    */
    readonly sshKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#user_data Server#user_data}
    */
    readonly userData?: string;
    /**
    * network block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#network Server#network}
    */
    readonly network?: ServerNetwork[] | cdktn.IResolvable;
    /**
    * public_net block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#public_net Server#public_net}
    */
    readonly publicNet?: ServerPublicNet[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#timeouts Server#timeouts}
    */
    readonly timeouts?: ServerTimeouts;
}
export interface ServerNetwork {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#alias_ips Server#alias_ips}
    */
    readonly aliasIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ip Server#ip}
    */
    readonly ip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#network_id Server#network_id}
    */
    readonly networkId: number;
}
export declare function serverNetworkToTerraform(struct?: ServerNetwork | cdktn.IResolvable): any;
export declare function serverNetworkToHclTerraform(struct?: ServerNetwork | cdktn.IResolvable): any;
export declare class ServerNetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServerNetwork | cdktn.IResolvable | undefined;
    set internalValue(value: ServerNetwork | cdktn.IResolvable | undefined);
    private _aliasIps?;
    get aliasIps(): string[];
    set aliasIps(value: string[]);
    resetAliasIps(): void;
    get aliasIpsInput(): string[] | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    get macAddress(): string;
    private _networkId?;
    get networkId(): number;
    set networkId(value: number);
    get networkIdInput(): number | undefined;
}
export declare class ServerNetworkList extends cdktn.ComplexList {
    internalValue?: ServerNetwork[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServerNetworkOutputReference;
}
export interface ServerPublicNet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ipv4 Server#ipv4}
    */
    readonly ipv4?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ipv4_enabled Server#ipv4_enabled}
    */
    readonly ipv4Enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ipv6 Server#ipv6}
    */
    readonly ipv6?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#ipv6_enabled Server#ipv6_enabled}
    */
    readonly ipv6Enabled?: boolean | cdktn.IResolvable;
}
export declare function serverPublicNetToTerraform(struct?: ServerPublicNet | cdktn.IResolvable): any;
export declare function serverPublicNetToHclTerraform(struct?: ServerPublicNet | cdktn.IResolvable): any;
export declare class ServerPublicNetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServerPublicNet | cdktn.IResolvable | undefined;
    set internalValue(value: ServerPublicNet | cdktn.IResolvable | undefined);
    private _ipv4?;
    get ipv4(): number;
    set ipv4(value: number);
    resetIpv4(): void;
    get ipv4Input(): number | undefined;
    private _ipv4Enabled?;
    get ipv4Enabled(): boolean | cdktn.IResolvable;
    set ipv4Enabled(value: boolean | cdktn.IResolvable);
    resetIpv4Enabled(): void;
    get ipv4EnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ipv6?;
    get ipv6(): number;
    set ipv6(value: number);
    resetIpv6(): void;
    get ipv6Input(): number | undefined;
    private _ipv6Enabled?;
    get ipv6Enabled(): boolean | cdktn.IResolvable;
    set ipv6Enabled(value: boolean | cdktn.IResolvable);
    resetIpv6Enabled(): void;
    get ipv6EnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ServerPublicNetList extends cdktn.ComplexList {
    internalValue?: ServerPublicNet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServerPublicNetOutputReference;
}
export interface ServerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#create Server#create}
    */
    readonly create?: string;
}
export declare function serverTimeoutsToTerraform(struct?: ServerTimeouts | cdktn.IResolvable): any;
export declare function serverTimeoutsToHclTerraform(struct?: ServerTimeouts | cdktn.IResolvable): any;
export declare class ServerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ServerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server hcloud_server}
*/
export declare class Server extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_server";
    /**
    * Generates CDKTN code for importing a Server resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Server to import
    * @param importFromId The id of the existing Server that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Server to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server hcloud_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerConfig
    */
    constructor(scope: Construct, id: string, config: ServerConfig);
    private _allowDeprecatedImages?;
    get allowDeprecatedImages(): boolean | cdktn.IResolvable;
    set allowDeprecatedImages(value: boolean | cdktn.IResolvable);
    resetAllowDeprecatedImages(): void;
    get allowDeprecatedImagesInput(): boolean | cdktn.IResolvable | undefined;
    get backupWindow(): string;
    private _backups?;
    get backups(): boolean | cdktn.IResolvable;
    set backups(value: boolean | cdktn.IResolvable);
    resetBackups(): void;
    get backupsInput(): boolean | cdktn.IResolvable | undefined;
    private _datacenter?;
    get datacenter(): string;
    set datacenter(value: string);
    resetDatacenter(): void;
    get datacenterInput(): string | undefined;
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _firewallIds?;
    get firewallIds(): number[];
    set firewallIds(value: number[]);
    resetFirewallIds(): void;
    get firewallIdsInput(): number[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreRemoteFirewallIds?;
    get ignoreRemoteFirewallIds(): boolean | cdktn.IResolvable;
    set ignoreRemoteFirewallIds(value: boolean | cdktn.IResolvable);
    resetIgnoreRemoteFirewallIds(): void;
    get ignoreRemoteFirewallIdsInput(): boolean | cdktn.IResolvable | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    get ipv4Address(): string;
    get ipv6Address(): string;
    get ipv6Network(): string;
    private _iso?;
    get iso(): string;
    set iso(value: string);
    resetIso(): void;
    get isoInput(): string | undefined;
    private _keepDisk?;
    get keepDisk(): boolean | cdktn.IResolvable;
    set keepDisk(value: boolean | cdktn.IResolvable);
    resetKeepDisk(): void;
    get keepDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _placementGroupId?;
    get placementGroupId(): number;
    set placementGroupId(value: number);
    resetPlacementGroupId(): void;
    get placementGroupIdInput(): number | undefined;
    get primaryDiskSize(): number;
    private _rebuildProtection?;
    get rebuildProtection(): boolean | cdktn.IResolvable;
    set rebuildProtection(value: boolean | cdktn.IResolvable);
    resetRebuildProtection(): void;
    get rebuildProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _rescue?;
    get rescue(): string;
    set rescue(value: string);
    resetRescue(): void;
    get rescueInput(): string | undefined;
    private _serverType?;
    get serverType(): string;
    set serverType(value: string);
    get serverTypeInput(): string | undefined;
    private _shutdownBeforeDeletion?;
    get shutdownBeforeDeletion(): boolean | cdktn.IResolvable;
    set shutdownBeforeDeletion(value: boolean | cdktn.IResolvable);
    resetShutdownBeforeDeletion(): void;
    get shutdownBeforeDeletionInput(): boolean | cdktn.IResolvable | undefined;
    private _sshKeys?;
    get sshKeys(): string[];
    set sshKeys(value: string[]);
    resetSshKeys(): void;
    get sshKeysInput(): string[] | undefined;
    get status(): string;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _network;
    get network(): ServerNetworkList;
    putNetwork(value: ServerNetwork[] | cdktn.IResolvable): void;
    resetNetwork(): void;
    get networkInput(): cdktn.IResolvable | ServerNetwork[] | undefined;
    private _publicNet;
    get publicNet(): ServerPublicNetList;
    putPublicNet(value: ServerPublicNet[] | cdktn.IResolvable): void;
    resetPublicNet(): void;
    get publicNetInput(): cdktn.IResolvable | ServerPublicNet[] | undefined;
    private _timeouts;
    get timeouts(): ServerTimeoutsOutputReference;
    putTimeouts(value: ServerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ServerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
