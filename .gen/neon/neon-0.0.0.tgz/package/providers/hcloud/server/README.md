# `hcloud_server`

Refer to the Terraform Registry for docs: [`hcloud_server`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/server).
