# `hcloud_zone_record`

Refer to the Terraform Registry for docs: [`hcloud_zone_record`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/zone_record).
