# `hcloud_load_balancer_target`

Refer to the Terraform Registry for docs: [`hcloud_load_balancer_target`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_target).
