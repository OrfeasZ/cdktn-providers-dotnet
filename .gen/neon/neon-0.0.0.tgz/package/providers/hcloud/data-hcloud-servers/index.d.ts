import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudServersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/servers#id DataHcloudServers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/servers#with_selector DataHcloudServers#with_selector}
    */
    readonly withSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/servers#with_status DataHcloudServers#with_status}
    */
    readonly withStatus?: string[];
}
export interface DataHcloudServersServersNetwork {
}
export declare function dataHcloudServersServersNetworkToTerraform(struct?: DataHcloudServersServersNetwork): any;
export declare function dataHcloudServersServersNetworkToHclTerraform(struct?: DataHcloudServersServersNetwork): any;
export declare class DataHcloudServersServersNetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudServersServersNetwork | undefined;
    set internalValue(value: DataHcloudServersServersNetwork | undefined);
    get aliasIps(): string[];
    get ip(): string;
    get macAddress(): string;
    get networkId(): number;
}
export declare class DataHcloudServersServersNetworkList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudServersServersNetworkOutputReference;
}
export interface DataHcloudServersServers {
}
export declare function dataHcloudServersServersToTerraform(struct?: DataHcloudServersServers): any;
export declare function dataHcloudServersServersToHclTerraform(struct?: DataHcloudServersServers): any;
export declare class DataHcloudServersServersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudServersServers | undefined;
    set internalValue(value: DataHcloudServersServers | undefined);
    get backupWindow(): string;
    get backups(): cdktn.IResolvable;
    get datacenter(): string;
    get deleteProtection(): cdktn.IResolvable;
    get firewallIds(): number[];
    get id(): number;
    get image(): string;
    get ipv4Address(): string;
    get ipv6Address(): string;
    get ipv6Network(): string;
    get iso(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    private _network;
    get network(): DataHcloudServersServersNetworkList;
    get placementGroupId(): number;
    get primaryDiskSize(): number;
    get rebuildProtection(): cdktn.IResolvable;
    get rescue(): string;
    get serverType(): string;
    get status(): string;
}
export declare class DataHcloudServersServersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudServersServersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/servers hcloud_servers}
*/
export declare class DataHcloudServers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_servers";
    /**
    * Generates CDKTN code for importing a DataHcloudServers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudServers to import
    * @param importFromId The id of the existing DataHcloudServers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/servers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudServers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/servers hcloud_servers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudServersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudServersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _servers;
    get servers(): DataHcloudServersServersList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _withStatus?;
    get withStatus(): string[];
    set withStatus(value: string[]);
    resetWithStatus(): void;
    get withStatusInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
