# `hcloud_managed_certificate`

Refer to the Terraform Registry for docs: [`hcloud_managed_certificate`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/managed_certificate).
