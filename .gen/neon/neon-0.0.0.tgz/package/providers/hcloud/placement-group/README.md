# `hcloud_placement_group`

Refer to the Terraform Registry for docs: [`hcloud_placement_group`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/placement_group).
