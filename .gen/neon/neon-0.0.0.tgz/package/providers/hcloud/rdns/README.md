# `hcloud_rdns`

Refer to the Terraform Registry for docs: [`hcloud_rdns`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns).
