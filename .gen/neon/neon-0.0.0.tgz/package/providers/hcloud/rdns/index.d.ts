import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RdnsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#dns_ptr Rdns#dns_ptr}
    */
    readonly dnsPtr: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#floating_ip_id Rdns#floating_ip_id}
    */
    readonly floatingIpId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#id Rdns#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#ip_address Rdns#ip_address}
    */
    readonly ipAddress: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#load_balancer_id Rdns#load_balancer_id}
    */
    readonly loadBalancerId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#primary_ip_id Rdns#primary_ip_id}
    */
    readonly primaryIpId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#server_id Rdns#server_id}
    */
    readonly serverId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns hcloud_rdns}
*/
export declare class Rdns extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_rdns";
    /**
    * Generates CDKTN code for importing a Rdns resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Rdns to import
    * @param importFromId The id of the existing Rdns that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Rdns to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/rdns hcloud_rdns} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RdnsConfig
    */
    constructor(scope: Construct, id: string, config: RdnsConfig);
    private _dnsPtr?;
    get dnsPtr(): string;
    set dnsPtr(value: string);
    get dnsPtrInput(): string | undefined;
    private _floatingIpId?;
    get floatingIpId(): number;
    set floatingIpId(value: number);
    resetFloatingIpId(): void;
    get floatingIpIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    get ipAddressInput(): string | undefined;
    private _loadBalancerId?;
    get loadBalancerId(): number;
    set loadBalancerId(value: number);
    resetLoadBalancerId(): void;
    get loadBalancerIdInput(): number | undefined;
    private _primaryIpId?;
    get primaryIpId(): number;
    set primaryIpId(value: number);
    resetPrimaryIpId(): void;
    get primaryIpIdInput(): number | undefined;
    private _serverId?;
    get serverId(): number;
    set serverId(value: number);
    resetServerId(): void;
    get serverIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
