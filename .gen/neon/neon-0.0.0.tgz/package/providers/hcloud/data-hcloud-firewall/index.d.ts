import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#id DataHcloudFirewall#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#labels DataHcloudFirewall#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#most_recent DataHcloudFirewall#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#name DataHcloudFirewall#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#with_selector DataHcloudFirewall#with_selector}
    */
    readonly withSelector?: string;
    /**
    * apply_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#apply_to DataHcloudFirewall#apply_to}
    */
    readonly applyTo?: DataHcloudFirewallApplyTo[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#rule DataHcloudFirewall#rule}
    */
    readonly rule?: DataHcloudFirewallRule[] | cdktn.IResolvable;
}
export interface DataHcloudFirewallApplyTo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#label_selector DataHcloudFirewall#label_selector}
    */
    readonly labelSelector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#server DataHcloudFirewall#server}
    */
    readonly server?: number;
}
export declare function dataHcloudFirewallApplyToToTerraform(struct?: DataHcloudFirewallApplyTo | cdktn.IResolvable): any;
export declare function dataHcloudFirewallApplyToToHclTerraform(struct?: DataHcloudFirewallApplyTo | cdktn.IResolvable): any;
export declare class DataHcloudFirewallApplyToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudFirewallApplyTo | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcloudFirewallApplyTo | cdktn.IResolvable | undefined);
    private _labelSelector?;
    get labelSelector(): string;
    set labelSelector(value: string);
    resetLabelSelector(): void;
    get labelSelectorInput(): string | undefined;
    private _server?;
    get server(): number;
    set server(value: number);
    resetServer(): void;
    get serverInput(): number | undefined;
}
export declare class DataHcloudFirewallApplyToList extends cdktn.ComplexList {
    internalValue?: DataHcloudFirewallApplyTo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudFirewallApplyToOutputReference;
}
export interface DataHcloudFirewallRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#description DataHcloudFirewall#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#destination_ips DataHcloudFirewall#destination_ips}
    */
    readonly destinationIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#direction DataHcloudFirewall#direction}
    */
    readonly direction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#port DataHcloudFirewall#port}
    */
    readonly port?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#protocol DataHcloudFirewall#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#source_ips DataHcloudFirewall#source_ips}
    */
    readonly sourceIps?: string[];
}
export declare function dataHcloudFirewallRuleToTerraform(struct?: DataHcloudFirewallRule | cdktn.IResolvable): any;
export declare function dataHcloudFirewallRuleToHclTerraform(struct?: DataHcloudFirewallRule | cdktn.IResolvable): any;
export declare class DataHcloudFirewallRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudFirewallRule | cdktn.IResolvable | undefined;
    set internalValue(value: DataHcloudFirewallRule | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationIps?;
    get destinationIps(): string[];
    set destinationIps(value: string[]);
    resetDestinationIps(): void;
    get destinationIpsInput(): string[] | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _sourceIps?;
    get sourceIps(): string[];
    set sourceIps(value: string[]);
    resetSourceIps(): void;
    get sourceIpsInput(): string[] | undefined;
}
export declare class DataHcloudFirewallRuleList extends cdktn.ComplexList {
    internalValue?: DataHcloudFirewallRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudFirewallRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall hcloud_firewall}
*/
export declare class DataHcloudFirewall extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_firewall";
    /**
    * Generates CDKTN code for importing a DataHcloudFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudFirewall to import
    * @param importFromId The id of the existing DataHcloudFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/firewall hcloud_firewall} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudFirewallConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudFirewallConfig);
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _applyTo;
    get applyTo(): DataHcloudFirewallApplyToList;
    putApplyTo(value: DataHcloudFirewallApplyTo[] | cdktn.IResolvable): void;
    resetApplyTo(): void;
    get applyToInput(): cdktn.IResolvable | DataHcloudFirewallApplyTo[] | undefined;
    private _rule;
    get rule(): DataHcloudFirewallRuleList;
    putRule(value: DataHcloudFirewallRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | DataHcloudFirewallRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
