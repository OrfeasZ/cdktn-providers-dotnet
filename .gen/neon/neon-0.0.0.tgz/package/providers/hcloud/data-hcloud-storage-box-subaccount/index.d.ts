import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxSubaccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Storage Box Subaccount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount#id DataHcloudStorageBoxSubaccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Storage Box Subaccount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount#name DataHcloudStorageBoxSubaccount#name}
    */
    readonly name?: string;
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount#storage_box_id DataHcloudStorageBoxSubaccount#storage_box_id}
    */
    readonly storageBoxId: number;
    /**
    * Username of the Storage Box Subaccount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount#username DataHcloudStorageBoxSubaccount#username}
    */
    readonly username?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/hetzner#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount#with_selector DataHcloudStorageBoxSubaccount#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudStorageBoxSubaccountAccessSettings {
}
export declare function dataHcloudStorageBoxSubaccountAccessSettingsToTerraform(struct?: DataHcloudStorageBoxSubaccountAccessSettings): any;
export declare function dataHcloudStorageBoxSubaccountAccessSettingsToHclTerraform(struct?: DataHcloudStorageBoxSubaccountAccessSettings): any;
export declare class DataHcloudStorageBoxSubaccountAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxSubaccountAccessSettings | undefined;
    set internalValue(value: DataHcloudStorageBoxSubaccountAccessSettings | undefined);
    get reachableExternally(): cdktn.IResolvable;
    get readonly(): cdktn.IResolvable;
    get sambaEnabled(): cdktn.IResolvable;
    get sshEnabled(): cdktn.IResolvable;
    get webdavEnabled(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount hcloud_storage_box_subaccount}
*/
export declare class DataHcloudStorageBoxSubaccount extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box_subaccount";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBoxSubaccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBoxSubaccount to import
    * @param importFromId The id of the existing DataHcloudStorageBoxSubaccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBoxSubaccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box_subaccount hcloud_storage_box_subaccount} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxSubaccountConfig
    */
    constructor(scope: Construct, id: string, config: DataHcloudStorageBoxSubaccountConfig);
    private _accessSettings;
    get accessSettings(): DataHcloudStorageBoxSubaccountAccessSettingsOutputReference;
    get description(): string;
    get homeDirectory(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get server(): string;
    private _storageBoxId?;
    get storageBoxId(): number;
    set storageBoxId(value: number);
    get storageBoxIdInput(): number | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
