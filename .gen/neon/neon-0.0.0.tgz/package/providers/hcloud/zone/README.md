# `hcloud_zone`

Refer to the Terraform Registry for docs: [`hcloud_zone`](https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/zone).
