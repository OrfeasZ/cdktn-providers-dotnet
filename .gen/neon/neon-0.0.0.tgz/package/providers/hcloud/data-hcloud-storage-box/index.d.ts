import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudStorageBoxConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box#id DataHcloudStorageBox#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Storage Box.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box#name DataHcloudStorageBox#name}
    */
    readonly name?: string;
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/hetzner#label-selector).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box#with_selector DataHcloudStorageBox#with_selector}
    */
    readonly withSelector?: string;
}
export interface DataHcloudStorageBoxAccessSettings {
}
export declare function dataHcloudStorageBoxAccessSettingsToTerraform(struct?: DataHcloudStorageBoxAccessSettings): any;
export declare function dataHcloudStorageBoxAccessSettingsToHclTerraform(struct?: DataHcloudStorageBoxAccessSettings): any;
export declare class DataHcloudStorageBoxAccessSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxAccessSettings | undefined;
    set internalValue(value: DataHcloudStorageBoxAccessSettings | undefined);
    get reachableExternally(): cdktn.IResolvable;
    get sambaEnabled(): cdktn.IResolvable;
    get sshEnabled(): cdktn.IResolvable;
    get webdavEnabled(): cdktn.IResolvable;
    get zfsEnabled(): cdktn.IResolvable;
}
export interface DataHcloudStorageBoxSnapshotPlan {
}
export declare function dataHcloudStorageBoxSnapshotPlanToTerraform(struct?: DataHcloudStorageBoxSnapshotPlan): any;
export declare function dataHcloudStorageBoxSnapshotPlanToHclTerraform(struct?: DataHcloudStorageBoxSnapshotPlan): any;
export declare class DataHcloudStorageBoxSnapshotPlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHcloudStorageBoxSnapshotPlan | undefined;
    set internalValue(value: DataHcloudStorageBoxSnapshotPlan | undefined);
    get dayOfMonth(): number;
    get dayOfWeek(): number;
    get hour(): number;
    get maxSnapshots(): number;
    get minute(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box hcloud_storage_box}
*/
export declare class DataHcloudStorageBox extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_storage_box";
    /**
    * Generates CDKTN code for importing a DataHcloudStorageBox resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudStorageBox to import
    * @param importFromId The id of the existing DataHcloudStorageBox that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudStorageBox to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/storage_box hcloud_storage_box} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudStorageBoxConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudStorageBoxConfig);
    private _accessSettings;
    get accessSettings(): DataHcloudStorageBoxAccessSettingsOutputReference;
    get deleteProtection(): cdktn.IResolvable;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get server(): string;
    private _snapshotPlan;
    get snapshotPlan(): DataHcloudStorageBoxSnapshotPlanOutputReference;
    get storageBoxType(): string;
    get systemAttribute(): string;
    get username(): string;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
