import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudZoneRrsetsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter results using a [Label Selector](https://docs.hetzner.cloud/reference/cloud#label-selector)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrsets#with_selector DataHcloudZoneRrsets#with_selector}
    */
    readonly withSelector?: string;
    /**
    * ID or Name of the parent Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrsets#zone DataHcloudZoneRrsets#zone}
    */
    readonly zone: string;
}
export interface DataHcloudZoneRrsetsRrsetsRecords {
}
export declare function dataHcloudZoneRrsetsRrsetsRecordsToTerraform(struct?: DataHcloudZoneRrsetsRrsetsRecords): any;
export declare function dataHcloudZoneRrsetsRrsetsRecordsToHclTerraform(struct?: DataHcloudZoneRrsetsRrsetsRecords): any;
export declare class DataHcloudZoneRrsetsRrsetsRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudZoneRrsetsRrsetsRecords | undefined;
    set internalValue(value: DataHcloudZoneRrsetsRrsetsRecords | undefined);
    get comment(): string;
    get value(): string;
}
export declare class DataHcloudZoneRrsetsRrsetsRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudZoneRrsetsRrsetsRecordsOutputReference;
}
export interface DataHcloudZoneRrsetsRrsets {
    /**
    * ID or Name of the parent Zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrsets#zone DataHcloudZoneRrsets#zone}
    */
    readonly zone?: string;
}
export declare function dataHcloudZoneRrsetsRrsetsToTerraform(struct?: DataHcloudZoneRrsetsRrsets): any;
export declare function dataHcloudZoneRrsetsRrsetsToHclTerraform(struct?: DataHcloudZoneRrsetsRrsets): any;
export declare class DataHcloudZoneRrsetsRrsetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHcloudZoneRrsetsRrsets | undefined;
    set internalValue(value: DataHcloudZoneRrsetsRrsets | undefined);
    get changeProtection(): cdktn.IResolvable;
    get id(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    private _records;
    get records(): DataHcloudZoneRrsetsRrsetsRecordsList;
    get ttl(): number;
    get type(): string;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
}
export declare class DataHcloudZoneRrsetsRrsetsList extends cdktn.ComplexList {
    internalValue?: DataHcloudZoneRrsetsRrsets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHcloudZoneRrsetsRrsetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrsets hcloud_zone_rrsets}
*/
export declare class DataHcloudZoneRrsets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_zone_rrsets";
    /**
    * Generates CDKTN code for importing a DataHcloudZoneRrsets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudZoneRrsets to import
    * @param importFromId The id of the existing DataHcloudZoneRrsets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrsets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudZoneRrsets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/zone_rrsets hcloud_zone_rrsets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudZoneRrsetsConfig
    */
    constructor(scope: Construct, id: string, config: DataHcloudZoneRrsetsConfig);
    get id(): string;
    private _rrsets;
    get rrsets(): DataHcloudZoneRrsetsRrsetsList;
    private _withSelector?;
    get withSelector(): string;
    set withSelector(value: string);
    resetWithSelector(): void;
    get withSelectorInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
