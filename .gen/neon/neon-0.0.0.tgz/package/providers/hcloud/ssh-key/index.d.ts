import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SshKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * User-defined [labels](https://docs.hetzner.cloud/reference/cloud#labels) (key-value pairs) for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/ssh_key#labels SshKey#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the SSH Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/ssh_key#name SshKey#name}
    */
    readonly name: string;
    /**
    * Public key of the SSH Key pair. If this is a file, it can be read using the `file` interpolation function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/ssh_key#public_key SshKey#public_key}
    */
    readonly publicKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/ssh_key hcloud_ssh_key}
*/
export declare class SshKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_ssh_key";
    /**
    * Generates CDKTN code for importing a SshKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SshKey to import
    * @param importFromId The id of the existing SshKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/ssh_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SshKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/ssh_key hcloud_ssh_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SshKeyConfig
    */
    constructor(scope: Construct, id: string, config: SshKeyConfig);
    get fingerprint(): string;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
