import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Wether the Load Balancer public interface is enabled. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network#enable_public_interface LoadBalancerNetwork#enable_public_interface}
    */
    readonly enablePublicInterface?: boolean | cdktn.IResolvable;
    /**
    * IP to assign to the Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network#ip LoadBalancerNetwork#ip}
    */
    readonly ip?: string;
    /**
    * ID of the Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network#load_balancer_id LoadBalancerNetwork#load_balancer_id}
    */
    readonly loadBalancerId: number;
    /**
    * ID of the Network to attach the Load Balancer to. Using `subnet_id` is preferred. Required if `subnet_id` is not set. If `subnet_id` or `ip` are not set, the Load Balancer will be attached to the last subnet (ordered by `ip_range`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network#network_id LoadBalancerNetwork#network_id}
    */
    readonly networkId?: number;
    /**
    * ID of the Subnet to attach the Load Balancer to. Required if `network_id` is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network#subnet_id LoadBalancerNetwork#subnet_id}
    */
    readonly subnetId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network hcloud_load_balancer_network}
*/
export declare class LoadBalancerNetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_load_balancer_network";
    /**
    * Generates CDKTN code for importing a LoadBalancerNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancerNetwork to import
    * @param importFromId The id of the existing LoadBalancerNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancerNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/load_balancer_network hcloud_load_balancer_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerNetworkConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerNetworkConfig);
    private _enablePublicInterface?;
    get enablePublicInterface(): boolean | cdktn.IResolvable;
    set enablePublicInterface(value: boolean | cdktn.IResolvable);
    resetEnablePublicInterface(): void;
    get enablePublicInterfaceInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _loadBalancerId?;
    get loadBalancerId(): number;
    set loadBalancerId(value: number);
    get loadBalancerIdInput(): number | undefined;
    private _networkId?;
    get networkId(): number;
    set networkId(value: number);
    resetNetworkId(): void;
    get networkIdInput(): number | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
