import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PrimaryIpConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#assignee_id PrimaryIp#assignee_id}
    */
    readonly assigneeId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#assignee_type PrimaryIp#assignee_type}
    */
    readonly assigneeType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#auto_delete PrimaryIp#auto_delete}
    */
    readonly autoDelete: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#datacenter PrimaryIp#datacenter}
    */
    readonly datacenter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#delete_protection PrimaryIp#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#id PrimaryIp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#labels PrimaryIp#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#location PrimaryIp#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#name PrimaryIp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#type PrimaryIp#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip hcloud_primary_ip}
*/
export declare class PrimaryIp extends cdktn.TerraformResource {
    static readonly tfResourceType = "hcloud_primary_ip";
    /**
    * Generates CDKTN code for importing a PrimaryIp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrimaryIp to import
    * @param importFromId The id of the existing PrimaryIp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrimaryIp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/resources/primary_ip hcloud_primary_ip} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrimaryIpConfig
    */
    constructor(scope: Construct, id: string, config: PrimaryIpConfig);
    private _assigneeId?;
    get assigneeId(): number;
    set assigneeId(value: number);
    resetAssigneeId(): void;
    get assigneeIdInput(): number | undefined;
    private _assigneeType?;
    get assigneeType(): string;
    set assigneeType(value: string);
    get assigneeTypeInput(): string | undefined;
    private _autoDelete?;
    get autoDelete(): boolean | cdktn.IResolvable;
    set autoDelete(value: boolean | cdktn.IResolvable);
    get autoDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _datacenter?;
    get datacenter(): string;
    set datacenter(value: string);
    resetDatacenter(): void;
    get datacenterInput(): string | undefined;
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddress(): string;
    get ipNetwork(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
