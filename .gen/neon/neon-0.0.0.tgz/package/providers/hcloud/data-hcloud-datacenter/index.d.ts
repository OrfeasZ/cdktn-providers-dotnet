import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHcloudDatacenterConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Datacenter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/datacenter#id DataHcloudDatacenter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
    /**
    * Name of the Datacenter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/datacenter#name DataHcloudDatacenter#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/datacenter hcloud_datacenter}
*/
export declare class DataHcloudDatacenter extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "hcloud_datacenter";
    /**
    * Generates CDKTN code for importing a DataHcloudDatacenter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHcloudDatacenter to import
    * @param importFromId The id of the existing DataHcloudDatacenter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/datacenter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHcloudDatacenter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hetznercloud/hcloud/1.60.1/docs/data-sources/datacenter hcloud_datacenter} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHcloudDatacenterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataHcloudDatacenterConfig);
    get availableServerTypeIds(): number[];
    get description(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    private _location;
    get location(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get supportedServerTypeIds(): number[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
